# Global characteristic flow of the trial velocity, transport inverses and orbit weights (target T3 of the framework)

Lead note, revision 3, 2026-10-20T20:23Z (revision 2 19:55Z, backup notes/global_flow_rev2_backup.md; revision 1 19:40Z,
backup notes/global_flow_rev1_backup.md). Revision 2 incorporated the referee audit flow1 (section 11) and added section 10.
Revision 3 incorporates the referee audit flow2 of revision 2 (single model; lead check of each item, section 12): repairs
in (H5), section 6 and the constant of section 10; the axis-jet obstructions are recorded in section 12.
Notation: `A` and `D` are the saddle rates, `DV(0) = diag(-A, D)`, `A = 2 c_l - 1`, `D = 4 c_l - 1`; `S = a + b` is the total
weight exponent at the corner (revision 1 used `A` for both in places). Status labels: [P] proof given here (lead), not yet independently checked;
[F] floating-point diagnostic (certifies nothing); [C] conditional on hypotheses that still need certification.
Nothing here is used in a conclusion of FINAL_REPORT.md until the verifier and an astra audit have checked it.

## 0. Summary
- (Lemma NT) [P] Assume the parity, C^1 regularity and linear growth of `V = c_l X + U[rho]`, and the four certifiable facts
  H1-H4 below: only two equilibria in the closed quadrant, sign conditions on the axes, the saddle and source
  linearizations, and outward radial drift beyond `R_0`. Then every orbit of the open quadrant `Q` comes from `P` and goes
  to infinity: `alpha(X) = {P}` and `|phi_t X| -> inf`.
- (Lemma U, flow box) [P] Each orbit of `Q` crosses a small circle `Sigma` around `P` exactly once, which gives
  `Q = Sigma x R` as a C^1 flow box. The time an orbit spends outside fixed neighbourhoods of `0`, `P` and infinity is
  bounded uniformly over `Q`, including orbits that hug the separatrices.
- (Lemma T) [P] `R_- f = -int_0^inf e^{-t} f o phi_t dt` inverts `V.grad - 1`. If a weight `m` satisfies `V.grad log m <= beta < 1`,
  then `||R_-||_{sup/m} <= 1/(1 - beta)`. In `L^2(w dX)`, using `div V = 2 c_l`, `||R_-|| <= 1/(1 + c_l - beta/2)` whenever
  `w(phi_{-t} Y) <= e^{beta t} w(Y)`. Uniqueness holds in both classes.
- (Lemma W, orbit weights) [P] For a reference weight `w_0` with margin `T_0 = -(1 + c_l) - (1/2) V.grad log w_0`, put
  `C_kappa = sup` over orbit segments of `int 2 (T_0 + kappa) dt`. If `C_kappa < inf`, then the weight `w_0 e^psi` with
  `0 <= psi <= C_kappa` has margin `<= -kappa`, and `||R_-||_{L^2_{w_0}} <= e^{C_kappa/2}/kappa`. By Lemma U, `C_kappa` is finite
  whenever `T_0 + kappa <= 0` near `0`, near `P` and near infinity.
- (Necessary margins) [P] The pointwise margins at the three ends are explicit. Corner: `-(1 + c_l) - aA + bD`. Source:
  `-(1 + c_l) + b mu`. Infinity: `-(1 + c_l) + gamma' c_l`. At the V11 point these are -6.652, -3.505 and -0.281
  (the last uses `c_l = 1/k`).
- [F] Conic weight `w_0 = |cos theta|^{-2a} |sin theta|^{-2b} M(r)`, where `-(1/2) r M'/M = mu(r)` interpolates from `A` to
  `gamma'` near `r = 6`. At the V11 parameters, `sup T_0 = 1.23` and `sup (T_0 + b+) = 1.80`. The maximal orbit-segment costs at
  `kappa = 1/4` are 0.155 (transport) and 0.292 (transport plus the zeroth-order coupling symbol). Hence, in floating point,
  `||R_-||_{L^2_{w_0}} <~ 4.3`, a bound set by the far-field margin. The naive composite weight
  `|x|^{-2a}|y|^{-2b}(1 + r^2/R_w^2)^{A - gamma'}` has `sup T_0` between 20 and 54 for every tested `R_w`, and orbit costs of
  about 12 (`R_w = 20`).
- (Revision 2, section 10) [P] Floating point gives `V_2/y >= 0.988` on the whole quadrant. Under this single inequality
  (Y), y grows exponentially along every orbit. This gives a shorter proof of non-trapping (Lemma NT') and a box-crossing
  lemma (Lemma C) that bounds `C_kappa` by finitely many box inequalities. Floating evaluation gives
  `||R_-||_{L^2_{w_0}} <= 6.1` at `kappa = 0.2`. The far-field lower bound `||R_-|| >= 1/kappa_inf = 3.56` is now proved (section 5).
- (Coupling) [C] The zeroth-order coupling `U[h].grad rho` has principal symbol `(rho_x xi eta - rho_y xi^2)/|zeta|^2`, with
  maximum `b+ = (|grad rho| - rho_y)/2` over directions. A weight with `T + b+ <= -kappa` gives only a Garding-type
  estimate modulo a compact-type term. It does not give an explicit inverse. Section 6 lists the gaps.

## 1. Setting and hypotheses
`V = c_l X + U[rho]` on `R^2`, with `rho` the trial (or any background) even in x and odd in y. Then `V_1` is odd in x and
even in y, and `V_2` is even in x and odd in y. Hence `V_1(0, y) = 0` and `V_2(x, 0) = 0`: both axes are invariant, the four
open quadrants are invariant, and the reflections `(x, y) -> (-x, y)`, `(x, -y)` conjugate the flow. Also `div V = 2 c_l`
(`div U = 0`). Let `Q = {x > 0, y > 0}`, `P = (x_*, 0)` and `q(X) = |X - P|^2`. Standing assumptions:
- (H0) `V` is C^1 on `R^2` and `|V(X)| <= C_V (1 + |X|)`. Then the flow `phi_t` is global and C^1. Since `V_1/x` and `V_2/y`
  are continuous on `R^2` by parity and C^1, `DV` is diagonal on the axes.
- (H1) In the closed quadrant `Q-bar`, `V` vanishes only at `0` and `P`.
- (H2) `V_2(0, y) > 0` for `y > 0`. `V_1(x, 0) < 0` for `0 < x < x_*` and `V_1(x, 0) > 0` for `x > x_*`.
- (H3) `DV(0) = diag(-A, D)` with `A, D > 0`. `DV(P) = diag(A_P, mu_P)` with `A_P, mu_P > 0`. (At exact solutions
  `A_P = 2 c_l - mu_P` and `mu_P = 1`; for the trial, `mu~ - 1 = -2.25e-8`, SPEC 1.)
- (H4) `X.V(X) >= kappa_0 |X|^2` for `|X| >= R_0`, with some `kappa_0 > 0`.
- (H5) (used only for the end values at infinity) `|U(X)| <= C r^k` and `|DU(X)| <= C r^{k-1}` for `|X| >= R_0`. Then
  `U_1/x`, `U_2/y` and `X.U/r^2` are `O(r^{k-1})` uniformly in `Q`, including near the axes, for `r >= sqrt2 R_0`. Proof
  (repaired in revision 3): if `x >= r/sqrt2` divide the amplitude bound by x; otherwise `y >= r/sqrt2 >= R_0`, so the whole
  segment from `(0, y)` to `(x, y)` lies in `|X| >= R_0` and `U_1/x = int_0^1 d_x U_1(tx, y) dt` (parity: `U_1(0, y) = 0`).
  Symmetrically for `U_2/y`. A bare mean value argument can leave the controlled region. Requires `0 < k < 1`.
  Sublinear amplitude alone does not suffice: the divergence-free field `U = (-sin x F'(y), cos x F(y))` from the stream
  function `sin x F(y)`, F odd, zero near 0, `F(y) = y^k sin y` for large y, has the parity and `|U| = O(r^k)`, but
  `U_1/x -> -F'(y)` as `x -> 0`, which does not decay.
For the trial, (H0) holds: `rho` is C^{4,1}, so `U` is C^{4,nu} locally, and `U = O(r^k)` at infinity. (H1)-(H4) are
floating-point facts at present (section 7). Their certification is request N1 to the numerics lane.

## 2. Lemma NT (non-trapping) [P]
Under (H0)-(H4), for every `X in Q`: `phi_t X in Q` for all `t`, `phi_t X -> P` as `t -> -inf`, and `|phi_t X| -> inf` as
`t -> +inf`.

Proof.
(a) Basic sets.
- `Q` is invariant because the axes are unions of orbits.
- On `|X| >= R_0`, `d/dt |X|^2 = 2 X.V >= 2 kappa_0 |X|^2`. So `N_inf := {|X| > R_0}` is forward invariant,
  `|phi_t X| >= e^{kappa_0 t} |X|` there for `t >= 0`, and `B-bar_{R_0}` is backward invariant. A backward orbit starting at
  `|X| > R_0` enters `B-bar_{R_0}` within time `log(|X|/R_0)/kappa_0`.
- By (H3), `V(Y) = DV(P)(Y - P) + o(|Y - P|)`, so `V.grad q = 2 (A_P (x - x_*)^2 + mu_P y^2) + o(q) >= m_P q` on
  `{0 < q <= delta}` for some `delta > 0`, where `m_P = min(A_P, mu_P)`.
- Consequently, for `0 < d <= delta`, no orbit enters `{q < d}` in forward time from `{q >= d}`. At a first entry time one
  would have `d/dt q <= 0` at `q = d`, contradicting `V.grad q > 0`. Also, a backward orbit in `{q <= delta}` satisfies
  `q(phi_{-s} Y) <= e^{-m_P s} q(Y)`.

(b) Stable and unstable sets of 0.
- By the stable manifold theorem for the hyperbolic saddle 0, there is a neighbourhood `N` of 0 in which
  `{Y in N : phi_t Y in N for all t >= 0}` is a C^1 graph `y = w_s(x)` over `|x| < eps`.
- The points `(x, 0)`, `|x| < eps`, have forward orbits in `N` that converge to 0. This uses (H2), the oddness of `V_1` in
  x, and invariance of the axis. So they lie in that set, and by the graph property `w_s = 0`.
- Hence any orbit with `phi_t Y -> 0` lies in the x-axis. Symmetrically, using (H2) for `V_2` and backward time, any orbit
  with `phi_{-t} Y -> 0` lies in the y-axis.
- So there is no orbit in `Q` converging to 0 in either time direction, and no homoclinic orbit at 0: the two axes meet
  only at 0.

(c) No periodic orbit in `Q-bar`.
- A periodic orbit meeting an axis would lie in that axis, where the flow is one-dimensional and has no periodic orbits.
- A periodic orbit in `Q` bounds a Jordan domain contained in the convex set `Q`, and that domain contains an equilibrium,
  contradicting (H1).

(d) Forward limit.
- Suppose the forward orbit of `X in Q` never meets `N_inf`. Then it stays in the compact set `K = Q-bar cap B-bar_{R_0}`, and
  `omega(X)` is nonempty, compact, connected, invariant and contained in `K`. It contains at most the two equilibria 0 and P.
- By the Poincare-Bendixson theorem, `omega(X)` is an equilibrium, a periodic orbit, or a union of equilibria and orbits
  whose alpha- and omega-limits are equilibria in `omega(X)`.
- `P` is not in `omega(X)`, since by (a) the forward orbit avoids `{q < min(q(X), delta)}`. So `omega(X) = {0}` or
  `omega(X)` contains a homoclinic orbit at 0, both excluded by (b). Periodic orbits are excluded by (c).
- Hence the orbit meets `N_inf` and `|phi_t X| -> inf`.

(e) Backward limit.
- By (a) we may assume the backward orbit lies in `K`, so `alpha(X)` is nonempty, compact, connected, invariant and in `K`.
- If `P in alpha(X)`, the backward orbit enters `{q < delta}` at some time and then `q -> 0` by (a), so `alpha(X) = {P}`.
- Otherwise the Poincare-Bendixson alternatives for `-V` reduce, as in (d), to `alpha(X) = {0}` or a homoclinic orbit at 0.
  Both are excluded by (b), and periodic orbits by (c). QED.

## 3. Lemma U (flow box and uniform transit) [P]
Fix `0 < eps_P <= sqrt(delta)` with `eps_P < x_*/2`, and let `Sigma = {q = eps_P^2} cap Q`, parametrized by
`sigma(t) = P + eps_P (cos t, sin t)`, `0 < t < pi`. Fix `eps_0 > 0` such that the box `B_0 = [0, eps_0]^2` is disjoint from
`{q <= eps_P^2}`, with `V_1/x <= -A/2` and `V_2/y >= D/2` on `B_0` (continuity at 0). Fix `R_1 >= R_0` with
`R_1 > x_* + eps_P`, so that `Sigma` lies inside `B_{R_1}` (revision 1 omitted this; without it the hitting time below need
not exist). Put
`N_0 = [0, eps_0)^2`, `N_P = {q < eps_P^2}`, `N_inf = {|X| > R_1}` and `K' = Q-bar \ (N_0 cup N_P cup N_inf)`.

(i) Flow box.
- Every orbit of `Q` meets `Sigma` exactly once, transversally. It enters `N_P` in backward time by Lemma NT and leaves it
  in forward time. A second crossing would be a forward entry into `N_P`, excluded by 2(a).
- So `Phi : Sigma x R -> Q`, `Phi(sigma, t) = phi_t sigma`, is a bijective local C^1 diffeomorphism (transversality),
  hence a C^1 diffeomorphism, and the crossing time is C^1 on `Q`.

(ii) Uniform transit. `tau_* := sup over X in Q of |{t in R : phi_t X in K'}|` is finite.
Proof.
- For the orbit through `sigma(t)`, the time before the crossing is spent in `N_P`. Let `H(t)` be the time at which the orbit
  reaches the sphere `|X| = R_1`. The crossing is transversal (`X.V > 0`) and `N_inf` is forward invariant, so the time in
  `K'` is at most `H(t)`.
- `H` is finite (Lemma NT) and continuous on `(0, pi)` by continuous dependence and the implicit function theorem. So the
  transit time is bounded on compact subsets of `(0, pi)`.
- At `t = 0`: `sigma(0) = (x_* + eps_P, 0)` lies on the x-axis. By (H2) and (H4) its axis orbit reaches `|X| = R_1` at a
  finite time `H_0`, transversally, so `H` extends continuously to `t = 0` and is bounded near 0.
- At `t = pi`, entry: `sigma(pi) = (x_* - eps_P, 0)` flows along the x-axis and crosses the line `{x = eps_0}`
  transversally (`V_1 < 0`) at a finite time `t_1`. By continuous dependence, for `t` near `pi` the orbit of `sigma(t)` crosses
  `{x = eps_0}` at a time `<= t_1 + 1`, at a point `(eps_0, y_in)` with `0 < y_in -> 0` as `t -> pi`.
- Box passage: inside `B_0`, `x` decreases and `y` increases. So the orbit stays in `N_0` until it leaves through the top
  face, at a point `(x_out, eps_0)`, after a time `t_box >= log(eps_0/y_in)/sup_{B_0}(V_2/y)`. Since
  `x_out <= eps_0 e^{-A t_box/2}`, we get `x_out -> 0`.
- Exit: the y-axis orbit of `(0, eps_0)` reaches `|X| = R_1` at a finite time `H_1` by (H2) and (H4). By continuous
  dependence, the orbit of `(x_out, eps_0)` reaches it by time `H_1 + 1` once `x_out` is small.
- So the time in `K'` is at most `t_1 + H_1 + 2` for `t` near `pi`. Compactness of `[0, pi]` gives `tau_* < inf`. QED.

## 4. Transport inverse (Lemma T) [P]
Let `R_- f(X) = -int_0^inf e^{-t} f(phi_t X) dt`. Along orbits, `d/ds (R_- f)(phi_s X) = (R_- f)(phi_s X) + f(phi_s X)`, so
`(V.grad - 1) R_- f = f` in the sense of derivatives along the flow, and distributionally when the integral converges in
`L^1_loc`. `R_-` commutes with both reflections, so it preserves the parity class.
- (T-sup) If `m > 0` is C^1 with `V.grad log m <= beta < 1`, then `m(phi_t X) <= e^{beta t} m(X)`, so
  `|R_- f| <= ||f/m||_inf m/(1 - beta)`. If `(V.grad - 1) u = 0` with `u/m` bounded, then `u(phi_t X) = e^t u(X)` and
  `|u(X)| <= C e^{(beta - 1) t} m(X) -> 0`. So the inverse is unique in this class.
- (T-L2) Weights satisfy `0 < w < inf` a.e. and `w, 1/w in L^inf_loc(Q)`. All `L^2` statements are on the open quadrant `Q`. The axes are null sets and the parity class is determined by the
  restriction to `Q`. The weights of interest (e.g. `|x|^{-2a}` with `a >= 1/2`) are not locally integrable across the
  axes, but they are locally bounded above and below on `Q`, so `L^2_w(Q)` is contained in `L^2_loc(Q)` and distributions are
  taken on `Q`. Let `||f||_w^2 = int_Q |f|^2 w dX` and suppose `w(phi_{-t} Y) <= e^{beta t} w(Y)` for all `t >= 0` and a.e. `Y`. For
  C^1 `w` this is implied by `-V.grad log w <= beta`. The flow has Jacobian `det D phi_{-t} = e^{-2 c_l t}`, since
  `div V = 2 c_l`. So `||f o phi_t||_w^2 = int |f(Y)|^2 w(phi_{-t} Y) e^{-2 c_l t} dY <= e^{(beta - 2 c_l) t} ||f||_w^2`. Minkowski's
  inequality gives `||R_- f||_w <= ||f||_w/(1 + c_l - beta/2)` when `1 + c_l - beta/2 > 0`.
- Domain. `D_max = {u in L^2_w(Q) : V.grad u in L^2_w(Q) distributionally on Q}`. In the flow-box coordinates
  `Phi(sigma, tau)` of Lemma U the Jacobian is `j(sigma) e^{2 c_l tau}`, `j > 0`; the weak equation `V.grad u = g` becomes
  `d_tau (u o Phi) = g o Phi` in distributions (C^1 change of variables, tests pulled back with the factor `1/J`). By the
  one-dimensional characterization of weak derivatives and Fubini, `u(phi_t X) - u(X) = int_0^t g(phi_s X) ds` for a.e. X.
  The bound for `R_-` is a Bochner integral estimate for `S_t f = f o phi_t`, `||S_t||_w <= e^{(beta/2 - c_l) t}`, and
  `(V.grad - 1) R_N f = f - e^{-N} S_N f` for the truncations `R_N`, with `D_max`-closedness, gives `(V.grad - 1) R_- f = f`.
- Uniqueness in `L^2_w`: in the flow-box coordinates of Lemma U (and the axes, a null set), distributional solutions of
  `(V.grad - 1) u = 0` are `e^t g(sigma)`. So `u = e^{-t} u o phi_t`, and `||u||_w <= e^{-(1 + c_l - beta/2) t} ||u||_w -> 0`.
- Hence `V.grad - 1` is a bijection from its maximal domain in `L^2_w` onto `L^2_w`, with inverse `R_-`.
- Unweighted, `beta = 0` and the bound is `1/(1 + c_l) = 0.1521`. In terms of the pointwise margin
  `T_w := -(1 + c_l) - (1/2) V.grad log w`, the condition `T_w <= -kappa` gives `||R_-||_{L^2_w} <= 1/kappa`.
- On an L^2 weight the energy identity is the same statement: for `h in C_c^inf(Q)`,
  `Re <(V.grad - 1) h, h>_w = int T_w |h|^2 w dX`, from `int (V.grad h) h w = -(1/2) int |h|^2 (2 c_l + V.grad log w) w`.

## 5. Orbit weights (Lemma W) [P]
Let `w_0 > 0` be C^1 on `Q`, `T_0 = -(1 + c_l) - (1/2) V.grad log w_0`, `kappa > 0`, and
`C_kappa = sup over X in Q, t_1 <= t_2 of int_{t_1}^{t_2} 2 (T_0 + kappa)(phi_s X) ds`, the maximal orbit-segment cost.
If `C_kappa < inf`, put `psi(X) = sup_{s >= 0} int_{-s}^0 2 (T_0 + kappa)(phi_tau X) dtau`. Then:
- `psi` is lower semicontinuous and `0 <= psi <= C_kappa`.
- `psi(phi_t X) >= psi(X) + int_0^t 2 (T_0 + kappa)(phi_tau X) dtau` for `t >= 0`. Write the defining supremum for
  `phi_t X` with `s = s' + t` and take the supremum over `s'`.
- `w = w_0 e^psi` satisfies `log w(phi_{-t} Y) - log w(Y) <= 2 (1 + c_l - kappa) t`. The `w_0` part contributes
  `int_0^t 2 (T_0 + 1 + c_l)(phi_{-s} Y) ds`, and the `psi` part at most `-int_0^t 2 (T_0 + kappa)(phi_{-s} Y) ds`.
- Hence `||R_-||_{L^2_w} <= 1/kappa` by (T-L2) with `beta = 2 (1 + c_l - kappa)`. Since `w_0 <= w <= e^{C_kappa} w_0`,
  `||R_- f||_{w_0} <= e^{C_kappa/2} ||f||_{w_0}/kappa`.
The sup-norm analogue is the same with `V.grad log m - 1` in place of `2 T_0` and `m e^{-psi}` in place of `w_0 e^psi`.
Remarks (audit flow1). (i) For the transport inverse alone the corrected weight is not needed: the segment bound gives
`log(w_0(phi_{-t} Y)/w_0(Y)) <= C_kappa + 2 (1 + c_l - kappa) t`, hence `||e^{-t} S_t||_{w_0} <= e^{C_kappa/2} e^{-kappa t}` and the same
inverse bound. (ii) Along each orbit `p(t) = psi(phi_t X)` is locally Lipschitz with `p' >= 2 (T_0 + kappa)` a.e. (dynamic
programming), so `T_w <= -kappa` holds in the weak along-flow sense. No transverse regularity of `psi` is available; psi
cannot be used as a symbol weight in a Garding argument without further construction (smoothing across orbits).

Finiteness. If `sup_Q T_0 < inf` and `T_0 + kappa <= 0` on `(N_0 cup N_P cup N_inf) cap Q` for some admissible choice of
`eps_0`, `eps_P` and `R_1` in Lemma U, then `C_kappa <= 2 tau_* sup_Q (T_0 + kappa)^+`. The integrand is nonpositive outside
`K'`, and the time in `K'` is at most `tau_*`. Strict margins at the three ends therefore suffice, provided `T_0` extends
continuously to the axes near 0 and P. The two-sided limits at the corner exist for the weights below.

Necessary values at the ends [P], for the conic weight of section 7. The product weight `|x|^{-2a}|y|^{-2b}` has the same
values at the corner and at P, and the composite weight has the same values at all three ends:
- at the corner (`V_1/x -> -A`, `V_2/y -> D`, `mu -> S = a + b`): `T_0(0) = -(1 + c_l) - a A + b D`. (The cancellation needs
  `mu(0) = S`; with any other limit a direction-dependent term `(mu(0) - S)(-A cos^2 theta + D sin^2 theta)` remains.) This is `delta` of V11:
  -6.652 at (6.45, 3.07).
- at P (`V = 0`, `V_1/x = 0`, `V_2/y = mu_P`): `T_0(P) = -(1 + c_l) + b mu_P`, which is -3.505 at `b = 3.07`, `mu_P = 1`.
- at infinity, under (H5) (`V = c_l X + O(r^k)`, `c_l = 1/k`, quotients `O(r^{k-1})`): `T_0 -> -(1 + c_l) + gamma' c_l =
  -(1 + k - gamma')/k`, which is -0.2808 at `gamma' = 1129/1000`. This requires `gamma' < 1 + k` (T4); the
  asymptotic restriction is `kappa <= kappa_inf := (1 + k - gamma')/k = 0.2808` (strict inequality is what the simple
  finiteness criterion uses).
  Lower bound [P]. Let the weight be asymptotic to `c |cos theta|^{-2a} |sin theta|^{-2b} r^{-2 gamma'}` (true for the conic
  weight). Put `h_{R,L} = r^{gamma' - 1} chi((log r - log R)/L) eta(theta)`, `chi in C_c^inf(0, 1)`, `eta in C_c^inf(0, pi/2)`.
  Then `||h_{R,L}||^2` is `L int chi^2 ds int eta^2 |cos|^{-2a} |sin|^{-2b} dtheta` up to `1 + o(1)`, and
  `(c_l r d_r - 1 + kappa_inf) h = c_l r^{gamma' - 1} L^{-1} chi'(.) eta` because `c_l (gamma' - 1) - 1 + kappa_inf = 0`, while
  `|U.grad h| <= C r^{k-1} (|h| + |r^{gamma'-1} chi eta'| + |r^{gamma'-1} chi' eta|/L)` with `r >= R` on
  the support (amplitude tail on the fixed sector `supp eta` suffices). So `||(V.grad - 1 + kappa_inf) h||/||h|| = O(1/L) +
  O(R^{k-1})`, and if `V.grad - 1` is invertible on `L^2_{w_0}` then `||R_-|| >= 1/kappa_inf = 3.56`. (Checked by the lead; the
  audit flow1 supplied the construction.)

## 6. Coupling at zeroth order [C]
`L h = (V.grad - 1) h + U[h].grad rho + (c[h]/3) X.grad rho`. The multipliers of `U_1, U_2` are `xi eta/|zeta|^2`,
`-xi^2/|zeta|^2`, so `U[h].grad rho` has principal symbol `b(X, zeta) = (rho_x xi eta - rho_y xi^2)/|zeta|^2`. With
`zeta = (cos phi, sin phi)`, `b = (rho_x/2) sin 2 phi - (rho_y/2)(1 + cos 2 phi)`, so `max_phi b = b+ := (|grad rho| - rho_y)/2`
(exact). Frozen at P, `b` is `-g` times the symbol of `M`, which is `<= 0`. The zeroth-order energy symbol with weight `w` is
`E_w = T_w + b+`. A weight with `E_w <= -kappa` (Lemma W applied to `E_0 = T_0 + b+`) would give, by a sharp Garding inequality,
`Re <L h, h>_w <= -(kappa - eps) ||h||_w^2 + (compact-type term)`. This is NOT an inverse estimate. The gaps are:
- (i) In the corner the coupling must be applied to the double Taylor remainder (Lemma D, notes/corner_coupling.md),
  because `|x|^{-2a}|y|^{-2b}` with `a = 6.45` is not an `A_2` weight and the Riesz transforms are unbounded on it. The Taylor
  projections do not commute with `V.grad` beyond the linear part, so the margin of the remainder system is not `T_w`
  alone.
- (ii) Garding remainders are compact only locally. The explicit low-frequency and far-field control needs a separate
  argument.
- (iii) The strain functional `c[h]` is bounded on the composite weight (corner_coupling K4: `S > 2`, `gamma' < 2`), but
  `X.grad rho ~ 3 x^2 y` is not in `L^2_{a,b}` near 0 for `a >= 5/2` or `b >= 3/2`. In the full coupling the cubic terms
  cancel: `U[h] = (-c[h] x, c[h] y) + o(r)` gives `U[h].grad rho = -c[h] x^2 y + o(r^3)` and `(c[h]/3) X.grad rho = c[h] x^2 y +
  o(r^3)` (this is `J_c = 0` of corner_coupling). The strain term must be kept together with the coupling, in the jet part.
- (iv) The trial's residual is not in the corner product-weight `L^2` for `A >= 6` (verified centre obstruction, topic 50 of
  the verification record). The forcing space or the trial's centre representation must change before any of this applies
  to the actual residual.
- (v) The Garding step itself is unproved: a sharp Garding inequality needs a symbol calculus for this singular weight
  (non-integrable across the axes), finite coefficient regularity, explicit constants, axis regions and low frequencies.
  The orbit correction `psi` has no transverse regularity (section 5).
- (vi) Transport preserves the ideal of functions vanishing to prescribed orders on both axes:
  `V.grad (x^n y^m v) = x^n y^m (V.grad v + n (V_1/x) v + m (V_2/y) v)`. The Taylor projections (jets along the axes, not only
  corner coefficients) create jet-to-remainder terms; their size needs the actual block computation.
- (vii) The singular axes extend beyond the corner; a Taylor polynomial at 0 does not handle the global conic weight.
- (viii) Principal-symbol control does not exclude a kernel or a cokernel.
So the zeroth-order computation shows only that the formal interior scalar symbol has no obstruction for these weights.
It does not settle the axis models or the jet/remainder system, and the orbit costs are uncertified. It gives no
closing estimate. Note also that `b+ = (-rho_y)^+` on the axes (parity gives `rho_x = 0` there). On the x-axis `b+ = 0` iff
`g(x) = rho_y(x, 0) >= 0` (true for the trial in floating point). On the y-axis parity alone does not give `rho_y(0, y) = 0`
(rho is even in x, so `rho(0, y)` need not vanish; correction of revision 3, audit flow2). For an exact solution,
`V_1(0, y) = 0` and the equation on the y-axis reads `V_2 d_y rho(0, y) = rho(0, y)`, whose solutions are `C exp(int dy/V_2)`,
`~ C y^{1/D}` at 0; `rho = x^2 y alpha` near 0 forces `C = 0`, so `rho(0, .) = 0` and `b+ = 0` there. For the trial,
`rho~(0, .)` and hence `b+` on the y-axis are of the size of the residual on the y-axis, not zero; this must be bounded,
not assumed.

## 7. Floating diagnostics [F] (grids 1500 x 128; key numbers repeated on 3000 x 256)
| check | script / output | result |
|---|---|---|
| zeros of `V` in `Q` | code/vzeros.py, runs/vzeros_N1500.json | no interior local minimum of `|V|/r` on `r in [1e-3, 1e5]`, `|X - P| > 0.5`; global min `0.079` at `(8.57, 0.061)` (next to P) |
| (H4) | same | `min X.V/r^2` by band: `[20,100]` 3.53, `[100,1e3]` 5.18, `[1e3,1e5]` 5.52 (negative below 20) |
| `b+` | code/energy_s0.py, runs/energy_s0_N1500.json | `max b+ = 10.14` at `(r, theta) = (12.59, 1.240)`; `{b+ > 1 + c_l}` within `r in [5.5, 51.7]`, `theta in [0.785, 1.485]`; `b+ = 0` on the axes |
| unweighted energy costs | energy_s0 (forward), energy_s0_back (backward) | `max int 2 (b+ - 1 - c_l + kappa)^+ = 1.06, 1.32, 1.61, 2.27` for `kappa = 0, 0.5, 1, 2` |
| naive composite weight | code/transport_margin.py, code/orbit_costs.py | `sup T_0 = 53.8, 20.2, 46.5, 53.3` for `R_w = 1, 20, 60, 200`; costs about 12 at `R_w = 20` |
| conic weight, `R_m = 6`, `p = 4` | code/conic_weight.py, runs/conic_Rm6_p4.json | `sup T_0 = 1.225` (1.226 at 3000 x 256), `sup E_0 = 1.798` (same); maximal segment costs (`kappa = 0, 0.1, 0.2, 0.25`): `T_0`: 0.116, 0.131, 0.147, 0.155; `E_0`: 0.235, 0.257, 0.280, 0.292; all 60 backward orbits from `r = 1e5` reach P |
The conic weight is `w_0 = |cos theta|^{-2a} |sin theta|^{-2b} M(r)`, where `-(1/2) r M'/M = mu(r) = gamma' + (S - gamma')/(1 + (r/R_m)^p)`, `S = a + b`, i.e.
`M(r) = r^{-2S} (1 + (r/R_m)^p)^{2(S - gamma')/p}`. It
equals `|x|^{-2a}|y|^{-2b}` times a factor tending to 1 as `r -> 0`, and is asymptotic to the composite weight at infinity.
Margin formula, with `s = X.V/r^2`: `T_0 = -(1 + c_l) + a (V_1/x - s) + b (V_2/y - s) + mu(r) s`.
The positive parts of `T_0` sit near the x-axis segment `x in [4.9, 6]` (`T_0 <= 1.23`). The positive parts of `E_0` sit near
`(6.1, 0.39 rad)`. Both are crossed in bounded time.
Reading: with `kappa = 1/4`, `||R_-||_{L^2_{w_0}} <= e^{0.078} * 4 = 4.3` (floating), dominated by the far margin 0.281. The
radial transition of `mu` must sit at `r ~ 6`. A transition near `r ~ 3` is required along the y-axis and one near `r ~ 14`
along the outgoing x-axis. The orbit correction `psi` reconciles the two at small cost.

## 8. What certification needs (requests)
- Revision 2: the requests N1 and N1b are replaced by the shorter list at the end of section 10, which is (Y), (H2'),
  (H3), (H4), (H5), the box inequalities on `B_1`, and `T_0 <= -0.22` off `B_1`. The text below is kept for reference.
- N1 (numerics lane): certified versions of (H1)-(H4) for the trial velocity. These are: zero exclusion in
  `Q-bar cap B-bar_{R_0}` outside small disks at 0 and P, with Krawczyk or linearization inside the disks; the axis signs
  (H2); `X.V >= kappa_0 |X|^2` for `|X| >= R_0` with explicit `R_0` (about 20); and enclosures of `DV(0)` and `DV(P)`. The far
  field (H4) beyond the computed region follows from the certified tail bounds for `U`.
- N1b: certified `sup T_0` and `sup E_0` for the conic weight on `Q`, and a certified upper bound for `tau_*` (Lemma U) or,
  better, for the segment costs `C_kappa`. A crude version suffices: certified sup bounds on cells plus certified exit times
  through cell faces.
- Verifier: reproduce N1, audit Lemmas NT, U, T and W.

## 9. Lead checks
- The margin values at the three ends were checked against code/conic_weight.py on two grids: corner -6.652, far field
  -0.281 (from below).
- The value at P was checked by hand: `-(1 + c_l) + b = -3.505`.
- The formula for `b+` was checked by hand.
- The energy identity in section 4 was checked by direct integration by parts.
- Not checked: the Poincare-Bendixson case analysis by an independent reader; the continuity of `H` at the endpoint in
  Lemma U (relies on continuous dependence up to the axis, which holds since the axis points are regular points of `V`).

## 10. Addition (19:54Z): the coordinate log y is a Lyapunov function; box-crossing cost bound [P]
Floating observation [F] (code/conic_weight.py fields, 1500 x 128): `min V_2/y = 0.988` over `{x >= 0, y > 0}`, attained on
the x-axis at `x = 8.84` (just beyond `x_*`, where `d_y V_2(x, 0)` dips below 1). Band minima: `r < 1`: 20.6; `[1, 5]`: 8.96;
`[5, 8]`: 1.22; `[8, 9.5]`: 0.988; `[9.5, 20]`: 1.09; `[20, 100]`: 4.27; `[100, 1e5]`: 5.37. This suggests replacing (H1)-(H2)
by the single inequality
- (Y) `V_2(x, y) >= m_0 y` for `x >= 0`, `y > 0`, with some `m_0 > 0`,
together with
- (H2') `V_1(x, 0) < 0` for `0 < x < x_*` and `V_1(x, 0) > 0` for `x > x_*`, and (H0), (H3), (H4) as before.
(Y) implies (H1) off the x-axis and the y-axis part of (H2).

Lemma NT' [P]. Under (H0), (Y), (H2'), (H3), (H4), every `X in Q` satisfies `y(phi_t X) >= e^{m_0 t} y(X)` for `t >= 0`
(so `|phi_t X| -> inf`) and `phi_t X -> P` as `t -> -inf`.
Proof. `d/dt y = V_2 >= m_0 y` gives the forward bound and `y(phi_{-t} X) <= e^{-m_0 t} y(X) -> 0`. By (H4) the backward
orbit enters `B-bar_{R_0}` and stays there (2(a)). So `alpha(X)` is nonempty, compact, connected, invariant, and contained
in the segment `[0, R_0] x {0}`, on which the flow is `x' = w(x)`. If `alpha(X)` contains an axis point `(x, 0)` with
`x > 0`, `x != x_*`, it contains the closure of that axis orbit, whose backward limit is P by (H2'); so `P in alpha(X)`,
and by 2(a) the backward orbit then converges to P. Otherwise `alpha(X)` is contained in `{0, P}` and, being connected,
equals `{0}` or `{P}`. `alpha(X) = {0}` would put X in the unstable set of 0, which is the y-axis (2(b)). QED.
(No Poincare-Bendixson argument and no exclusion of periodic orbits is needed: y is strictly increasing.)

Lemma C (box crossing) [P]. Assume only that y is nondecreasing along orbits in `Q` (true under (Y)). Let
`B = [x_1, x_2] x [0, y_2]` with `0 < x_1 < x_2`, `y_2 > 0`, and `X in Q`. Let `I = {t : phi_t X in B}`.
- (a) If `V_1 <= -v < 0` on `B`, then `I` is empty or an interval of length `<= (x_2 - x_1)/v`.
- (b) If `V_1 >= v x > 0` on `B`, then `I` is empty or an interval of length `<= log(x_2/x_1)/v`.
Proof. Let `t_a < t_b` lie in `I`. For `t <= t_b`, `0 < y(t) <= y(t_b) <= y_2`, so on `[t_a, t_b]` a point outside B has
`x < x_1` or `x > x_2`. Let `(s_1, s_2)` be a maximal open subinterval of `[t_a, t_b]` of times outside B; its endpoints lie
in B, and by continuity either `x < x_1` on all of `(s_1, s_2)` or `x > x_2` on all of it, with `x(s_1) = x(s_2)` equal to
`x_1` or `x_2` respectively. In case (a), `x' = V_1 < 0` at the endpoints. If `x < x_1` inside, then `x` increases to
`x_1` as `t -> s_2-`, contradicting `x'(s_2) < 0`; if `x > x_2` inside, then `x` increases from `x_2` as `t -> s_1+`,
contradicting `x'(s_1) < 0`. Case (b) is symmetric (`x' > 0` at the endpoints). So `I` is an interval, on which
`x' <= -v` (resp. `(log x)' >= v`), and the length bounds follow. QED.

Corollary (cost bound) [P]. Let `B_1, ..., B_n` be boxes as in Lemma C with crossing bounds `t_i`, let
`tau_i >= sup_{B_i cap Q} (T_0 + kappa)^+`, and assume `T_0 + kappa <= 0` on `Q \ (B_1 cup ... cup B_n)`. Then along every
orbit `int 2 (T_0 + kappa)^+ dt <= 2 sum_i tau_i t_i`, hence `C_kappa <= 2 sum_i tau_i t_i` and, by Lemma W,
`||R_-||_{L^2_{w_0}} <= exp(sum_i tau_i t_i)/kappa`. The same holds with `E_0 = T_0 + b+` in place of `T_0`.
This replaces the uniform-transit constant `tau_*` of Lemma U(ii) by finitely many box inequalities, all of which are
interval-certifiable: (Y) on Q (cells plus the expansions at 0, at the axes and at infinity), the signs of `V_1` on the
boxes, upper bounds for `T_0` on the boxes, and `T_0 + kappa <= 0` on the complement (cells plus the three ends).

Floating evaluation [F] (conic weight `R_m = 6`, `p = 4`, V11 parameters; boxes enlarged by 0.05 in x and 0.1 in y around
the positive set of `T_0 + kappa`):
| kappa | box B_1 | min(-V_1) on B_1 | sup (T_0 + kappa) | t_1 | far box B_2 | bound on C_kappa | `exp(C/2)/kappa` |
|---|---|---|---|---|---|---|---|
| 0.10 | `[4.86, 6.74] x [0, 2.70]` | 14.01 | 1.325 | 0.134 | none | 0.355 | 11.9 |
| 0.20 | `[4.82, 6.77] x [0, 2.78]` | 13.93 | 1.425 | 0.140 | none | 0.399 | 6.10 |
| 0.22 | `[4.82, 6.78] x [0, 2.78]` | 13.93 | 1.445 | 0.141 | none | 0.408 | 5.57 |
| 0.25 | `[4.81, 6.80] x [0, 2.82]` | 13.16 | 1.475 | 0.151 | `[44.1, 145.4] x [0, 16.7]`, `V_1/x >= 4.96`, sup 0.011 | 0.451 | 5.01 |
At `kappa <= 0.22` the positive set of `T_0 + kappa` is a single component next to the x-axis, `x in [4.86, 6.75]`, on which
`V_1 in [-27.1, -16.2]`: the orbits there are flowing from P toward the saddle. With `E_0` in place of `T_0` (zeroth-order
coupling symbol), the box is `[4.21, 7.27] x [0, 4.90]`, `min(-V_1) = 3.27`, `sup (E_0 + 0.2) = 2.00`, giving `C <= 3.74`:
finite but much larger than the maximal segment cost 0.28, because the box bound ignores the negative parts.
Certification target (replaces N1, N1b): (Y) with a certified `m_0`, (H2'), (H3), (H4) with certified `R_0`, `kappa_0`;
`V_1 <= -13` and `T_0 <= 1.23` on `B_1 = [4.80, 6.82] x [0, 2.85]`; `T_0 <= -0.22` on `Q \ B_1`. These give
`||R_-||_{L^2_{w_0}} <= exp((1.23 + 0.2) * 2.02/13)/0.2 = 6.2441...`, so `<= 6.25` (not 6.2; corrected in revision 3) at
`kappa = 0.2`. The same certified inequalities also allow `kappa = 0.22` (`T_0 + 0.22 <= 1.45` on `B_1`, `<= 0` off it):
`exp(1.45 * 2.02/13)/0.22 = 5.694... <= 5.70`.

## 11. Audit record (referee flow1, 19:53Z, single model; lead check of each item)
- NT: correct as stated. Added precision: `W^s(0) cap Q-bar = [0, x_*) x {0}`, `W^u(0) cap Q-bar = {0} x [0, inf)`. The
  saddle step can be made elementary: in a small square `|y|` grows exponentially along any orbit with `y != 0`. Periodic
  orbits are also excluded by constant positive divergence. Lead: agreed; no change to the proof needed.
- U: proof defect. `R_1 >= R_0` does not put `Sigma` inside `B_{R_1}`, so the hitting time may not exist. Repaired
  (`R_1 > x_* + eps_P`). The audit also made explicit the finite top exit time of the box passage,
  `log(eps_0/y_in)/M_2 <= t_box <= (2/D) log(eps_0/y_in)`, and noted that compactness needs only local upper bounds.
  Lead: agreed; in revision 2 Lemma C makes the explicit constant certifiable.
- T: correct after stating `w, 1/w in L^inf_loc(Q)` and the maximal domain; the along-orbit identity is derived from the
  distributional equation in flow coordinates. Added to section 4.
- W: correct. The direct semigroup proof and the weak along-flow form of `T_w <= -kappa` were added. ψ has no transverse
  regularity, so it cannot serve as a Garding weight as it stands. Added to section 5 and gap (v).
- End values: correct, after a notation repair (S versus A). A uniform far-field hypothesis is missing; (H5) was added,
  with the audit's counterexample. The cap is `kappa <= kappa_inf`. The far lower bound is proved; the lead checked the
  computation `c_l (gamma' - 1) - 1 + kappa_inf = 0` and the norm asymptotics.
- b+: formula confirmed. `b+ = 0` on the x-axis needs `rho_y >= 0` there.
- Section 6: four further gaps added ((v)-(viii)). Gap (iii) now records the cubic cancellation.
- Route to an operator estimate (Q6): split space with corner remainder `h = x^6 y^3 v`. The norm of `v` then carries the
  locally `A_2` product weight `x^{-0.9} y^{-0.14}`. Next come kernel estimates for the combined projected coupling
  (principal-value part by local singular-integral bounds; separated, Taylor-correction and tail parts by Schur/Hardy
  bounds), and finally an estimate `Re <L_rr h, h> <= -(kappa - eta) ||h||^2 + C ||Pi h||^2` with explicit constants and a
  controlled low-mode operator. A Neumann series `||R_- K|| < 1` is not available. Recorded as the plan, not a result.
- Not covered by flow1: section 10 (written after the question). Audit request flow2.

## 12. Audit record (referee flow2 of revision 2, collected 20:22Z, single model; lead check of each item)
- NT' (Q1): correct. The audit adds two precisions, both checked: `x_* < R_0` is forced by (H4) at the equilibrium P; and
  `alpha(X) = {0}` is excluded elementarily (near 0, `V_1/x <= -A/2`, so a backward orbit with `x > 0` cannot tend to 0).
  Only the backward axis orbit of a limit point is used. No change to the proof beyond these remarks.
- Lemma C and the Corollary (Q2): correct, including boxes touching the x-axis (an orbit of Q never reaches `y = 0` in
  finite time; nondecreasing y suffices). The gap step should be stated with one-sided difference quotients at the gap
  endpoints rather than "x increases throughout the gap"; the lead agrees (the endpoint form is what the proof uses).
  The same cost statement holds for `E_0`; it is not an inverse estimate for the coupled operator.
  Constant: `exp(1.43 * 2.02/13)/0.2 = 6.2441`, so 6.25 is the correct upward rounding; `kappa = 0.22` gives 5.70.
  Lead recomputation: `t_1 = 2.02/13 = 0.15538`, `exp(0.22220) = 1.24882`, `exp(0.22531) = 1.25272`. Section 10 corrected.
- (H5) and the far lower bound (Q3): correct with a repair of the quotient bound (case split, now in section 1) and the
  remark that `kappa_inf = (1 + k - gamma')/k` uses the exact identity `c_l = 1/k` (otherwise use `1 + c_l - gamma' c_l`).
  The norm asymptotics of the test family carry the constant c of the weight's angular profile; it cancels in the ratio.
  The lead rechecked `c_l (gamma' - 1) - 1 + kappa_inf = 0` and that only sectorial amplitude bounds are used.
- Certification design (Q4): adopted as the instruction set for the numerics lane (NOTES_FOR_TEAM 20:3xZ):
  the margin in the form `T_0 = -(1 + c_l) + a q_1 + b q_2 + (mu(r) - S) s`, `q_1 = V_1/x`, `q_2 = V_2/y`,
  `s = X.V/r^2` (avoids subtracting separately inflated enclosures); derivative-average forms of `q_1, q_2` on cells
  touching an axis; a 1D certified root of `w` with `w' > 0` on its isolating interval; the consistency identity
  `w'(P) + mu_P = 2 c_l`; mu_P must not be replaced by 1 for the trial (`F(rho~)_y(P) = (mu_P - 1) rho~_y(P)`); the exterior
  needs density-tail control through the Green representation, not only residual tails.
- Section 6 (b+ on the y-axis): corrected, see section 6.
- Split space and jet inverse (Q5): the transport bound on the corner remainder `x^6 y^3 v` does NOT extend to an inverse on
  the axis jets automatically. Statements (lead-checked; elementary):
  (J1) Conic cutoffs `C_x = chi(x/lambda(y))`, `C_y = chi(y/lambda(x))` with `lambda = l` near 0 and `|s|` far out give an
  extension `EJ = C_x sum_{j=0,2,4} x^j a_j(y) + C_y y b(x) - C_0 y sum_j x^j c_j` whose two Taylor projections commute
  and which commutes with `c_l X.grad` at large radius (fixed-width strips do not; they leave dilation errors).
  (J2) Axis jet equations: `q a_0' - a_0 = f_0`, `q a_2' + (2 p_1 - 1) a_2 + q_2 a_0' = f_2`,
  `q a_4' + (4 p_1 - 1) a_4 + 2 p_3 a_2 + q_2 a_2' + q_4 a_0' = f_4` on the y-axis and `w b' + (mu - 1) b = f_y` on the
  x-axis, `mu = d_y V_2(x, 0) = 2 c_l - w'`.
  (J3) Obstruction at P: a regular solution satisfies `(mu_P - 1) b(P) = f_y(P)` (evaluate at `w(P) = 0`). At an exact
  solution `mu_P = 1`, so the x-axis transport jet operator is not onto any forcing space containing `f_y(P) != 0`; for the
  trial (`mu_P - 1 = -2.25e-8`) any inverse with bounded evaluation at P has norm `>= 1/|mu_P - 1| = 4.4e7`. In the full
  linearization the P-row also contains the nonlocal terms `d_y U_2[h](P) g(P) + U_1[h](P) rho_xy(P)` and the strain term,
  so the defect must be absorbed by the coupling (this is the P-disc problem of the framework), not by transport.
  (J4) Obstruction at the corner: for perturbations divisible by `x^2 y` the cubic coefficient is multiplied by
  `-2A + D - 1 = 0`; the cubic forcing coefficient must vanish and the cubic solution coefficient is a normalization.
  (J5) Near P a homogeneous x-axis solution behaves like `|x - x_*|^{-(mu_P - 1)/A_P}`; for the trial this mode is
  continuous but not C^1, and a normalization at 0 does not remove it; the Taylor denominators at P are
  `(mu_P - 1) + n A_P`.
  (J6) Conditional block bound: if the compatible jet realization has inverse bound `M_J`, the remainder inverse `M_r`, and
  `||(A E - E A_J) J||_{w_0} <= b_* ||J||`, then `||A^{-1}|| <= max(M_r, (1 + M_r b_*) M_J)` in the sum norm. Neither `M_J`
  nor `b_*` is available; `C^{4,nu}` velocity regularity does not give the sixth-order normal remainders that `b_*` needs.
  (J7) With `mu_P = 1` and `H` the homogeneous solution with `H/x^2 -> 1` at 0, the normalized x-axis inverse is
  `b = H int_0^x f_y/(w H)` for forcing with `f_y = O(x^4)` at 0 and `f_y(P) = 0`; its weighted bound is an explicit kernel
  integral. This is a usable building block for the x-axis jet once the P-row is handled by the coupling.
Lead assessment: the transport part of target T3 (sections 2-5, 10) is now audited twice; its numerical inputs are the
certification target N1' with the constant 6.25. The coupled jet system ((J3), (J4) and the commutator `b_*`) is the next
analytic obstacle; it is the same obstacle as the P-disc problem and the centre obstruction already recorded, seen from the
transport side.
