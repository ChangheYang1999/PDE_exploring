# The cubic axis coefficient B_3 and the P_infty question

Lead note, revision 1, 2026-10-20T20:35Z. Sources: referee answer pinf1 (single model; standalone derivation with
algebra checks, no interval certificate), the lead's floating diagnostic code/b3_axis.py (runs/b3_axis.json, run
20:25:59Z to 20:28Z), the prompt's description of the earlier estimator. Nothing here enters FINAL_REPORT.md as a
result until the verifier has checked it. Status labels: [P] proof in the cited derivation, checked by the lead for
structure; [R] counterexample; [F] floating-point evidence only.

## 1. Axis equations and exact identities
Notation: `L = x_*`, `c = c_l`, `A = 2c - 1`, `D = 4c - 1`, `p = (3D - 1)/A = 6 + 2/A` (6.19703 at the trial),
`G_1 = rho_y(x, 0)`, `G_3 = rho_yyy(x, 0)/6`, `w = W_1(x, 0)`, `w_2 = W_1,yy(x, 0)/2`, `v_1 = W_2,y(x, 0)`,
`v_3 = W_2,yyy(x, 0)/6`.
(A1) [P] Incompressibility: `w' + v_1 = 2c`, `w_2' + 3 v_3 = 0`. Curl (`-Lap psi = rho_x`): `2 w_2 = G_1' - w''`.
  These hold for every density and its own canonical velocity, exact solution or not.
(A2) [P] Equations: `w G_1' + (v_1 - 1) G_1 = 0` and `w G_3' + (3 v_1 - 1) G_3 = f`, `f = -(w_2 G_1' + v_3 G_1)`.
  The cubic equation follows in distributions from `div(W rho) = (2c + 1) rho` and cubic Peano traces; `rho, W` in
  `C^3` near the open segment and near P suffice. [R] `C^{2,alpha}` does not suffice (`y|y|^{1+alpha}` has no cubic
  coefficient; a localized `y^3 |x - L|^{-lambda} chi(y/|x - L|)` is `C^{2,alpha}` at P for `alpha <= 1 - lambda`
  with divergent cubic trace). These are regularity counterexamples, not IPM solutions.
(A3) [P] At P, if `G_1(L) != 0`: `v_1(L) = 1`, hence `A_P := w'(L) = 2c - 1 = A`, and with `c = (1 - w'(0))/2`
  this is the constraint `w'(L) = -w'(0)` on the axis velocity trace. Trial (floating): `A_P - A = 2.3e-8`,
  `v_1(L) - 1 = -2.25e-8`.
(A4) [P] Normalized solutions: `G_1 = x^2 exp int_0^x ((1 - v_1)/w - 2/t) dt`; with `q = (3 v_1 - 1)/w`,
  `H(x) = x^{-p} exp(+int_0^x (q + p/t) dt)` (so `H'/H = q`; sign corrected 2026-10-20T21:23Z after the verifier's V16
  check, rev 1 printed a minus), `H ~ C_P (L - x)^{2/A_P}` at P; the P-bounded solution is
  `G_3 = H^{-1} int_L^x H f/w`, with `G_3(L) = f(L)/2`.
(A5) [P] Consequence of (A1), (A3), (A4): for an exact solution, the trace w alone determines c, A, p, v_1, G_1,
  w_2, v_3, f and hence B_3 below (velocity-only reconstruction).

## 2. The coefficient and the smoothness criterion
(B1) [P] With `Q = x e^{-E} f / w` (E as in pinf1, so `x^{-p-1} Q = H f / w`), `Q = q_2 x^2 + q_4 x^4 + q_6 x^6 + R`,
  `|R| <= K_Q x^8` near 0: `G_3 = e^{E} sum_j q_j x^j/(j - p) + B_3 x^p e^{E} + O(x^8)`,
  `B_3 = -FP int_0^L H f / w`. Dimensionless: `beta_3 = L^{p-2} B_3`.
(B2) [P] If `a in C^{6,alpha}` near 0 with `alpha > p - 6` (in particular `a in C^7`), then `B_3 = 0`.
  [R] `C^6` does not suffice: `a_* = |x|^{p-2} y^2 chi(y/x)` is `C^{6,p-6}` and gives `G_3 = |x|^p`.
(B3) [P] B_3 = 0 is necessary for P_infty (with global `C^{3,beta}` and the axis hypotheses of (A2)); it is not
  necessary for P_2, and P_2 does not supply the cubic traces. A nonzero B_3 is not a P_2 obstruction.
(B4) [P] Cutoff: `|B_3 - Phi_delta| <= K_Q delta^{8-p}/(8 - p)`, `Phi_delta = -int_delta^L x^{-p-1} Q - sum_j q_j
  delta^{j-p}/(j - p)`. Physical multipliers of K_Q: 0.1590 (delta = 0.5), 0.5546 (delta = 1).
(B5) [P] Continuity in a pullback metric `d_*` (Taylor data of Q, p, and `int x^{-p_+-1} |Delta R|`) with explicit
  Lipschitz constant `M_*`; [R] no continuity in low norms: `Q_eps = eps^p phi(x/eps)` has vanishing Taylor
  coefficients and `C^j` norms (j <= 6) tending to 0 while its contribution `int t^{-p-1} phi` is fixed. So B_3 needs
  uniform corner control (order about 8 in Q, about 9 to 11 in the velocity trace) for the class considered.
(B6) [P] Conditional exclusion: with a reference satisfying `|Phi_{delta,0}| >= b_delta`, a map bound
  `d_delta <= C_N ||rho - rho_0||_N` on the ball, the axis geometry on the ball and a corner bound K_Q for the class,
  `M_delta C_N r + K_Q delta^{8-p_+}/(8 - p_+) < b_delta` excludes every exact smooth-centre profile of that class in
  the ball. None of the inputs is available; this is a criterion, not an exclusion.

## 3. The present trial [F unless stated]
(C1) The modal trial's inner representation is `a_m = delta_{m0} + sum_{j<=7} D_{mj} (r/rmin)^{2j} + (r/rmin)^{b_i}
  (polynomial in log(r/rmin))`, `b_i` about 50, so on the axis G_3 is an even polynomial plus `x^{b_i}`-type terms:
  it has no `x^p` term (the original X3 inserted one, coefficient about 0.046 in natural units). Hence, exactly for
  this representation, `FP lim e^{Lambda} G_3 = 0` and `B_3[f + E_3] = 0`, i.e.
  `B_3[f] = FP int_0^L H E_3 / w` with the trial's cubic defect `E_3 = w G_3' + (3 v_1 - 1) G_3 - f`.
  Code check: `-H G_3 (x) = int_x^L H (f + E_3)/w` agrees to relative 1e-12 at x = 0.1 .. 6.
(C2) Sizes and smoothness near the centre (runs/b3_axis.json table, x from 0.001 to 0.03): `f/x^2 = -0.504383`,
  `G_1/x^2 - 1 = -0.01145 x^2`, `w/x + A = 0.2325 x^2` (so `u_3 = 0.2325`), `v_1 - D = -0.697 x^2`, all smooth to the
  printed digits; `E_1` is below 2e-15. The trial's cubic defect is not small relative to f at the centre:
  `E_3/f = -2.5e-5, -1.6e-5, -2.9e-6, -2.6e-7, 1.7e-6` at x = 0.0010, 0.0015, 0.0024, 0.0036, 0.0056 (inside
  `r < rmin`), `-4.4e-5` at x = 0.0085, about `1e-6` up to x = 0.05, `1e-2` in the middle. It comes from the trial's
  G_3 (a sum over 260 angular modes with weights up to `m^3/6`, consistent with the verified centre obstruction).
  `int_{0.05}^L H f / w = 3418.5`, `int_{0.05}^L H E_3 / w = 0.0077`, P end 1e-5; the diagnostic's centre Taylor fits
  on `(0, rmin]` are unreliable beyond second order (amplification `rmin^{-2i}`).
(C2') Conditioning of B_3 [elementary]: a relative perturbation eta of f supported in `[x, 2x]` (x small) changes
  `beta_3` by about `eta |f_2| (L/x)^{p-2} (1 - 2^{2-p})/(A (p - 2))`, i.e. about `0.011 eta (L/x)^{4.197}`; at
  `x = 1e-3 L` this is `4e10 eta`. So `beta_3` to 0.01 needs centre data with relative structure below `2e-13` at
  that scale. The trial's `E_3/f ~ 1e-5` at `x ~ 1e-4 L .. 1e-3 L` makes every B_3 estimator built on its data
  uncertain by many orders of magnitude more than the values 0.046 and 0.30 discussed in the problem statement.
(C3) Lead assessment: the trial's B_3 is a weighted integral of its own centre defects; it says nothing about a
  nearby exact solution. This is consistent with the verified centre obstruction (the trial's factor is not C^2 at 0).
  The earlier estimator (0.299 to 0.303) and the inserted coefficient (0.046) are different reference constructions;
  neither carries an error budget.

## 4. What a scoped P_infty exclusion would need
- A reference axis trace `w_0` on `[0, L_0]` satisfying `w_0'(L_0) = -w_0'(0)` exactly (A3), with simple zeros and
  `w_0 < 0` between them, centre-regular (odd Taylor series to order at least 9 with remainder bound).
- A validated 1D evaluation of the velocity-only `B_3[w_0]` (ODE quadratures; feasible with interval arithmetic).
- A Lipschitz bound of `B_3[w]` on the constraint set in a stated trace topology (centre jets to order 9 to 11 plus a
  weighted norm on (0, L) after integrations by parts, endpoint subtraction at P).
- Then: no exact `P_infty` profile (global `C^{3,beta}`) has axis trace within r of `w_0` in that topology. Whether the
  ball contains a meaningful numerical-uncertainty set must be argued separately; the trial's own trace has structure
  at knot scale (0.006 to 0.016) and is not centre-regular, so this is doubtful for high-order trace norms.
- Open first step (floating): the velocity-only B_3 of the trial and its stability under centre regularization.
