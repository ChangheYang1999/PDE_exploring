# Retained report excerpt

Line numbers refer to the frozen local sources/NUM_REPORT.md.

114:   certified ceilings of 7.2, 7.3, 7.3b, 7.3c, 7.11 are now directed roundings regenerated from the saved per-cell data (src/report_tables.py,
115:   src/xnorm_cert.py in Arb); the changes are in the last printed digit (e.g. middle sup W/m 2.5964e-4 -> 2.5965e-4, (1+u)^{1/2} form 3.8070e-4 ->
116:   3.8071e-4, outer (1+u)^{1/2} form 7.3680e-3 -> 7.3681e-3, inner tail 2.138e-6 -> 2.139e-6) except two corrections of substance: the whole-plane
117:   (1+u)^{1/2} multiplier value is the outer region's 7.3681e-3 (not the middle region's 3.8071e-4), and the R2 tails are now bounded by explicit
118:   integrals (src/r2_tails.py; 6.5e-16 and 3.8e-20 in norm^2) instead of a 'sup times measure' remark that was invalid for the outer tail. The
119:   notation block 7.0, the stored-trial scope of every floating K quantity, the finite-region domain of the X-norm ceilings (tails: verifier topic
120:   178), stale status lines, the N7 and v3/v4 comparison wording, and the section-8 commands and current hashes were added or corrected. RIGOROUS
487: Outer and inner regions and tails: table below (chain4, 22:54Z). R2 (whole plane): ( int_{R^2} |eps~/m|^2 dX/(1+u^2) )^{1/2} <= 6.2899e-4
488: (6.29e-4). Finite regions: the outward sum of the L2 pieces, 4.9727e-9 (middle) + 3.9065e-7 (outer) + 3.4826e-16 (inner) <= 3.9562e-7, i.e. as norms
489: outer <= 6.2502e-4, middle <= 7.0518e-5, inner <= 1.8662e-8. Tails (src/r2_tails.py, runs/r2_tails.json; Arb at 200 bits): on r >= r_T,out the
490: certificate gives W (1+u)^delta / m <= C_out = 1.75412e-6 for every r there (delta = 1/2 - k, runs/cert_tail.json), and sup_theta |eps~| <= W, so the
491: outer tail contributes at most 2 pi C_out^2 int_{r_T,out}^inf (1+u)^{-2 delta} r dr/(1+u^2) <= pi C_out^2 L^2 U_T^{-2 delta} / delta = 6.504e-16
492: (U_T = r_T,out / L = 1.0774e10; u/(1+u^2) <= 1/u and (1+u)^{-2 delta} <= u^{-2 delta}) to the squared norm; on r <= r_T,in, W/m <= C_in =
493: 2.13842e-6 gives at most pi C_in^2 r_T,in^2 = 3.819e-20. (The weighted measure dX/(1+u^2) has infinite mass outside every disc, so 'sup times
494: measure' is not an argument for the outer tail; the bound above uses the decay of the weighted tail majorant. The earlier text said 'negligible'
495: without this computation; corrected 2026-10-22, shift 7.) R4 (origin): sup W/r^5 <= 1.2562e-3 on the inner cells (at r = 5.155e-5) and <= 1.797
