# Packets, radial thresholds, and the IPM specification

This is an informal mathematical referee report, with complete proofs of the
claims identified as proved below. It is not a certificate of the numerical
profile X3. The input documents are `PROMPT.md` and `SPEC.md`, version 1, in
`analysis`.

## 1. Hypotheses, conventions, and scope

Write \(z=(s,y)=(x-x_*,y)\), \(A=2c_l-1\), and \(d=1+g_*\).
The local conclusions assume an actual equilibrium
\[
V(P)=0,\qquad DV(P)=\operatorname{diag}(A,1),\qquad
\nabla\widetilde\rho(P)=(0,g_*).
\]
The coefficients must possess the derivatives used in the stated norms.
For the pseudodifferential discussion assume smooth coefficients locally.
None of these assumptions is certified by rounded numerical measurements.
In particular, the identities for the eigenvalues hold for an exact profile
with \(\rho_y(P)\ne0\), but need not hold exactly for a numerical trial.

The operator is
\[
Lh=V\cdot\nabla h-h+U[h]\cdot\nabla\widetilde\rho+
\frac{c[h]}3G,\quad
G=X\cdot\nabla\widetilde\rho,\quad c[h]=\psi[h]_{xy}(0).
\]
The whole-plane velocity has Fourier symbols
\[
\widehat U_1=\frac{\xi\eta}{\xi^2+\eta^2}\widehat h,\qquad
\widehat U_2=-\frac{\xi^2}{\xi^2+\eta^2}\widehat h.
\]
Indeed \(\widehat\psi=i\xi|\zeta|^{-2}\widehat h\), and applying
\((-\partial_y,\partial_x)\) gives these signs.

Local norms below are taken on a fixed disc about P, not on a disc whose
radius is part of the norm. Global conclusions require compatible weighted
norms away from P and the stated sublinear far-field derivative bounds.
The rank-one term must either be retained as an allowed residual direction
or measured with a weight admitting \(G\).

With the supplied rounded inputs, exact rational arithmetic gives
\[
\begin{split}
A&=10.1507252,\quad 4c_l-1=21.3014504,\quad d=30.75,\\
d/A&=3.029340209111\ldots,\\
s_*&=\frac{2d+A+1}{2A}
=\frac{1+g_*+c_l}{A}=3.578597773487\ldots,\\
3c_l-c-1&=-2\cdot10^{-8}.
\end{split}
\]
The last discrepancy is consistent with rounding; it is not evidence for
an exact normalization defect of X3.

## 2. What the model cusp proves

Let \(F\in C_c^\infty(\mathbb R)\) be nonzero and define, for \(y\ne0\),
\[
H(s,y)=\operatorname{sgn}(y)|y|^dF(s/|y|^A).
\]
Extend by zero on \(y=0\) and cut off smoothly at a fixed small outer value
of \(|y|\). Put \(T=A s\partial_s+y\partial_y\).
Away from the outer cutoff,
\[
(T-d)H=0.
\]
This is an exact identity for \(T-d\), not for \(L_P=T-1-g_*M\).

On the support of H,
\[
|\partial_s^j\partial_y^\ell H|
\le C_{j,\ell}|y|^{d-Aj-\ell}.
\]
Let \(\beta=d/A\), which is nonintegral. These estimates show
\(H\in C^\beta\), with the usual large Hölder space convention.
For completeness, the most singular derivative of order \(m=\lfloor\beta\rfloor\)
has amplitude \(y^{A(\beta-m)}\) and transverse width \(y^A\).
At a fixed y its Hölder quotient of order \(\beta-m\) is bounded.
For two y-values at comparable scales, split their distance into
distances at least \(c y^A\), controlled by the amplitude, and smaller
distances, controlled by the displayed derivative estimates and
\(|y-y'|\le C y^A\). Noncomparable scales are controlled by the amplitude.
Mixed derivatives have smaller singularity. This proves the endpoint bound.
Conversely, take two distinct fixed values of \(s/y^A\) where
\(F^{(m)}\) differs. Their Hölder quotient of order \(\alpha\) is a nonzero
constant times \(y^{d-A(m+\alpha)}\). It diverges when \(m+\alpha>\beta\).
The critical cusp is not in the corresponding little Hölder space.

The Sobolev threshold can be checked without an isotropic scaling guess.
Partial Fourier transform in s gives, for \(\sigma\ge0\),
\[
\|\,|D_s|^\sigma H\|_2^2
=C_{F,\sigma}\int_0^\epsilon y^{2d+A-2A\sigma}\,dy
+\text{a finite outer contribution}.
\]
Here \(C_{F,\sigma}>0\). Thus the integral is finite exactly when
\(\sigma<s_*\). This proves necessity and endpoint failure.
For sufficiency below this threshold, four ordinary y-derivatives are
square integrable, since \(2(d-4)+A>-1\).
The inequality
\((1+\xi^2+\eta^2)^\sigma\le C_\sigma
(1+|\xi|^{2\sigma}+|\eta|^{2\sigma})\),
then proves \(H\in H^\sigma\) for \(0\le\sigma<s_*\).
Negative orders follow from \(H\in L^2\).

The statement that spatial support in \(|s|\ll|y|\) alone implies \(M\sim1\)
is false: multiply such a packet by oscillations in y whose frequency is
much larger than the inverse s-width. One needs frequency localization or
a controlled scaled profile.

## 3. An explicit singular sequence for the true operator

Choose nonzero \(f\in C_c^\infty((-1,1))\), an integer \(N\ge2\), and
\(\chi\in C_c^\infty((1,2))\), and set \(F=f^{(N)}\).
For \(\epsilon\downarrow0\) let
\[
h_\epsilon(P+(s,y))
=\operatorname{sgn}(y)|y|^d\chi(|y|/\epsilon)
F(s/|y|^A).
\tag{1}
\]
This is smooth and odd in y, supported where
\(\epsilon<|y|<2\epsilon\), \(|s|\le (2\epsilon)^A\).
Write
\[
\delta=\epsilon^A,\quad \kappa=\delta/\epsilon,\quad
h_\epsilon=\epsilon^d Q(s/\delta,y/\epsilon).
\]
The fixed smooth compactly supported Q is an Nth derivative in its first
variable. Consequently \(\widehat Q(u,v)=u^N\widehat R(u,v)\) up to a
constant phase, for a Schwartz function \(\widehat R\).

For nonintegral \(r>0\), and for Sobolev orders \(r\ge0\),
\[
\|h_\epsilon\|_{C^r}\asymp\epsilon^d\delta^{-r},\qquad
\|h_\epsilon\|_{H^r}\asymp
\epsilon^d(\delta\epsilon)^{1/2}\delta^{-r}.
\tag{2}
\]
For Hölder norms the lower bound follows from differences of derivatives
in s at a fixed y; the upper bound follows by differentiation and Hölder
interpolation. For Sobolev norms use Fourier scaling and integrate over a
fixed region where \(u\ne0\) and \(\widehat Q\ne0\).

The full error decomposition, on a fixed disc D, is
\[
Lh_\epsilon=(T-d)h_\epsilon+
g_*(1-M)h_\epsilon+
(V-(As,y))\cdot\nabla h_\epsilon+
(\nabla\widetilde\rho-(0,g_*))\cdot U[h_\epsilon]
+\frac{c[h_\epsilon]}3G.
\tag{3}
\]
The terms obey the following estimates. Constants depend on f, chi, the
fixed disc, coefficient bounds and the orders, never on epsilon.
For \(t\ge0\), the first five bounds have the additional common
factor \((\delta\epsilon)^{1/2}\) when interpreted as Sobolev bounds.
The final, rank-one bound has no such factor.

| Term | \(C^t(D)\) upper bound |
| --- | --- |
| \((T-d)h_\epsilon\) | \(C\epsilon^d\delta^{-t}\) |
| \((1-M)h_\epsilon\) | \(C\epsilon^d\delta^{-t}\kappa^2\) |
| \(R_1\partial_s h_\epsilon\), \(R=V-(As,y)\) | \(C\epsilon^d\delta^{-t}\epsilon^2/\delta\) |
| \(R_2\partial_y h_\epsilon\) | \(C\epsilon^d\delta^{-t}\epsilon\) |
| \((\nabla\widetilde\rho-(0,g_*))\cdot U[h_\epsilon]\) | \(C\epsilon^d\delta^{-t}\) |
| \(c[h_\epsilon]G/3\) | \(C_D\epsilon^d\delta\epsilon\) |

Use \(t=m+\alpha\), \(0<\alpha<1\), in the Hölder column. At integer t
the indicated differentiable sup norm estimate also holds for these packets.

Here are proofs of the bounds. The first term is exactly
\[
\operatorname{sgn}(y)|y|^d(|y|/\epsilon)\chi'(|y|/\epsilon)
F(s/|y|^A);
\]
the homogeneous transport does not make this cutoff error small relative
to the same-order norm. For the second term the scaled multiplier is
\[
\frac{\kappa^2v^2}{u^2+\kappa^2v^2}.
\]
Its product with \(\widehat Q\) is bounded by
\(\kappa^2 |v|^2 |u|^{N-2}|\widehat R|\).
Weighted Fourier L1 estimates give all the displayed Hölder bounds
(use \(|e^{ia}-e^{ib}|\le C_\alpha|a-b|^\alpha\)); weighted L2 estimates
give the Sobolev bounds. The same argument with the bounded velocity
symbols, without the factor \(\kappa^2\), bounds \(U[h_\epsilon]\).
Multiplication by fixed smooth coefficients on D proves the fifth bound.
For the third and fourth bounds, Taylor's theorem gives
\(R=O(|z|^2)\). After composition with \((\delta u,\epsilon v)\),
\(R/\epsilon^2\) and all its required derivatives are uniformly bounded
on the fixed support of Q. Differentiation supplies respectively
\(\delta^{-1}\) and \(\epsilon^{-1}\).

The nonlocal estimates are global, not a zero-extension fiction. If E is
a fixed compact set at positive distance from P, the velocity kernel K
is smooth on \(E-\operatorname{supp}h_\epsilon\), with
\(|\partial^jK(Z)|\le C_j|Z|^{-2-j}\). Hence
\[
\|U[h_\epsilon]\|_{C^j(E)}
\le C_{E,j}\epsilon^d\delta\epsilon,\qquad
|c[h_\epsilon]|\le C\epsilon^d\delta\epsilon.
\tag{4}
\]
The latter estimate uses the derivative of the velocity kernel at the
origin, which is separated from P. At infinity,
\[
|\partial^j U[h_\epsilon](X)|
\le C_j\epsilon^d\delta\epsilon\,|X|^{-2-j}.
\]
If \(\partial^j\nabla\widetilde\rho=O(r^{k-1-j})\), the coupling tail
and its scaled derivatives are \(O(\epsilon^d\delta\epsilon\,r^{k-3})\).
This belongs to the proposed decaying residual weight for
\(0<\delta_{\rm far}<1-k\). The G term is measured in its explicitly
adjoined one-dimensional space.

A nonzero function even in x cannot be supported only near positive P.
For the admissible symmetry class replace (1) by
\(h_\epsilon(x,y)+h_\epsilon(-x,y)\).
Its support shrinks to \(\{P,-P\}\). Near either point the contribution
of the other packet is covered by (4). It vanishes near the origin,
so \(h=x^2yb\), \(b(0)=0\), there.
Near the origin its velocity is
\((-c[h]x,c[h]y)+O(r^3)\); the cubic contribution
\(-c[h]x^2y\) from the coupling cancels \(c[h]x^2y\) from the rank-one term.
The remaining local residual is \(O(\epsilon^d\delta\epsilon\,r^5)\)
when the background has a smooth even center factor. Required weighted
derivative bounds follow by Taylor expansion of the separated kernel.

Dividing (3) by (2), the principal bound for \(X=C^r,Y=C^t\) or
\(X=H^r,Y=H^t\) is
\[
C\delta^{r-t}\left(1+\kappa^2+\epsilon^2/\delta+\epsilon\right),
\tag{5}
\]
plus a vanishing separated-kernel term. In particular for \(t=r-1\)
this is \(O(\epsilon^A+\epsilon^{3A-2}+\epsilon^2+
\epsilon^{A+1})\), hence tends to zero.
For \(r=3+\alpha,t=1+\alpha\) it also tends to zero, for every alpha
allowed by the coefficients, not only alpha below the cusp threshold.
Take \(\epsilon_n=2^{-n}\) and normalize (1) in X.
This gives the requested singular sequence for the actual variable
coefficient operator under the stated hypotheses.

The \(\epsilon^{2-A}\) error before normalization is significant.
For instance, if \(V_1=As+\beta y^2+\cdots\), then
\(\beta y^2\partial_s H\) has size \(y^{d+2-A}\).
It is larger than \(y^d\) as \(y\to0\) when \(\beta\ne0\).
The uncorrected straight cusp is therefore not a same-order approximate
solution of the variable-coefficient equation. Following a curved
invariant manifold and controlling the nonlocal expansion would require
additional work.

## 4. The derivative-gap obstruction is not a threshold phenomenon

For all \(r>t\ge0\), use the simpler isotropic packet
\[
q_\epsilon(X)=a_\epsilon q((X-P)/\epsilon),
\]
where q is any fixed nonzero smooth compactly supported function odd in
y (and reflect in x for admissibility). Since \(V(P)=0\),
\[
\begin{array}{lll}
\|q_\epsilon\|_{C^r}\asymp |a_\epsilon|\epsilon^{-r},
&\quad&
\|Lq_\epsilon\|_{C^t(D)}\le C|a_\epsilon|\epsilon^{-t},\\
\|q_\epsilon\|_{H^r}\asymp |a_\epsilon|\epsilon^{1-r},
&&
\|Lq_\epsilon\|_{H^t(D)}\le C|a_\epsilon|\epsilon^{1-t}.
\end{array}
\]
These follow by isotropic change of variables, homogeneity of the velocity
multiplier, and \(V(P+\epsilon z)/\epsilon=O(1)\) with bounded derivatives.
The separated tail and c functional are \(O(|a_\epsilon|\epsilon^2)\).
Thus the normalized residual tends to zero at rate
\(\epsilon^{r-t}\), with the additional c term also tending to zero.
Every strictly weaker nonnegative local order tends to zero as well.
No classification of negative orders or same-order realizations is
asserted by this argument.

It follows that no estimate with a strictly weaker compact remainder can
bound the X norm by the Y norm of Lh for these pairs. In particular the
proposed \(C^{4,\alpha}\to C^{3,\alpha}\) inverse fails just as the
\(C^{2,\alpha}\to C^{1,\alpha}\) inverse does.
If L is a bounded map on a globally specified pair of spaces with these
local norms, it is not Fredholm: a Fredholm map would put the normalized
packets at distance tending to zero from its finite-dimensional kernel.
A convergent subsequence in that kernel would force convergence in X;
convergence to zero in a weaker norm would identify its limit as zero,
contradicting unit X norm.

This excludes a Newton argument that requires that particular inverse.
It does not exclude graph domains, anisotropic spaces, other iteration
schemes, or solutions in either P_2 or P_infty.

## 5. No infinite-dimensional kernel theorem follows

For the local differential model \(T-d\), the arbitrary F in Section 2
indeed supplies infinitely many local \(C^{2,\alpha}\) homogeneous
solutions. They are not compactly supported solutions on the whole plane.
They are not solutions of L or, in general, of L_P.

A concrete check of the logical distinction uses L_P itself. For every
smooth compactly supported h,
\[
\operatorname{Re}\langle L_Ph,h\rangle
=-(1+c_l)\|h\|_2^2-g_*\langle Mh,h\rangle
\le-(1+c_l)\|h\|_2^2.
\]
The identity extends to its natural L2 graph domain by cutoff and
regularization. Thus L_P has trivial L2 kernel, while Section 4 still
gives its \(H^r\to H^{r-1}\) singular sequences.

The dimension of the kernel of the actual full-plane L is unresolved
from these data. A local nonlocal equation is not even specified until
one prescribes how h extends outside the neighborhood. A proof of
infinite-dimensional kernel would need a solution operator that extends
arbitrary label data and solves the full nonlocal equation while retaining
the origin, infinity, parity and normalization conditions.

## 6. Radial dynamics and the order-zero term

Use Euclidean L2 density and set \(p(X,\zeta)=V(X)\cdot\zeta\).
Then
\[
H_p=V\cdot\partial_X-(DV)^T\zeta\cdot\partial_\zeta.
\]
At an equilibrium with diagonal eigenvalues \(\lambda_1,\lambda_2\),
the radial covectors are the two signed coordinate axes. On the first
axis \(\dot{|\zeta|}=-\lambda_1|\zeta|\).
The ratio \(\zeta_2/\zeta_1\) has exponent \(\lambda_1-\lambda_2\).
These statements follow directly from
\((z_j,\zeta_j)(t)=(e^{\lambda_jt}z_j,e^{-\lambda_jt}\zeta_j)\).

At P the signed ds points have cosphere linearization eigenvalues
\((A,1,A-1)\): they are sources. The signed dy points have eigenvalues
\((A,1,1-A)\): they are saddles, not full cosphere sinks.
Restricted to p=0, remove the base eigenvalue in the covector direction:
the ds exponents are \((1,A-1)\), and the dy exponents are \((A,1-A)\).
Within the fibre over P alone, ds is a repeller and dy is an attractor.
Both directions have contracting covector magnitude and are sources
in the fibre-radial boundary coordinate \(1/|\zeta|\).

At the origin write \(B=4c_l-1=2A+1\). The ds cosphere exponents are
\((-A,B,-A-B)\), and the dy exponents are \((-A,B,A+B)\).
Both are saddles, also on the characteristic cosphere after removing the
corresponding base direction. Within the fibre alone dy repels toward ds.
The ds covector expands in forward time and is a fibre-radial sink;
the dy covector contracts and is a fibre-radial source.
Invariant conormal sets, rather than a misidentification of all four
points as simple sources or sinks, are needed for a global escape function.

Write the real order-zero symbol of L as
\[
q_0=-1+\frac{\rho_x\xi\eta-\rho_y\xi^2}{|\zeta|^2}.
\]
At a radial covector with exponent lambda the real symbol after
conjugation by \(\langle D\rangle^s\) and taking the symmetric part is
\[
q_0-\tfrac12\operatorname{div}V+s\lambda.
\tag{6}
\]
To verify the signs, the adjoint of \(V\cdot\nabla\) is
\(-V\cdot\nabla-\operatorname{div}V\).
Moreover \([\partial_j,V\cdot\nabla]=\lambda_j\partial_j\)
in the diagonal linear model. The fractional-order commutator has
principal symbol \(s\lambda\) for the same reason, or by differentiating
\(|\zeta|^s\) along \(H_p\).

Since \(\operatorname{div}V=2c_l\), the critical values are

| Point and covector | lambda | \(q_0\) | Critical s |
| --- | ---: | ---: | ---: |
| P, ds | A | \(-1-g_*\) | \(3.578597773487\ldots\) |
| P, dy | 1 | \(-1\) | \(6.5753626\) |
| 0, dx | \(-A\) | \(-1\) | \(-0.647772693127\ldots\) |
| 0, dy | B | \(-1\) | \(0.308681450161\ldots\) |

At the origin the coupling symbol vanishes because
\(\nabla\widetilde\rho=O(r^2)\). The locally smoothing rank-one term has
no radial principal symbol at P. Its global continuity must nevertheless
be checked, especially on a space allowing distributions at the origin.

The exact frozen homogeneous Sobolev energy identity is
\[
\operatorname{Re}\langle |D|^sL_Ph,|D|^sh\rangle
=\int\left[
s\frac{A\xi^2+\eta^2}{|\zeta|^2}
-(1+c_l)-g_*\frac{\xi^2}{|\zeta|^2}
\right]\bigl||\zeta|^s\widehat h\bigr|^2\,d\zeta.
\tag{7}
\]
It follows by Fourier transforming T and integrating by parts.
For \(0\le s<s_*\) the bracket is strictly negative in every direction,
so the frozen operator is bounded below in the same homogeneous order.
For \(s>6.5753626\) it is strictly positive in every direction.
The number \(s_*\) is only the ds threshold; it is not the sole radial
value at P.

For smooth variable coefficients, the positive symbol in the latter
range persists on a sufficiently small disc. Pseudodifferential
localization and the sharp Gårding inequality give, for functions supported
there, a same-order estimate with a lower-order remainder. In a local
estimate for arbitrary h, one must additionally retain cutoff terms and
control of the nonlocal exterior contribution.
This is a same-order assertion, not an \(H^{s-1}\)-to-\(H^s\) gain.
For a source microlocal estimate near ds alone one uses \(s>s_*\);
regularity across a radial threshold cannot be bootstrapped from arbitrary
low regularity without the hypotheses of the radial estimate.
No same-order \(C^{4,\alpha}\) theorem for the full operator is proved here.

For a forward Fredholm construction by a positive symmetric-part estimate,
one seeks an order function m making the conjugated real symbol positive,
including
\[
-(H_pm)\log|\zeta|+m\lambda+q_0-c_l.
\]
A sufficient local choice is \(H_pm\le0\), strict away from the appropriate
invariant sets, together with
\[
\begin{split}
m(P,ds)&>3.578597773487,\quad m(P,dy)>6.5753626,\\
m(0,dx)&<-0.647772693127,\quad m(0,dy)>0.308681450161.
\end{split}
\]
These are local sign requirements, not a global Fredholm theorem.
For example one can take a constant m greater than 6.5753626 over the
whole fibre at P; a purported variable choice must also respect the
direction of angular transport.
The relevant domain is
\(\mathcal D_m=\{h\in H^m:Lh\in H^m\}\), with graph norm.
This is one sign convention and one sufficient escape construction, not
a necessary characterization of every possible Fredholm realization.
For the adjoint or a backward construction the propagation choices reverse.

## 7. Infinity and missing global hypotheses

At infinity put \(t=\log r\), assuming the symbol derivative versions of
\(U=O(r^k)\), \(\nabla\rho=O(r^{k-1})\). The leading operator is
\[
L_\infty=c_l\partial_t-1.
\]
The coupling tends to zero. For \(h=r^qv(t,\theta)\),
\[
r^{-q}L_\infty(r^qv)
=c_l\partial_tv+(c_lq-1)v.
\]
Thus the indicial growth threshold is \(q=k\). On Euclidean
\(L^2(r^{-2\ell}dX)\), a power \(r^q\) is integrable at infinity
exactly when \(q<\ell-1\), and the critical weight is
\(\ell=1+k=1.179360531636\ldots\).
The leading real weighted energy coefficient is
\(c_l(\ell-1-k)\). Thus the positive symmetric-part convention used
above asks for \(\ell>1+k\) at this end; the opposite convention asks
for \(\ell<1+k\). Neither inequality specifies the missing global
boundary/asymptotic domain.

Under base radial compactification \(\rho=1/r\), the leading flow is
\(\dot\rho=-c_l\rho,\dot\theta=0\). Infinity is a normally attracting
circle, with neutral angular dynamics, not a finite collection of
hyperbolic Morse critical points. In b-cotangent variables
\(\sigma\,dt+\eta\,d\theta\), the normal symbol is \(c_l\sigma\).
Its characteristic boundary is \(\sigma=0,\eta\ne0\), with no leading
angular or fibre expansion. There is no invariantly specified
"Sobolev order threshold at infinity" until the calculus, density,
spatial weight and boundary/asymptotic data are fixed.

A global theorem further needs the full flow geometry, control of every
equilibrium and connecting trajectory, appropriate escape and adjoint
estimates, a treatment of the noncompact end, and boundedness of the
canonical inverse and c functional on the proposed domain.
The established anisotropic spectral theorems do not assert these
hypotheses for X3. The original X3 trial has finite differentiability;
invoking a smooth symbolic calculus additionally requires justification.

Primary references consulted: Haber--Vasy, *Propagation of singularities
around a Lagrangian submanifold of radial points*, arXiv:1110.1419,
Theorems 1.4--1.6 and Section 1.5.1; Dang--Rivière, *Spectral analysis
of Morse--Smale gradient flows*, arXiv:1605.05516, Sections 3--4 and
Proposition 4.2; Faure--Sjöstrand, *Upper bound on the density of Ruelle
resonances for Anosov flows*, arXiv:1003.0513.
Also Dyatlov--Zworski, *Dynamical zeta functions for Anosov flows via
microlocal analysis*, arXiv:1306.4203.
The arXiv abstracts and relevant passages of the Haber--Vasy,
Dang--Rivière and Dyatlov--Zworski full texts were checked on 2026-10-20.
In particular,
Dang--Rivière Sections 2.1, 3.5, 3.7--3.8 and Proposition 4.2 spell out
the smooth linearization, transversality, compactness and graph-domain
issues relevant to the distinction here.
The first reference's Lagrangian radial-set hypotheses do not directly
apply to each isolated saddle radial point computed above.

## 8. Audit of SPEC 3.1--3.4

1. F1 correctly states the frozen symbol, but confuses spatial and
   frequency localization, local homogeneous cusps, singular sequences,
   and exact kernels. Sections 2--5 give the corrections. Raising X to
   C4 while keeping a one-derivative weaker Y does not repair invertibility.
   Moreover, at a trial with transport residual epsilon and an actual
   axis zero of V, write \(\mu=\partial_yV_2(P)\). Differentiation gives
   \[
   \partial_y\epsilon(P)=(\mu-1)g_*,
   \qquad \partial_xV_1(P)=2c_l-\mu.
   \]
   Thus setting mu exactly to 1 in the trial's frozen operator requires
   an extra identity; it does not follow from imposing center normalization.
   With \(\widetilde A=2c_l-\mu\), the corresponding fast threshold is
   \((1+g_*+c_l)/\widetilde A\), and the slow threshold is
   \((1+c_l)/\mu\). The derivative-gap obstruction only requires V(P)=0.

2. F2's global kernel/cokernel dimensions are unproved. An approximate
   transported profile is not an exact kernel element:
   \(L_0\widetilde\rho=\widetilde\epsilon\).
   A resonant y-jet is not a continuous functional on a C0 residual space.
   Even on bare C1 spaces a single zero resonant jet need not suffice.
   For \(yh'-h=f\), take
   \(f(y)=y/\log(e/|y|)\) near zero. This f is C1 with f'(0)=0,
   but \(h/y=C+\int f(t)t^{-2}dt\) diverges like a logarithm of a logarithm.
   Hence there is no C1 solution. Positive Hölder control removes this
   particular Dini failure but does not prove the global assertion.

3. The origin linear-model relation is correct:
   \[
   -Aa+(2A+1)b=1,\quad a=2b+(b-1)/A.
   \]
   It gives \(p_3=6.197030257503\ldots\) and
   \(p_5=10.394060515006\ldots\). These monomials are solutions of the
   linear model; coefficients and corrections for the full equation
   require proof. Membership of a mode does not require its nonzero
   presence in every solution.

4. F3's log weight describes an infinitesimal exponent derivative, not
   a neighborhood of changing exponents:
   \[
   \frac{r^{k+\tau}-r^k}{r^k(1+\log r)}
   \longrightarrow\infty\quad(\tau>0).
   \]
   Either parametrize the exponent as part of the asymptotic expansion or
   introduce a fixed growth margin.

5. More decisively, the stated X does not map to the stated Y. Take an
   exterior cutoff of \(r^k\log r\,B(\theta)\), with the required parity
   and \(B\notin\operatorname{span}\Theta_0\).
   It satisfies the stated X bounds, but
   \[
   Lh=c_lr^kB+\frac{c[h]}3\,k r^k\Theta_0+o(r^k).
   \]
   The first term is neither in the decaying residual space nor in its
   added span(G). Arbitrary oscillation in log r causes related failures.
   One needs actual asymptotic restrictions, not only growth inequalities.
   The quadratic dilation term \(c[h]X\cdot\nabla h/3\) likewise has
   inadmissible \(r^k\log r\) size for generic such h.

6. F4's transport identity and principal coupling maximum are correct:
   the symbol matrix is
   \(\left(\begin{smallmatrix}-\rho_y&\rho_x/2\\
   \rho_x/2&0\end{smallmatrix}\right)\), whose larger eigenvalue is
   \((|\nabla\rho|-\rho_y)/2\).
   The pointwise symbol bound does not give an exact weighted quadratic
   form bound for variable coefficients. Commutators and lower-order
   remainders must be bounded.
   For a concrete illustration, on a periodic patch let
   \(b(y)=1+\beta\cos(Ny)>0\), \(0<\beta<1\), and \(\rho_x=0\),
   \(\rho_y=b\). On the Fourier modes \(e^{ix}\) and \(e^{i(x+Ny)}\),
   the symmetric part of bM has compression
   \[
   \begin{pmatrix}
   1&\beta(1+m_N)/4\\
   \beta(1+m_N)/4&m_N
   \end{pmatrix},\qquad m_N=(1+N^2)^{-1}.
   \]
   Its determinant tends to \(-\beta^2/16<0\). Thus the operator
   \(-bM\) can have a positive quadratic form although its pointwise
   principal symbol is nonpositive. This illustrates the
   variable-coefficient inference error; it is not asserted to be an
   IPM stationary background.
   Concretely, beta=1/2 and N=10 give determinant -985/163216<0.
   The separate finite-rank contribution to the full L also needs an
   energy bound; it is not included in the displayed D_w criterion.
   Singular axis powers do not all fail A2: the product weight
   \(|x|^\alpha|y|^\beta\) is A2 exactly for
   \(-1<\alpha,\beta<1\), by checking integrability of each weight and its
   reciprocal on intervals through zero and scaling the averages.
   Radial powers in two dimensions have range \(-2<\alpha<2\).
   The particular weight \(m^{-2}\sim r^{-6}\) fails the usual A2 criterion
   at zero; restricted vanishing spaces require a separate argument.

7. Derivative energy indefiniteness must specify the operator and order.
   Formula (7) is negative in all directions for the full frozen coupled
   operator at orders 1, 2 and 3. At order 4 its ds and dy coefficients
   are \(4.2775382\) and \(-2.5753626\).
   The origin is indefinite at every positive integer derivative order.

8. In Section 3.2 the factor variable has the wrong stated exponent:
   \(h=y^3|x|^{p_3}\) corresponds to
   \(b=y^2|x|^{p_3-2}\), not \(y^2|x|^{p_3}\).
   The displayed weighted inequalities may allow the correct term, but
   the asserted expansion must be repaired. Specify the finite jet norm,
   remainder space, Hölder seminorms or completion, low space, velocity
   space and bounded maps. The current alternatives are not a defined
   Banach-space theorem.

9. The normalization removes the dilation mode at an exact profile:
   \(\rho_\lambda(X)=\lambda\rho(X/\lambda)\) preserves the equation and
   canonical gauge, with derivative \(K=\rho-X\cdot\nabla\rho\).
   Its center coefficient is -2. At a trial with residual epsilon,
   \(LK=\epsilon-X\cdot\nabla\epsilon\), not zero.
   The cubic cancellation of Lh under exact center normalization is
   correct.

10. Section 3.3's algebraic splitting and fixed-point equation are correct.
    Its scalar condition is overstated: differentiation at a fixed point
    gives \((\mu-1)\rho_y(P)=0\), so \(\mu=1\) requires nonzero slope.
    For \(0<\mu<1\), an odd power of degree \(1/\mu>1\) is C1 with zero
    slope; the assertion "else not C1" is false.

11. The linearized source condition includes more than the stated
    functional. At an exact background, with \(g(x)=\rho_y(x,0)\),
    \[
    \partial_yLh(P)
    =g_*\left(\partial_yU_2[h](P)+c[h]/3\right)
    +g'(x_*)\left(U_1[h](P)+(c[h]/3)x_*\right).
    \]
    This follows by differentiating every term of L. The second
    bracket represents source displacement. There is no established
    nondegeneracy showing that the required scalar condition is absorbed.

12. T1 omits the dilation contribution from its constants. Put
    \(W(h)=U[h]+c[h]X/3\). It needs bounds
    \(\|W(h)\|_{X_V}\le C_W\|h\|_X\) and
    \(\|W(v)\cdot\nabla g\|_{Y_{\rm low}}
    \le C_B\|v\|_{X_{\rm low}}\|g\|_X\).
    With compatible inverses and a high ball closed in the low metric,
    the correct conditions are
    \(K\epsilon\le R,\ C_WR\le r_V,\ K_{\rm low}C_BR<1\).
    Indeed \(T(h)=-L_{V+W(h)}^{-1}\epsilon\) maps this ball to itself, and
    the resolvent identity gives
    \[
    \|T(h)-T(k)\|_{X_{\rm low}}
    \le K_{\rm low}C_BR\|h-k\|_{X_{\rm low}}.
    \]
    Banach contraction then proves the corrected conditional theorem.
    Without low-metric closedness one must prove an appropriate
    compactness and limit passage instead.
    Original H2 is already impossible on the listed local derivative-gap
    spaces, and the far-field mapping failure is independent of H2.
    Thus "everything except H2 is computable" is not an established claim.

P_infty in PROMPT strengthens the center factor. Smoothness there alone
does not remove packets supported near P. None of these obstructions is
an exclusion theorem for exact profiles in P_2 or P_infty.

## 9. Verification and collaboration limitation

`verification/check_numbers.py` uses exact rational arithmetic on the
supplied rounded decimal inputs. `verification/numbers.txt` is its full
stdout. No profile coefficients, residual enclosure, or root enclosure
were reconstructed. There are no formal proof sources.

A permitted Python/boto3 attempt to discover the available Anthropic
Bedrock models failed while retrieving credentials for `cline-profile`:
`CredentialRetrievalError`, no credentials found in its
`Ec2InstanceMetadata` credential source. Claude Opus 5.5 was therefore not
consulted; no other model was substituted and no independent model audit
is claimed. No server, JavaScript, GPU, or RLScience cluster was used.
