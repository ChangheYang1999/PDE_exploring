# SPEC (ipmA-lead): target theorem, spaces, splitting, bounds and owners

Version 2, 2026-10-20T14:57Z (shift 1). Supersedes v1 (14:15Z). Change log at the end. Status labels: PROVED (with
the place of the proof), VERIFIED (independently reproduced by the verifier), CONDITIONAL, HEURISTIC, REFUTED.

## 0. Decisions
- Target: an a posteriori existence theorem near X3 in a class contained in `P_2`, via the verifier's two-norm
  quasilinear theorem (ver research/two_norm_scheme/PROOF.md, here called T2N). No decisive `P_infty` route: the `B_3`
  exclusion is formal at every radius achieved so far (first run and smooth-setting run); `B_3` is a diagnostic only.
- v1's inverse spaces were wrong (REFUTED by the verifier, ver research/spec_audit/PROOF.md): the inverse cannot gain a
  derivative (compact flow-box waves), and the logarithmic far weight admits tails `r^k log r Phi(theta)` whose images
  leave the decaying residual space. v2 uses SAME-ORDER spaces on both sides and a common power weight at infinity.
- New structural obstruction (section 3.6, CONDITIONAL, under audit): in any class above the source threshold the
  normalized linearization has index -1 (if the natural Fredholm homotopy holds), so T2N's high solution bound cannot
  hold there. Proposed repair: add one flow-adapted singular source mode as an unknown. Until this is settled the
  realistic endpoint is UNRESOLVED with: certified residual, T2N with named constants, the threshold and index
  obstructions, and model inverse bounds.

## 1. Equation and notation (fixed)
- `F(rho) = (c_l X + U[rho]).grad rho - rho`, `U = (-psi_y, psi_x)`, `-Lap psi = d_x rho` (canonical inverse, no
  `lambda x y`), `c[rho] = psi_xy(0)`, `c_l = (1 + c[rho])/3`. Parity: rho even in x, odd in y; `rho = x^2 y a` near 0,
  a continuous; `J(rho) := a(0)`, normalization `J = 1`. The y-axis ODE forces `rho(0, y) = 0`.
- `V = c_l X + U[rho]`; `DV(0) = diag(c_l - c, c_l + c) = diag(1 - 2c_l, 4c_l - 1) = diag(-A, D)`, `D = 2A + 1`.
- Axis source `P = (x_*, 0)`, `DV(P) = diag(2c_l - mu, mu)`, `mu := d_y V_2(P)`; `mu = 1` at an exact solution with
  `g := rho_y(P) != 0` (VERIFIED, ver local_geometry). At the trial `mu~ - 1` is small but not zero (num S1).
  `A = 2c_l - 1` when `mu = 1`; `g' := rho_xy(P)`; `d := 1 + g`; `k := 1/c_l`.
- X3 values: `c_l = 5.5753626`, `A = 10.1507252`, `x_* = 8.60006`, `g = 29.75`, `d = 30.75`, `k = 0.17936`, `L = 7.6514`,
  `p_3 = 6 + 2/A = 6.19703` (centre mode `|x|^{p_3} y^3`), `p_b = 2b + (b-1)/A`.
- Linearization: `L h = (V.grad - 1) h + B h`, `B h = W[h].grad rho`, `W[h] = U[h] + (c[h]/3) X` (the full velocity
  increment; v1 omitted `(c[h]/3) X` from the constants). `J(L h) = 0` for all h, because `2 lambda_x + lambda_y = 1`
  and `W[h].grad rho` has zero `x^2 y` coefficient. So `L : X -> Y_0 := {f : J(f) = 0}`.
- Scaling: `rho_a(X) = a rho(X/a)`; `F(rho_a) = (F rho)_a`, `c[rho_a] = c[rho]`, `J(rho_a) = a^{-2} J(rho)`.
  `K := rho - X.grad rho` satisfies `L K = F(rho) - X.grad F(rho)`, `c[K] = 0`, `J(K) = -2 J(rho)`.
  At the trial: `L K~ = eps~ - X.grad eps~` exactly (PROVED by differentiating `F(rho~_a) = (eps~)_a` at a = 1).

## 2. The trial (decided; unchanged in substance)
- The rigorous object is num's explicit modal trial `rho~` (exponential-polynomial splines in `t = log r`, even polynomial
  core, explicit far form), with closed-form Green integrals so that the elliptic equation holds exactly, `c~` closed
  form, `c_l := 1/k` and the normalization `c~ = 3/k - 1` imposed by exact recomputation of dependent coefficients
  (verifier's positive closed-form slope lemma, ver modal_repair, and its exactification audit, ver modal_exactification).
  The only residual is `eps~ = F(rho~)`.
- Verifier facts adopted: exact X3 scalar repair at factor distance < 1.477e-5 (VERIFIED, ver far_field_normalization);
  stored X3 with `c_l = (1+c0)/3` has an unbounded absolute far residual (VERIFIED), which the exact `c_l k = 1` trial
  avoids.

## 3. Analytic set-up

### 3.1 Same-order transport at the source (VERIFIED for the linear model, ver source_transport)
For `L_A h = A s h_s + y h_y - h` on a box, odd f in `C^{m,alpha}`, m >= 1: solvable in `C^{m,alpha}` iff `f_y(0) = 0`;
solutions `c y + R f`, `R f = int_0^inf e^t f(T_t X) dt`; `|D^beta R f| <= |D^beta f|/(A a + b - 1)` for `|beta| >= 2`,
Hoelder `/(A a + b - 1 + alpha)`; first order `/(A-1)` (s) and `R^alpha [f_y]_alpha/alpha` (y). No derivative gain. A Dini
modulus is necessary (counterexample `y/log(e/r)`).

### 3.2 Coupled source thresholds (astra packets1; to be VERIFIED)
Frozen operator at P: `L_P h = A s h_s + y h_y - h - g M h`, `M = xi^2/|zeta|^2`. Radial packets give Weyl sequences
(approximate kernel, weakly null) in every space below the thresholds:
| | fast (s) direction | slow (y) direction |
|---|---|---|
| Hoelder `C^{m,alpha}` | `d/A = 3.0293402` | `1` |
| Sobolev `H^s` | `(d + c_l)/A = 3.5785978` | `1 + c_l = 6.5754` |
So `C^{2,alpha}` (any alpha < 1) is below threshold; `C^{3,alpha}` is above iff `alpha > 0.0293402`; `C^{4,alpha}` is
above. Both the high and the low space of T2N must be above threshold (scheme1 (43)). The degree-d quasi-homogeneous
family (`y^p |s|^{(d-p)/A}`, p odd, and cusp packets `sgn y |y|^d F(s/|y|^A)`) contains the axis-visible conormal
exponent `g/A = 2.931` of the first run (lam1).

### 3.3 Spaces v2 (working choice)
- Parity (even in x, odd in y) in all spaces. alpha = 1/2.
- High: `X = ` weighted `C^{4,alpha}`; low: `E = X_low = ` weighted `C^{3,alpha}` (above threshold). Forcing: `Y_H` with the
  same order as X (weighted `C^{4,alpha}`), `Y_L` the same order as E; both inside `Y_0` (J = 0) and with the centre
  structure below.
- Near 0 (`r < r_0`): `h = x^2 y b`, b in logarithmic-coordinate Hoelder norms (scheme1 (34)) allowing the modes
  `y^2 |x|^{p_b - 2}` (note: exponent `p_3 - 2 = 4.197`, v1 wrote `p_3`), and log-variations when `c_l` moves; the part of b
  beyond its value at 0 measured with weight `r^beta`, `0 < beta < p_3 - 6 = 0.197` (margin for log-variations).
- Near P: plain `C^{4,alpha}` on the disc `|X - P| < x_*/4` (moving P stays inside).
- At infinity: common weight `(1+u)^gamma`, `u = r/L`, for `r^j grad^j`, `j <= 4`, on BOTH X and Y, with
  `k + margin < gamma < 1` (so that `r^{k(h)}` tails with `|k(h) - k|` small lie in X, and `X.grad rho~ ~ k r^k Theta_0` lies
  in Y). Model inverse at infinity: `(c_l r d_r - 1)^{-1}(r^sigma H) = r^sigma H/(c_l sigma - 1)` (scheme1 (35)-(37)).
- Elsewhere: weighted `C^{4,alpha}`.

### 3.4 Conditional theorem (replaces v1's T1): T2N
Adopt ver two_norm_scheme verbatim: `A_h u = L u + (Gamma h).grad u`, `Gamma h = U[h] + (c[h]/3) X`,
`B(e, u) = (Gamma e).grad u`. Hypotheses: high solution bound `||R_h f||_X <= K_H ||f||_{Y_H}`; low a priori bound
`||u||_E <= K_L ||A_h u||_{Y_L}` on the low domain; `||B(e,u)||_{Y_L} <= C_B ||e||_E ||u||_X`; `||Gamma h||_V <= C_V ||h||_X`;
ball closed in E. Closing: `K_H eta <= r`, `K_L C_B K_H eta < 1`, `C_V r <= r_V`. Conclusion: unique `h` in the ball,
`||h||_X <= K_H eta`, `F(rho~ + h) = 0`. Everything except K_H, K_L is computable (lead: C_B, C_V; num: eta).

### 3.5 Transport inverse and the source functional (lead derivation; to be VERIFIED)
- `R_V f(X) = int_0^inf e^t f(Phi_{-t} X) dt`; `q_V(X) = lim_T e^T [Phi_{-T} X]_2` (kernel of `V.grad - 1`, when mu = 1).
  Normalized inverse on `Y_0 cap {d_y f(P) = 0}`: `T_V^{-1} f = R_V f - (J(R_V f)/J(q_V)) q_V` (then `J = 0`).
- Source functional: `d_y(L h)(P) = (mu - 1) h_y(P) + g d_y W[h]_2(P) + g' W[h]_1(P)`.
  At a trial with `mu~ != 1` the y-jet `h_y(P)` enters with the factor `(mu~ - 1)`; any inverse that solves for it
  costs `1/|mu~ - 1|` unless the y-jet is treated as an unknown balanced by this functional.
- Scaling check (PROVED identity): `W[K]_1(P) = -x_* A`, `d_y W[K]_2(P) = -x_* mu'(x_*)`, and the exact axis relation
  `g mu' + A g' = 0` gives `d_y(L K)(P) = 0` at exact solutions, as it must.

### 3.6 Index obstruction (CONDITIONAL; astra index1 and ver to audit)
(a) `T_V : X -> Y_0` has index 0 (kernel `q_V`, cokernel `d_y f(P)`; the origin resonance costs exactly `J`, already in
`Y_0`; `gamma > k` costs nothing at infinity). (b) IF `T_V + tau B : X -> Y_0` is Fredholm for all `tau` in [0,1]
(plausible above threshold: B's symbol vanishes at 0 and infinity, and the threshold `(1 + tau g)/A` is largest at
tau = 1), THEN `index(L : X -> Y_0) = 0` and `index(L : X_0 -> Y_0) = -1`, `X_0 = {J(h) = 0}`: the normalized operator is
not onto, so T2N's high bound fails in X_0. (c) Without normalization (PROVED, elementary, given `K~` in X): with the low a priori bound, the solution of
`L u = L K~` is `u = K~`, so `K_H >= ||K~||_X/||L K~||_{Y_H}`, `K_L >= ||K~||_E/||L K~||_{Y_L}`, `C_B >= ||B(K~,K~)||_{Y_L}/
(||K~||_E ||K~||_X)`, hence `q = K_L C_B K_H eta >= (eta/||L K~||_{Y_H}) ||B(K~,K~)||_{Y_L}/||L K~||_{Y_L}`, with
`L K~ = eps~ - X.grad eps~` of residual size and `B(K~,K~) = (Gamma K~).grad K~` of size one: T2N cannot close in X. (d) At an exact solution with K in X (any
solution `C^{m+1,alpha}` near P, in particular any `P_infty` solution), K spans part of ker L and index 0 forces a
cokernel: such solutions are degenerate zeros. (e) HEURISTIC repair: exact solutions near X3 generically carry a
singular source mode below threshold (axis conormal `y |x - x_*|^{g/A}`, one-sided coefficients `C_+-`), so they are
`P_2` but not `C^{3,alpha}`; the class `X_0 + span(eta_V)` with one mode attached to the moving source would have index 0;
two one-sided modes would give index +1, a one-parameter family, matching the first run's soft c_l direction.

## 4. Owners and tasks

### 4.1 num (priority order)
R0  Rigorous weighted sup of eps~ (Wiener sum over modes) by region, weight `m(r) (1+u)^{gamma - k}` with gamma = 0.5
    to be reported, together with the unweighted shell values so that any gamma can be read off. (v1 delta -> gamma.)
S1  Balls for `c~`, `c_l`, `x_*`, `mu~ - 1`, `g`, `g' = rho~_xy(P)`, `A~ = 2c_l - mu~`.
R1  The same as R0 for `r^j grad^j eps~`, j = 1, 2 (then up to 4 near P only: R3).
R3  Taylor bounds of eps~ to order 5 on the disc around P (order 4 plus Hoelder for Y_H).
R5  `||eps~ - X.grad eps~||` in the R0/R1 norms and `||K~||` with `K~ = rho~ - X.grad rho~` (for 3.6(c)).
R4  Origin: `sup_{r<r_1} W(r)/r^5` and the `y^3` angular coefficient (B_3 diagnostic only).
C2  (floating point, after R0/S1) finite sections of L in an above-threshold weighted norm, unnormalized: two smallest
    singular values and vectors at three resolutions. Prediction: sigma_1 ~ ||L K~||/||K~|| with right vector ~ K~,
    sigma_2 bounded below; then the same with the axis conormal mode added as a column.

### 4.2 ver
V1  Independent reproduction of S1 and R0 on sample cells (ongoing work on exactification and arithmetic counts).
V2  Audit of 3.2 (packets1 thresholds and Weyl sequences) and of the scaling identity `L K~ = eps~ - X.grad eps~`.
V3  Audit of 3.6 (index count, the homotopy assumption, the lower bound (c)); counterexample search welcome.
V4  Audit of 3.5 (source functional, `T_V^{-1}` formula).

### 4.3 lead
L1 Proofs of 3.5 and 3.6 in final form (with astra index1). L2 Explicit C_B, C_V in the spaces of 3.3 (using ver's
`|c[h]|` bound). L3 The best statement about the linear hypothesis: a proof in a restricted setting or a precise
obstruction. L4 FINAL_REPORT.md.

## Change log
- v1 2026-10-20T14:15Z: initial.
- v2 2026-10-20T14:57Z: same-order spaces (v1's derivative-gaining inverse and log far weight REFUTED by ver); common power
  far weight; W[h] includes `(c[h]/3) X`; T1 replaced by ver's T2N; thresholds from packets1 (low space above threshold,
  alpha > 0.0293); centre exponent corrected to `p_3 - 2`; source functional with `g' W_1` and mu~ != 1 at the trial;
  v1's claim "mu != 1 implies not C^1" removed (`|y|^{1/mu}` is `C^{1,1/mu-1}` for mu < 1); index obstruction 3.6 added;
  num tasks R5 and the revised C2 added.
