# Forward singularity of the frozen coupled source

Status: proved for the frozen whole-plane operator and compactly supported smooth data. The variable-coefficient extension is conditional. All arguments below concern ordinary local Sobolev and classical noninteger Hölder spaces unless explicitly stated otherwise.

The question supplies the below-threshold inverse theorem. Its two supplied proof notes were read. The expansion below is derived independently from the Fourier formula, rather than inferred from the threshold theorem.

## 1. Constants and exact inverse

Use the Fourier transform \(\widehat f(\xi,\eta)=\int e^{-i(s\xi+y\eta)}f(s,y)\,ds\,dy\). Set

\[
Q=A+1,\quad d=1+g,\quad a=\frac g{A-1},\quad
q=Q+1-a,\quad
\delta_r(\xi,\eta)=(r^A\xi,r\eta).
\]

For the stated decimals,

\[
\begin{aligned}
a&=3.2510527908760718,\\
p:=d/A&=3.0292900353562916,\\
\gamma:=g/A&=2.9307749066047025,\\
s_f:=\frac{d+Q/2}{A}&=3.5785475997320861,\\
s_1:=s_f+2-\frac2A&=5.3815173422289079,\\
q-\tfrac12&=8.3996724091239282.
\end{aligned}
\]

The forward inverse satisfies, for \(\zeta=(\xi,\eta)\ne0\),

\[
\widehat h(\zeta)=
-|\zeta|^{-a}\int_0^1 r^{q-1}|\delta_r\zeta|^a
                 \widehat f(\delta_r\zeta)\,dr.                 \tag{1}
\]

Indeed, with \(D=A\xi\partial_\xi+\eta\partial_\eta\),

\[
\widehat L=-D-(A+2)-g\frac{\xi^2}{|\zeta|^2},
\qquad
|\zeta|^a\widehat L|\zeta|^{-a}=-D-q.
\]

If \(G=|\zeta|^a\widehat f\) and \(I=\int_0^1r^{q-1}G(\delta_r\zeta)\,dr\), integration by parts gives \(DI=G-qI\), proving (1). Equivalently (1) follows by Fourier transforming the forward integral in the question. The lower endpoint converges since \(q+a=A+2>0\); oddness gives an additional vanishing factor.

The inverses for \(0\leq\sigma<s_f\) coincide: the solution in the larger Sobolev space also belongs to the maximal graph domain in every smaller space, and uniqueness there applies. Negative ordinary Sobolev orders, if desired, also have the forward inverse: conjugation by \(\langle\zeta\rangle^\sigma\) has real energy multiplier
\[
-\frac{A+3}{2}-gm+
\sigma\frac{|\zeta|^2}{1+|\zeta|^2}[1+(A-1)m],
\quad m=\xi^2/|\zeta|^2,
\]
which is strictly negative for \(\sigma<0\). The same closed-generator argument used in the supplied notes applies.

## 2. The profile map and its finite part

Define

\[
B_f(\zeta)=\int_0^\infty r^{q-1}|\delta_r\zeta|^a
                      \widehat f(\delta_r\zeta)\,dr.             \tag{2}
\]

The integral converges for every nonzero \(\zeta\), and
\[
B_f(\delta_R\zeta)=R^{-q}B_f(\zeta).
\]
For \(\xi\ne0\), write
\[
B_f(\xi,\eta)=|\xi|^{-q/A}C_{\operatorname{sgn}\xi}
                  \left(\eta|\xi|^{-1/A}\right),\qquad
C_\pm(\theta)=B_f(\pm1,\theta).                                \tag{3}
\]
Directly from (2),
\[
C_\pm(\theta)=O(|\theta|)\quad(\theta\to0),\qquad
C_\pm(\theta)=O(|\theta|^{-q})\quad(|\theta|\to\infty).           \tag{4}
\]
For the second estimate, use
\[
C_\pm(\theta)=|\theta|^{-q}
B_f(\pm|\theta|^{-A},\operatorname{sgn}\theta).
\]
The function on the right is smooth in its first argument near zero. Differentiating (2) proves this: at large \(r\), the second frequency coordinate supplies arbitrary Schwartz decay; at small \(r\), every first-coordinate derivative supplies an additional factor \(r^A\).

Define the homogeneous singular term by
\[
\boxed{\quad
\widehat K_f=-\operatorname{fp}_{\xi}
                     \bigl(|\xi|^{-a}B_f(\xi,\eta)\bigr).
\quad}                                                        \tag{5}
\]

This prescription matters: \(|\xi|^{-a}\) is not locally integrable, so ordinary multiplication at \(\xi=0\) is invalid.

For \(\eta\ne0\), the finite part is the one-dimensional homogeneous distribution \(\operatorname{fp}|\xi|^{-a}\), multiplied by the smooth function \(B_f(\cdot,\eta)\). For example, its action on a test function \(v\) is
\[
\lim_{\varepsilon\downarrow0}\left[
\int_{|\xi|>\varepsilon}|\xi|^{-a}v(\xi)\,d\xi
-\frac{2v(0)}{a-1}\varepsilon^{1-a}
-\frac{v''(0)}{a-3}\varepsilon^{3-a}\right].
\]
Here \(3<a<4\), and neither denominator vanishes.

Extend this distribution through \(\zeta=0\) by anisotropic homogeneity of degree \(-Q-d\). For completeness, this extension can be constructed by a partition into anisotropic annuli: subtract a sufficiently long Taylor polynomial of each test function at zero, sum the resulting convergent annular pairings, and assign the subtracted monomials their homogeneous values. The latter involve denominators \(Ai+j-d\). There is no zero denominator: for \(i=0,1,2,3\), \(d-Ai\) is respectively
\[
30.7494907,\quad20.5987655,\quad10.4480403,\quad0.2973151,
\]
and for \(i\ge4\) it is negative. The extension is unique: a difference would be supported at the origin, hence a finite sum of delta derivatives, whose possible degrees are \(-Q-Ai-j\). This also explains why no logarithm is required here.

Fourier scaling now gives
\[
K_f(r^As,ry)=r^dK_f(s,y).
\]
The estimates below prove that \(K_f\) is a function of class \(C^{3,p-3}_{\rm loc}\). Thus
\[
\boxed{\quad K_f(s,y)=\operatorname{sgn}(y)|y|^d
F_f(s/|y|^A),\qquad F_f(z)=K_f(z,1).\quad}                     \tag{6}
\]
Equations (2), (5), and (6) explicitly define the linear profile map. No compact support or arbitrary smoothness of \(F_f\) is assumed.

## 3. Expansion and the gain in the remainder

Subtracting (2) from (1) gives, away from zero frequency,
\[
\widehat h=-|\zeta|^{-a}B_f+E_f,\qquad
E_f=|\zeta|^{-a}\int_1^\infty r^{q-1}|\delta_r\zeta|^a
\widehat f(\delta_r\zeta)\,dr.                                \tag{7}
\]
The function \(E_f\), with all derivatives, decreases faster than every power at high frequency. This follows from \(|\delta_r\zeta|\ge r|\zeta|\) for \(r\ge1\) and arbitrary Schwartz bounds on \(\widehat f\).

We verify the regularity of \(h-K_f\), including the vertical frequency sector where a naive horizontal approximation is invalid.

In the horizontal sector \(|\eta|\le c|\xi|\), put \(N=|\xi|\), \(\theta=\eta N^{-1/A}\), and
\[
\beta=a+q/A=(Q+d)/A.
\]
Then
\[
|\widehat K_f|=N^{-\beta}|C_\pm(\theta)|,\qquad
\bigl||\zeta|^{-a}-|\xi|^{-a}\bigr|
\le C\eta^2|\xi|^{-a-2}.
\]
Consequently the squared weighted \(L^2\) integral for the difference is bounded by a constant times
\[
\int_1^\infty
N^{2r-2\beta-4+5/A}\,dN
\int_{\mathbb R}\theta^4|C_\pm(\theta)|^2\,d\theta.             \tag{8}
\]
The angular integral is finite by (4). The radial integral converges exactly for \(r<s_1\).

In the vertical sector \(|\xi|\le c|\eta|\), \(|\eta|\ge1\),
\[
B_f=|\eta|^{-q}b_\pm(\xi/|\eta|^A),
\]
where \(b_\pm\) is smooth with bounded derivatives on the relevant compact interval. The ordinary multiplier \(|\zeta|^{-a}B_f\) has size \(O(|\eta|^{-A-2})\), and its vertical-sector contribution is in \(H^r\) for \(r<A+1\).

For the finite part, localize in \(s\) by a compact smooth cutoff. Convolution in \(\xi\) with its Schwartz Fourier transform turns the finite part into a function. Its \(L^2_\xi\) norm is bounded by \(C|\eta|^{-q}\), and its weighted norm by \(C_r|\eta|^{r-q}\). To see the uniform bound, split \(|\xi|\le1\), \(1\le|\xi|\le C|\eta|\), and the exterior: the first part is controlled by the displayed finite-part formula; the second has decay \(\langle\xi\rangle^{-a}\), square-integrable because \(a>1/2\); the exterior has arbitrary decay from the cutoff convolution. Derivatives of \(b_\pm(\xi/|\eta|^A)\) and the sector cutoff are uniformly bounded. Thus the vertical contribution, after localization, lies in
\[
H^r_{\rm loc}\quad\text{for }r<q-\tfrac12.
\]
Both vertical bounds exceed \(s_1\).

Compactly supported frequency distributions have smooth inverse Fourier transforms. Combining this observation, (7), and (8) proves
\[
\boxed{\quad h=h_{\rm reg}+\chi K_f+h_{\rm rem},
\qquad h_{\rm reg}\in C^\infty,\qquad
h_{\rm rem}\in H^r_{\rm loc}\quad(r<s_1).\quad}                 \tag{9}
\]
Here \(\chi=1\) on a neighborhood of the origin. For example, \(r=21/4=5.25\) is valid and makes the remainder locally \(C^{4,\varepsilon}\) for every \(0<\varepsilon<1/4\).

An explicit decomposition follows by choosing a frequency cutoff \(\kappa=1\) near zero, taking
\[
\widehat h_{\rm reg}=\kappa(\widehat h-\widehat K_f)
 +(1-\kappa)E_f,
\]
and using
\[
(1-\kappa)
\bigl[\operatorname{fp}|\xi|^{-a}-|\zeta|^{-a}\bigr]B_f
\]
for the remainder before the spatial cutoff is inserted.

## 4. Sharp Sobolev and Hölder regularity

On horizontal dyadic shells \(N\le|\xi|\le2N\), the squared \(H^r\) contribution of \(K_f\) is bounded by
\[
C N^{2r-2\beta+1+1/A}=C N^{2(r-s_f)}.                         \tag{10}
\]
If \(B_f\ne0\), choose a compact angular interval away from \(\theta=0\) on which \(C_\pm\ne0\). The same expression is bounded below there. Multiplication by a spatial cutoff equal to one at the origin preserves the leading amplitude on this interval: Fourier convolution changes \(\xi\) and \(\eta\) by bounded amounts, hence changes the normalized amplitude by \(o(1)\). Large convolution shifts are negligible by Schwartz decay. Therefore the critical dyadic contributions do not tend to zero, proving
\[
B_f\ne0\quad\Longrightarrow\quad h\notin H^{s_f}_{\rm loc}
\text{ at the origin}.                                      \tag{11}
\]

The \(L^1\) Fourier bound on the same shells is
\[
C N^{1+1/A-\beta}=C N^{-p}.
\]
The vertical sector is much smoother. Summing dyadic blocks after three derivatives, and bounding a difference of spatial size \(\ell\) by the factor \(\min(1,N\ell)\), gives
\[
\sum_N N^{3-p}\min(1,N\ell)\le C\ell^{p-3}.
\]
This proves the endpoint assertion
\[
h\in C^{3,\alpha_*}_{\rm loc},\qquad
\alpha_*=p-3=0.0292900353562916.                              \tag{12}
\]

If \(B_f\ne0\), \(F_f\) cannot be a polynomial of degree at most three. Otherwise \(K_f\) would be polynomial in \(s\), its Fourier transform would be supported on \(\xi=0\), and (5) would force \(B_f=0\) off that axis. Choose \(z_1,z_2\) with \(F_f'''(z_1)\ne F_f'''(z_2)\). Homogeneity gives
\[
\partial_s^3K_f(\varepsilon^Az_i,\varepsilon)
=\varepsilon^{d-3A}F_f'''(z_i).
\]
The distance of these two points is \(\varepsilon^A|z_1-z_2|\). Their Hölder quotient diverges for every \(\alpha>\alpha_*\). The smooth term and the \(H^{21/4}\) remainder contribute only \(O(\varepsilon^A)\) to this difference and cannot cancel it. Thus the endpoint in (12) is exact for nonzero \(B_f\); in particular \(h\notin C^4\) near the origin.

## 5. An explicit forcing and the derivative trace

Let
\[
b(t)=\begin{cases}e^{-1/(1-t^2)},&|t|<1,\\0,&|t|\ge1,\end{cases}
\quad
\phi(s,y)=b(s)b(y),\quad
\psi=\phi*\widetilde\phi,\quad f=\partial_y\psi,
\]
where \(\widetilde\phi(X)=\phi(-X)\). Then \(f\) is compactly supported, smooth, even in \(s\), odd in \(y\), and
\[
\widehat f(\xi,\eta)=i\eta|\widehat\phi(\xi,\eta)|^2.
\]
For \(\theta>0\),
\[
C_+(\theta)=i\theta
\int_0^\infty r^q(r^{2A}+\theta^2r^2)^{a/2}
|\widehat\phi(r^A,\theta r)|^2\,dr.
\]
The integral is strictly positive, since \(\widehat\phi(0)>0\). Hence \(B_f\ne0\), proving all the failures of regularity in (11)--(12) for an explicit allowed forcing.

For even-\(s\) data, partial Fourier inversion and (4) give
\[
\mathcal F_s[\partial_yK_f(\cdot,0)](\xi)
=-\frac{i}{2\pi}|\xi|^{-1-\gamma}
\int_{\mathbb R}\theta C_+(\theta)\,d\theta,\qquad\gamma=g/A.
\]
This identity is understood by homogeneous extension at \(\xi=0\); possible polynomial ambiguities disappear by the noninteger homogeneity. Define
\[
J=-i\int_{\mathbb R}\theta C_+(\theta)\,d\theta.
\]
For the explicit forcing \(J>0\), and
\[
\partial_yK_f(s,0)=c|s|^\gamma,\qquad
c=\frac{J}{-4\pi\Gamma(1+\gamma)\sin(\pi\gamma/2)}\ne0.        \tag{13}
\]
The trace of the remainder in (9), with \(r=21/4\), is \(C^{3,\varepsilon}\) after one \(y\)-derivative for every \(\varepsilon<1/4\). Therefore
\[
\partial_yh(s,0)=P_2(s)+c|s|^{2.9307749066}
                    +O(|s|^3),                              \tag{14}
\]
where \(P_2\) is even and of degree at most two. The trace does not generally equal a pure power without subtracting this smooth jet.

For other forcings, the scalar \(c\) can vanish even when the whole profile does not. Thus a nonzero trace coefficient is sufficient, not necessary, for a nonzero profile.

## 6. Adjoint obstructions and genericity

For \(w\in C_c^\infty(\mathbb R\setminus\{0\})\), on the positive-\(\xi\) branch define
\[
\ell_w(f)=\int C_+(\theta)w(\theta)\,d\theta.
\]
In coordinates \(\xi=r^A,\eta=r\theta\), the Jacobian is \(Ar^A\). Accordingly the associated dual Fourier density is, up to conjugation conventions,
\[
\widehat v_w(\xi,\eta)
=\frac1A|\zeta|^a r^{1-a}w(\theta),\qquad \xi>0.              \tag{15}
\]
It satisfies
\[
\widehat{L^*}v_w=(D-1-gm)\widehat v_w=0,
\]
because \(D\log|\zeta|=1+(A-1)m\). Its squared homogeneous \(H^{-\sigma}\) norm is controlled by
\[
\int_0^\infty r^{A+2-2a}|\delta_r(1,\theta)|^{2a-2\sigma}\,dr
\]
on a compact angular set away from zero. At infinity the radial power is \(A+2+2g-2A\sigma\); at zero it is \(A+2-2\sigma\). Thus it belongs to the dual space precisely in the two relevant directions when
\[
s_f<\sigma<(A+3)/2.
\]
Choose the angular parity and the negative-\(\xi\) branch to respect the imposed physical parities.

These are actual adjoint-kernel functionals, not merely a dimension analogy. Integration by parts in (2) also directly gives \(\ell_w(Lu)=0\) for smooth rapidly decreasing \(u\). Arbitrarily many independent \(w\)'s give independent distributions (15) and hence independent functionals on compactly supported smooth data. Vanishing of all angular tests is equivalent to \(B_f=0\).

If \(B_f=0\), (7) shows that \(\widehat h\) decreases faster than every power at high frequency, so \(h\in H^N\) for every \(N\) and is smooth. Conversely (11) excludes local smoothness at the origin when \(B_f\ne0\). Therefore
\[
h\text{ smooth near }0\quad\Longleftrightarrow\quad B_f=0
\quad\Longleftrightarrow\quad F_f=0.                          \tag{16}
\]
The exceptional forcing space is closed and of infinite codimension in the smooth test-function space. Its complement is open and dense: continuity follows from the Schwartz seminorm bounds in (2), and a proper linear subspace has empty interior.

## 7. Residual of the cusp and smooth approximation

Homogeneity implies \((T-d)K_f=0\). Hence, where \(\chi=1\),
\[
L(\chi K_f)=g(1-M)(\chi K_f).
\]
In the horizontal sector, \(1-M=\eta^2/(\xi^2+\eta^2)\) supplies precisely the factor used in (8). The vertical sector has the already established higher regularity. Cutoff contributions from separated spatial supports are smooth locally: this follows from the off-diagonal smooth kernel of the high-frequency multiplier, while the low-frequency part is smoothing.

Consequently
\[
\boxed{\quad L(\chi K_f)\in H^r_{\rm loc}\quad
\text{for every }r<s_1=5.3815173422.\quad}                    \tag{17}
\]
For \(B_f\ne0\) the threshold is sharp: on a compact nonzero angular interval, its leading high-frequency coefficient is a nonzero multiple of \(\theta^2C_\pm(\theta)\), and the critical dyadic contributions again have a nonzero limit.

The gain is \(2A-2\) in the \(y\)-weight, or \(2-2/A\) in ordinary Sobolev order. It is not an arbitrarily large regularizing effect.

There is a precise below-threshold statement about smooth trials. If \(u\) is in the frozen graph domain in \(H^\sigma\), \(\sigma<s_f\), mollification gives smooth \(u_\varepsilon\) with
\[
u_\varepsilon\to u,\qquad Lu_\varepsilon\to Lu
\quad\text{in }H^\sigma.
\]
The multiplier \(M\) commutes with convolution. The Fourier symbol of the commutator of \(T\) with the mollifier is a uniformly bounded function tending pointwise to zero, so dominated convergence proves the second limit. Thus a singular exact solution can have smooth trials with arbitrarily small residual in these norms. This is compatible with the inverse estimate, because their errors also tend to zero in the same norm.

For a nonlinear residual map, one additionally needs differentiability and a nonlinear remainder estimate in the chosen graph/output spaces. The formal notation \(\mathcal F(T)\sim L(T-\rho_*)\) alone proves no estimate. Nor does (17) imply that ordinary mollification has small residual above \(s_f\): its transport commutator can retain the critical cusp scale, and the adjoint obstructions remain relevant.

## 8. Variable coefficients: what is conditional

For the exactly linear drift \(A s\partial_s+\mu y\partial_y\), constant gradient \((0,g)\), and \(\mu>0\), put
\[
a_\mu=\frac{g}{A-\mu},\quad Q_\mu=A+\mu,\quad
b_\mu=1+\frac{Q_\mu}{2}.
\]
The exact conjugation is
\[
\Lambda^{a_\mu}L\Lambda^{-a_\mu}
=A s\partial_s+\mu y\partial_y+(a_\mu\mu-1).
\]
The corresponding formulas are
\[
s_{f,\mu}=\frac{g+b_\mu}{A},\qquad
s_{\rm slow,\mu}=\frac{b_\mu}{\mu},\qquad
s_{1,\mu}=s_{f,\mu}+\frac{2(A-\mu)}A.
\]
For \(\mu\) close to one, all strict inequalities used above persist, and the frozen proof goes through. The cusp is
\[
\operatorname{sgn}(y)|y|^{(1+g)/\mu}
F\!\left(s/|y|^{A/\mu}\right).
\]
Its fast Hölder exponent remains \((1+g)/A\); the derivative trace exponent becomes \((1+g-\mu)/A\).

Knowing only the derivative of a variable drift at the source does not justify this expansion in the original coordinates. For example,
\[
V=(A s+c(2\mu-A)y^2,\ \mu y)
\]
has exactly the specified derivative at zero. Its linear coordinate is \(S=s-cy^2\), and \(V(S)=AS\). The slow invariant curve is \(s=cy^2\). Since \(2\mu<A\), its displacement is much larger than the proposed fast cusp width \(|y|^{A/\mu}\). Equivalently, the term \(y^2\partial_s\) has negative anisotropic order \(2\mu-A\); it is not a small perturbation of the frozen transport on an unshifted cusp.

For a variable-coefficient theorem one needs, at a minimum:

1. A source \(V(P)=0\), and adapted coordinates straightening the invariant geometry and linearizing the drift to sufficient anisotropic order; or an explicit normal form including resonances.
2. Preservation of the intended parity class.
3. A specified global realization and exterior data for the nonlocal velocity, together with the forward condition.
4. Quantitative control of the transformed order-zero operator in the fast frequency sector and of the complementary sector, with remainders that improve the required weighted regularity.
5. A proof that other singularities and boundary conditions do not contribute less regular terms; resonances must be checked if a polyhomogeneous expansion is sought.

Under an established normal-form/asymptotic theorem of this kind, the leading fast indicial exponent is determined by \(A,\mu,g\) at the source, whereas its profile depends on the full forcing, coefficients, and matching data. Smooth coordinate changes preserve the ordinary local Sobolev and Hölder exponents. The hypotheses in the question alone do not supply that theorem. In particular, the exact Fourier profile map, its infinite-dimensional range, and nonlinear genericity are not automatically inherited.

## 9. Admissible classes and the alleged one-dimensional cokernel

For the frozen forward inverse with compact smooth forcing, a nonzero profile gives membership in \(P_2\) and \(P_3\), including the endpoint \(C^{3,\alpha_*}\), and excludes \(P_4\). Smoothness is exactly the whole-profile condition (16), involving infinitely many independent linear functionals. This is a theorem about this forcing/solution map. It is only a conditional prediction for a nonlinear global profile problem: one must prove the corresponding expansion and that the globally admissible forcing family is not confined to its exceptional set.

The claimed local kernel \(y\) and cokernel \(f_y(0)\) belong to the scalar transport germ calculation for \(T-1\). They are not established for the full coupled nonlocal operator. In fact the asserted cokernel condition is false for this operator, even on compactly supported smooth input and output.

Choose an even cutoff \(\chi_0=1\) near zero and set
\[
k=\chi_0(s^2y-y^3/3),\qquad u=-\Delta k.
\]
Then \(u\) is compactly supported and smooth,
\[
Mu=-\partial_s^2k,\qquad
f=Lu=(T-1)(-\Delta k)+g\partial_s^2k
\]
is also compactly supported and smooth. The cubic is harmonic, so \(u=0\) on a whole neighborhood of zero. Nevertheless
\[
f=2gy,\qquad f_y(0)=2g\ne0.
\]
Thus smooth solvability of the coupled equation does not require \(f_y(0)=0\).

The exact jet identity for any sufficiently regular frozen coupled solution is
\[
f_y(0)=(\mu-1)h_y(0)-g(Mh)_y(0),
\]
and the last quantity depends on the whole function, not its local germ. Also \(y\) is not in the whole-plane Sobolev realization; treating \(My=0\) is a separate polynomial/exterior convention.

A conditional global index count of “overdetermined by one” is therefore neither established nor contradicted simply by the frozen infinite-dimensional obstruction space. Different domains and realizations can have different indices, and global matching may already restrict the data. One needs an actual Fredholm construction, specified exterior conventions, and the dependence of global matching data on the source profiles before comparing such counts.

## Verification and limitations

The displayed decimal constants were recomputed locally with Python `decimal` at 35-digit precision, with single-thread limits and a memory limit below 2 GB. No numerical computation is used as a substitute for a proof.

An actual request to `us.anthropic.claude-opus-5-5` through the existing Python Bedrock configuration failed before model invocation with `CredentialRetrievalError`: the configured `Ec2InstanceMetadata` credential source supplied no credentials. Thus no Opus review was obtained, and no substitute model review is claimed.

No JavaScript/TypeScript tooling, server, GPU, or RLScience cluster was used.
