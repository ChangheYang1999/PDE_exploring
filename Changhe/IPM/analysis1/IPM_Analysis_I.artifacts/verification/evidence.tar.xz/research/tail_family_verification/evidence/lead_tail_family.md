# Tail data, kernel and family: a conditional answer to "kernel, family or ill-conditioning" (PROMPT 5(ii), 5(vi))

Lead note, written 2026-10-20 (shift 1, after 17:25Z). Status: CONDITIONAL theorems with every hypothesis named;
proofs below; unverified, unaudited. Notation of SPEC v3.4 (sections 1, 4, 5) and notes/conormal_framework.md.

## 0. Summary
In the fixed-tail formulation F- the tail datum (exponent and angular profile of the non-decaying term) is a
well-defined functional of the solution (Lemma T). Consequently:
- (Theorem FL, linear) at an exact F- solution where the F- linearization is invertible, the linearization of the
  unnormalized problem on a P_2-type growth space has a kernel of infinite dimension: one element per admissible tail
  profile, modulo the single profile `Theta_1` of F-. The scaling tangent `K = rho - X.grad rho` is the element
  belonging to the solution's own profile, and it carries no change of exponent.
- (Theorem FN, nonlinear) if the F- closing inequality holds for all tail profiles in a ball, the exact solutions form
  an injectively parametrized family over an infinite-dimensional set of tail profiles. `c_l = 1/k'` along the
  family, and for a fixed tail profile the solution is unique in the T2N ball.
- So, conditionally, the soft `c_l` is a true family (P_2 solutions are not isolated), the linearization in P_2-type
  spaces has an infinite-dimensional kernel, and in the fixed-tail complement `c_l` is determined. Holding the leading
  angular profile fixed excludes genuine neighbouring solutions with other tails.
- Whether `c_l` actually varies along the family is the vanishing or not of one linear functional `delta k'` on the
  profile space (section 5). It vanishes on the scaling direction. It is not decided here.

## 1. Setting and hypotheses
Polar coordinates `r, theta`. `chi_far` is smooth with `chi_far = 0` for `r <= R_1` and `chi_far = 1` for `r >= 2 R_1`.
Profile space: `Tau` is a real Banach space of angular profiles `Phi(theta)` with the parity of the problem
(`Phi(pi - theta) = Phi(theta)`, `Phi(-theta) = -Phi(theta)`), continuously embedded in `L^2(S^1)`. Example (enough for
every statement below): `Tau_c :=` the profiles in `C^m(S^1)` with this parity that vanish near `theta in {0, pi/2, pi, 3pi/2}`
(supported away from both axes). `Tau_c` is infinite-dimensional. `Theta_1 in Tau` is the fixed F- profile and
`Theta_0` the trial's leading tail profile; `Theta_0` and `Theta_1` are linearly independent.

Far-field norm. X, the F- remainder space, embeds continuously into `L^2({r > 2 R_1}, r^{-2 gamma'} dX)` with
`gamma' = gamma_E + 1`, where `gamma_E < k - margin` is the allowed growth (conormal note 2.3). For a nonzero `Phi in L^2(S^1)`,
`r^q Phi(theta)` lies in `L^2({r > R}, r^{-2 gamma'} dX)` iff `q < gamma_E` (radial integral of `r^{2q - 2 gamma' + 1}`).

F- ansatz with profile `Theta`. `rho~^Theta_{k', tau} := (1 - chi_far) rho~ + chi_far [r^{k'} (Theta + tau Theta_1)
+ C(k', Theta)]`, where `C` collects the trial's fixed far corrections of order `r^{2k-1}`, which lie in X. The unknowns are
`(h, k', tau) in X x R x R`, and `rho = rho~^Theta_{k', tau} + h`. The forcing space is `Y_- (+) R`, where the scalar is the
coefficient of the non-decaying term. As in SPEC 4, for `rho` of this form
  `F(rho) = (c_l[rho] k' - 1) chi_far r^{k'} (Theta + tau Theta_1) + (element of Y_-)`, with `c_l[rho] = (1 + c[rho])/3`.
(Reason: `(c_l r d_r - 1)(r^{k'} Phi) = (c_l k' - 1) r^{k'} Phi`; `U[rho].grad rho = O(r^{2k'-1})`, the cutoff terms are
compactly supported, and the h terms decay; this is part of the F- mapping hypothesis (S1).)
In particular every exact solution of this form has `c_l[rho] = 1/k'`.

Named hypotheses.
- (S1) F- mapping. For every `Theta` in a ball `B_delta(Theta_0) subset Tau`, `F` maps the ansatz into `Y_- (+) R` as
  displayed, with the T2N structure of SPEC 5.
- (S2) Far mapping of tail increments. At the background considered, for every `Phi in Tau`,
  `L(chi_far r^{k'} Phi) = f_Phi + s_Phi chi_far r^{k'} (Theta + tau Theta_1)`, with `f_Phi in Y_-` and `s_Phi in R`
  depending continuously and linearly on `Phi`. (Heuristic content: `(c_l X.grad - 1)` annihilates `r^{k'} Phi` when
  `c_l k' = 1`; the terms `U[rho].grad(r^{k'} Phi)` and `U[r^{k'} Phi].grad rho` are `O(r^{2k'-1})`; the strain term
  `(c[r^{k'} Phi]/3) X.grad rho` gives `s_Phi`. The strain functional converges for `k' < 1` by the parity-symmetrized
  kernel, whose decay is `|X'|^{-3}`. The edge structure of `U[chi_far r^{k'} Phi].grad rho` near the axes must belong to
  `Y_-`; this is a G1/G4-type mapping statement and is NOT proved.)
- (S3) F- linear invertibility at an exact F- solution `rho_*` with tail data `(k_*, Phi_* = Theta + tau_* Theta_1)`. The map
  `(g, dk, dtau) -> L_*(g + dk chi_far r^{k_*} log r Phi_* + dtau chi_far r^{k_*} Theta_1)` is a bijection
  `X x R^2 -> Y_- (+) R chi_far r^{k_*} Phi_*`. Here `L_*` is the linearization at `rho_*`, and `d/dk'` of
  `r^{k'} Phi_*` is `r^{k'} log r Phi_*`. Also needed: the far corrections `C` are differentiable in `(k', Theta)` with
  values in X. This is the F- inverse, which is NOT proved.
- (S4) Uniform closure. For every `Theta in B_delta(Theta_0)` the T2N hypotheses and closing conditions of SPEC 5
  hold for the F- problem with profile `Theta`. The constants may depend on `Theta`.
- (S5) Continuity (only for the non-isolation statement). The T2N fixed point `(h_Theta, k'(Theta), tau(Theta))` depends
  continuously on `Theta` in `X x R^2`. A sufficient condition is the uniform contraction principle with parameters:
  the constants in (S4) are independent of `Theta`, and the iteration map is continuous in `Theta` for fixed iterate.

## 2. Lemma T (the tail datum is a functional of the solution)
Let `rho = chi_far r^{k_1} Phi_1 + g_1 = chi_far r^{k_2} Phi_2 + g_2` on `r > 2 R_1`, with `g_1, g_2` in
`L^2({r > 2 R_1}, r^{-2 gamma'} dX)`, `k_1, k_2 > gamma_E`, and nonzero `Phi_1, Phi_2 in L^2(S^1)`. Then `k_1 = k_2` and
`Phi_1 = Phi_2`. Log version (equal exponents): if `chi_far r^k (d_1 log r Psi + Phi_1) + g_1 = chi_far r^k (d_2 log r Psi + Phi_2) + g_2`
with `k > gamma_E`, `Psi != 0` fixed and `Phi_i in L^2(S^1)` arbitrary (possibly zero), then `d_1 = d_2` and `Phi_1 = Phi_2`.
Proof. Let `k_1 >= k_2` and suppose `k_1 > k_2`. The difference `r^{k_1} Phi_1 - r^{k_2} Phi_2 = g_2 - g_1` has angular
`L^2` norm at least `r^{k_1} (||Phi_1|| - r^{k_2 - k_1} ||Phi_2||) >= r^{k_1} ||Phi_1||/2` for large r. So its weighted
square integral dominates `int^inf r^{2 k_1 - 2 gamma' + 1} dr = infinity`, since `k_1 > gamma_E = gamma' - 1`. This is a
contradiction, so `k_1 = k_2`. Then `r^{k_1}(Phi_1 - Phi_2)` lies in the weighted space, which forces `Phi_1 = Phi_2`.
Log version: the angular norm of
`r^k [(d_1 - d_2) log r Psi + Phi_1 - Phi_2]` is at least `r^k (|d_1 - d_2| ||Psi|| log r - C)`, which is not square
integrable unless `d_1 = d_2`. QED.

## 3. Theorem FL (linear: infinite-dimensional kernel in P_2-type growth spaces)
Assume (S2) and (S3) at an exact F- solution `rho_*`. Let
`X_+ := X (+) {chi_far r^{k_*} Phi : Phi in Tau} (+) span{chi_far r^{k_*} log r Phi_*}`. Every element grows at most like
`r^{k_*} log r`, so `X_+` lies in every growth class `gamma` with `k_* < gamma < 1`. Then:
(a) For every `Phi in Tau` there is a unique `kappa(Phi) = chi_far r^{k_*} Phi + g + dk chi_far r^{k_*} log r Phi_* +
dtau chi_far r^{k_*} Theta_1` with `(g, dk, dtau) in X x R^2` and `L_* kappa(Phi) = 0`. The map `kappa` is linear and
continuous.
(b) `kappa(Phi) = 0` iff `Phi in span(Theta_1)`. Hence `dim ker(L_* on X_+) >= dim(Tau/span Theta_1) = infinity`.
(c) Scaling. Assume in addition that `K_* := rho_* - X.grad rho_*` satisfies
`K_* - chi_far (1 - k_*) r^{k_*} Phi_* in X`. This is a regularity hypothesis on `rho_*`: `X.grad` is a first-order
operator, so it needs one derivative of `rho_*` beyond the X norm away from the axes and near P (the b-derivatives
`x d_x`, `y d_y` at the axes are harmless), and `C - X.grad C`, `h_* - X.grad h_*` in X at infinity. Then
`K_*` is in `X_+`, with tail profile `(1 - k_*) Phi_*`. It equals `kappa((1 - k_*) Phi_*)`, and its
`dk`-component is 0 (the scaling direction does not change `c_l`). Moreover `c[K_*] = 0`.
Proof. (a) By (S2), `L_*(chi_far r^{k_*} Phi) = f_Phi + s_Phi chi_far r^{k_*} Phi_*` lies in `Y_- (+) R chi_far r^{k_*} Phi_*`.
By (S3) there is a unique `(g, dk, dtau)` with `L_*(g + dk ... + dtau ...) = -L_*(chi_far r^{k_*} Phi)`.
Linearity and continuity follow from those of `Phi -> (f_Phi, s_Phi)` and of the inverse.
(b) If `kappa(Phi) = 0`, the far field gives `chi_far r^{k_*}(Phi + dtau Theta_1) + dk chi_far r^{k_*} log r Phi_* = -g`,
which lies in X. Lemma T (log version) gives `dk = 0` and then `Phi + dtau Theta_1 = 0`. Conversely,
`kappa(Theta_1) = 0` by uniqueness, since `chi_far r^{k_*} Theta_1` is itself the `dtau` direction: `(g, dk, dtau) = (0, 0, -1)`
solves the equation. The induced map `Tau/span Theta_1 -> ker L_*` is therefore injective.
(c) Exact scaling covariance (VERIFIED, SPEC 3.5) gives `L_* K_* = 0` at an exact solution, together with `c[K_*] = 0`.
Its far field is `chi_far (1 - k_*) r^{k_*} Phi_* + (C - X.grad C) + (h_* - X.grad h_*) + (compact cutoff terms)`
(`X.grad r^{k_*} Phi_* = k_* r^{k_*} Phi_*`). By the added hypothesis, `K_* in X_+` with `dk = dtau = 0`. Uniqueness in (a) gives `K_* = kappa((1 - k_*) Phi_*)`. QED.

## 4. Theorem FN (nonlinear: a family of exact solutions parametrized by tail profiles)
Assume (S1) and (S4). For `Theta in B_delta(Theta_0)` let `rho_Theta = rho~^Theta_{k'(Theta), tau(Theta)} + h_Theta` be
the exact solution given by T2N. It is unique in its T2N ball for the problem with profile `Theta`. Write
`Z` for a closed complement of `span(Theta_1)` in `Tau`. Assume `K_H eta(Theta)` is small enough that
`Theta + tau(Theta) Theta_1 != 0` (for example `|tau(Theta)| ||Theta_1|| < ||Theta||`). Then:
(a) Every `rho_Theta` is an exact solution with `c_l[rho_Theta] = 1/k'(Theta)`.
(b) Injectivity. If `Theta, Theta' in (Theta_0 + Z) cap B_delta(Theta_0)` and `rho_Theta = rho_Theta'`, then `Theta = Theta'`.
(c) Scale. The exact rescaling `rho -> a rho(X/a)` maps exact solutions to exact solutions and multiplies the tail
profile by `a^{1 - k'}`. After normalization to `J = 1` the family is injectively parametrized by the profiles modulo
`span(Theta_1)` and modulo positive multiples, which is still infinite-dimensional when `Tau` is.
(d) Non-isolation. Under (S5), for every `gamma in (k, 1)` and every `epsilon > 0`, there is `Theta != Theta_0` with
`rho_Theta` within `epsilon` of `rho_{Theta_0}` in the weighted growth norm `sup (1 + r)^{-gamma}(|.| + (1 + r)|grad .|)`
(provided X embeds into that norm). So the exact solution `rho_{Theta_0}` is not isolated in any P_2-type topology. For
fixed `Theta` it is unique in the F- ball.
Proof. (a) is the scalar equation of section 1. (b) On `r > 2 R_1`,
`rho_Theta = chi_far r^{k'}(Theta + tau Theta_1) + (C + h_Theta)`, and `C + h_Theta` lies in the weighted space. Lemma T gives
`k'(Theta) = k'(Theta')` and `Theta + tau Theta_1 = Theta' + tau' Theta_1`. So `Theta - Theta' in span(Theta_1) cap Z = {0}`.
(c) This is direct substitution: `F(rho_a) = (F rho)_a`, which is VERIFIED (SPEC 3.5). The tail
`a (r/a)^{k'} Phi = a^{1-k'} r^{k'} Phi`. (d) The difference is
`rho_Theta - rho_{Theta_0} = chi_far [r^{k'(Theta)}(Theta + tau Theta_1) - r^{k'(Theta_0)}(Theta_0 + tau_0 Theta_1)]
+ (C(Theta) - C(Theta_0)) + (h_Theta - h_{Theta_0})`. The bracket tends to 0 in the growth-`gamma` norm as `Theta -> Theta_0` in a
`C^1` profile norm, by (S5) and `|r^{k_1} - r^{k_2}| <= |k_1 - k_2| r^{max k} log r`. The other terms tend to 0 by (S5) and
the embedding. QED.

## 5. Does `c_l` vary along the family?
Linearize (S4)-(S5) along a `C^1` curve `Theta(epsilon) = Theta_0 + epsilon Phi`. Then `d rho/d epsilon = kappa(Phi)` of
Theorem FL, with `dk = d k'/d epsilon`, and `d c_l/d epsilon = -c_l^2 dk = c[kappa(Phi)]/3`. Define the functional
`ell(Phi) := dk(kappa(Phi))` on `Tau`. Then:
- `ell(Theta_1) = 0` and `ell(Phi_*) = 0`, the latter by Theorem FL(c): scaling does not change `c_l`.
- `c_l` is locally constant on the family iff `ell = 0` on `Tau`.
- `ell` is computable from the F- linear inverse alone: `ell(Phi) = -pi_k L_F^{-1} [L_*(chi_far r^{k_*} Phi)]`.
No exact identity forcing `ell = 0` is known. It is decided by the F- linear solve, which is not available. A floating
finite-section version of this solve is the experiment that distinguishes "c_l varies along the family" from "c_l is
rigid on the family" (FINAL_REPORT section 10, next step 1).

## 6. Answer to PROMPT 5(ii) and 5(vi) (conditional on (S1)-(S5))
- Kernel. In P_2-type growth spaces (`k < gamma < 1`) the linearization at an exact solution has an infinite-dimensional
  kernel (Theorem FL). An isolated-kernel picture is therefore wrong in P_2. In the fixed-tail space F- it is
  invertible by assumption (S3).
- Family. The exact solutions near X3 in P_2, if F- closes on a ball of profiles, form an infinite-dimensional family
  parametrized by far-field angular data (Theorem FN). `c_l = 1/k'` along it. Holding the leading `Theta_0` fixed
  excludes these genuine neighbouring solutions.
- Ill-conditioning. A numerical method that does not fix the tail sees the family directions as near-null directions.
  This is consistent with the first run's equal-residual states with `c_l` between 5.29 and 5.60 and far-field softest
  directions, but that observation is floating point and is not evidence for `ell != 0`.
- Scope. The family lives in the mixed class (below threshold at P, free tails). In classes smooth at P with free
  tails, the conditional count is index -1 (SPEC 3.7), and no family is expected there. `P_infty` adds the centre
  conditions `B_b = 0` (`b = 3, 5, ...`): countably many scalar conditions on the family. Whether they can be met is not
  decided; it would need continuity of the `B_b` on the F- spaces and a transversality statement, neither of which is
  proved.

## 7. What is new and what is assumed
New (proved here, elementary): Lemma T; the injectivity and kernel-dimension arguments; the scaling identification;
the formula for `d c_l` along the family. Assumed: the F- mapping and inverse ((S1)-(S3)), uniform closure (S4) and
continuity (S5). These assumptions are the main open problem of the run, so these theorems are not endpoints. They
fix what an endpoint in the F- formulation would mean for P_2: a YES there is one member of a family, never an
isolated solution.
