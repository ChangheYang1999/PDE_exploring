# Double Taylor splitting at the corner and the corner coupling (gap G1, corner part)

Lead note, revision 1, 2026-10-20T18:59Z. Source: referee answer corner1 (single-model; it derived the statements
below from the question, it did not audit an existing lead proof) plus the lead's own checks (section 7). Verifier check
V14 refers to this note. Status of each item is given in brackets: [P] proof given below or in the cited referee
derivation and checked by the lead as indicated; [R] refutation with explicit counterexample; [C] conditional.
Nothing here is used in a conclusion of FINAL_REPORT.md until V14 confirms it.

## 0. Summary
- (Lemma D, double remainder) [P] On the product weight `w_{a,b} = |x|^{-2a}|y|^{-2b}` with `N_x - 1/2 < a < N_x + 1/2`,
  `N_y - 1/2 < b < N_y + 1/2`, the double Taylor remainder `R_i = T_x^{N_x} T_y^{N_y} U_i` is bounded on `L^2_{a,b}`, with an
  explicit (very conservative) constant and with no restriction on `A := a + b`. The b-derivative version holds.
- (Rectangular corner subtraction) [R] Subtracting only the corner monomials `l < N_x` (resp. `j < N_y`) from a face trace
  does not give a bounded weighted trace in general; the correct global subtraction removes all parity-allowed powers
  below the homogeneity threshold `t_j = A - j - 1`. In the working window (`8 < A < 10`) 7 of the 9 rectangular traces
  fail. Resonance: when `A` is an even integer no global subtraction works (in this parity class).
- (Corner coefficients) [P] No nonzero corner coefficient `c_{i,l,j}` is bounded on the global pure-power space; on
  unit-box data `c_{i,l,j}` (degree `k = l + j`) is bounded iff `A > k + 1`, with an explicit dual-norm bound; on the
  composite weight `w_{a,b}(1 + |X|)^{2(A - gamma')}` iff `A > k + 1` and `gamma' < k + 1` (exact dual norm).
- (Corner coupling) [P for unit-box data, C in general] For `rho = x^2 y alpha` near the corner (`alpha` even in x and in y,
  automatic in the parity class) the coupling decomposes as `y q_1(x) + x^2 q_2(y) + x^4 q_4(y) - J_c x^2 y - K_c x^4 y + f_rem`
  with explicit edge coefficients, `J_c = 0` identically, `K_c = -alpha(0,0) c_{1,3,0} - (4/3) c alpha_2(0)`, and
  `||f_rem||_{L^2(B_{1/2}, w_{a,b})} <= C ||alpha||_{C^8} ||h||_{L^2_{a,b}}` for data supported in the unit box. The
  degree-7 velocity coefficient is not controlled by the global pure weight (explicit unbounded family); it is controlled
  on unit-box data and on the composite weight with `1 < gamma' < 2`.

## 1. Setting and notation
`h` real, even in x, odd in y; `U = (U_1, U_2)` the canonical IPM velocity (multipliers `xi eta/|zeta|^2`, `-xi^2/|zeta|^2`);
off the support `U_2 + i U_1 = (1/2pi) int h(W) (z - W)^{-2} dA(W)`. `L^2_{a,b} = L^2(R^2, w_{a,b} dX)`, `A = a + b`.
`P_x F = sum_{l < N_x} x^l d_x^l F(0, y)/l!`, `P_y F = sum_{j < N_y} y^j d_y^j F(x, 0)/j!`, `T_x = I - P_x`, `T_y = I - P_y`.
Dense class `D = C^inf_c(R^2 minus the axes)` with the parity. Face traces `u_{i,j}(x) = d_y^j U_i(x, 0)/j!`,
`v_{i,l}(y) = d_x^l U_i(0, y)/l!`, corner coefficients `c_{i,l,j} = d_x^l d_y^j U_i(0, 0)/(l! j!)`. Strain `c = -d_x U_1(0)`.
Working parameters: `a in (5.5, 6.5)`, `b in (2.5, 3.5)` (`N_x = 6`, `N_y = 3`), e.g. `(a, b) = (6.45, 3.07)`, `A = 9.52`.
On completion all jets and coefficients are canonical moment coefficients or Sobolev traces, not classical derivatives of
arbitrary weighted data (compare notes/yface_collar.md 1.3).

## 2. Lemma D (double remainder) [P]
Let T be a convolution operator bounded on `L^2(R^2)` whose kernel off 0 is smooth, homogeneous of degree `-2`, with
`|d_1^p d_2^q K(Z)| <= D_{pq} |Z|^{-2-p-q}` (a multiple of the identity allowed). Both IPM components qualify, with
`D_{pq} <= (p+q+1)!/(2 pi)` and `||T||_{2->2} <= 1`; the local term of `U_2` has vanishing Taylor projections on D.
(D1) With dyadic blocks `Q_{kl} = E_k x E_l`, `E_k = {2^k <= |t| < 2^{k+1}}`, and
  `Phi_N(d) = 2^{(N+1/2) d}` (`d <= -3`), `1` (`|d| <= 2`), `2^{(N-1/2) d}` (`d >= 3`):
  `||1_{Q_{kl}} T_x^N T_y^M T 1_{Q_{pq}}||_{2->2} <= B_{NM} Phi_N(k - p) Phi_M(l - q)`.
  Proof (referee derivation, checked by the lead for structure): separated scales in a coordinate give the one-dimensional
  factor `X^N S^{-N-1}` (`X <= S/8`) or `X^{N-1} S^{-N}` (`X >= 8S`) via Taylor's integral remainder and
  `|Z|^{-2-p-q} <= |Z_1|^{-1-p}|Z_2|^{-1-q}`; a comparable coordinate is integrated out with
  `int |d_2^q K(s, t)| ds <= pi D_{0q} |t|^{-1-q}`; single-face and corner-polynomial terms in comparable blocks are bounded
  by `S^{l+1} T^{j+1}/(S^2 + T^2)^{(l+j+2)/2} <= 1`, uniformly in the aspect ratio.
(D2) Conjugating by the weight gives the sequence kernel `2^{-a(k-p)} Phi_{N_x}(k-p) 2^{-b(l-q)} Phi_{N_y}(l-q)`, summable
  exactly under the two strict windows; discrete Young gives `||R_i h||_{L^2_{a,b}} <= C_{a,b} ||h||_{L^2_{a,b}}` with
  `C_{a,b} = 2^{2(|a|+|b|)} B_{N_x N_y} L_{N_x}(a) L_{N_y}(b)`, `L_N(a) = 5 * 2^{2|a|} + 1/(1 - 2^{-(N+1/2-a)}) + 1/(1 - 2^{-(a-N+1/2)})`,
  `B_{NM} = 2^{12(N+M+2)} (N+M+2)! [1 + sum_{d<=N+M+2} (d+1)(d+1)!/(2 pi)]`.
  Floating evaluation (lead): `log10 C_{a,b} = 69.2` at `(6.45, 3.07)`, `69.7` at `(6.495, 3.403)`. Effective, useless for
  a closing inequality.
(D3) Endpoints: the strict inequalities are used only in the two geometric series per coordinate. At `a = N_x + 1/2` a
  nonzero first remaining term `x^{N_x} g(y)` diverges logarithmically at 0; at `a = N_x - 1/2` (`N_x >= 1`) a nonzero top
  subtracted term `x^{N_x - 1} g(y)` diverges at infinity; the same in y. Which component carries the offending jet depends
  on parity; at `N_y = 0`, `b = -1/2` the oddness in y gives an extra cancellation (that endpoint is not obstructed).
(D4) b-derivatives [P]: `D_x = x d_x`, `D_y = y d_y` commute with the Taylor projections, `[D_x, T]` has multiplier
  `-xi d_xi m` (kernel `(1 + z_1 d_1) K`), and
  `D_x^m D_y^n R_i h = sum_{p<=m, q<=n} binom(m,p) binom(n,q) T_x^{N_x} T_y^{N_y} T_{pq} D_x^{m-p} D_y^{n-q} h`,
  `T_{pq}` with multiplier `(-xi d_xi)^p (-eta d_eta)^q m_i`; (D1)-(D2) apply to each `T_{pq}`.

## 3. Face traces near the corner
(T1) [R] Rectangular subtraction. Let `u~_{i,j} = u_{i,j} - sum_{l < N_x} c_{i,l,j} x^l`, `beta_j = A - j - 1/2`,
  `t_j = A - j - 1`, and `p_{i,j}` the first parity-allowed x-power `>= N_x` (odd for `U_1`, even for `U_2`). For a nonzero
  trace, `||u~_{i,j}||_{L^2(|x|^{-2 beta_j})} <~ ||h||_{L^2_{a,b}}` iff `A < p_{i,j} + j + 1` (equality fails logarithmically);
  similarly for `v~_{i,l}` with `A < l + p^_{i,l} + 1`. Homogeneity forces the exponent `beta_j`. In `8 < A < 10`:
  | trace | first remaining power | bound |
  | `u~_{1,0}` | `x^7` | fails |  | `u~_{1,2}` | `x^7` | holds |  | `u~_{2,1}` | `x^6` | fails |
  | `v~_{1,1}` | `y^4` | fails |  | `v~_{1,3}` | `y^4` | fails |  | `v~_{1,5}` | `y^4` | holds |
  | `v~_{2,0}` | `y^3` | fails |  | `v~_{2,2}` | `y^3` | fails |  | `v~_{2,4}` | `y^3` | fails |
  Counterexample: `h in D` even, unit-box supported, with `c_{1,7,0} != 0`; then `u~_{1,0} = c_{1,7,0} x^7 + O(x^9)` and
  `int_0^eps x^{15 - 2A} dx = inf` for `A >= 8`.
(T2) [P] Correct global subtraction: `u^nat_{i,j} = u_{i,j} - sum_{l < t_j, parity-allowed} c_{i,l,j} x^l`. If `t_j` is not a
  parity-allowed power, `||u^nat_{i,j}||_{T_{beta_j, sigma_j}} <~ ||h||_{L^2_{a,b}}`, `sigma_j = b - j - 1/2`, in the annular
  Sobolev space `||g||^2_{T_{beta,sigma}} = sum_k 2^{k(1 - 2 beta)} ||g(2^k .)||^2_{H^sigma(1 < |s| < 2)}`; the same for
  `v^nat_{i,l}` (exponent `A - l - 1/2`, regularity `a - l - 1/2`). Proof by radial dyadic decomposition of the source
  (comparable annuli by W1(b) after scaling; `R >> r` gives `(r/R)^{p - t_j}`; `R << r` gives `(R/r)^{t_j - l}`).
(T3) [R] Resonance: if `l + j = A - 1` is a nonzero allowed corner degree, keeping that power diverges at 0 and
  subtracting it diverges at infinity. In this parity class all nonzero corner degrees are odd, so this happens exactly for
  `A` an even integer. The working value `A = 9.52` is non-resonant; `A` must stay away from 8 and 10.
(T4) [P] Local version, unit-box data: `||u~_{i,j}||_{L^2(|x| < 1/2, |x|^{-2 beta})} <~ ||h||_{L^2_{a,b}}` whenever
  `beta <= beta_j` and `beta < p_{i,j} + 1/2`; in the working window the canonical traces satisfy
  `||u_{i,j}||_{H^{b-j-1/2}(R)} <~ ||h||`, `||v_{i,l}||_{H^{a-l-1/2}(R)} <~ ||h||` (inhomogeneous; the finite normal support gives
  the low-frequency bound). This is consistent with the dilation obstruction of weighted_velocity 4.2 (expanding
  dilations leave the unit box).
Consequence for the subtraction orders at `(a, b) = (6.45, 3.07)`: the parity-allowed powers removed globally are
  `u_{1,0}`: `x, x^3, x^5, x^7`; `u_{1,2}`: `x, x^3, x^5`; `u_{2,1}`: `1, x^2, x^4, x^6`;
  `v_{1,1}`: `1, y^2, y^4, y^6`; `v_{1,3}`: `1, y^2, y^4`; `v_{1,5}`: `1, y^2`;
  `v_{2,0}`: `y, y^3, y^5, y^7`; `v_{2,2}`: `y, y^3, y^5`; `v_{2,4}`: `y, y^3`.
  So corner coefficients of total degree up to 7 enter the face expansions, beyond the rectangle `l < 6, j < 3`.

## 4. Corner coefficients
(K1) [P] Near 0, `U_2 + i U_1 = i sum_{k odd} d_k z^k`, `d_k` real (so `U_1 = sum d_k Re z^k`, `U_2 = -sum d_k Im z^k`,
  `d_1 = -c`); nonzero `c_{i,l,j}` only for `U_1`: l odd, j even; `U_2`: l even, j odd. The kernel of `c_{i,l,j}` is, up to
  sign, `L_{lj} r^{-k-2} sin((k+2) theta)`, `L_{lj} = (k+1) binom(k, l)/(2 pi)`, `k = l + j` (from
  `(z - W)^{-2} = sum_k (k+1) z^k W^{-k-2}` and the parity of h).
(K2) [P] Dilations `h_R = F(X/R)`: `||h_R||_{a,b} = R^{1-A} ||F||_{a,b}`, `c[h_R] = R^{-k} c[F]`; so no nonzero corner
  coefficient is bounded on the global pure-power space (`k < A - 1`: expanding; `k > A - 1`: shrinking; `k = A - 1`:
  summed dyadic annuli).
(K3) [P] Unit-box data: with `J_k(a,b) = int_0^{2pi} |cos|^{2a} |sin|^{2b} sin^2((k+2) theta) d theta <= 2 B(a + 1/2, b + 1/2)`,
  `|c_{i,l,j}[h]| <= L_{lj} [J_k(a,b) (sqrt 2)^{2(A-k-1)}/(2(A-k-1))]^{1/2} ||h||_{L^2_{a,b}}` iff `A > k + 1` (Cauchy-Schwarz;
  the unit box lies in `r < sqrt 2`). All rectangular corner coefficients satisfy this since `l + j <= N_x + N_y - 2 < A - 1`;
  the degree-7 coefficients need `A > 8`.
(K4) [P] Composite weight `w = w_{a,b} (1 + r)^{2(A - gamma')}`: a nonzero coefficient is bounded iff `A > k + 1` and
  `gamma' < k + 1`, with exact dual norm `L_{lj} [J_k(a,b) B(2(A-k-1), 2(k+1-gamma'))]^{1/2}`. Strain (`k = 1`): `gamma' < 2`.
  Defining the whole canonical symmetrized velocity still requires `gamma' < 2`.

## 5. The corner coupling [P for unit-box data under the stated hypotheses; C otherwise]
Hypotheses: `rho = x^2 y alpha` near the corner, `alpha in C^8` even in x and in y. In the parity class this evenness is
automatic: `alpha = rho/(x^2 y)` with rho even in x and odd in y (the referee's counterexample `alpha + x y^2` leaves the
class). The remaining hypothesis is the regularity `alpha in C^8` near 0, which must be verified for the trial (open).
Put `r(x) = x^2 alpha(x, 0)`, `alpha_0(y) = alpha(0, y)`, `alpha_2(y) = alpha_xx(0, y)/2`. Edge coefficients:
  `q_1 = r' (u_{1,0} + c x/3) + r (u_{2,1} + c/3)`,
  `q_2 = 2 y alpha_0 (v_{1,1} + c/3) + (alpha_0 + y alpha_0') (v_{2,0} + c y/3)`,
  `q_4 = 2 y alpha_0 v_{1,3} + 4 y alpha_2 (v_{1,1} + c/3) + (alpha_0 + y alpha_0') v_{2,2} + (alpha_2 + y alpha_2') (v_{2,0} + c y/3)`.
With `G := W[h].grad rho` (even in x, odd in y, `G(0, y) = 0`), `P_y G = y q_1(x)`, `P_x G = x^2 q_2 + x^4 q_4`,
`P_x P_y G = J_c x^2 y + K_c x^4 y`, `J_c = [x^2] q_1 = [y] q_2`, `K_c = [x^4] q_1 = [y] q_4`, and
  `G = y q_1(x) + x^2 q_2(y) + x^4 q_4(y) - J_c x^2 y - K_c x^4 y + f_rem`,  `f_rem := T_x^6 T_y^3 G`,
  `J_c = 0` identically,  `K_c = -alpha(0,0) c_{1,3,0} - (4/3) c alpha_2(0)`.
(`W_1 = -(2/3) c x + O(|X|^3)`, `W_2 = (4/3) c y + O(|X|^3)` annihilates `x^2 y`; this is the centre normalization `c_l`
built into F, seen at the level of the linearization.) For h supported in the unit box,
  `||f_rem||_{L^2(B_{1/2}, w_{a,b})} <= C_{a,b} ||alpha||_{C^8} ||h||_{L^2_{a,b}}`,
proved by inserting `U_i = R_i + sum_j y^j u~_{i,j} + sum_l x^l v~_{i,l} + sum c_{i,l,j} x^l y^j` into `T_x^6 T_y^3 (W.grad rho)`:
the `R_i` terms by Lemma D; the u-trace terms are smooth multiples of `x y^3 u~_{1,0}`, `x y^3 u~_{1,2}`, `x^2 y^3 u~_{2,1}`
(T4 with `beta = a - 1, a - 1, a - 2`); the v-trace terms smooth multiples of `x^6 y v~_{1,l}` (l = 1, 3, 5) and
`x^6 v~_{2,l}` (l = 0, 2, 4) (exchanged T4 with `beta = b - 1`, `b`); the corner-polynomial and projected strain terms by
`C ||alpha||_{C^8} (sum |c_{i,l,j}| + |c|) |x|^6 |y|^3` with (K3) (degrees up to 7); and
`int_{-1/2}^{1/2} |x|^{12-2a} dx = 2 (1/2)^{13-2a}/(13 - 2a)`, `int_{-1/2}^{1/2} |y|^{6-2b} dy = 2 (1/2)^{7-2b}/(7 - 2b)`.
For constant alpha: `f_rem = alpha_0 [2 x y T_x^5 T_y^2 U_1 + x^2 T_x^4 T_y^3 U_2]` (Lemma D with `(a-1, b-1)` and `(a-2, b)`).
Limitations: (i) the strain term `(c/3) X.grad rho` cannot be dropped (it cancels the `x^2 y` term, enters `K_c`, and enters
`f_rem` for nonconstant alpha). (ii) [R] Without support or far-field control the remainder is unbounded on the global pure
weight even for `rho = x^2 y`: a degree-7 velocity term `i d_7 z^7` gives `T_x^6 T_y^3 (2 x y U_1 + x^2 U_2) = -7 d_7 x^6 y^3`, and
`h_R = R^{A-1} F(X/R)` (`||h_R||_{a,b} = ||F||_{a,b}`, `d_7[F] != 0`) gives `f_rem[h_R] = -7 d_7[F] R^{A-8} x^6 y^3 + O(R^{A-10})`,
unbounded since `A > 8` (exponent 1.52 at `A = 9.52`). On the composite weight with `1 < gamma' < 2` the degree-7 coefficient
is bounded by (K4), and a near/far splitting gives the local analogue of the bound.

## 6. Consequences for the framework (lead assessment, not a theorem)
- The corner chart of conormal_framework 2.3 must use the subtraction orders of section 3 (degree up to 7), not the
  rectangle; the face edge data (`c_1` on the x-face, `e_2`, `e_4` on the y-face) are matched at the corner through
  `J_c, K_c` and through the corner coefficients up to degree 7; `A` must avoid even integers.
- `J_c = 0` means the coupling never forces the `x^2 y` corner mode, consistent with the centre normalization.
- The constants (`C_{a,b} ~ 1e69`) are effective but many orders of magnitude from any closing inequality; a usable corner
  estimate would need a sharp (Mellin) computation of the double-remainder norm.
- Not covered: derivative versions of the coupling bound; Hoelder versions; the corner edge-matching problem (solvability
  of the coupled face transport systems with the matching conditions); verification of `alpha in C^8` for the trial.

## 7. Lead checks
- code/corner/check_corner1.py (sympy, exact): `J_c = 0`; `K_c` formula; `T_x^6 T_y^3 (2 x y U_1 + x^2 U_2) = -7 d_7 x^6 y^3`
  for the degree-7 term; floating size of `C_{a,b}`. Output: `J = 0`, `K - formula(47) = 0`, `-7*d7*x**6*y**3`,
  `log10 C_ab = 69.2, 69.67`.
- code/corner/check_corner_q.py (sympy, exact): `q_1, q_2, q_4` formulas of section 5 for general jet functions and
  `alpha = alpha_0(y) + alpha_2(y) x^2 + alpha_4(y) x^4` (resp. `r_0(x) + r_2(x) y^2`); `G(0, y) = 0`. All differences 0.
- Table of (T1) re-derived by hand from the criterion (`p_{1,j} = 7`, `p_{2,j} = 6`, `p^_{1,l} = 4`, `p^_{2,l} = 3`).
- Parity structure (K1): `Re z^k` is odd in x and even in y, `Im z^k` even in x and odd in y, for k odd.
- Not checked by the lead: the block estimate (D1) in full detail, the constant (10), the annular trace proof (T2).
