# Frozen full-nonlocal source inverse on the Hölder scale

Topic74, written before its checking code, 2026-10-20. This is an independent proof audit of lead V21. The statements below concern a specified constant-coefficient dilation operator on the full plane. They are not a variable-coefficient IPM inverse theorem or a profile exclusion. Status remains OPEN until the recorded reviews and checks are complete.

## 1. Exact statement and realization

Use coordinates z=(s,y) centered at a source. Let A>1, a=g/(A-1), and assume 1<a<A+1. Define

 T=A s partial_s+y partial_y,
 M=partial_s^2 Delta^{-1}, with Fourier symbol xi^2/(xi^2+eta^2),
 L=T-1-gM,
 b=(A-1)/A, p=A/(A-1), q=(1+g)/A=a-(a-1)/A,
 r(sigma)=b sigma+1/A.

The Fourier convention is fhat(zeta)=integral exp(-i z.zeta)f(z)dz, inverse factor(2pi)^-2. M is the bounded L2 multiplier with any value at frequency zero. T is the closed generator of D_t f(z)=f(exp(tB)z), B=diag(A,1), on L2. L is the bounded perturbation T-1-gM, with domain D(T). Thus the domain and inverse selection are part of the statement.

Let C_*^sigma=B^sigma_{infinity,infinity} be the inhomogeneous isotropic Besov space, using a fixed smooth annular dyadic decomposition and a low block. For noninteger positive sigma it equals the usual bounded Hölder space with equivalent norms. Local norms mean restriction norms on an open ball. Fix any compact K in the plane. The following statements hold with finite constants depending on A,a,K, the decomposition and the indicated exponents:

(i) R=L^-1 on L2 exists, ||R||<=2/(A+3).

(ii) For supp f subset K and 1<sigma<a,

 ||Rf||_{C_*^{r(sigma)}}<=C||f||_{C_*^sigma}.             (1)

The exact output exponent is attained. No larger exponent admits a uniform estimate of this form, even for smooth inputs supported in any fixed small source neighborhood, even in s and odd in y.

(iii) If 1<sigma<q, there are such smooth packets with uniformly bounded input C_*^sigma norm and

 ||Rf_N||_{C_*^sigma(B_r)} comparable to N^{(sigma-1)/(A-1)}. (2)

Both constants in comparability are independent of N=2^n; r>0 is fixed.

(iv) For 0<sigma<1, the same compact-input inverse is bounded into C_*^sigma. At sigma=1 its dyadic upper bound loses one logarithm; this logarithm is necessary for C_*^1 inputs. A separate single-packet sequence has bounded classical C1 input norm and

 partial_y Rf_N(0)=-phi(0)psi(0) log N/(A-1)+O(1).       (3)

(v) For sigma>a, the output is bounded in C_*^q. No exponent greater than q works uniformly, and there is one fixed smooth compactly supported parity-compatible forcing whose selected solution fails to belong locally to any C_*^beta with beta>q. At sigma=a, we prove only a logarithmically weakened q upper bound; necessity of this endpoint logarithm in the odd class is OPEN.

Constants denoted C below are finite existence constants derived from fixed Schwartz kernels and geometric integrals. None is a numerical a posteriori inverse constant. This result cannot close the nonlinear PDE error theorem.


## 4. Packet lower bound and exact transformed integral

Choose real even phi,psi in C_c^infinity on arbitrarily small intervals, with psi(0)>0 and phihat(kappa0) nonzero at some kappa0>0. Put

 f_N(s,y)=N^{-sigma}phi(s)psi(y)sin(Ny),
 t_N=log N/(A-1), lambda_N=N^p,
 H_N(Z)=N^{sigma+1/(A-1)}Rf_N(Z/lambda_N).                       (13)

Modulation and fixed smooth multiplication give ||f_N||_{C_*^tau}<=C_tau N^{tau-sigma} for tau>0. Their L2 norms are at most C N^{-sigma}.

We prove the Fourier limit on compact sets where kappa>0 and nu>0, keeping kappa bounded away from0. Substitute t=t_N+tau into(5), then v=e^{-tau}nu. A direct cancellation of every N power gives

 Hhat_N(kappa,nu)= (i N/2)|(kappa,nu)|^{-a} nu^{a-A-2}
 integral_0^{nu N^{1/(A-1)}} v^{A+1}
 [1+kappa^2 v^{2A-2}/(N^2 nu^{2A})]^{a/2}
 phihat(kappa(v/nu)^A)
 [psihat(N(v-1))-psihat(N(v+1))]dv.                              (14)

This formula makes the delta limit precise. Its multiplier of the square bracket in the last line has a uniform integrable polynomial-decay majorant at infinity, since kappa stays positive and phihat is Schwartz. At0 it is bounded by C v^{A+1}, which is integrable. Near v=1 it converges uniformly to phihat(kappa/nu^A), times the displayed powers. The approximate identity N psihat(N(v-1)) has integral tending to integral psihat=2pi psi(0). Its absolute L1 norm is uniformly bounded, and its mass outside any fixed neighborhood of1 tends to0 faster than any inverse power. The negative carrier has no positive root, so its integral tends to0 by the same decay bounds. The upper endpoint tends uniformly to infinity. Thus locally uniformly on these frequency compacts,

 Hhat_N -> i pi psi(0)|(kappa,nu)|^{-a}nu^{a-A-2}
                         phihat(kappa/nu^A).                    (15)

In particular the limit is nonzero near(kappa0,1). Choose a Schwartz test W with compact Fourier support there, with phase arranged so its pairing with the limit is nonzero. Real and imaginary parts can be used if desired. Every polynomial moment of W vanishes. Then

 |<Rf_N,lambda_N^2 W(lambda_N .)>|>=c N^{-sigma-1/(A-1)}.         (16)

For any beta>0 and fixed ball B_r, frequency localization and the Besov norm give

 |<h,lambda^2 W(lambda .)>|<=C lambda^{-beta}||h||_{C_*^beta(B_r)}
                                      +C_M lambda^{-M}||h||_2.   (17)

To see the local assertion, choose an extension realizing the restriction norm up to a factor2, multiply it by a fixed smooth cutoff supported in B_r and equal to1 near0, and use the usual whole-space dyadic pairing for that cutoff function. The difference from h is supported away from0, where the rescaled Schwartz test has L2 norm smaller than any prescribed inverse power. The cutoff extension is L2-controlled by the local norm; this extra term is absorbed in the first term by taking a sufficiently large power. No support or smoothness of Rf_N is assumed in this argument.

Using(6) to control the last term of(17), we obtain

 ||Rf_N||_{C_*^beta(B_r)}>=c N^{p beta-sigma-1/(A-1)}.            (18)

The exponent is positive exactly when beta>r(sigma). For beta=sigma>1 it equals(sigma-1)/(A-1). If sigma<q, apply(1) at input order tau=(A sigma-1)/(A-1), which lies in(1,a), and use the packet norm at that order. This gives the matching upper bound in(2). Claims for classical noninteger Hölder spaces follow by norm equivalence. No assertion about classical integer C^m is needed for(2).

These packets are even in s and odd in y. If parity about a distinct original x-origin is wanted, replace phi(s) by phi(s)+phi(s+2x_*). Its Fourier transform is phihat(xi)(1+e^{2i x_*xi}), nonzero on a suitable smaller test set. The same frozen-operator proof works. This does not make the frozen operator a global reflection-invariant variable-coefficient operator.

