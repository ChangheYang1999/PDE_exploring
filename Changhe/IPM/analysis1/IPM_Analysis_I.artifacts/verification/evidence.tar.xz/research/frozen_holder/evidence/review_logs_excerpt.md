# Frozen full-nonlocal source inverse on the Hölder scale

Topic74, written before its checking code, 2026-10-20. This is an independent proof audit of lead V21. The statements below concern a specified constant-coefficient dilation operator on the full plane. They are not a variable-coefficient IPM inverse theorem or a profile exclusion. Status remains OPEN until the recorded reviews and checks are complete.

## 1. Exact statement and realization

Use coordinates z=(s,y) centered at a source. Let A>1, a=g/(A-1), and assume 1<a<A+1. Define

 T=A s partial_s+y partial_y,
 M=partial_s^2 Delta^{-1}, with Fourier symbol xi^2/(xi^2+eta^2),
 L=T-1-gM,
 b=(A-1)/A, p=A/(A-1), q=(1+g)/A=a-(a-1)/A,
 r(sigma)=b sigma+1/A.

The Fourier convention is fhat(zeta)=integral exp(-i z.zeta)f(z)dz, inverse factor(2pi)^-2. M is the bounded L2 multiplier with any value at frequency zero. T is the closed generator of D_t f(z)=f(exp(tB)z), B=diag(A,1), on L2. L is the bounded perturbation T-1-gM, with domain D(T). Thus the domain and inverse selection are part of the statement.

Let C_*^sigma=B^sigma_{infinity,infinity} be the inhomogeneous isotropic Besov space, using a fixed smooth annular dyadic decomposition and a low block. For noninteger positive sigma it equals the usual bounded Hölder space with equivalent norms. Local norms mean restriction norms on an open ball. Fix any compact K in the plane. The following statements hold with finite constants depending on A,a,K, the decomposition and the indicated exponents:

(i) R=L^-1 on L2 exists, ||R||<=2/(A+3).

(ii) For supp f subset K and 1<sigma<a,

 ||Rf||_{C_*^{r(sigma)}}<=C||f||_{C_*^sigma}.             (1)

The exact output exponent is attained. No larger exponent admits a uniform estimate of this form, even for smooth inputs supported in any fixed small source neighborhood, even in s and odd in y.

(iii) If 1<sigma<q, there are such smooth packets with uniformly bounded input C_*^sigma norm and

 ||Rf_N||_{C_*^sigma(B_r)} comparable to N^{(sigma-1)/(A-1)}. (2)

Both constants in comparability are independent of N=2^n; r>0 is fixed.

(iv) For 0<sigma<1, the same compact-input inverse is bounded into C_*^sigma. At sigma=1 its dyadic upper bound loses one logarithm; this logarithm is necessary for C_*^1 inputs. A separate single-packet sequence has bounded classical C1 input norm and

 partial_y Rf_N(0)=-phi(0)psi(0) log N/(A-1)+O(1).       (3)

(v) For sigma>a, the output is bounded in C_*^q. No exponent greater than q works uniformly, and there is one fixed smooth compactly supported parity-compatible forcing whose selected solution fails to belong locally to any C_*^beta with beta>q. At sigma=a, we prove only a logarithmically weakened q upper bound; necessity of this endpoint logarithm in the odd class is OPEN.

Constants denoted C below are finite existence constants derived from fixed Schwartz kernels and geometric integrals. None is a numerical a posteriori inverse constant. This result cannot close the nonlinear PDE error theorem.


## 5. Both logarithmic endpoints at input order1

For classical C1 take the single packet in(13) with sigma=1 and phi(0)psi(0)>0. These inputs have uniformly bounded classical C1 norms. Since partial_y(e^{-t}D_t F)(0)=partial_y F(0), Fourier inversion and the two symmetric carriers give

 D_N(t):=partial_y S_t f_N(0)
 =(2pi)^-2 integral phihat(xi)psihat(zeta)(1+zeta/N)
 [((xi/N)^2+(1+zeta/N)^2)/(z^2 xi^2+(1+zeta/N)^2)]^{a/2} dxi dzeta,
 z=e^{(A-1)t}/N.                                              (19)

For N^{-1}<=z<=1 let

 H(z)=psi(0)/(2pi) integral phihat(xi)(1+z^2 xi^2)^(-a/2)dxi.

Schwartz decay and |(1+w)^(-a/2)-1|<=C_a w for w>=0 give H(z)=phi(0)psi(0)+O(z^2). Uniformly for z in this range, D_N(t)=H(z)+O(N^{-1}). For completeness split |zeta|<=N/2, where v=1+zeta/N>=1/2. Taylor expansion in v around1 and in xi/N around0 is bounded by C_a (|zeta|/N+N^{-2})(1+|xi|)^{a+4}, independently of z<=1. Integrating this against the Schwartz factors is O(N^{-1}). On the complement Q_t<=1 and the rapid decay of psihat give the same estimate with any inverse power; the corresponding H tail is controlled likewise. Therefore

 integral_0^{t_N}D_N(t)dt=phi(0)psi(0)t_N+O(1),                  (20)

because integral_0^{t_N}z^2dt<=1/[2(A-1)] and t_N/N is bounded.

For z>=1, put v=1+zeta/N and use

 [(xi/N)^2+v^2]/[z^2 xi^2+v^2]
       <=(Nz)^(-2)+v^2/[z^2 xi^2+v^2].

Raising to a/2 costs only a fixed factor. Integrating the second term in xi, using bounded phihat and w=z xi/|v|, gives at most

 C |v|/z integral_R(1+w^2)^(-a/2)dw.

This integral is finite because a>1; an explicit elementary upper bound is 2+2/(a-1). The first term is bounded using ||phihat||_1. Including |v psihat(zeta)| and integrating gives

 |D_N(t)|<=C[(Nz)^(-a)+z^{-1}], z>=1.                           (21)

The same absolute Fourier estimate bounds the spatial supremum of partial_y S_t f_N. It is integrable for t>=t_N. For fixed N the earlier time interval is finite, so differentiating the Bochner integral is legitimate in the uniform derivative norm. Equations(20)-(21) prove(3). In particular the output classical C1 and Lipschitz norms are unbounded on this bounded C1 input sequence.

For C_*^1 itself a sum of packets is needed, since a large derivative alone is not a C_*^1 lower bound. Fix 0<epsilon<1/(2A), lambda=2^J, and take j between ceil((b+epsilon)J) and floor((1-epsilon)J), N=2^j. Set

 F_J=phi(s)psi(y)sum_j N^{-1}sin(Ny).                           (22)

The lacunary sum has uniformly bounded C_*^1 norm; each dyadic block meets only a bounded number of carriers. Multiplication by fixed smooth compact factors is bounded on C_*^1, so this remains true for F_J, whose support is fixed.

For a single summand write t=log(lambda/N)+tau and L0=lambda^{A-1}/N^A. In rescaled coordinates,

 lambda S_t f_N(S/lambda,Y/lambda)
 =e^{-tau}[Q_t(phi psi sin(Ny))](L0 e^{A tau}S,e^tau Y/N).       (23)

Uniformly over the stated j range, N tends to infinity, L0<=lambda^{-A epsilon} tends to0, and the lower time endpoint tends to minus infinity. On bounded tau intervals Fourier inversion, Q_t<=1 and Schwartz Fourier decay show that(23) tends to

 e^{-tau}phi(0)psi(0)sin(e^tau Y),

independent of S. Indeed the effective multiplier has transverse ratio e^{(A-1)t}/N=L0 e^{(A-1)tau}, tending to0 on bounded xi and on each carrier; the envelope arguments tend to0. Dominated convergence is uniform over the j range.

Choose a Schwartz test W whose Fourier support has nu bounded away from0 and kappa near0, and with nonzero trace of What at kappa=0. For tau>=0, the pairing in(23) has absolute value at most C e^{-tau}, because Q_t<=1 and the input Fourier L1 norm is uniformly bounded. For tau<=0 use that integral W(S,Y)Y^m dY=0 for m=0,1 and every S. The second Y derivative of(23) is at most C e^tau: the input second y derivative has Fourier L1 norm at most C N^2, and the chain rule contributes(e^tau/N)^2 e^{-tau}. Taylor subtraction in Y then bounds the pairing by C e^tau. These two integrable bounds are uniform in N,j,lambda and justify both time tails.

Consequently the pairing tends uniformly in j to that of the nonzero distribution

 -phi(0)psi(0)integral_R e^{-tau}sin(e^tau Y)dtau.               (24)

This formula is only used against the stated tests, so no absolutely convergent lower-end integral is asserted. Substitution v=e^tau gives integral sin(vY)dv/v^2. Its Fourier transform for nu>0 is a nonzero imaginary multiple of nu^{-2}; it is supported on kappa=0 in the transverse variable. Choose the phase of W so the limiting pairing has positive real part. Every packet then has the same positive contribution for large J. There are at least cJ packets. The local testing estimate(17), with beta=1 and ||RF_J||_2 uniformly bounded, yields

 ||RF_J||_{C_*^1(B_r)}>=cJ.                                    (25)

This proves necessity of the logarithmic loss at input1 separately from(3).

