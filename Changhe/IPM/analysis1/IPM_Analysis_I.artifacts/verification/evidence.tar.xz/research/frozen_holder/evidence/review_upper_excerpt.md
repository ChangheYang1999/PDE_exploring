# Frozen full-nonlocal source inverse on the Hölder scale

Topic74, written before its checking code, 2026-10-20. This is an independent proof audit of lead V21. The statements below concern a specified constant-coefficient dilation operator on the full plane. They are not a variable-coefficient IPM inverse theorem or a profile exclusion. Status remains OPEN until the recorded reviews and checks are complete.

## 1. Exact statement and realization

Use coordinates z=(s,y) centered at a source. Let A>1, a=g/(A-1), and assume 1<a<A+1. Define

 T=A s partial_s+y partial_y,
 M=partial_s^2 Delta^{-1}, with Fourier symbol xi^2/(xi^2+eta^2),
 L=T-1-gM,
 b=(A-1)/A, p=A/(A-1), q=(1+g)/A=a-(a-1)/A,
 r(sigma)=b sigma+1/A.

The Fourier convention is fhat(zeta)=integral exp(-i z.zeta)f(z)dz, inverse factor(2pi)^-2. M is the bounded L2 multiplier with any value at frequency zero. T is the closed generator of D_t f(z)=f(exp(tB)z), B=diag(A,1), on L2. L is the bounded perturbation T-1-gM, with domain D(T). Thus the domain and inverse selection are part of the statement.

Let C_*^sigma=B^sigma_{infinity,infinity} be the inhomogeneous isotropic Besov space, using a fixed smooth annular dyadic decomposition and a low block. For noninteger positive sigma it equals the usual bounded Hölder space with equivalent norms. Local norms mean restriction norms on an open ball. Fix any compact K in the plane. The following statements hold with finite constants depending on A,a,K, the decomposition and the indicated exponents:

(i) R=L^-1 on L2 exists, ||R||<=2/(A+3).

(ii) For supp f subset K and 1<sigma<a,

 ||Rf||_{C_*^{r(sigma)}}<=C||f||_{C_*^sigma}.             (1)

The exact output exponent is attained. No larger exponent admits a uniform estimate of this form, even for smooth inputs supported in any fixed small source neighborhood, even in s and odd in y.

(iii) If 1<sigma<q, there are such smooth packets with uniformly bounded input C_*^sigma norm and

 ||Rf_N||_{C_*^sigma(B_r)} comparable to N^{(sigma-1)/(A-1)}. (2)

Both constants in comparability are independent of N=2^n; r>0 is fixed.

(iv) For 0<sigma<1, the same compact-input inverse is bounded into C_*^sigma. At sigma=1 its dyadic upper bound loses one logarithm; this logarithm is necessary for C_*^1 inputs. A separate single-packet sequence has bounded classical C1 input norm and

 partial_y Rf_N(0)=-phi(0)psi(0) log N/(A-1)+O(1).       (3)

(v) For sigma>a, the output is bounded in C_*^q. No exponent greater than q works uniformly, and there is one fixed smooth compactly supported parity-compatible forcing whose selected solution fails to belong locally to any C_*^beta with beta>q. At sigma=a, we prove only a logarithmically weakened q upper bound; necessity of this endpoint logarithm in the odd class is OPEN.

Constants denoted C below are finite existence constants derived from fixed Schwartz kernels and geometric integrals. None is a numerical a posteriori inverse constant. This result cannot close the nonlinear PDE error theorem.

## 2. Semigroup and inverse

Direct Fourier transport gives the combined operator

 S_t=e^{(a-1)t} Lambda^{-a}D_t Lambda^a=e^{-t}D_t Q_t,
 Q_t(xi,eta)=[(xi^2+eta^2)/(e^{2(A-1)t}xi^2+eta^2)]^{a/2},             (4)

or equivalently

 (S_t f)^hat(zeta)=e^{(a-A-2)t}|zeta|^{-a}
       |e^{-tB}zeta|^a fhat(e^{-tB}zeta).                           (5)

No separate low-frequency definition of Lambda^{-a} is needed. The product in(5), or Q_t in(4), defines S_t on L2. Its symbols satisfy the cocycle relation, so S_{t+u}=S_tS_u. It is strongly continuous at0 by dominated convergence and strong continuity of D_t. Since 0<=Q_t<=1,

 ||S_t||_{2->2}<=e^{-t}e^{-(A+1)t/2}=e^{-(A+3)t/2}.                (6)

Differentiating(4) at0 gives T-1-a(A-1)M=L on functions with smooth Fourier transform compactly supported away from0. This set is a core for T: truncate frequency first near0 and infinity with smooth cutoffs whose logarithmic radial derivative is uniformly bounded, then approximate smoothly on the resulting annuli. The cutoff commutators with the first-order Fourier transport vanish in L2 by absolute continuity of its integral; ordinary local smooth approximation converges in its first-order graph norm. Bounded perturbation preserves this core and determines L uniquely. Hence S_t is its semigroup.

The Bochner integral R=-integral_0^infinity S_t dt converges on L2 by(6). For finite H, L integral_0^H S_t f dt=S_Hf-f, first on the core and then by the closed-generator identity. Letting H tend to infinity and using closedness gives LRf=f. The analogous identity for f in D(L) gives RLf=f. Integration of(6) gives the norm in(i). Parity in s and y is preserved.

## 3. Dyadic estimate with compact-support gain

Write Delta_N for a homogeneous smooth annular block, N dyadic. The high-frequency inhomogeneous blocks have N>=1. For such N and compactly supported f,

 ||Delta_N f||_infinity+||Delta_N f||_{L_s^1 L_y^infinity}
       <=C_K N^{-sigma}||f||_{C_*^sigma}.                         (7)

On a fixed enlargement of the s-projection of K, the second norm follows from the first times the strip width. Outside this strip, convolving the compact input with the Schwartz kernel gives a bound C_M N^{-M}(1+dist(s,K))^{-M}||f||_infinity, integrable in s. Choose M>sigma+2. Applying Lambda^a to an annular function costs at most C N^a in both norms, because its localized multiplier has an L1 convolution kernel with that scaling.

For lambda>=1 the kernel K_lambda of Delta_lambda Lambda^{-a} satisfies

 ||K_lambda||_1<=C lambda^{-a},
 integral sup_s |K_lambda(s,y)|dy<=C lambda^{1-a}.                (8)

These follow by dilation from a fixed Schwartz kernel. D_t preserves the supremum norm and multiplies the mixed norm in(7) by e^{-At}. Convolution, using either line of(8), gives

 ||Delta_lambda S_t Delta_N f||_infinity
 <=C e^{(a-1)t}(N/lambda)^a N^{-sigma}
               min(1,lambda e^{-At})||f||_{C_*^sigma}.            (9)

Frequency support forces N e^t lesssim lambda lesssim N e^{At}. Fixed overlap constants merely shift the time endpoints by bounded constants and alter C. With idealized endpoints l=log(lambda/N)/A and u=log(lambda/N), integrate over [l,u] intersect[0,infinity). Split also at t*=log(lambda)/A. The exponents before and after the split are a-1>0 and a-A-1<0. Each full exponential integral is bounded by its extreme endpoint divided by the respective positive gap. Using just the first branch gives a bound C N/lambda; using both branches at t* gives C N^a/lambda^q. Consequently

 ||Delta_lambda R Delta_N f||_infinity
 <=C N^{-sigma}min(N/lambda,N^a/lambda^q)||f||_{C_*^sigma}.         (10)

The crossover is N=lambda^b, since (a-1)b=q-1. Inputs N above a fixed multiple of lambda have no overlap. The fixed constants around N~lambda and around the crossover do not affect dyadic exponents or summability.

For low inputs use homogeneous N<=1 and |fhat|<=||f||_1. The input annulus intersected with the output condition |e^{tB}zeta|~lambda has area at most C N lambda e^{-At}: its xi width is bounded by C lambda e^{-At} and its eta width by C N. Fourier inversion in(4), with multiplier size at most C e^{(a-1)t}(N/lambda)^a, gives

 ||Delta_lambda S_t Delta_N f||_infinity
 <=C||f||_1 lambda^{1-a}N^{a+1}e^{(a-A-1)t}.

Integrating from t at least A^{-1}log(lambda/N) minus a fixed constant yields

 ||Delta_lambda R Delta_N f||_infinity
 <=C||f||_1 lambda^{-q}N^{q+2}.                             (11)

Here q>1, so the low input series converges. Homogeneous decomposition of the low block is legitimate in L2; the estimates then give absolute uniform convergence after the output projection. The low output block is bounded by the L2 inverse and its L2 convolution kernel, with ||f||_2<=C_K||f||_infinity.

For lambda>=2, (10)-(11) reduce the proof to

 ||Delta_lambda Rf||_infinity<=C||f||_{C_*^sigma}[
 lambda^{-q}+lambda^{-q} sum_{1<=N<=lambda^b}N^{a-sigma}
              +lambda^{-1} sum_{lambda^b<=N lesssim lambda}N^{1-sigma}]. (12)

All sums are over dyadic N. For 1<sigma<a the two sums are bounded respectively by constants times lambda^{b(a-sigma)} and lambda^{b(1-sigma)}, and both terms equal the order lambda^{-r(sigma)}. This proves(1), including its endpoint output exponent. For 0<sigma<1 the final sum instead gives lambda^{1-sigma}, and the result is lambda^{-sigma}. For sigma=1 it gives lambda^{-1}(1+log lambda). For sigma=a the first sum gives lambda^{-q}(1+log lambda). For sigma>a both sums are bounded by C lambda^{-q}. This proves all claimed upper bounds.

