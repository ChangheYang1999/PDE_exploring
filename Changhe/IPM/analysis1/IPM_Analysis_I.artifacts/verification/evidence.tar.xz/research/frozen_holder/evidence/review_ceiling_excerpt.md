# Frozen full-nonlocal source inverse on the Hölder scale

Topic74, written before its checking code, 2026-10-20. This is an independent proof audit of lead V21. The statements below concern a specified constant-coefficient dilation operator on the full plane. They are not a variable-coefficient IPM inverse theorem or a profile exclusion. Status remains OPEN until the recorded reviews and checks are complete.

## 1. Exact statement and realization

Use coordinates z=(s,y) centered at a source. Let A>1, a=g/(A-1), and assume 1<a<A+1. Define

 T=A s partial_s+y partial_y,
 M=partial_s^2 Delta^{-1}, with Fourier symbol xi^2/(xi^2+eta^2),
 L=T-1-gM,
 b=(A-1)/A, p=A/(A-1), q=(1+g)/A=a-(a-1)/A,
 r(sigma)=b sigma+1/A.

The Fourier convention is fhat(zeta)=integral exp(-i z.zeta)f(z)dz, inverse factor(2pi)^-2. M is the bounded L2 multiplier with any value at frequency zero. T is the closed generator of D_t f(z)=f(exp(tB)z), B=diag(A,1), on L2. L is the bounded perturbation T-1-gM, with domain D(T). Thus the domain and inverse selection are part of the statement.

Let C_*^sigma=B^sigma_{infinity,infinity} be the inhomogeneous isotropic Besov space, using a fixed smooth annular dyadic decomposition and a low block. For noninteger positive sigma it equals the usual bounded Hölder space with equivalent norms. Local norms mean restriction norms on an open ball. Fix any compact K in the plane. The following statements hold with finite constants depending on A,a,K, the decomposition and the indicated exponents:

(i) R=L^-1 on L2 exists, ||R||<=2/(A+3).

(ii) For supp f subset K and 1<sigma<a,

 ||Rf||_{C_*^{r(sigma)}}<=C||f||_{C_*^sigma}.             (1)

The exact output exponent is attained. No larger exponent admits a uniform estimate of this form, even for smooth inputs supported in any fixed small source neighborhood, even in s and odd in y.

(iii) If 1<sigma<q, there are such smooth packets with uniformly bounded input C_*^sigma norm and

 ||Rf_N||_{C_*^sigma(B_r)} comparable to N^{(sigma-1)/(A-1)}. (2)

Both constants in comparability are independent of N=2^n; r>0 is fixed.

(iv) For 0<sigma<1, the same compact-input inverse is bounded into C_*^sigma. At sigma=1 its dyadic upper bound loses one logarithm; this logarithm is necessary for C_*^1 inputs. A separate single-packet sequence has bounded classical C1 input norm and

 partial_y Rf_N(0)=-phi(0)psi(0) log N/(A-1)+O(1).       (3)

(v) For sigma>a, the output is bounded in C_*^q. No exponent greater than q works uniformly, and there is one fixed smooth compactly supported parity-compatible forcing whose selected solution fails to belong locally to any C_*^beta with beta>q. At sigma=a, we prove only a logarithmically weakened q upper bound; necessity of this endpoint logarithm in the odd class is OPEN.

Constants denoted C below are finite existence constants derived from fixed Schwartz kernels and geometric integrals. None is a numerical a posteriori inverse constant. This result cannot close the nonlinear PDE error theorem.


## 6. A fixed smooth forcing attaining the ceiling q

This independent argument avoids importing a generic cusp theorem. Choose nonzero real even compactly supported smooth functions u,v with nonzero integrals. Set phi=u*u and psi=v*v (for even real u,v these autocorrelations have nonnegative real Fourier transforms), and f(s,y)=-phi(s)psi'(y). Then f is smooth, even in s, odd in y, compactly supported, and

 fhat(xi,eta)=-i eta phihat(xi)psihat(eta).

For lambda tending to infinity use anisotropic spatial scaling

 G_lambda(S,Y)=lambda^q Rf(S/lambda,Y/lambda^{1/A}).

Substitute t=log(lambda)/A+tau into(5). On compact frequency sets with kappa>0 and nu>0, its Fourier transform converges to

 -|kappa|^{-a} integral_R e^{(a-A-2)tau}
 |(e^{-A tau}kappa,e^{-tau}nu)|^a
 fhat(e^{-A tau}kappa,e^{-tau}nu)dtau.                         (26)

All lambda factors cancel because q=a-(a-1)/A. The remaining output multiplier is
 |(kappa,lambda^{-(A-1)/A}nu)|^{-a}, converging uniformly to |kappa|^{-a}. At tau tending to minus infinity the Schwartz decay of fhat and kappa>0 dominates every exponential. At plus infinity fhat is O(e^{-tau}) because f is odd in y, while the norm factor is O(e^{-a tau}); the total is O(e^{-(A+3)tau}). Thus convergence follows by a uniform integrable majorant. The limit is nonzero: after multiplication by i its integrand has a fixed sign, and for sufficiently large finite tau both phihat and psihat are positive near0. No cancellation is possible.

Take a fixed Schwartz test with compact Fourier support where(26) is nonzero. The resulting physical test is lambda^{1+1/A}W(lambda s,lambda^{1/A}y). Its Fourier support lies in an isotropic annulus of radius comparable to lambda since kappa stays away from0, and its L1 norm is constant. The dyadic testing bound is therefore C lambda^{-beta}||h||_{C_*^beta}. Localization to any fixed ball has a tail smaller than any prescribed inverse power, since both dilation factors tend to infinity; the L2 tail argument from(17) applies. A nonzero limiting pairing forces

 ||Rf||_{C_*^beta(B_r)}>=c lambda^{beta-q}

for every sufficiently large lambda. This is impossible if beta>q and the norm is finite. Therefore this one fixed forcing attains the stated regularity ceiling. This proves the sharp ceiling claim in(v) but does not prove a logarithmic failure at the exact input sigma=a.

