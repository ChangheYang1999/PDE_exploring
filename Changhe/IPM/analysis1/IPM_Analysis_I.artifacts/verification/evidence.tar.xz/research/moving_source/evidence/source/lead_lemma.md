# Source shift and source data under a perturbation of the trial (lead derivation, 2026-10-21; to be verified)

Purpose: PROMPT section 5(ii) asks for the effect of a perturbation of rho on the nonlocal strain at 0 and on the
source point. The strain part is (E5) of SPEC 3.16 (weighted L^2) and (18) of the local estimate (local form). This
note treats the source point. Everything is elementary; no inverse of L is used or claimed.

## Setting and verified inputs

Canonical law: -Lap psi = d_x rho, U[rho] = (-psi_y, psi_x), raw strain c[rho] = psi[rho]_xy(0), c_l(rho) =
(1 + c[rho])/3, V[rho] = c_l(rho) X + U[rho]. rho is even in x and odd in y. rho~ is the explicit trial, normalized
exactly: c_l(rho~) = 1/k with k = 1615536043799051/2^53. V~ = V[rho~], w(x) = V~_1(x, 0), mu~(x) = d_y V~_2(x, 0),
G(x) = rho~_y(x, 0).

Verified inputs (independent verifier):
- (I1) w has a zero p, unique in (4841405518533377/2^49, 4841405518533711/2^49); P = (p, 0).
- (I2) mu~(p) - 1 = -2.2528046115e-8 within 4.7e-19; G(p) = g = 29.7494906633335090153 within 9.2e-20.
- (I3) On B_{0.0495}(P'), for every P' in the bracket of (I1): ||D^2 V~||_F < M_V := 0.2972 and
  ||D^2 rho~||_F < M_rho := 0.5059 (pointwise sup of the Frobenius norm of the third-order / second-order tensors).
- (I4) Local estimate of the source analysis (order s = 31/10, cutoffs chi, tau, theta, zeta at scale delta; zeta = 1
  on B_{5 delta/2}(P), supp zeta in B_{3 delta}(P)); its far-kernel bound: for h_far = (1 - zeta) h and X in
  B_{9 delta/4}(P), |D^gamma U_i[h_far](X)| <= k_j N with k_j = 100 (j + 1)!/(2 pi) (4/delta)^j, j = |gamma|, and
  N = int_{|X-P| >= 5 delta/2} |h|/|X - P|^2 dX + int_{R^2 \ B_{3 delta}(P)} |h|/|X|^3 dX. Raw strain bound (h(0) = 0,
  grad h(0) = 0): |c[h]| <= C_c H_h + N/pi, C_c = 3 delta/(sqrt(pi) (p - 3 delta)^3), H_h = ||h||_{H^{s-1}(B_{3 delta}(P))}.
- (I5) For v in H^r(R^2), with ||v||_{H^r}^2 = int (1 + |xi|^2)^r |v^(xi)|^2 dxi and the unitary Fourier transform
  v^: sup|v| <= alpha_r ||v||_{H^r} (r > 1) and sup|grad v| <= beta_r ||v||_{H^r} (r > 2, Euclidean norm of the
  gradient), with alpha_r = 1/(2 sqrt(pi (r - 1))), beta_r = 1/(2 sqrt(pi (r - 1)(r - 2))). Proof: Fourier inversion
  and Cauchy-Schwarz, int (1 + |xi|^2)^{-r} dxi = pi/(r - 1), int |xi|^2 (1 + |xi|^2)^{-r} dxi = pi/((r - 1)(r - 2)).
  (Lead derivation; this elementary input is part of what is to be checked.)

## S0. Exact identities (no smallness)

Let rho = rho~ + h, h even in x and odd in y, in a class where U[h] and c[h] are defined (for example h = O(|X|^2) at
0, locally Hoelder, with the decay used in N). Put W[h] = U[h] + (c[h]/3) X. Standing regularity for every statement
below that involves a derivative of V[rho], W[h] or rho at a point: that derivative exists there (for example W[h]
and h of class C^1 near the axis segment I of S1); this is not implied by the definedness of U[h] and c[h] alone
(astra srcshift1).
- (a) V[rho] = V~ + W[h]. Proof: U and c are linear, and c_l(rho) = c_l(rho~) + c[h]/3.
- (b) On the x-axis: V_2[rho] = 0, d_x V_2[rho] = 0, d_y V_1[rho] = 0 (where this derivative exists), rho = 0 and
  rho_x = 0. Proof: d_x rho is odd in
  x and odd in y, so psi (the convolution with the radial kernel -(2 pi)^{-1} log|X|) is odd in x and odd in y; then
  psi_x is odd in y and -psi_y is even in y; V_1 is even in y and V_2 is odd in y.
- (c) div V[rho] = 2 c_l(rho) = 2/k + 2 c[h]/3 everywhere (div U = 0).
So at any zero P_h = (p_h, 0) of V_1[rho](., 0) at which V[rho] is differentiable: V[rho](P_h) = 0, DV[rho](P_h) = diag(A_h, mu_h) with
A_h + mu_h = 2/k + 2 c[h]/3, and grad rho(P_h) = (0, g_h), g_h = G(p_h) + h_y(p_h, 0).

## S1. Location of the perturbed source

Let 0 < R < 0.0495, I = [p - R, p + R], A~ = w'(p) = 2/k - mu~(p), m = A~ - M_V R, and
eps_0 = sup_I |W[h]_1(x, 0)|, eps_1 = sup_I |d_x W[h]_1(x, 0)|, eps_2 = sup_I |d_y W[h]_2(x, 0)|, eps_3 = sup_I |h_y(x, 0)|.
Assume W[h]_1(., 0) is continuous on I.
- (a) |w'(x) - A~| <= M_V |x - p| on I (segment Taylor bound with (I3)), so w' >= m > 0 on I and
  |w(x)| >= m |x - p| there.
- (b) Existence and localization: if eps_0 < m R, then V_1[rho](., 0) = w + W[h]_1(., 0) has a zero in the open
  interval (p - R, p + R) (an equilibrium of V[rho]; it is a source when A_h > 0 and mu_h > 0, which holds under the
  box conditions of S2), and every zero p_h in I satisfies |p_h - p| <= eps_0/m. Proof: (w + u)(p + R) >= mR - eps_0
  > 0 and (w + u)(p - R) <= -mR + eps_0 < 0 for u = W[h]_1(., 0); intermediate value theorem; at a zero
  m|p_h - p| <= |w(p_h)| = |u(p_h)| <= eps_0.
- (c) Uniqueness: if in addition W[h]_1(., 0) is C^1 on I and eps_1 < m, then w + u is strictly increasing on I and
  the zero is unique in I.
- (d) First-order formula: under (b), (c), p_h - p = -u(p)/abar with abar = int_0^1 (w' + u')(p + tau (p_h - p)) dtau,
  |abar - A~| <= M_V |p_h - p|/2 + eps_1, hence
  |p_h - p + u(p)/A~| <= |u(p)| (M_V |p_h - p|/2 + eps_1) / (A~ (A~ - M_V |p_h - p|/2 - eps_1)).
- Numbers (exact rational arithmetic on the verified inputs): A~ in [10.150725243, 10.150725244]; for every
  R < 0.0495, m > 10.1360138 and 1/m < 0.09866.

## S2. Source data at the perturbed source

Under S1(b), at any zero p_h in I, assuming W[h] is differentiable at P_h and h_y(p_h, 0) exists:
- |mu_h - mu~(p)| <= M_V |p_h - p| + eps_2, A_h = 2/k + 2 c[h]/3 - mu_h, |g_h - g| <= M_rho |p_h - p| + eps_3.
Proof: mu_h = mu~(p_h) + d_y W[h]_2(p_h, 0), and |mu~(p_h) - mu~(p)| <= sup|d_x d_y V~_2| |p_h - p| <= M_V |p_h - p|;
g_h = G(p_h) + h_y(p_h, 0) and |G' | = |rho~_xy| <= M_rho on I.
Box of the local estimate (10 <= A <= 51/5, 99/100 <= mu <= 101/100, 29 <= g <= 30): the trial's margins are, for mu,
at least 0.01 - 2.2528046115e-8 - 4.7e-19 > 0.00999997747 on either side (an earlier draft wrote 0.01 - 2.2528046e-8,
which overstates the certified margin by about 1.2e-16; astra srcshift1); for A~, 0.0492747 below 51/5 and 0.1507252 above 10; for g,
0.2505093 below 30 and 0.7494906 above 29. So the perturbed source data stay in the box if
M_V eps_0/m + eps_2 <= 0.0099999, (2/3)|c[h]| + M_V eps_0/m + eps_2 <= 0.0492747 and M_rho eps_0/m + eps_3 <= 0.2505.
Remark (not part of the claim): the remaining hypotheses of the local estimate at P_h (regularity on B_{3 delta'}(P_h)
and E < kappa) need Hessian bounds there; the geometric containment alone does not give E < kappa. S5 treats this for
the operators of the two-norm scheme.

## S3. The source condition along the moving source

If rho is an exact solution (F(rho) = V[rho].grad rho - rho = 0 near P_h), rho is C^1 near P_h, V[rho] is
differentiable at P_h and g_h != 0, then mu_h = 1. Proof: V(P_h) = 0, so
V(P_h + t e_2).grad rho(P_h + t e_2) = t (d_y V(P_h).grad rho(P_h)) + o(t) = t mu_h g_h + o(t) by S0(b); and
rho(P_h + t e_2) = t g_h + o(t). F = 0 gives (mu_h - 1) g_h = 0.
Here eps_2 measures a transverse derivative on the axis (d_y W[h]_2), not a derivative of a restricted function.
Consequence: d_y W[h]_2(p_h, 0) = 1 - mu~(p_h), so eps_2 >= (1 - mu~(p)) - M_V |p_h - p| >= 2.2528046e-8 - M_V eps_0/m.
Hence (with R < 0.0495 and m = A~ - M_V R > 10.1360138): no exact solution rho = rho~ + h in the class of the first
paragraph (F(rho) = 0 classically near P_h, rho of class C^1 near P_h), with W[h] of class C^1 near I, g_h != 0
(guaranteed if eps_3 + M_rho eps_0/m < g) and eps_0 < m R satisfies eps_2 + M_V eps_0/m < 2.2528046e-8. In particular
none has eps_0, eps_2 <= 2.1886e-8 (exact: eps (1 + M_V/m) < 2.2528046e-8 - 4.7e-19 for eps <= 2.1886e-8). No density
smallness is needed beyond g_h != 0, which holds when eps_3 <= 29 (then eps_3 + M_rho eps_0/m < 29 + M_rho R < g), and
the statement follows the source of the perturbed profile.
Scope: this is a lower bound for the distance, in the C^0/C^1 velocity norms on the axis segment, from the trial to
any exact solution; it is a quantitative form of "the trial is not stationary at its source", and the neighbourhood
(about 2.19e-8 in velocity) is far too narrow to contain a meaningful numerical-uncertainty ball: for comparison, the
trial's certified normalized residual sup is about 2.9e-4 (residual tables of the report), and the floating velocity
difference between X3 and the trial at P is already about 1.6e-8 in W[h]_1 (num, floating). It is not an exclusion
endpoint and no global nonexistence statement is made.

## S4. Velocity bounds from norms of h (corollary of I4, I5)

Let R <= 9 delta/4, so I lies in B_{9 delta/4}(P), where zeta = 1. With r = s = 31/10 (alpha_r < 0.194664,
beta_r < 0.185605), and h with h(0) = 0, grad h(0) = 0:
- eps_0 <= alpha_r ||zeta h||_{H^r} + k_0 N + (p + R)|c[h]|/3,
- eps_1, eps_2 <= beta_r ||zeta h||_{H^r} + k_1 N + |c[h]|/3,
- eps_3 <= beta_r ||zeta h||_{H^r},
- |c[h]| <= C_c H_h + N/pi,
with k_0 = 100/(2 pi), k_1 = (200/(2 pi))(4/delta) (about 7716.6 at delta = 0.0165), C_c about 4.47e-5 at
delta = 0.0165. Proof: U[h] = U[zeta h] + U[h_far]; each component of the symbol of U has modulus at most 1, so
||U_i[zeta h]||_{H^r} <= ||zeta h||_{H^r}; then I5 for U[zeta h] and I4 for U[h_far]; the term (c[h]/3) X contributes
|c[h]| |x|/3 to W_1 and c[h]/3 to the derivatives.
So the source moves by at most eps_0/m, which is first order in these norms of h with constant 1/m < 0.09866.

## S5. The local source estimate along the operators of the two-norm scheme (added 02:26Z; corollary of S1, S2, I3)

The two-norm theorem uses A_h u = L u + W[h].grad u = (V~ + W[h]).grad u - u + W[u].grad rho~: velocity V~ + W[h],
background density rho~ (not rho~ + h). The local estimate of the source analysis (order s = 31/10) holds at a point
P' for a velocity V and a background rho if: V(P') = 0, DV(P') = diag(A, mu), grad rho(P') = (0, g) with (A, mu, g)
in the box of S2; V is C^4 and rho is C^5 on B_{3 delta}(P'), 0 < delta <= 1, 3 delta < p'/2; and E < kappa = 1687/500,
where E <= C_src delta with C_src = 41.7 M_V' + 3 M_rho' and M_V', M_rho' bound ||D^2 V||_F, ||D^2 rho||_F on
B_{3 delta}(P'). Its leading constant is K_1 = 1/(kappa - E).
Claim. Let h satisfy S1(b), (c) with R < 0.0495, let p_h be the zero in I, d_h = |p_h - p| (<= eps_0/m) and
delta_h = (0.0495 - d_h)/3. Assume W[h] is C^4 on B_{0.0495}(P) with ||D^2 W[h]||_F <= m_2 there, and
(B1) M_V eps_0/m + eps_2 <= 0.0099999, (B2) (2/3)|c[h]| + M_V eps_0/m + eps_2 <= 0.0492747, (B3) M_rho eps_0/m <= 0.2505.
Then for every 0 < delta' <= delta_h the hypotheses of the local estimate hold at P_h for V = V~ + W[h], rho = rho~,
with M_V' = M_V + m_2 and M_rho' = M_rho, except possibly E < kappa; and E <= (41.7 (M_V + m_2) + 3 M_rho) delta'.
Proof: B_{3 delta'}(P_h) is contained in B_{0.0495}(P) (3 delta' + d_h <= 0.0495), where (I3) and the hypothesis on
W[h] give the Hessian bounds; V(P_h) = 0 and DV(P_h) = diag(A_h, mu_h) by S0; grad rho~(P_h) = (0, G(p_h)) by parity;
(B1), (B2) put (A_h, mu_h) in the box by S2, and (B3) with |G(p_h) - g| <= M_rho d_h puts G(p_h) in [29, 30] (no h_y
term, since the background is rho~). V~ and rho~ are smooth on the disc (explicit modal trial).
Numbers (exact rational arithmetic): at delta' <= 33/2000, E < kappa whenever m_2 < (kappa/delta' - 3 M_rho)/41.7 - M_V,
which at delta' = 33/2000 is 4.5701177...; for m_2 <= 1: E <= 0.91758051, K_1 <= 0.40709660; for m_2 <= 2:
E <= 1.60563051, K_1 <= 0.56549268. (m_2 = 0 reproduces E < 0.22953051, K_1 < 0.3181.)
Bound for m_2 (near part only): for a compactly supported v in H^r, r > 3, sup ||D^2 U[v]||_F <= gamma_r ||v||_{H^r}
with gamma_r = 1/sqrt(2 pi (r - 1)(r - 2)(r - 3)) (gamma_3.1 < 0.830050), since sum_i |sigma_i(xi)|^2 =
xi_1^2/|xi|^2 <= 1 for the symbols sigma_i of U, and int |xi|^4 (1 + |xi|^2)^{-r} dxi = 2 pi/((r - 1)(r - 2)(r - 3)).
The far part needs a kernel bound on B_{0.0495}(P) for a cutoff equal to 1 on a neighbourhood of that disc; (I4) is
stated on B_{9 delta/4}(P) only, so this constant is not derived here. K_2, K_3, K_4 depend on Wiener and Sobolev norms
of the cut-off coefficients and need corresponding norms of W[h]; not treated here.
Scope: only the hypotheses and K_1 of the local estimate are made uniform over perturbations; no inverse of A_h is
claimed, and the auxiliary inverse, rank-one denominator and outer matching remain open as for the trial.
