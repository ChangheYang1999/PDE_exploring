The \(P\)-row is implied by the full equation in the proposed disc space. **That does not, by itself, prove global surjectivity or eliminate every possible scalar obstruction.** There is an explicit matching equation at the origin; scaling makes normalization harmless at an exact solution only if the scaling vector belongs to the global domain. The transition and the projected nonlocal coupling still need estimates not supplied by F1–F5.

I take F1–F5 as hypotheses. Below, numerical values are illustrative unless a bound follows algebraically from the parameter box in F1. Write
\[
c_0=1+c_l,\qquad
\gamma h=[x^2y]h,
\]
and denote the complete coupling in the jet equation by
\[
Jh=
G_1'U_1[h](x,0)+G_1\partial_yU_2[h](x,0)
+\frac{c[h]}3(xG_1'+G_1).
\]

**Q1. The \(P\)-row is redundant, but the origin matching equation must be retained.**

Assume that \(V,\rho\) are smooth near \(P\), that \(V(P)=0\), and that \(h,f\in H^\sigma_{\mathrm{loc}}\) there, with \(\sigma>5/2\). Also assume the global realization makes \(U[h]\) continuously differentiable near \(P\) and makes \(c[h]\) well defined. The latter assumptions concern the nonlocal tails and do not follow from a disc norm alone.

These hypotheses imply that \(h,f\) are \(C^1\) near \(P\). No second derivative of \(h\) at \(P\) is needed: writing \(Z=X-P\),
\[
V(P+Z)\cdot\nabla h(P+Z)
=DV(P)Z\cdot\nabla h(P)+o(|Z|).
\]
Consequently,
\[
\partial_y(V\cdot\nabla h)(P)
=DV(P)e_y\cdot\nabla h(P)=\mu_P h_y(P).
\]
Differentiating the other terms, using parity, gives
\[
\boxed{\;
(\mu_P-1)h_y(P)+l_P(h)=f_y(P).
\;}
\tag{1}
\]
Equality \(Lh=f\), initially distributional, gives this identity because its terms have the stated representatives and differentiability at \(P\).

Thus at an exact profile,
\[
l_P(h)=f_y(P)
\]
is an equation already present in \(Lh=f\). It is not an additional boundary condition. For the trial, the implied equation is (1), including the small term \((\mu_P-1)h_y(P)\).

Now let \(b(x)=h_y(x,0)\), \(b_1=b(x_1)\), and
\[
R(x)=f_y(x,0)-Jh(x).
\]
On \(0<x\le x_1\),
\[
wb'+(\mu-1)b=R,\qquad b(x_1)=b_1.
\tag{2}
\]
Since \(w<0\), \(x_1\) is the incoming endpoint for this transport problem. Notice that \(R\) depends on the unknown global \(h\): solving (2) with that forcing is a representation of a coupled solution, not an independent construction of one.

At an exact profile, \(TG_1=0\), hence
\[
\boxed{\;
b(x)=G_1(x)\left[
\frac{b_1}{G_1(x_1)}
+\int_{x_1}^{x}\frac{R(t)}{w(t)G_1(t)}\,dt
\right].
\;}
\tag{3}
\]
Suppose
\[
G_1(x)/x^2\longrightarrow1,\qquad
\int_0^{x_1}\left|\frac{R(t)}{w(t)G_1(t)}\right|dt<\infty.
\tag{4}
\]
Then
\[
b(x)=\beta G_1(x)
+G_1(x)\int_0^x\frac{R(t)}{w(t)G_1(t)}\,dt,
\]
where
\[
\boxed{\;
\beta=
\frac{b_1}{G_1(x_1)}
-\int_0^{x_1}\frac{R(t)}{w(t)G_1(t)}\,dt.
\;}
\tag{5}
\]
In particular \(b(x)=\beta x^2+o(x^2)\).

For a quantitative version, assume
\[
w=-Ax+O(x^3),\qquad G_1=x^2(1+O(x^2)),
\qquad R=O(x^{2+\nu}),\quad \nu>0.
\]
Then
\[
b(x)=\beta x^2+O\!\left(x^{2+\min\{\nu,2\}}\right).
\tag{6}
\]
For perturbations with the prescribed corner expansion, \(\beta=\gamma h\).

The integrability hypothesis matters. If \(R=r_2x^2+o(x^2)\), a nonzero \(r_2\) produces
\[
b(x)=-\frac{r_2}{A}x^2\log x+\cdots.
\]
Even \(R/x^2\to0\) alone is insufficient: \(R=x^2/\log(e/x)\) produces a divergent logarithmic integral. The target space must impose the required remainder control, as well as the cubic coefficient condition furnished by F4.

If the incoming trace is prescribed independently, normalization requires the scalar equation
\[
\boxed{\;
\frac{b_1}{G_1(x_1)}
=
\int_0^{x_1}
\frac{f_y(t,0)-Jh(t)}{w(t)G_1(t)}\,dt.
\;}
\tag{7}
\]
This is the origin matching equation. It cannot simply be omitted.

At an exact profile, there is nevertheless a precise reason why normalization creates no *new obstruction to an already solvable global equation*. Assume that:

- \(K=X\cdot\nabla\rho-\rho\) belongs to the global domain;
- the domain permits adding multiples of \(K\);
- \(\gamma\) is a continuous functional on that domain.

Then
\[
LK=0,\qquad \gamma K=2,
\]
so every solution \(Lh=f\) has a normalized representative
\[
h_{\mathrm{norm}}=h-\frac{\gamma h}{2}K.
\tag{8}
\]
Its incoming disc trace changes along with its coupling, and (7) holds automatically for this representative. Indeed,
\[
K_y(x,0)=xG_1'(x),\qquad \gamma K=2.
\]

This proves that normalization removes the scaling direction. It does **not** prove that scaling is the entire kernel or that the unnormalized operator is onto. Nor does it apply if, for example, a prescribed far-field amplitude excludes \(K\). Those are genuine global questions.

For the trial, replace \(G_1\) in (3)–(5) by the positive integrating factor \(\Phi\) satisfying
\[
w\Phi'+(\mu-1)\Phi=0,\qquad \Phi(x)/x^2\to1.
\tag{9}
\]
The same formulas hold with \(G_1\) replaced by \(\Phi\). On \((0,x_1]\), this construction never divides by \(\mu_P-1\).

The near-\(P\) exponent is
\[
-\frac{\mu_P-1}{A_P}\simeq 2.22\times10^{-9}.
\]
At a fixed positive distance from \(P\), its effect is a factor involving this exponent times a logarithm of distance, not \(4.4\times10^7\). The latter number appears if one isolates
\[
b(P)=\frac{f_y(P)-l_P(h)}{\mu_P-1},
\]
thereby treating the essential coupling as an independently prescribed forcing. F1 directly demonstrates that this division is unnecessary for the coupled source operator.

There is an additional trial-profile qualification:
\[
\boxed{\;
LK=(X\cdot\nabla-1)F(\rho).
\;}
\tag{10}
\]
Thus (8) does not preserve the equation at an approximate profile. Stability of the normalized inverse must be certified from a full operator perturbation bound or a reduced matrix. The single number \(\mu_P-1\) establishes neither bad conditioning nor good conditioning of that global problem.

**Q2. An explicit transition norm exposes conditions missing from the proposal.**

Here is one concrete construction. Work first on \(y>0\), with smooth test functions supported away from the patch boundary. Choose a nonnegative smooth \(\lambda(x)\), constant and positive on the disc side and zero on the strip side, and put
\[
a(x,y)=\sqrt{y^2+\lambda(x)^2},
\qquad W(x,y)=e^{\phi(x)}a(x,y)^{-b_x}.
\tag{11}
\]
For example, \(\lambda(x)=\lambda_0\vartheta((x-x_0)/d)\), where \(\vartheta\) is smooth, nondecreasing, zero on \((-\infty,0]\), and one on \([1,\infty)\).

Define the positive Friedrichs realization
\[
\mathcal A_a=1-\partial_x^2-\partial_y(a^2\partial_y),
\]
and use the norm
\[
\|r\|_{\mathcal X}=\|\mathcal A_a^{\sigma/2}(Wr)\|_{L^2}.
\tag{12}
\]
Where \(\lambda\) is bounded below, this is locally equivalent to \(H^\sigma\). Where \(\lambda=0\), it is a weighted conormal norm associated with \(\partial_x,y\partial_y\). The principal symmetrizer is
\[
m=W(\xi^2+a^2\eta^2)^{\sigma/2}.
\]

The following principal-symbol calculation is rigorous on compact subsets where \(a>0\). Uniform estimates through the degenerating endpoint require additional estimates; ordinary local pseudodifferential calculus alone does not supply them. The composition and commutator rules used here are the usual principal-symbol rules. ([math.mit.edu](https://math.mit.edu/~rbm/18-155-F15/PseudodifferentialOperators.pdf), [math.mit.edu](https://math.mit.edu/~dyatlov/files/2011/nontrapping.pdf))

Let \(p=V_1\xi+V_2\eta\). The principal real part after conjugation is
\[
\beta_m=-c_0-H_p\log m+q.
\tag{13}
\]
Set
\[
v_a=V\cdot\nabla\log a.
\]
Direct differentiation gives
\[
\boxed{
\begin{aligned}
\beta_m={}&-c_0-V_1\phi'+b_xv_a+q\\
&+\sigma
\frac{
V_{1x}\xi^2+
(V_{2x}+a^2V_{1y})\xi\eta+
a^2(V_{2y}-v_a)\eta^2
}{
\xi^2+a^2\eta^2
}.
\end{aligned}}
\tag{14}
\]
This includes the stretching, the weight derivative, the changing transverse scale, and the coupling.

Define
\[
S_a=
\begin{pmatrix}
V_{1x}&\frac12(V_{2x}/a+aV_{1y})\\
\frac12(V_{2x}/a+aV_{1y})&V_{2y}-v_a
\end{pmatrix}.
\]
An explicit sufficient condition for negative principal real part is
\[
\boxed{\;
-c_0-V_1\phi'+b_xv_a
+\sigma\lambda_{\max}(S_a)
+\frac{|\nabla\rho|-\rho_y}{2}
\le-\kappa.
\;}
\tag{15}
\]
The sharper condition is simply (14) \(\le-\kappa\) for every direction; (15) sacrifices the correlation between stretching and coupling.

If \(\rho_y>0\), one can bound the adverse coupling by
\[
\frac{|\nabla\rho|-\rho_y}{2}
=\frac{\rho_x^2}{2(|\nabla\rho|+\rho_y)}
\le\frac{\rho_x^2}{4\rho_y}.
\tag{16}
\]
Thus a thin strip helps with the positive part of \(q\), provided bounds for \(\rho_x,\rho_y\) are certified.

For the axis-linear model
\[
V_1=w(x),\qquad V_2=\mu(x)y,
\]
one has
\[
v_a=\frac{w\lambda\lambda'+\mu y^2}{\lambda^2+y^2}.
\tag{17}
\]
At \(y=0\), with \(\lambda>0\), a pure transverse frequency gives
\[
\boxed{\;
\beta_\perp
=-c_0-w\phi'+\sigma\mu
+(b_x-\sigma)w\frac{\lambda'}{\lambda}.
\;}
\tag{18}
\]
This term is easy to miss. Along the incoming flow, \(w<0\) and \(\lambda'\ge0\). Therefore, when \(b_x<\sigma\), collapse of the transverse scale contributes *positively*.

In fact, if \(\lambda\) becomes zero at a finite endpoint with \(w\) bounded away from zero, then \(\lambda'/\lambda\) is unbounded along some sequence. If \(b_x<\sigma\) and \(\phi'\) stays bounded, (18) becomes arbitrarily positive. Hence this particular transition cannot have a uniformly negative principal real part under those assumptions—even if \(\sigma\mu-c_0<0\) everywhere in the transition.

Taking \(b_x\ge\sigma\) removes that particular adverse term, but introduces stronger weighted regularity requirements. It does not finish the construction.

On the pure strip side, write \(\tau=y\eta\). At the boundary \(y=0\), the stretching matrix in these variables is
\[
S_{\rm strip}=
\begin{pmatrix}
w'&\mu'/2\\
\mu'/2&0
\end{pmatrix}.
\tag{19}
\]
In particular, a conservative sufficient transport condition is
\[
b_x\mu-w\phi'
+\frac{\sigma}{2}
\left(w'+\sqrt{(w')^2+(\mu')^2}\right)
<c_0-\kappa,
\tag{20}
\]
with off-axis and coupling errors added using (14).

This also explains why the negative coupling on the physical axis is insufficient. For fixed \((\xi,\tau)\) with \(\tau\ne0\), its limiting symbol is zero, whereas the conormal stretching in (19) need not be negative.

There is a useful sharper check on the characteristic set. At the conormal boundary,
\[
p=w\xi+\mu\tau=0.
\]
For \(w\ne0\), substitution of \(\tau=-w\xi/\mu\) gives
\[
\boxed{\;
\beta_{\rm char}
=-c_0+b_x\mu-w\phi'
+\sigma\frac{w'-w\mu'/\mu}{1+(w/\mu)^2}.
\;}
\tag{21}
\]
The coupling tends to zero in this limit. As \(x\to x_*^-\), the right-hand side tends, for bounded \(\phi'\), to
\[
-c_0+b_x+\sigma A_P.
\]
At \(\sigma=3.25\), this is approximately \(26.41+b_x\). Thus a pure strip norm with customary positive \(b_x\) cannot extend all the way to \(P\) with this negative characteristic-energy mechanism. The ordinary disc is doing essential work.

Failure of negativity away from the characteristic set need not obstruct an a priori estimate: those frequencies can be treated by elliptic estimates. That distinction is part of the usual propagation argument and must also be respected in the adapted calculus. ([math.mit.edu](https://math.mit.edu/~dyatlov/files/2011/nontrapping.pdf))

The cutoff terms are equally explicit. For
\[
\chi(x,y)=\theta(y/\lambda(x)),
\]
\[
\boxed{\;
[V\cdot\nabla,\chi]
=\theta'(y/\lambda)
\left(\frac{V_2}{\lambda}
-\frac{yV_1\lambda'}{\lambda^2}\right).
\;}
\tag{22}
\]
An additional longitudinal cutoff contributes \(V_1\partial_x\chi\).

For a sum of localized energies with principal symbols
\[
m_{\rm tot}^2=\sum_j\chi_j^2m_j^2,
\]
the corresponding principal real part is
\[
\beta_{\rm tot}
=\sum_j\omega_j\beta_j
-\frac{\sum_j\chi_j(V\cdot\nabla\chi_j)m_j^2}
{\sum_j\chi_j^2m_j^2},
\qquad
\omega_j=\frac{\chi_j^2m_j^2}{m_{\rm tot}^2}.
\tag{23}
\]
Even if \(\sum_j\chi_j^2=1\), the last term need not cancel when the norms differ. Equations (14), (22), and (23) provide pointwise conditions that can actually be checked.

For the jet extension, take \(Eb=\chi(x,y)yb(x)\), with \(\chi=1\) near the axis in the strip. An exact identity is
\[
\boxed{
\begin{aligned}
&(V\cdot\nabla-1)Eb-E\{wb'+(\mu-1)b\}\\
&\quad=\chi y(V_1-w)b'
+\chi(V_2-\mu y)b
+y(V\cdot\nabla\chi)b.
\end{aligned}}
\tag{24}
\]
By parity, the first two terms are \(O(y^3)(|b'|+|b|)\) for smooth coefficients. The last term is supported where the extension changes.

For example, if
\[
|V_1-w|\le C_1y^2,\qquad
|V_2-\mu y|\le C_2|y|^3,
\]
then their weighted \(L^2\) norm over \(|y|<d\) is bounded by
\[
\left(\frac{2d^{7-2b_x}}{7-2b_x}\right)^{1/2}
\bigl(C_1\|b'\|_{L^2_x}+C_2\|b\|_{L^2_x}\bigr),
\qquad b_x<7/2.
\tag{25}
\]
Higher-order estimates require the corresponding coefficient and jet derivatives. These extension terms are off-diagonal blocks; they are not automatically harmless lower-order errors.

There is also a trace-lifting issue. The disc estimate supplies
\[
h_y|_{y=0}\in H^{\sigma-3/2}_x.
\]
A fixed product extension \(\chi(y)yb(x)\) does not map this trace space boundedly into \(H^\sigma(\mathbb R^2)\): high tangential frequencies immediately show the missing \(3/2\) derivatives. One must choose a bounded Sobolev jet lifting, use an appropriate lower-order jet norm, or establish additional regularity. F1 alone does not justify a fixed product extension inside an \(H^\sigma\) estimate.

Finally, the proposed threshold
\[
\mu<c_0/\sigma
\]
is **not a universal necessary condition for transition**. On a compact collar with \(w\ne0\), any bounded adverse rate \(B(x)\) can be offset by choosing
\[
w\phi'\ge B(x)+\kappa.
\tag{26}
\]
The equivalence constant costs an exponential of the finite flow-time integral
\[
\int_{x_0}^{x_1}\frac{B(x)+\kappa}{|w(x)|}\,dx.
\]
Thus positive unweighted rates can be tolerated on a finite collar. But the scale-collapse divergence in (18), or an infinite orbit cost, cannot be paid by a bounded equivalent weight. Conversely, transitioning where \(\mu<c_0/\sigma\) does not by itself control the cutoff and scale derivatives.

**Q3. The remainder needs a projected coupling, and the jet has its own nonlocal equation.**

For \(y>0\), the interior principal symbol of the coupling in conormal frequencies \((\xi,\tau)\), \(\tau=y\eta\), is
\[
\boxed{\;
q_b(x,y,\xi,\tau)
=\frac{\rho_x\,y\xi\tau-\rho_y\,y^2\xi^2}
{y^2\xi^2+\tau^2}.
\;}
\tag{27}
\]
Scalar conjugation does not change this interior principal symbol. But it is not a smooth, uniformly ordinary order-zero symbol on the whole conormal boundary: its limits at \(y=0,\tau=0\) depend on the approach. Boundedness and commutator estimates in the proposed weighted space therefore require proof.

More decisively, the raw coupling does not preserve a zero-jet remainder. If \(r_y(x,0)=0\), generally
\[
\bigl(U[r]\cdot\nabla\rho\bigr)_y(x,0)
=G_1'U_1[r](x,0)+G_1\partial_yU_2[r](x,0)\ne0.
\tag{28}
\]
Thus a smooth remainder vanishing like \(y^3\) can be sent to a function with a nonzero \(y\)-term. Such an output fails to lie in \(L^2(|y|^{-2b_x}dx\,dy)\) when \(b_x\ge3/2\), since
\[
\int_0^\varepsilon y^{2-2b_x}\,dy=\infty.
\]
This is an actual mapping obstruction, not a question of the sign of \(q\).

Let \(J_0r=r_y|_{y=0}\) and choose an extension with \(J_0E=I\). The remainder coupling must consequently be
\[
\boxed{\;
(I-EJ_0)\bigl(U[r]\cdot\nabla\rho
+\tfrac{c[r]}3X\cdot\nabla\rho\bigr).
\;}
\tag{29}
\]
The subtracted jet goes into the jet equation. This projection has to be included in both the boundedness estimates and the energy estimate; it is not generally orthogonal.

The operators induced by a fixed transverse extension can be computed exactly. Let
\[
Eb(x,y)=y\chi(y)b(x),
\]
where \(\chi\) is even, smooth, compactly supported, and equal to one near zero. Take \(b\) initially Schwartz on the whole line; an interval formulation additionally needs a specified extension in \(x\). Define
\[
I_\chi(a)=\int_0^\infty z\chi(z)e^{-az}\,dz.
\tag{30}
\]
Fourier transformation in \(x\), with frequency \(k\), gives
\[
(-\partial_y^2+k^2)\widehat\psi
=ik\,\widehat b(k)\,y\chi(y).
\]
Using its Green kernel \(e^{-|k||y-z|}/(2|k|)\), differentiation at zero yields
\[
\boxed{
\begin{aligned}
\widehat{U_1[Eb](\cdot,0)}(k)
&=-ikI_\chi(|k|)\widehat b(k),\\
\widehat{\partial_yU_2[Eb](\cdot,0)}(k)
&=-k^2I_\chi(|k|)\widehat b(k).
\end{aligned}}
\tag{31}
\]
The second identity also follows from incompressibility,
\(\partial_yU_2=-\partial_xU_1\).

Write \(B_\chi\) and \(P_\chi\) for the multipliers
\[
-ikI_\chi(|k|),\qquad k^2I_\chi(|k|),
\]
respectively. Because \(\chi=1\) near zero,
\[
I_\chi(a)=a^{-2}+\text{a rapidly decreasing error},\qquad a\to\infty.
\]
Hence
\[
B_\chi:\text{ order }-1,\qquad
P_\chi=I-S_\chi,
\tag{32}
\]
where \(S_\chi\) gains arbitrarily many ordinary Sobolev derivatives. Thus:

- \(U_1[Eb]|_{y=0}\) is an order \(-1\) operator, with high-frequency multiplier \(-i/k\), rather than an order-zero Hilbert transform.
- \(\partial_yU_2[Eb]|_{y=0}\) is \(-b\) plus a smoothing operator.
- Both remain nonlocal, and smoothing alone does not imply compactness on the full line.

Moreover,
\[
c[Eb]=\partial_yU_2[Eb](0,0)=-(P_\chi b)(0).
\]
The complete induced jet coupling is therefore
\[
\boxed{\;
N_\chi b
=G_1'B_\chi b-G_1P_\chi b
-\frac{xG_1'+G_1}{3}(P_\chi b)(0).
\;}
\tag{33}
\]
Its leading one-dimensional term is the local damping \(-G_1b\). Its remaining terms include nonlocal operators and the strain functional.

The split system contains
\[
(T+N_\chi)b=f_y-Jr,
\tag{34}
\]
together with the remainder equation and matching to the disc. It needs an estimate of its own unless the full two-dimensional estimate already controls this block.

A simple sufficient condition can be stated without pretending it is satisfied numerically. On \(I=[x_0,x_1]\), with \(w<0\), impose homogeneous incoming data at \(x_1\). For the integrating factor \(\Phi\) in (9), define
\[
M=\sup_{x\in I}
\int_x^{x_1}\frac{\Phi(x)}{|w(t)|\Phi(t)}\,dt.
\tag{35}
\]
The Volterra formula proves
\[
\|T^{-1}\|_{C^0(I)\to C^0(I)}\le M.
\]
If the specified extension and coupling satisfy
\[
\|N_\chi\|_{C^0(I)\to C^0(I)}\le n,\qquad Mn<1,
\]
then
\[
\boxed{\;
\|(T+N_\chi)^{-1}\|
\le\frac{M}{1-Mn}.
\;}
\tag{36}
\]
Nonzero incoming data are handled by a lift. For the smooth fixed cutoff above, bounds for \(n\) can be obtained from the convolution-kernel norms of \(B_\chi,S_\chi\), multiplication coefficients, and the chosen longitudinal extension.

There is an analogous normalized formulation on \((0,x_1]\). In
\[
\|b\|_\nu=\sup_{0<x\le x_1}x^{-2-\nu}|b(x)|,\qquad \nu>0,
\]
use the origin-normalized inverse
\[
T^{-1}_\nu R(x)=
\Phi(x)\int_0^x\frac{R(t)}{w(t)\Phi(t)}\,dt.
\]
Its bound is
\[
M_\nu=\sup_x x^{-2-\nu}
\int_0^x\frac{\Phi(x)t^{2+\nu}}{|w(t)|\Phi(t)}\,dt.
\tag{37}
\]
For \(w=-Ax,\ \Phi=x^2\), this equals \(1/(A\nu)\). If the full normalized jet coupling is bounded on this space by \(n_\nu\), then \(M_\nu n_\nu<1\) gives the bound \(M_\nu/(1-M_\nu n_\nu)\).

In this version the value at \(x_1\) is an output. Matching it to the disc is still required. These conditions are sufficient, not numerical claims about the proposed profile.

**Q4. A validated Schur complement is the cleaner route, after establishing a genuine global high-frequency estimate.**

An estimate
\[
\|h\|_X\le C\|Lh\|_Y+C'\|h\|_{X_{\rm weak}}
\tag{38}
\]
does not yet give an inverse. If the weaker inclusion is compact on the relevant graph-bounded sets, a contradiction argument gives finite-dimensional kernel and closed range. Surjectivity or finite-dimensional cokernel still needs an adjoint estimate or a suitable parametrix.

Compactness is a substantial hypothesis here. Lowering differential order while keeping the same weights does not ensure it: translations in \(\log y\), \(\log x\), or toward spatial infinity can remain bounded without convergent subsequences. Frequency truncation on the full plane is also not finite rank. The construction needs spatial/tail control as well as frequency control.

Once those issues are settled, work with the normalized operator, or equivalently retain normalization as a row:
\[
h\longmapsto (Lh,\gamma h)
\quad\text{with target }Y_0\oplus\mathbb R,
\qquad Y_0=\{f:\gamma f=0\}.
\tag{39}
\]
The global coupling at \(P\) must remain in the infinite-dimensional principal operator.

Choose finite-dimensional complements and write
\[
L=
\begin{pmatrix}
A&B\\ C&D
\end{pmatrix}.
\]
Suppose \(D\) is proved bijective with
\[
\|D^{-1}\|\le d.
\]
The finite-dimensional quantity to certify is
\[
\boxed{\;
S=A-BD^{-1}C,\qquad \sigma_{\min}(S)\ge s>0.
\;}
\tag{40}
\]
This certification must include errors in approximating \(D^{-1}\), the coupling, the strain, and the matching functionals. A positive lower singular-value bound is more useful than merely verifying a nonzero determinant.

The block inverse formula gives, for compatible direct-sum norms, the conservative bound
\[
\boxed{\;
\|L^{-1}\|
\le d+(1+d\|C\|)\,s^{-1}(1+\|B\|d).
\;}
\tag{41}
\]
Alternatively, a numerical inverse can be validated by two-sided residual bounds. One-sided injectivity information alone must not be presented as surjectivity.

A homotopy that turns the coupling off is not justified in these spaces. At the frozen source, replacing \(g\) by \(tg\) requires, for negative fast-direction energy,
\[
\sigma A<c_0+tg.
\tag{42}
\]
At the illustrative trial values and \(\sigma=3.25\), this requires approximately
\[
t>0.88788.
\]
At \(t=0\), F3 also supplies the failed \(P\)-row for transport alone. Thus an index argument starting from uncoupled transport would cross a regime where the required realization is not controlled; F1’s high-regularity obstruction makes this especially consequential.

The Schur-complement route avoids that homotopy. It still needs a proved global principal estimate, bounded jet/remainder couplings, and a controlled infinite-dimensional complement. F1–F5 do not yet provide those ingredients.

**Q5. The frozen-source window is nonempty; a global parameter window has not been established.**

For the frozen source, strict negativity in every Fourier direction is equivalent to
\[
\boxed{
\begin{aligned}
\sigma A&<g+\frac{A+\mu}{2}+1,\\
\sigma\mu&<\frac{A+\mu}{2}+1.
\end{aligned}}
\tag{43}
\]
Together with the desired ordinary \(C^{2,\alpha}\) regularity, a sufficient local window is
\[
3<\sigma<
\min\left\{
\frac{g+(A+\mu)/2+1}{A},
\frac{(A+\mu)/2+1}{\mu}
\right\}.
\tag{44}
\]
At \(\mu=1\), the first endpoint is the given \(s_{\rm fast}\).

There is also an exact uniform calculation over the entire F1 parameter box. The two worst directional coercivity margins are
\[
\kappa_y=6-(\sigma-\tfrac12)\frac{101}{100},
\qquad
\kappa_x=\frac{99}{200}+30-(\sigma-\tfrac12)\frac{51}{5}.
\tag{45}
\]
They give
\[
\begin{array}{c|c|c}
\sigma&\kappa_y&\kappa_x\\ \hline
31/10&1687/500&159/40\\
13/4&1289/400&489/200
\end{array}
\]
and therefore a nonempty uniform window
\[
3<\sigma<\frac{2373}{680}\approx3.48971.
\tag{46}
\]

At \(\sigma=13/4\), the frozen inverse bound can in fact be extended from the same calculation:
\[
\boxed{\;\|L_P^{-1}\|_{H^{13/4}\to H^{13/4}}\le\frac{200}{489}.\;}
\tag{47}
\]
Here is the existence justification, rather than merely an energy estimate. The affine transport with bounded Fourier-multiplier coupling generates a strongly continuous evolution \(S(t)\), obtained directly by Fourier characteristics. The inhomogeneous Sobolev rate is bounded above by the homogeneous rate, since its positive stretching factor is multiplied by
\[
\frac{|\zeta|^2}{1+|\zeta|^2}\le1.
\]
Thus \(\|S(t)\|\le e^{-(489/200)t}\), and
\[
L_P^{-1}f=-\int_0^\infty S(t)f\,dt
\]
is a two-sided inverse on the maximal graph domain. This proves (47) for the frozen model.

For the variable disc, a useful sufficient principal perturbation condition is
\[
\sup_{B(P,r_P)}
\left[
\sigma\|\operatorname{sym}(DV-DV(P))\|
+\tfrac12|\rho_x|+|\rho_y-g|
\right]<\kappa_P.
\tag{48}
\]
One should retain margin for localization and lower-order terms. Smoothness ensures that the expression tends to zero with \(r_P\), but the supplied floating data do not give a certified radius.

There are two qualifications to “take the disc smaller.” First,
\[
(V-V_{\rm frozen})\cdot\nabla
\]
is not automatically a small bounded perturbation of the maximal transport graph operator; that graph norm need not control every derivative. The energy argument is the appropriate starting point. Second, a cutoff on scale \(r_P\) has
\[
|V\cdot\nabla\chi|\sim O(1),
\]
since \(V=O(r_P)\) and \(\nabla\chi=O(r_P^{-1})\). Shrinking the disc does not automatically make its transport commutator small.

For the strip and corner, the conditions must include:

- the principal inequalities (14), or their characteristic versions together with elliptic estimates;
- the cutoff terms (22)–(23);
- bounded jet lifting and projected coupling (29);
- admissibility of the weights for the actual remainder;
- the corner gap from F2, bounded away from zero.

For example, if the corner remainder contains a generic \(x^p y^q\) term and the measure is \(dx\,dy\), local integrability requires
\[
a<p+\tfrac12,\qquad b<q+\tfrac12.
\tag{49}
\]
F2 requires
\[
\delta=bD-aA-c_0\ne0.
\]
A negative-energy implementation specifically requires \(\delta<0\).

There is a concrete interaction with the jet choices. If only the \(y\)-jet has been removed, a generic corner remainder still contains \(x^2y^3\), requiring \(a<5/2\). If \(b\ge3/2\), then the exact identities give
\[
\delta
=D(b-\tfrac32)+A(\tfrac52-a)>0.
\tag{50}
\]
Thus those choices cannot give a negative corner energy. They can still use F2’s positive-gap inverse, or split further corner jets, but the distinction must enter the gluing argument.

The floating value
\[
c_0/\sigma=2.0232\qquad(\sigma=3.25)
\]
is consequently only an unweighted isotropic diagnostic. It neither certifies the collar nor rules out a collar with suitable weights.

What is established is the redundant \(P\)-row, the jet representation and normalization mechanism under the stated domain hypotheses, the explicit transition-symbol formulas, the projected remainder structure, and a nonempty frozen-source window. **A global inverse bound, absence of additional kernel or cokernel, and a nonempty fully compatible choice of collar and corner parameters remain unproved from F1–F5.** The next decisive certificate is a global complement estimate followed by the positive lower singular-value bound in (40).

Opus 5.5 collaboration was unavailable: the permitted Bedrock credential-source connection failed with “Operation not permitted,” so no second-model review was obtained.