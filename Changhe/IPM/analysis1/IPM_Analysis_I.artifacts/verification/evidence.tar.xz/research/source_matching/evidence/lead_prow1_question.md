You are an independent mathematical researcher and referee, consulted by another researcher working on the problem described below. Be skeptical, concrete and complete; check every step you rely on; say plainly when something is wrong, unproved, or only conditional. Your final message is your answer: make it self-contained.

Machine rules (no exceptions): never start a server or anything that listens on a port; never run JavaScript tooling (node, npm, npx, pnpm, yarn, vite, playwright); no GPU; wrap shell commands in `timeout 540`; single-threaded computations under 2 GB RAM. Write files only in your current directory. Do not modify any other file.

Question:

Context. We study self-similar profiles of the 2D incompressible porous media (IPM) equation in the full plane. The
profile equation is F(rho) = (c_l X + U[rho]).grad rho - rho = 0 with U = grad^perp psi = (-psi_y, psi_x), -Lap psi = d_x rho
(canonical full-plane inverse), rho even in x and odd in y, rho = x^2 y a(X) near 0 with a(0) = 1, c_l = (1 + psi_xy(0))/3.
On the Fourier side U[h]^ = (xi eta, -xi^2)/|zeta|^2 h^, so U is bounded on L^2 with norm 1 and U[h].grad rho has the
order-zero symbol q(X, zeta^) = rho_x xi^ eta^ - rho_y xi^2 (zeta^ = zeta/|zeta|).
Linearization at a profile: L h = (V.grad - 1) h + U[h].grad rho + (c[h]/3) X.grad rho, V = c_l X + U[rho],
c[h] = psi_xy[h](0) (strain functional; c_l depends on rho). div V = 2 c_l.
For an explicit numerical trial: c_l = 5.5754 (= 1/k, k = 0.17936), DV(0) = diag(-A, D), A = 2 c_l - 1 = 10.1507,
D = 2A + 1 = 21.3015; second axis zero P = (x_*, 0), x_* = 8.6001, DV(P) = diag(A_P, mu_P), mu_P = 2 c_l - A_P.
At exact solutions A_P = A and mu_P = 1 (identity w'(x_*) = -w'(0) for w(x) = V_1(x, 0)); for the trial
mu_P - 1 = -2.25e-8. g := rho_y(P) = 29.75. Write G_1(x) = rho_y(x, 0) = x^2 e^{H(x)} > 0 on (0, inf) and
mu(x) = d_y V_2(x, 0) = 2 c_l - w'(x); floating values: mu ranges over [0.9885, 21.3015] on (0, inf) (mu(0) = D,
minimum near x = 8.88, mu -> c_l at infinity); w < 0 on (0, x_*), w > 0 beyond, so on the x-axis the flow runs from P
towards 0 and towards infinity. 0 is a saddle (incoming along x, outgoing along y); P is a source.

Verified facts (treat as given).
(F1) Frozen coupled source: L_P = A s d_s + mu y d_y - 1 - g M, M = xi^2/|zeta|^2, s = x - x_*. A direct Fourier energy
computation gives Re <L_P h, h>_{H^sigma-dot} = int |zeta|^{2 sigma} |h^|^2 beta(zeta^),
beta = -(A + mu)/2 - 1 + sigma (A xi^2 + mu eta^2) - g xi^2 (affine in xi^2), and a verified theorem: L_P is bijective from
its maximal graph domain onto inhomogeneous H^{31/10} (also on the parity subspace) with inverse norm <= 500/1687 for
10 <= A <= 51/5, 99/100 <= mu <= 101/100, 29 <= g <= 30. Above s_fast = (g + (A + 3)/2)/A = 3.5785 (mu = 1) the cokernel is
infinite dimensional, and for the variable-coefficient operator no ordinary H^s realization with s above threshold
(plus finite rank) is Fredholm. So near P we use an ordinary H^sigma disc, 3 < sigma < s_fast (the class P_2 needs C^{2,alpha}).
(F2) Saddle: T_0 = -A x d_x + D y d_y - 1 on the quadrant with b-Sobolev norm sum_{i+j<=m} ||x^{-a} y^{-b} (x d_x)^i (y d_y)^j f||
is invertible iff delta := bD - aA - (A+3)/2 != 0, inverse norm exactly 1/|delta|. Isotropic Sobolev fails at the saddle
(the y-frequency rate sigma D - (1 + c_l) > 0 for sigma > 0.309), hence near 0 and along the incoming x-axis we use b-vector
fields (y d_y, and x d_x near 0) with power weights, splitting off axis jets.
(F3) x-axis jet. For h odd in y put b(x) = h_y(x, 0). Differentiating L h = f in y at y = 0:
  w b' + (mu - 1) b + U_1[h](x, 0) G_1' + d_y U_2[h](x, 0) G_1 + (c[h]/3)(x G_1' + G_1) = f_y(x, 0).
The jet transport T b = w b' + (mu - 1) b has T G_1 = 0 at exact solutions (equation of rho at order y). At P (w = 0,
mu_P = 1) the equation reduces to the nonlocal scalar relation l_P(h) := U_1[h](P) G_1'(P) + d_y U_2[h](P) g
+ (c[h]/3)(x_* G_1'(P) + g) = f_y(P). Transport alone (coupling treated as forcing) is not onto any space containing
f_y(P) != 0, and for the trial any such inverse with bounded evaluation at P costs >= 1/|mu_P - 1| = 4.4e7. Near P a
homogeneous jet behaves like |x - x_*|^{-(mu_P - 1)/A_P}. Near 0 the homogeneous jet behaves like x^{(D-1)/A} = x^2.
(F4) Symmetry and normalization. rho_lambda(X) = lambda^{-1} rho(lambda X) solves the same equation with the same c_l, so
K = X.grad rho - rho satisfies L K = 0 at exact solutions; [x^2 y] K = 2 and the normalization a(0) = 1 linearizes to
[x^2 y] h = 0. The x^2 y coefficient of F(rho) vanishes identically by the definition of c_l, and the x^2 y coefficient
of the normalized coupling is identically 0 (verified). The cubic coefficient of a perturbation divisible by x^2 y is
multiplied by -2A + D - 1 = 0.
(F5) Floating diagnostics (not proofs): with sigma = 3.25 the isotropic energy rate restricted to the characteristic set
(zeta normal to V) is <= -1.87 on |X - P| < 1; it equals sigma D - (1 + c_l) = 62.65 on the incoming x-axis near 0.
Orbit costs of its positive part from a circle around P: about 1.61 for orbits leaving towards infinity, unbounded
for orbits hugging the incoming x-axis.

Design under consideration (lead proposal, not proved): an ordinary H^sigma disc B(P, r_P); on the strip along the
x-axis between the corner region and the disc, regularity measured by d_x and y d_y with a power weight |y|^{-2 b_x}
and the jet b split off (h = chi y b(x) + h_rem); b-Sobolev with product weights and jets at the corner; flow-adapted
weights elsewhere. The jet is NOT split at P.

Questions. Give proofs or explicit counterexamples; state hypotheses exactly; separate what is proved from what is
heuristic. Be candid if a step cannot be done.
Q1. The P-row in this design. Show precisely that with no jet splitting on B(P, r_P) the relation l_P(h) = f_y(P) is
not an extra condition: it is implied by L h = f for h in the H^sigma disc space (sigma > 5/2 so that h_y and f_y have
traces at P). Then show how the jet b on (0, x_1], x_1 = x_* - r_P/2, is determined: incoming data b(x_1) from the disc
trace, transport toward 0 (w < 0), forcing including the coupling functionals of h. Compute the behaviour at 0
(b = beta x^2 + particular part), identify beta with [x^2 y] h, and show that the count is consistent: the normalization
[x^2 y] h = 0 removes exactly the scaling direction K, and no scalar solvability condition (Melnikov-type) remains, or
exhibit the condition if one does. Address both exact solutions (mu_P = 1) and the trial (mu_P - 1 = -2.25e-8, where
T G_1 != 0): does the trial's tiny defect create an ill-conditioned scalar anywhere in this design, and how large?
Q2. Transition collar. On x in [x_0, x_1] near P, mu(x) grows from about 1 toward D as x decreases, and the isotropic
y-frequency rate sigma mu(x) - (1 + c_l) becomes positive. Construct an explicit transition norm between d_y-regularity
(isotropic disc) and y d_y-regularity with weight |y|^{-2 b_x} (strip), for example via cutoffs in y/lambda(x) or a
variable-order or anisotropically scaled norm, and compute the principal part of Re <L h, h> in it, including the
commutators of V.grad with the transition cutoffs and the jet extension, and the coupling symbol q. State explicit
pointwise sufficient conditions (inequalities involving mu(x), w(x), w'(x), G_1, rho_x, b_x, sigma, cutoff derivatives).
Is there an obstruction: must the transition occur where sigma mu(x) - (1 + c_l) < 0, i.e. at points with
mu(x) < (1 + c_l)/sigma (about 2.02 for sigma = 3.25), and is that compatible with the y d_y-norm on the side towards 0?
Q3. Sign of the coupling. On the x-axis rho_x = 0 and rho_y = G_1 > 0, so q = -G_1 xi^2 <= 0 there; away from the axis
the quadratic form q has eigenvalues (-rho_y +- |grad rho|)/2. In the strip norm (y d_y-regularity), what is the
principal symbol of the coupling acting on h_rem, and what operator does the coupling induce on the jet b (compute
d_y U_2[chi y b](x, 0) and U_1[chi y b](x, 0) as 1D operators on b: are they Hilbert-transform-type, local, smoothing)?
Does the jet system become a 1D nonlocal transport equation whose solvability needs its own estimate, and if so give the
simplest sufficient condition for its invertibility with an explicit bound.
Q4. Lower-order terms and closure. With the principal parts negative (assume this), the a priori estimate has the form
||h|| <= C ||L h|| + C' ||h||_weak with a weaker norm. State the cleanest route to an explicit inverse bound that is
compatible with a computer-assisted proof: for example, a finite-rank approximation of the low-frequency coupling with a
validated Schur complement, or a homotopy in the coupling strength with an index count. Which route needs the fewest
unproved ingredients given F1-F5, and what finite-dimensional quantity would have to be certified?
Q5. Consistency check. Relate the design to the verified frozen estimate (F1): which parameter inequalities on
(sigma, r_P, b_x, collar widths) are necessary, which are sufficient, and is the window nonempty at the trial values?

Answer in text with formulas; do not start servers, run JavaScript tooling or Lean, or write outside your working area.
