# Velocity splitting and coupling on a collar of the y-axis (gap G1, y-face part, local)

Lead note, revision 2, 2026-10-20T19:05Z (revision 1 of 18:29Z kept as notes/yface_collar_v1_backup.md).
Status: Lemma S, Lemma NF-Y, Lemma E-Y and Corollary CC-Y are EXACT with proofs below, by reduction to
notes/collar_coupling.md revision 2 (Lemmas NF, E; astra-audited, verifier check V10 CONFIRMED) and
notes/weighted_velocity.md (Lemma W1, astra-audited VALID for N >= 1). Revision 1 was audited by astra (single-model,
verdict NEEDS-FIX: identities, smoothing mechanism, coupling coefficients and remainder constants correct; repairs
required in the meaning of the jets, the localization of the edge inputs, finite-regularity ranges, and the
justification of the axis condition). All repairs are incorporated here; changes from revision 1 are listed in section 7.
Verifier check V12 refers to THIS revision. Floating sanity checks: code/check_yface.py (not an accuracy certificate,
see section 7); constants: code/yface_constants.py.

## 0. Summary
- (Lemma S, swap) With `(S h)(x, y) = h(y, x)`: `U_1[h] = S U_1[S h]` and `U_2[h] = -h - S U_2[S h]`. So `U_1` and the
  nonlocal part `U~_2 := U_2 + h` are, after the swap, the x-face operators `U_1` and `-U_2` of collar_coupling.md; the
  local term `-h` of `U_2` is carried separately. The kernel estimates of the x-face lemmas transfer with `y`-weights
  replaced by `x`-weights, `b` by `a`, and `N = 3` by `N = 6` (the corner window `5.5 < a < 6.5`). The parity-specific
  statements do not transfer literally (after the swap the density is odd in the new x and even in the new y); they are
  re-derived in (P-Y).
- (Lemma NF-Y) On a collar `(-d/2, d/2) x J` of the y-axis away from the corner, `U_1 = sum_{l<6} chi_0(x) x^l v_{1,l} + R_1`
  and `U~_2 = sum_{l<6} chi_0(x) x^l v~_{2,l} + R~_2` with `R_1, R~_2` in `L^2(|x|^{-2a})` and the coefficients in
  inhomogeneous `H^{a - l - 1/2}`, explicit constants. The coefficients are defined by continuous extension (section 1.3),
  not as classical traces.
- (Lemma E-Y) For a localized edge component `H_p = Phi_p(x) E_p(y)`, the FULL velocity jets (local term included) are
  SMOOTHING in `E_p`: order `-2` for the even jets of `U_2`, order `-1` for the odd jets of `U_1`, with explicit multiplier
  bounds; the jets `v_{2,p}`, `v_{1,p+1}` are smoothing of infinite order (exponential multiplier). The local term `-h`
  cancels exactly the order-zero part of `U~_2`. This is the reverse of the x-face, where `u_{2,1}[y chi c] = -c + smooth`
  has an order-zero part (collar_coupling 3, Remark 1). Reason: `U_2 = -M h`, `M = xi^2/|zeta|^2`; an x-face edge
  component oscillates in x (`M -> 1`), a y-face edge component oscillates in y (`M -> 0`).
- (Corollary CC-Y) For `rho` even in x, `rho(0, y) = 0`, `rho in W^{7,inf}` near the collar and finite strain `c[h]`,
  `W[h].grad rho = chi_0(x) [x^2 q_2[h](y) + x^4 q_4[h](y)] + R_W[h]`, `R_W in L^2(|x|^{-2a})` on the collar, with the
  exact remainder formula (5.2); the near part of `q_2` (resp. `q_4`) lies in `H^s` for `0 <= s <= min(a - 3/2, 4)` (resp.
  `min(a - 7/2, 2)`), i.e. in `H^4` (resp. `H^2`) throughout the window; the edge parts of `q_2, q_4` gain one tangential
  derivative over `(E_2, E_4)` in the ranges (5.4); the far parts are `W^{4,inf}(J)` and `W^{2,inf}(J)`.
- Consequence (local bookkeeping, not an invertibility statement): on bounded collars of the y-axis the coupling adds
  to the triangular edge transport system of conormal_framework 2.1 only terms that gain at least one tangential
  derivative (compact on bounded intervals); it introduces neither a transport derivative nor a zeroth-order
  multiplication term. On the x-face it does introduce a zeroth-order term (the `-rho_y(x,0) c_1` term), which changes
  the zeroth-order coefficient and the frozen (indicial) balance, not the order-one principal symbol.
Not covered: see section 6.

## 1. Setting
### 1.1 Parameters and regions
- `5.5 < a < 6.5` (`N = 6`; corner window of conormal_framework 2.3: `a - 1/2 < 6`), `0 < gamma' < 2`.
- Parity class: h even in x, odd in y. `L^2_a(S) := L^2(S, |x|^{-2a} dx dy)`.
- Collar: `J = [y_1, y_2]`, `J_t := [y_1 - t, y_2 + t]`, `d > 0` with `y_1 > 2d`. Regions
  `N := (-2d, 2d) x (J_{2d} cup -J_{2d})`, `N_1 := (-d, d) x (J_d cup -J_d)`, `N_0 := (-d/2, d/2) x J`.
  For `z in N_0` and `W notin N_1`: `|z - W| >= d/2` (as in collar_coupling 1 with the axes exchanged).
- Cutoffs: chi as in collar_coupling 1 (even, `= 1` on `[-1, 1]`, supported in `[-2, 2]`); `chi_N(X) := chi(x/d) chi_1(y)`
  with `chi_1` even, `= 1` on `J_d cup -J_d`, supported in `J_{2d} cup -J_{2d}`; `chi_0(x) := chi(x/delta_0)`, `delta_0 := d/4`.

### 1.2 Hypothesis on h and the exact localized decomposition
On N, `h = phi_2(x) e_2(y) + phi_4(x) e_4(y) + h_rem` with `phi_p(x) = x^p chi(x/d_e)`, `d_e >= d/2`, `e_2, e_4` odd and in
`L^2(J_{2d} cup -J_{2d})`, `h_rem in L^2_a(N)`; `Z_f(h) := ||(1 + |X|)^{-gamma'} h||_{L^2(R^2 \ N_1)} < inf`; for Corollary
CC-Y also `N_c(h) < inf` (collar_coupling 1) and `|c[h]| < inf` (finite strain is a separate hypothesis; it is not supplied
by NF-Y). The exact decomposition used throughout is
  `h = h_n + H_2 + H_4 + h_f`,  `h_n := chi_N h_rem`,  `E_p := chi_1 e_p` (extended by zero),  `Phi_p(x) := chi(x/d) phi_p(x)`,
  `H_p(x, y) := Phi_p(x) E_p(y)`,  `h_f := (1 - chi_N) h`.
Indeed `chi_N h = chi_N h_rem + chi(x/d) chi_1(y) (phi_2 e_2 + phi_4 e_4) = h_n + H_2 + H_4`. `Phi_p = x^p` on
`|x| < r := min(d, d_e) >= d/2`, and `E_p = e_p` on `J_d cup -J_d`. (Revision 1 used the unlocalized `phi_p e_p` together with
the same `h_f`, which double-counts the transition region: for `h = phi_2 e_2` with `chi_N h != h` the sum of the
unlocalized edge source and `h_f` is `h + (1 - chi_N) h`.)

### 1.3 Meaning of the jets
`v_{i,l}[g]`, `v~_{2,l}[g]` denote the x-Taylor coefficients at `x = 0` of `U_i[g]`, `U~_2[g]`, defined as follows.
- far part (`g = h_f`): classical, since `U[h_f]` is real-analytic on `N_0` (F1-Y);
- edge part (`g = H_p`): by the explicit multipliers of Lemma E-Y (a well-defined tempered distribution in y for each l);
- near part (`g = h_n`): by continuous extension, in the Sobolev spaces of (N1-Y), of the map defined on
  `C^inf_c` data vanishing near `x = 0`, for which the coefficients are classical. These are not classical traces of
  `U[h_n]`: membership `h_rem in L^2_a` does not give classical x-derivatives of `h_rem` at the axis (example:
  `theta(x)|x|^7 sin(|x|^{-8}) g(y)`, `theta` an even cutoff, `g` smooth odd supported in the collar intervals; it lies in
  `L^2_a` throughout the window, is continuous with value 0 on the axis, and has no classical second x-derivative there).
  In particular no pointwise kernel trace is claimed for `v_{1,5}[h_n]` (`sigma_5 = a - 11/2 in (0, 1)`).
- density coefficients: `h_0 = 0`, `h_2 = e_2`, `h_4 = e_4` (on `J`) are the coefficients of the prescribed weighted
  expansion of section 1.2, not classical density traces; correspondingly `v_{2,l} = v~_{2,l} - h_l` is the definition of
  the full coefficient, with `h_l := 0` for the near and far parts and `h_l = delta_{l,p} E_p` for `H_p` (l < 6, since
  `Phi_p = x^p` near 0 and `p < 6`).

### 1.4 The axis component (conditional)
For sufficiently regular h put `e_0(y) := h(0, y)`. Background parity gives `V_1(0, y) = 0`, and `rho(0, y) = 0` gives
`rho_x(0, y) = rho_y(0, y) = 0`; hence `(L h)(0, y) = v(y) e_0'(y) - e_0(y)`, `v(y) := V_2(0, y)`. For a solution of `L h = f`
the conclusion `e_0 = 0` requires, in addition: `f(0, .) = 0`; a well-defined axis trace and axis equation in the chosen
space; `v(y) > 0` on the whole positive axis (connecting the collar to infinity); `v(y)/y -> c_l > 0`; and an axis growth
restriction with exponent `gamma < 1/c_l`. Then every nonzero homogeneous axis solution
`e_0 = C exp(int_{y_*}^y dt/v(t)) = y^{1/c_l + o(1)}` violates the growth restriction. These are global hypotheses (the
trial's axis-drift properties are floating-point observations, conormal_framework 1.3), not consequences of a bounded-collar
lemma. For general forcing the axis equation is `v e_0' - e_0 = f(0, .)`. This note therefore keeps `h(0, y) = 0` as an
assumption of the class, with the forcing space restricted correspondingly (`f(0, .) = 0`).

### 1.5 Velocity on N_0
`U[h] := U[chi_N h] + U^sym[(1 - chi_N) h]` exactly as in collar_coupling 1 (the definition and the far-field series do
not depend on which face the collar lies on).

## 2. Lemma S (swap) and parity
For `h in L^2(R^2)`: `U_1[h] = S U_1[S h]` and `U_2[h] + h = -S U_2[S h]`.
Proof. With `(d_x h)^ = i xi h^`: `psi^ = i xi h^/|zeta|^2`, `U_1^ = (xi eta/|zeta|^2) h^`, `U_2^ = -(xi^2/|zeta|^2) h^`.
`(S h)^(xi, eta) = h^(eta, xi)`, so `S m(D) S` is the multiplier `m(eta, xi)`. `U_1` has the symmetric symbol. `-S U_2 S` has
symbol `eta^2/|zeta|^2 = 1 - xi^2/|zeta|^2`, the symbol of `U_2 + I`. The value of a multiplier at the single point 0 is
immaterial on `L^2`. QED. (Floating check: code/check_yface.py (1), agreement to `4e-16`.)
(P-Y) In the original coordinates `U_1` is odd and `U_2`, `U~_2` are even in x, so `v_{1,l} = 0` for l even and
`v_{2,l} = v~_{2,l} = 0` for l odd. `div U = 0` gives, for the FULL coefficients, distributionally in y (by approximation
for the near part, section 1.3),
  `(l + 1) v_{1,l+1} + d_y v_{2,l} = 0`, in particular `v_{1,1} = -v_{2,0}'`, `v_{1,3} = -v_{2,2}'/3`, `v_{1,5} = -v_{2,4}'/5`,
and for the nonlocal coefficients `(l + 1) v_{1,l+1} + d_y v~_{2,l} = d_y h_l`. The local subtraction is essential.
Partial Fourier transform in y (dual variable eta, `k = |eta| > 0`): `U_1^(x, eta) = (i eta/2) int sgn(x - t) e^{-k|x - t|} h^(t, eta) dt`,
`U~_2^(x, eta) = (k/2) int e^{-k|x - t|} h^(t, eta) dt` (weighted_velocity 1 with the axes exchanged and, for `U~_2`, the
sign of `-U_2`).

## 3. Lemma NF-Y (near/far splitting on the y-collar)
Let h be as in section 1, `h_n = chi_N h_rem`, `h_f = (1 - chi_N) h`. Constants as in collar_coupling 2 with `(b, j < 3)`
replaced by `(a, l < 6)`: `c_{l,a} = Gamma(2a+1)^{1/2} 2^{-a-1}/l!`, `e_{l,a,d} = (2 (2d)^{2a+1}/(2a+1))^{1/2}/(2 l!)`,
`M_l := max(c_{l,a}, e_{l,a,d})`, `sigma_l := a - l - 1/2`, `C_{6,a}` of W1(a) with `(N, b) = (6, a)`;
`R_B := (y_2^2 + d^2/4)^{1/2}`, `rho_0 := 2 R_B`, `A_m` and J as in (F1) of collar_coupling 2 with this `R_B`.
(N1-Y) `v_{1,l}[h_n], v~_{2,l}[h_n] in H^{sigma_l}(R)` with norm `<= 2^{sigma_l/2} M_l ||h_n||_{L^2_a}`, and `L^2` norm `<= M_l ||h_n||_{L^2_a}`.
(N2-Y) `R^n_1 := U_1[h_n] - sum_{l<6} chi_0(x) x^l v_{1,l}[h_n]`, `R~^n_2 := U~_2[h_n] - sum_{l<6} chi_0 x^l v~_{2,l}[h_n]` satisfy
  `||R^n_1||_{L^2_a(R^2)}, ||R~^n_2||_{L^2_a(R^2)} <= K^Y_n ||h_n||_{L^2_a}`, `K^Y_n := C_{6,a} + sum_{l<6} (2/(2a-2l-1))^{1/2} delta_0^{l-a+1/2} M_l`.
  For the full `U_2`: `R^n_2 := U_2[h_n] - sum_{l<6} chi_0 x^l v_{2,l}[h_n] = R~^n_2 - h_n`, so `||R^n_2||_{L^2_a} <= (1 + K^Y_n) ||h_n||_{L^2_a}`.
(F1-Y) `f[h_f] = U_2[h_f] + i U_1[h_f]` is holomorphic on `N_0` with `|d^alpha U_i[h_f]| <= A_{|alpha|} Z_f(h)` there; on
  `N_0` `h_f = 0`, so `U~_2[h_f] = U_2[h_f]`; `|d_y^n v_{i,l}[h_f]| <= A_{n+l} Z_f(h)/l!` on J.
(F2-Y) `R^f_i := U_i[h_f] - sum_{l<6} chi_0 x^l v_{i,l}[h_f]` satisfies
  `||R^f_i||_{L^2_a(N_0)} <= K^Y_f Z_f(h)`, `K^Y_f := (A_6/720) (2 |J| (d/2)^{13-2a}/(13-2a))^{1/2}
   + sum_{l<6} (A_l/l!) (2 |J| delta_0^{2l-2a+1}/(2a-2l-1))^{1/2}`.
Proof. By Lemma S, `U_1[h_n] = S U_1[S h_n]`, `U~_2[h_n] = -S U_2[S h_n]`, and `S` maps `L^2_a(R^2)` (weight `|x|^{-2a}`)
isometrically onto the x-face space `L^2(|y|^{-2a})`, taking x-Taylor coefficients at `x = 0` to y-Taylor coefficients at
`y = 0`. W1(a), (b), (d) is applied at order `N = 6` with `N - 1/2 < a < N + 1/2` (this is W1 at order six and an adaptation
of the proof of NF, not the order-three NF statement outside its range); the proofs of (N1), (N2) in collar_coupling 2
apply verbatim to `S h_n` (supported in `|y| <= 2d` after the swap, which supplies the low-frequency bound behind the
inhomogeneous norms; neither proof uses the parity). The terms `(1 - chi_0) x^l v` are bounded by
`int_{|x| >= delta_0} |x|^{2l - 2a} dx = 2 delta_0^{2l-2a+1}/(2a-2l-1)`, finite exactly for `l < a - 1/2`, i.e. `l <= 5`.
(F1-Y): the proof of (F1) uses only `|z - W| >= d/2` for `z in N_0`, `W in supp h_f`, `|z| <= R_B`, and the reflection series
for `|z| < |W|`, which uses the parity of the ORIGINAL h and cutoff (even in x, odd in y), not of `S h`; `y_1 > 2d` and
`0 < gamma' < 2` are the geometric and integrability hypotheses of (F1). Holomorphy gives `d_x = d_z`, `d_y = i d_z`.
(F2-Y): Taylor's theorem in x to order 6 with `|d_x^6 U_i[h_f]| <= A_6 Z_f` gives `|T_6 U_i[h_f]| <= A_6 Z_f |x|^6/720`, and
`int_{|x|<d/2} |x|^{12-2a} dx = 2 (d/2)^{13-2a}/(13-2a)` is finite since `a < 6.5`; the cutoff terms as in (N2-Y). No endpoint
extension (`a = 5.5` or `a = 6.5`) is claimed. QED.
Example (floating evaluation, code/yface_constants.py; reproduced by the astra audit): `a = 6.45`, `gamma' = 1.129`,
`J = [1, 7]`, `d = 0.45`: `C_{6,a} ~ 1.1e4`, `K^Y_n ~ 8.1e7`, `A_0 ~ 1.7e3`, `K^Y_f ~ 4.4e9`. Bounded, far too crude for a
closing inequality (the factors `delta_0^{l - a + 1/2}` and `(2/d)^{m+2}` dominate).

## 4. Lemma E-Y (velocity of a localized y-face edge component)
Let `Phi in C^inf_c(R)` be even, `E in L^2(R)` odd, `H := Phi(x) E(y)`. Then for every `l <= 6`:
(E1-Y) `v~_{2,l}[H]^(eta) = E^(eta) (K~_eta * Phi^{(l)})(0)/l!`, `v_{1,l}[H]^(eta) = E^(eta) (K^1_eta * Phi^{(l)})(0)/l!`, with
  `K~_eta(t) = (k/2) e^{-k|t|}`, `K^1_eta(t) = (i eta/2) sgn(t) e^{-k|t|}`; so `||v~_{2,l}[H]||_{H^s}`,
  `||v_{1,l}[H]||_{H^s} <= (||Phi^{(l)}||_inf/l!) ||E||_{H^s}` (order zero).
(E2-Y) FULL jets (local term included): `v_{2,l}[H]^(eta) = E^(eta) m_{2,l}(eta)`, `v_{1,l}[H]^(eta) = E^(eta) m_{1,l}(eta)` with
  `m_{2,l}(eta) = (1/l!) int (k/2) e^{-k|t|} (Phi^{(l)}(t) - Phi^{(l)}(0)) dt`,
  `m_{1,l}(eta) = -(i eta/(2 l!)) int sgn(t) e^{-k|t|} Phi^{(l)}(t) dt`;
  `m_{2,l} = 0` for l odd, `m_{1,l} = 0` for l even, and for `eta != 0`
  `|m_{2,l}(eta)| <= min(||Phi^{(l)} - Phi^{(l)}(0)||_inf, ||Phi^{(l+2)}||_inf eta^{-2})/l!` (l even),
  `|m_{1,l}(eta)| <= min(||Phi^{(l)}||_inf, ||Phi^{(l+1)}||_inf |eta|^{-1})/l!` (l odd).
  Hence `||v_{2,l}[H]||_{H^{s+2}} <= C_{2,l} ||E||_{H^s}` and `||v_{1,l}[H]||_{H^{s+1}} <= C_{1,l} ||E||_{H^s}` for every real s,
  with `C_{2,l} = max(2 ||Phi^{(l)} - Phi^{(l)}(0)||_inf, 2 ||Phi^{(l+2)}||_inf)/l!`,
  `C_{1,l} = max(2^{1/2} ||Phi^{(l)}||_inf, 2^{1/2} ||Phi^{(l+1)}||_inf)/l!`.
  If `Phi = x^p` on `|x| < r` and `l = p` (for `m_{2,l}`) or `l = p + 1` (for `m_{1,l}`), the integrand vanishes on `|t| < r`
  and `|m(eta)| <= ||Phi^{(l)} - Phi^{(l)}(0)||_inf e^{-r|eta|}/l!` (resp. `||Phi^{(l)}||_inf e^{-r|eta|}/l!`): smoothing of
  infinite order. For `H_p = Phi_p E_p` of section 1.2, `r = min(d, d_e) >= d/2`, and the constants involve the derivatives
  of `Phi_p = chi(x/d) phi_p`.
(E3-Y) `||T_6 U_i[H]||_{L^2_a((-delta, delta) x R)} <= (||Phi^{(6)}||_inf/720) (2 delta^{13-2a}/(13-2a))^{1/2} ||E||_{L^2}`
  for `i = 1` and for `U~_2`; for the full `U_2` add `||T_6 Phi||_{L^2(|x|^{-2a}, |x| < delta)} ||E||_{L^2}`, which is `0` if
  `Phi = x^p` on `|x| < delta` with `p < 6` (true for `p = 2, 4`, `delta <= r`; false for `p >= 6`).
(E4-Y) for `l < 6`: `||(1 - chi_0) x^l v||_{L^2_a} <= (2 delta_0^{2l-2a+1}/(2a-2l-1))^{1/2} ||v||_{L^2}` for each jet v above.
Proof. (E1-Y), (E3-Y), (E4-Y) are Lemma E of collar_coupling 3 after Lemma S (with `-U_2` for `U~_2`; the bound
`||K||_{L^1} <= 1` is unchanged), plus the local term: `T_6 (Phi E) = (T_6 Phi) E`. (E2-Y): `v_{2,l} = v~_{2,l} - h_l` with
`h_l^(eta) = E^(eta) Phi^{(l)}(0)/l!`, and `int K~_eta = 1` for `eta != 0`. For l even, `Phi^{(l)}` is even, so
`Phi^{(l)}(t) - Phi^{(l)}(0) = int_0^t (t - u) Phi^{(l+2)}(u) du`, bounded by `t^2 ||Phi^{(l+2)}||_inf/2`, and
`int (k/2) e^{-k|t|} t^2/2 dt = k^{-2}`. For l odd, `Phi^{(l)}` is odd, `|Phi^{(l)}(t)| <= |t| ||Phi^{(l+1)}||_inf`, and
`int (k/2) e^{-k|t|} |t| dt = k^{-1}`; `(K^1 * Phi^{(l)})(0) = -(i eta/2) int sgn(t) e^{-k|t|} Phi^{(l)}(t) dt`.
The Sobolev bounds: `<eta>^2 min(A, B eta^{-2}) <= max(2A, 2B)` (`|eta| < 1`: `<eta>^2 <= 2`; `|eta| >= 1`: `<eta>^2 <= 2 eta^2`),
similarly `<eta> min(A, B/|eta|) <= 2^{1/2} max(A, B)`; the single point `eta = 0` does not affect the estimates. The last
statement: the integrand vanishes on `|t| < r` and `int_{|t| > r} (k/2) e^{-k|t|} dt = e^{-r k}`. QED.
Floating sanity check (code/check_yface.py (2), `d_e = 0.5`): leading constants `Phi^{(l+2)}(0)/l!` and `Phi^{(l+1)}(0)/l!`
reproduced (`eta^2 |v_{2,0}| -> 2.00`, `|eta| |v_{1,1}| -> 2.00` for `phi_2`; `|eta| |v_{1,3}| -> 4.00`, `eta^2 |v_{2,2}| -> 12.0`
for `phi_4`). The values reported for the infinitely smoothing jets are NOT accurate (section 7).

## 5. Corollary CC-Y (the coupling on the y-collar)
### 5.1 Hypotheses and coefficients
Let rho be even in x, odd in y, `rho(0, y) = 0`, and `rho in W^{7,inf}` on a neighbourhood of `N-bar`. (A `C^6` profile
does not suffice: `|r - r_0|^{6+alpha}`, `0 < alpha < 1`, is `C^6` with unbounded seventh derivative. A finite `C^6`
piecewise-polynomial profile in smooth coordinates away from the origin qualifies once bounded seventh derivatives on the
pieces are established.) Put `p_2 := d_x^2 rho(0, .)/2 in W^{5,inf}`, `p_4 := d_x^4 rho(0, .)/24 in W^{3,inf}`,
`S_x := ess sup_{N_0} |d_x^6 rho|/120`, `S_y := ess sup_{N_0} |d_x^6 d_y rho|/720`, and
`E_x := rho_x - 2 x p_2 - 4 x^3 p_4`, `E_y := rho_y - x^2 p_2' - x^4 p_4'`; then on `N_0` `|E_x| <= S_x |x|^5`, `|E_y| <= S_y x^6`
(rho_y is even in x, so its odd Taylor coefficients vanish). Let h be as in section 1 with `N_c(h) < inf` and `|c[h]| < inf`,
`W[h] = U[h] + (c[h]/3) X`, all jets FULL jets (near, edge and far parts summed, section 1.3; `v_{2,0} = v~_{2,0}` since
`h_0 = 0`). Then on `N_0`
  `W[h].grad rho = chi_0(x) [x^2 q_2 + x^4 q_4] + R_W[h]`,
  `q_2 := 2 p_2 (v_{1,1} + c/3) + p_2' (v_{2,0} + c y/3)`,
  `q_4 := 4 p_4 (v_{1,1} + c/3) + 2 p_2 v_{1,3} + p_4' (v_{2,0} + c y/3) + p_2' v_{2,2}`.
### 5.2 Exact remainder
With `P_1 := x v_{1,1} + x^3 v_{1,3} + x^5 v_{1,5}`, `P_2 := v_{2,0} + x^2 v_{2,2} + x^4 v_{2,4}`,
`B_6 := 4 p_4 v_{1,3} + 2 p_2 v_{1,5} + p_4' v_{2,2} + p_2' v_{2,4}`, `B_8 := 4 p_4 v_{1,5} + p_4' v_{2,4}`, `A_2 := 2 p_2 + y p_2'`,
`A_4 := 4 p_4 + y p_4'`, and the velocity remainders `R_1 := U_1 - chi_0 P_1`, `R_2 := U_2 - chi_0 P_2` on `N_0`:
  `R_W = chi_0 (x^6 B_6 + x^8 B_8) + chi_0 (P_1 E_x + P_2 E_y) + R_1 rho_x + R_2 rho_y
         + (c/3) [(1 - chi_0)(x^2 A_2 + x^4 A_4) + x E_x + y E_y]`.
Every term is accounted for: the uncut polynomial errors begin at order six; the lower-order cutoff errors vanish for
`|x| <= delta_0`. On `N_0`, `Phi_p = x^p` (since `d/2 <= r`) and `h_rem = h_n`, so the local part of `U_2` is
`-(x^2 e_2 + x^4 e_4 + h_rem)`, `-chi_0 (x^2 e_2 + x^4 e_4)` are the local parts of the jet terms `chi_0 x^l v_{2,l}`, and
  `R_2 = R~_2 - h_rem - (1 - chi_0)(x^2 e_2 + x^4 e_4)`,  `R~_2 := U~_2 - chi_0 sum_l x^l v~_{2,l}`,
  `R_1 = R^n_1 + R^e_1 + R^f_1`, `R~_2 = R~^n_2 + R~^e_2 + R~^f_2` (Lemmas NF-Y, E-Y applied to `h_n`, `H_2 + H_4`, `h_f`).
### 5.3 Remainder bound
With `k_p := (2 (d/2)^{2p+1-2a}/(2p+1-2a))^{1/2}` (`p >= 6`; `||chi_0 x^p g(y)||_{L^2_a(N_0)} <= k_p ||g||_{L^2(J)}`),
`k'_1 := (2 delta_0^{5-2a}/(2a-5))^{1/2}`, `k'_2 := (2 delta_0^{9-2a}/(2a-9))^{1/2}` (`||(1 - chi_0) x^{2m} g(y)||_{L^2_a(N_0)} <=
k'_m ||g||_{L^2(J)}`, m = 1, 2); background coefficients (`p_j`, `p_j'`, `rho_x`, `rho_y`) in `L^inf(J)` or `L^inf(N_0)`,
velocity coefficients in `L^2(J)`:
  `||R_W||_{L^2_a(N_0)} <= k_6 (4 ||p_4||_inf ||v_{1,3}|| + 2 ||p_2||_inf ||v_{1,5}|| + ||p_4'||_inf ||v_{2,2}|| + ||p_2'||_inf ||v_{2,4}||)
     + k_8 (4 ||p_4||_inf ||v_{1,5}|| + ||p_4'||_inf ||v_{2,4}||)
     + S_x (k_6 ||v_{1,1}|| + k_8 ||v_{1,3}|| + k_10 ||v_{1,5}||) + S_y (k_6 ||v_{2,0}|| + k_8 ||v_{2,2}|| + k_10 ||v_{2,4}||)
     + ||rho_x||_inf ||R_1|| + ||rho_y||_inf ||R_2|| + (|c[h]|/3) C^Y_rho`,
  `||R_2||_{L^2_a(N_0)} <= ||R~_2||_{L^2_a(N_0)} + ||h_rem||_{L^2_a(N_0)} + k'_1 ||e_2|| + k'_2 ||e_4||`,
  `C^Y_rho := k'_1 ||A_2||_{L^2(J)} + k'_2 ||A_4||_{L^2(J)} + S_x k_6 |J|^{1/2} + S_y k_6 ||y||_{L^2(J)}`
(the last two terms bound `x E_x` and `y E_y` via `|x E_x| <= S_x x^6`, `|y E_y| <= S_y |y| x^6`).
### 5.4 Regularity of the forcings
Split each jet into near (from `h_n`), edge (from `H_2, H_4`), far (from `h_f`) and strain parts. Let `mu_s(g)` be the norm
of multiplication by g on `H^s(R)` (finite for `g in W^{k,inf}`, `0 <= s <= k`) and `p~_j` compactly supported extensions of
`p_j` from J with `p~_2 in W^{5,inf}`, `p~_4 in W^{3,inf}` (Whitney).
- near: by (P-Y) and `h_0 = 0`, `q_{2,n} = -2 p~_2 d_y v~_{2,0}[h_n] + p~_2' v~_{2,0}[h_n]`, so for `0 <= s <= min(a - 3/2, 4)`
  `||q_{2,n}||_{H^s} <= (2 mu_s(p~_2) + mu_s(p~_2')) 2^{(a-1/2)/2} M_0 ||h_rem||_{L^2_a(N)}`,
  with `M_0` the maximum of the two NF-Y constants (here `||h_n||_{L^2_a} <= ||h_rem||_{L^2_a(N)}`, `0 <= chi_N <= 1`);
  `q_{4,n} in H^s` for `0 <= s <= min(a - 7/2, 2)` (lowest velocity regularity `v_{1,3}[h_n] in H^{a-7/2}`; the cap 2 comes
  from `p~_4' in W^{2,inf}`). Throughout the window: `q_{2,n} in H^4`, `q_{4,n} in H^2`.
- edge: with the localized data, `||q_{j,e}||_{H^{s+1}} <= C (||E_2||_{H^s} + ||E_4||_{H^s})`, C from `C_{1,l}, C_{2,l}` and the
  multiplier norms on `H^{s+1}`, in the ranges `0 <= s <= 3` (`j = 2`) and `0 <= s <= 1` (`j = 4`); for `s > 0` the regularity
  `E_p in H^s` is an assumption. The `L^2` hypotheses alone give `q_{2,e}, q_{4,e} in H^1`. No range with negative s is
  claimed (it is not justified by the finite coefficient regularity).
  Exact local cancellation for `p = 2`: `v~_{2,2}[H_2] = E_2 + S E_2` with S the exponential multiplier of (E2-Y)
  (infinitely smoothing), so on J `p_2' v~_{2,2}[H_2] - p_2' e_2 = p_2' S E_2`: the order-zero local term `-p_2' e_2` that the
  `-h` part of `U_2` puts into the `x^4` equation is cancelled by the leading part of `p_2' v~_{2,2}`. The output
  regularity of `p_2' S E_2` is limited by `p_2' in W^{4,inf}`.
- far: `q_{2,f} in W^{4,inf}(J)` (i.e. `C^{3,1}`) and `q_{4,f} in W^{2,inf}(J)` (`C^{1,1}`), with `|d_y^n q_{j,f}| <= C(n, rho) Z_f(h)`
  (ess sup for the top order). The far velocity coefficients are analytic, but the products with `p_2 in W^{5,inf}`,
  `p_4 in W^{3,inf}` give only this. (Sharp: `rho = x^2 (x^2 + (y - y_0)^2)^{5/2}` localized near `(0, y_0)` and extended
  oddly is `W^{7,inf}` with `p_2 = |y - y_0|^5`, `p_4 = (5/2)|y - y_0|^3`; with a far source having `v_{2,0}(y_0) != 0` the
  `C^4`, `C^2` endpoint statements fail.)
- strain: `q_{2,c} = (c/3) A_2`, `q_{4,c} = (c/3) A_4`.
Proof of 5.1-5.4. On `N_0`, `U_1 = chi_0 P_1 + R_1`, `U_2 = chi_0 P_2 + R_2` by definition. Multiply out `W_1 rho_x + W_2 rho_y` with
`W_1 = U_1 + c x/3`, `W_2 = U_2 + c y/3`, `rho_x = 2 x p_2 + 4 x^3 p_4 + E_x`, `rho_y = x^2 p_2' + x^4 p_4' + E_y`: the `x^2` and `x^4`
coefficients of `chi_0 (P_1 + c x/3)(2 x p_2 + 4 x^3 p_4) + chi_0 (P_2 + c y/3)(x^2 p_2' + x^4 p_4')` are `q_2, q_4`, its `x^6, x^8`
coefficients are `B_6, B_8`, and the rest is the displayed `R_W` (the strain terms are written as `chi_0 (...) + (1 - chi_0)(...)`).
The norms: `int_{|x|<d/2} |x|^{2p-2a} dx` is finite for `p >= 6 > a - 1/2`; `(1 - chi_0)` vanishes for `|x| <= delta_0`. The near
orders use (N1-Y) and `||u'||_{H^s} <= ||u||_{H^{s+1}}`; the edge orders use (E2-Y); the far orders use (F1-Y) and the
regularity of `p_j`. QED.

## 6. Remarks and what remains
- Comparison of the faces. x-face: `q[h] = w_{1,0} r_1' + w_{2,1} r_1` and the edge part contains `-r_1 c` (order zero), i.e.
  the c-equation is `w c' + (mu - 1 - rho_y(x, 0)) c + (order <= -1) = ...` locally; at P this is the frozen `T - 1 - g M` on
  edge data (`M -> 1`). The order-zero term changes the zeroth-order coefficient and the frozen (indicial) balance; the
  order-one principal symbol is unchanged. y-face: no order-zero coupling on edge data. In both cases the near part of the
  forcing gains derivatives over `h_rem` (`b - 3/2` at the x-face, `a - 3/2` at the y-face, capped by the regularity of rho).
- Open scope (not covered by this note):
  1. the corner (product weights; notes/corner_coupling.md) and the coupling of the y-face edge system to the corner jets
     (`e_2 ~ J y`, `e_4 ~ c_2 y^{beta_2}` at 0, conormal_framework 2.3);
  2. large y (conic collars, cross-annulus summation);
  3. derivative versions (the analogue of collar_coupling 5) and Hoelder estimates if the final norm requires them;
  4. the extraction and extension maps `h -> (e_2, e_4, h_rem)`, component norms, and the operator and forcing domains;
  5. verification for the trial of: `rho in W^{7,inf}` near the y-axis (the radial splines are `C^6` at their joins; near
     the y-axis `d_x` acts on `f(r)` through `r = (x^2 + y^2)^{1/2}`; bounded seventh derivatives on the pieces must be
     shown), finite strain, the axis-flow hypotheses of 1.4 (`v > 0` on the positive axis, `v/y -> c_l`) and the growth class;
  6. global localization and summation;
  7. boundary conditions and solvability estimates for the coupled edge system.

## 7. Changes from revision 1 (astra audit, single-model, NEEDS-FIX)
- Q1: classical vanishing of the jets of `h_rem` withdrawn (counterexample in 1.3); jets defined by continuous extension;
  `h_0, h_2, h_4` are expansion coefficients; divergence identities stated for full and nonlocal coefficients.
- Q2: VALID; endpoint extensions explicitly not claimed.
- Q3: VALID; in (E3-Y) `T_6 Phi = 0` requires `p < 6`.
- Q4: exact localized decomposition `h = h_n + H_2 + H_4 + h_f` (1.2); exact remainder formula (5.2); norm conventions
  (background `L^inf`, velocity `L^2`); finite strain made a separate hypothesis.
- Q5: near ranges `min(a - 3/2, 4)` and `min(a - 7/2, 2)`; edge estimate with localized `E_p`, ranges `0 <= s <= 3` and
  `0 <= s <= 1`; far forcings `W^{4,inf}`, `W^{2,inf}` (not `C^4`, `C^2`); the cancellation stated as `p_2' S E_2`.
- Q6: the axis condition `h(0, .) = 0` stated as a conditional consequence of listed global hypotheses, kept as a class
  assumption with compatible forcing; open scope extended (section 6); `C^6` does not imply `W^{7,inf}`.
- The quadrature in code/check_yface.py (2) is only a sanity check: for `phi_2`, `eta = 32`, it reports `v_{2,2} ~ 1.27e-4`,
  whereas an independent tail-integral evaluation gives about `-1.086e-7` (reversed-grid kernel indexing and numerical
  differentiation). No accuracy claim is made for it.
