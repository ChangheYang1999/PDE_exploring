# Numerics lane: coordination note (ipmA-num)

Updated 2026-10-20T14:23Z. Timestamps in this file are taken from `date -u`.

## Status of the verifier's objections (VERIFY_REPORT 13:31Z, 13:33Z, 13:52Z, 13:59Z, 14:15Z)
- inverse.py head term f_1/3 -> f_1/2: FIXED (c error on the manufactured tests now 3e-12 and 4e-12).
- inverse.py end-stencil shift sign: FIXED (+off).
- x3_arb.py span selection at exact knots / NaN at r = 0: FIXED (closed outward span selection; no division by chi).
  The box evaluation of x3_arb is still only a point/narrow-box tool (wide boxes wrap).
- modal_fit: affine constant rmin^2/8 in the normalization functional: FIXED; unstable primitive: FIXED by the
  Gauss-Legendre branch for |lam| h < 1.5 (expoly.integ_shift) and, in the certificate, by exact closed forms at 256 bits.
- cert_green: joins at the stored knots tmin = knots[0], t0 = knots[-1] (definition), rmin = e^{tmin}: FIXED;
  export of Arb balls to doubles now inflates the radius by u|mid| + eta: FIXED. The Arb run was restarted at the time
  of this note (runs/cert_green.log; 7809 sub-cells of length <= 0.0019).
- The stored trial file data/trial_v2_h0.008.npz has the keys Ei, Eo, bi, bo, p. The exact object is: stored S, D, Aout
  (except A_00) as exact doubles; Ei, Eo, A_00 defined by the C^6 join equations and c = 3/k - 1 (recomputed in Arb,
  data/cert_coeffs.json after the run; changes 1e-13 relative).

## What I am computing for SPEC v1 section 4.1
- R0: sup over each region of W(r)/m(r), W = sum_N |eps_N(r)|, via degree-12 Taylor models on the 7809 sub-cells
  (|gamma| h <= 1 for every exponent, including 2n for n <= 261), rigorous mid-rad arithmetic (src/midrad.py), Bernstein
  bounds per sub-cell; regions: r < rmin (separately), dyadic shells of [rmin, R0] with [x_*/2, 2 x_*] singled out, r > R0
  with the weight (1+u)^0.5 (to be confirmed by the lead: delta = 0.5).
- S1: c~ (exact by construction), c_l = 1/k, x_* and mu - 1, g_*, A, Theta_0 by Arb evaluation of the explicit axis
  functions (interval Newton on V~_1(x, 0)).
- R2 next, then C1/C2 (floating point), R1/R3/R4.
Floating-point values to expect (runs/trial_v2_resid.json): W/sup ratio 2.4 to 4.5; sup eps 5.4e-5 near r = 8.8.

## Questions / remarks for the lead
1. The size function m(r) = u^3 (1+u^2)^{(k-3)/2} is L^-3 times the base factor; W/m is then dimensionless. Confirm delta.
2. The far-field residual of the trial is X3's: N_v about 1.1e-6 at r = 3.6e4 to 4e4; W/m there will be about 1e-6
   times (1+u)^0.5 ~ 7e1 ~ 1e-4 at the far maximum unless the weight is chosen smaller. Please check that Y's far weight
   is what you want for the trial as fitted.
3. The verifier's SPEC audit (14:20Z) objects to the one-derivative gain of the inverse in X = C^{4,alpha}; I have no
   stake in that, but the C2 study (finite sections of L) can be run in whatever norm you specify.

## 2026-10-20T14:59Z numerics: SPEC v2 received; delivery plan and first rigorous results
- S1 (DONE, rigorous, runs/scalars_full.json; Taylor models from the Arb Green data, interval Newton): for the exact trial
  rho~ (data/trial_v2_h0.008.npz + data/cert_coeffs.json): c~ = 3 c_l - 1 exactly (Arb defect 1.7e-50), c_l = 1/k,
  x_* = 8.600063805157177 +/- 3.0e-13 (raw radius 2.9402e-13; corrected 00:5xZ), mu~ - 1 in [-2.2529e-8, -2.2527e-8], g = rho~_y(P) in [29.749490663330, 29.749490663337],
  A = 2 c_l - 1 = 10.1507252212831; g' = rho~_xy(P) and A~ = 2 c_l - mu~ are being added to the same output.
- R0 (RUNNING, runs/chain1.log): Taylor models of degree 12 on 7809 radial sub-cells (middle region), then the outer
  region tau in [0, 10] (r up to 7.5e7) and the inner region [-2.5, 0], then the far tail by a termwise majorant. Every
  sub-cell row stores W, m and r, so W (1+u)^(gamma-k)/m can be read off for any gamma; I will report gamma = 0.5 and
  the unweighted shells. Floating-point expectation: max W/m about 2.3e-4 near r = 8.8 (core); unweighted W/m decays
  like r^(k-1) beyond; with (1+u)^(gamma-k), gamma = 0.5: about 2e-3 at r ~ 4e4 and still growing slowly to r ~ 1e6
  (the Theta_1 mismatch of X3's far field): the far field will dominate R0 for gamma = 0.5.
- R1/R3/R5: need Taylor models of d_t^i eps_N (i <= 2 globally, <= 5 near P): the machinery (ODE identities A' = -2nA + g,
  exact derivatives of the exponential-polynomials, Leibniz over the convolutions) is in place; implementation next
  (shift 2). Angular derivatives are immediate: sum_N (2N+1)^j sup|eps_N| (stored per sub-cell from now on).
- Three resolutions: variant trials v3 (spline subdivision 0.004), v4 (M = 230), v5 (R0 = X3's second-to-last knot,
  191.9 L) are fitted; their full certificate pipelines are queued after chain1 (runs/chain2.sh, about 2 h each).
- Verifier: the exported Arb balls now include the double-conversion error in the radii; joins are defined at the stored
  knots (tmin = knots[0], t0 = knots[-1]); exactified Ei, Eo, A00 are in data/cert_coeffs.json (60 digits).

## 2026-10-20T15:23Z numerics: first rigorous R0 (middle region) and complete S1
- R0 middle region [rmin, R0] (certified, NUM_REPORT 7.3): sup W/m <= 2.926e-4 (cell [8.790, 8.798] next to P); with the
  v2 weight (1+u)^(gamma-k), gamma = 0.5: 3.74e-4 (same cell). Shell values 5e-6 to 2e-5 away from P (table in the report).
  L2 (R2) middle part <= 7.07e-5. Outer/inner regions and tails follow (chain1), derivatives (R1/R3/R5) in chain3.
- S1 complete (NUM_REPORT 7.2), including g' = rho~_xy(P) in [0.273411443976807, 0.273411443977693] and
  A~ = 2 c_l - mu~ in [10.150725243810255, 10.150725243812035].
- For 3.6(c): ||K~|| and ||L K~|| pieces come with chain3 (W_K, W_eps_minus_dteps per cell).

## 2026-10-20T16:28Z numerics: referee round, repairs, data regeneration
- astra refereed the certificate (astra/cert1/answer.md): analytic formulas confirmed; implementation defects repaired
  (WORKLOG 16:1xZ). Verifier objections 15:24Z (Newton derivative) and 15:41Z (exporter) repaired; the dependent
  coefficients are now exported as exact dyadic balls (verifier's suggestion), round-trip containment verified.
- A further bug was found by me in the inner-region Arb boundary values (mode 27: exponent mu ~ 7e-15, closed-form primitive
  cancellation); integrator repaired (series branch), inner/outer data regenerated in chain4. Middle region unaffected.
- Status of certified numbers: S1 final (runs/scalars_full.json). R0 middle: pre-fix 2.926e-4 (sup W/m), repaired rerun
  queued (expected about 2.6e-4 with the sub-interval Bernstein bound). Everything else arrives through the chains tonight.


## 2026-10-20T17:14Z numerics: second referee round done; all defects repaired; chains running
- astra/cert2/answer.md: round-1 repairs confirmed; integ_series tail bound, exact dyadic transport and the refined outer tail
  (exact e^{(2k-1) tau} coefficient) proved correct; new defects (Bernstein radii, series-tail float underflow, summary
  endpoints, truncation underflow amplification, inner-tail degree conditions, CLI ordering) repaired in the current code.
- Pre-fix picture of R0 (to be replaced by the post-fix reruns tonight): divisor form sup W/m: middle 2.93e-4 (next to P),
  outer 9.3e-5 (r = 3.3e4), far tail 8.3e-7; multiplier form W(1+u)^(1/2)/m: middle 4.29e-4, outer about 7.4e-3 at r ~ 5e4
  (X3's Theta_1 mismatch band), far tail 2.6e-3 at r = 7.5e7 (refined majorant; T_out will be 17 in the reruns).

## 2026-10-20T17:16Z numerics: warning for T2N (R3 preview)
Rigorous Taylor-model derivative bounds on one sub-cell next to P (r in [8.5987, 8.6006]): sum_N sup |eps_N| = 3.8e-5 but
sum_N sup |d_t eps_N| = 4.1e-2, sum_N sup |d_t^5 eps_N| = 2.7e11, sum_N (2N+1)^5 sup |eps_N| = 2.3e8 (angular). The
residual of the trial is small in sup norm but not in any norm with several derivatives near P: its radial structure is on the
scale dt ~ 1e-3 (the lobe). So eta = ||eps~||_{Y_H} with Y_H = weighted C^{4,alpha} is of order 1e8 or larger for this trial
and no reasonable K_H can make K_H eta small; either a lower-order forcing norm or a much smoother trial (the residual's fine
structure is X3's fit noise at P) is needed. Full tables when chain3 finishes.

## 2026-10-20T19:22Z numerics -> lead: residual near P in Sobolev norms (floating point, evidence only; answers to 18:05Z / 18:40Z)
1. Definitions. In the certificate (src/cert_resid_deriv.py), W_i_j = sum_N (2N+1)^j sup_{t in cell} |d_t^i eps_N(t)|, t = log r (so d_t = r d_r),
   the second index is the theta-derivative order (d_theta^j sin((2N+1)theta) brings (2N+1)^j), cells are the certificate sub-cells of
   length <= 0.0019 in t, eps in the physical units of the prompt's residual. W_i_j >= sup over the cell and over theta of
   |d_t^i d_theta^j eps~|. Those are upper bounds (Wiener sums). The numbers below are DIRECT floating evaluations of the Cartesian
   derivatives D^alpha eps~ (analytic radial jets, exact angular derivatives; src/trial_jets.py, validated against finite differences
   to 1e-3 relative at order 4), not majorants.
2. Sobolev seminorms |eps~|_k = (sum_{|alpha| = k} ||D^alpha eps~||^2_{L^2(region)})^{1/2} and sup_k = max_{|alpha|=k} sup |D^alpha eps~|
   (runs/pdisc/norms_A.json, norms_B.json, norms_C.json; polar grids with dt = 1e-5 .. 2e-7, trapezoid quadrature):
   | region            | area     | |.|_0    | |.|_1    | |.|_2    | |.|_3    | |.|_4    | sup_0   | sup_3  | sup_4  |
   | disc |X-P|<x_*/4  | 14.5     | 1.19e-5  | 1.27e-3  | 2.07e-1  | 3.73e+1  | 6.92e+3  | 5.0e-5  | 259    | 5.0e4  |
   | disc |X-P|<1      | 3.14     | 5.96e-6  | 3.92e-4  | 5.22e-2  | 9.34     | 1.77e+3  | 1.7e-5  | 77     | 1.5e4  |
   | disc |X-P|<0.5    | 0.785    | 2.87e-6  | 1.36e-4  | 8.08e-3  | 1.03     | 1.91e+2  | 1.1e-5  | 11.9   | 2.3e3  |
   | disc |X-P|<0.25   | 0.196    | 9.6e-7   | 4.5e-5   | 3.3e-3   | 0.486    | 88.3     | 7.6e-6  | 5.0    | 953    |
   | disc |X-P|<0.1    | 0.0314   | 1.7e-7   | 8.1e-6   | 8.4e-4   | 0.131    | 23.6     | 3.1e-6  | 2.8    | 552    |
   | ann j=2 (1/8..1/4)| 0.147    | 9.3e-7   | 4.3e-5   | 3.1e-3   | 0.448    | 81.1     | 7.6e-6  | 5.0    | 953    |
   | ann j=3           | 0.0368   | 2.3e-7   | 1.25e-5  | 1.13e-3  | 0.178    | 32.5     | 3.2e-6  | 3.7    | 740    |
   | ann j=4           | 0.0092   | 4.5e-8   | 3.8e-6   | 3.8e-4   | 0.061    | 11.3     | 1.5e-6  | 1.7    | 319    |
   | ann j=5           | 0.0023   | 7.9e-9   | 1.05e-6  | 1.6e-4   | 0.026    | 5.0      | 3.5e-7  | 1.3    | 260    |
   | ann j=6           | 5.8e-4   | 1.9e-9   | 4.1e-7   | 5.6e-5   | 0.0092   | 1.70     | 2.1e-7  | 0.76   | 152    |
   | ann j=7           | 1.4e-4   | 3.1e-10  | 1.3e-7   | 2.3e-5   | 3.6e-3   | 0.57     | 6.6e-8  | 0.40   | 69     |
   | ann j=8           | 3.6e-5   | 4.1e-11  | 3.5e-8   | 1.1e-5   | 1.4e-3   | 0.28     | 1.8e-8  | 0.31   | 53     |
   | ann j=9           | 9.0e-6   | 5.6e-12  | 9.1e-9   | 5.7e-6   | 6.2e-4   | 0.14     | 4.8e-9  | 0.26   | 53     |
   | ann j=10          | 2.2e-6   | 8.5e-13  | 2.4e-9   | 2.9e-6   | 3.0e-4   | 0.072    | 1.4e-9  | 0.22   | 52     |
   Local H^3 density |.|_3^2/area decreases toward P (1.4 on ann2, 0.15 on ann6, 0.04 on ann10): the structure is spread over the disc,
   not concentrated at P; sup_3 ~ 0.2-0.4 and sup_4 ~ 50 persist down to |X - P| ~ 1e-3. Direction: D^(4,0) (x, i.e. radial near the axis)
   carries 189 of the 191 of |.|_4 on the 0.5-disc (D^(3,1): 21, D^(0,4): 13): the structure is RADIAL. Thin annulus / full annulus
   (grid D) running (runs/pdisc/norms_D.json).
   Fractional norms by FFT of chi eps~ (chi = 1 on |X-P| <= 0.4, C^infty to 0 at 0.5; runs/pdisc/fft_r0.5.json): H^3 = 0.89,
   H^3.03 = 1.04, H^3.06 = 1.21, H^3.1 = 1.48, H^3.2 = 2.47, H^3.4 = 6.95, H^3.5 = 11.7, H^4 = 160; 87 percent of the H^3 norm^2
   comes from |xi| > 100, 27 percent from |xi| > 200, 0.05 percent from |xi| > 400 (wavelengths 0.016-0.06: the knot scale 0.0165 in r).
3. Cause: knot-scale structure of X3's spline fit, radial, present in X3 itself. Evidence: (a) axis trace g(x) = rho~_y(x, 0):
   d_x^4 g is continuous (C^6 spline) but varies between -319 and +708 inside the knot interval containing x_* and its per-interval
   means alternate (-279, +234, +377, -136, -36 on the intervals around x_*, knots at s = x - x_* = -0.0260, -0.0096, +0.0068, +0.0233,
   +0.0398) while the smooth level is O(10-40); X3's own formula (src/x3.py) by 7-point finite differences reproduces these values to
   0.03-1 percent, so it is X3's structure, not the modal re-representation's. (b) No power law: log-log slopes of |d_x^4 g| against
   |s| vary from -3.1 to +2.1 across knots and tend to 0 inside the knot interval containing x_* (d_x^4 g -> 365.2 as s -> 0+, 369 at
   s = 5e-5, 403 at 5e-4): this is not the layer |s|^{g/A} (slopes -0.07 / -1.07 expected). The trial is a spline and cannot show a cusp;
   the point is that nothing cusp-like is being resolved. (c) The residual's own knot-scale oscillation is small in value (eps_y(x,0)
   proxy: rms 1.7e-6 at the knot scale against a mean 1e-5) and the sup of |eps~| on the 0.5-disc is 1.1e-5; the large derivatives are
   values x (1/0.006)^k. (d) Removing the fine-scale content of the modes a_m(t) by a coarse-knot projection (spacing 0.02 in t, 10 x
   coarser, on t in [log 6, log 12]) changes a_0 by 4.5e-7 relative, a_1 by 6.5e-6 of itself, a_20 by 1.2e-2 of itself and modes
   m >= 50 by 17-50 percent of themselves (they are mostly knot-scale content); the summed change of the density is 2.2e-5 relative
   to the a_0 term, 1.7e-6 on the axis. So the fine-scale content is X3's angular-mode fit noise (1e-7 .. 5e-7 of a_0 per mode).
4. Smooth refit: a projection-smoothed trial (knots 10 x coarser on the band, data/trial_s02.npz; also 5 x and 20 x) is being evaluated
   (sup residual, H^3/H^4 on the 0.5-disc, FFT H^{3.06}): runs/pdisc/chainS.log. Expectation: the residual sup grows (the removed
   content is L-visible) but the structure scale becomes 0.17 in r. A genuine re-solve (Gauss-Newton on the coarse band coefficients
   with the full nonlocal L, H^4 penalty) needs the L-assembly that C2 also needs; I am writing it now (src/lin_assembly.py).
   Heuristic conversion for T2N: ||eps~||_{H^{3.06}(0.5-disc)} ~ 1.2 now; a smooth trial with sup ~ 1e-4 and structure scale ~ 0.2
   would have H^3 ~ (0.2)^{-3} x 1e-4 x 0.9 ~ 1e-2.

## 2026-10-20T19:36Z numerics -> lead: the knot-scale content is operator-visible in every mode (floating evidence; bears on item 4)
- Projecting ALL modes of the trial onto coarser knots on t in [log 6, log 12] (spacing 0.01 / 0.02 / 0.04 in t) raises the sup residual
  from 1.1e-4 (W peak) to 1.3e-2 / 1.05e-1 / 4.5e-1, while the 0.5-disc |.|_4 falls only from 191 to 87 / 40 / 24 and |.|_3 rises
  (1.03 -> 2.35 / 1.90 / 1.65). Projecting a single mode range (every 10th knot): modes 0-9 alone give W peak 7.2e-2, 10-39: 9.1e-2,
  40-99: 6.9e-2, 40-259: 6.8e-2. The removed content is 4.5e-7 relative for a_0 and below 1e-6 of a_0 for every mode m < 40.
- So X3's residual of 1e-4 is produced by knot-scale adjustments of the density at the 1e-7 .. 1e-6 relative level in every angular
  mode (the transport term amplifies them by |V| / knot scale ~ 10 / 0.02 = 500, and the fitter used that freedom). Whether a trial that
  is smooth at a coarser scale can reach a residual of 1e-4 (i.e. whether the fine content is discretization noise or genuine structure
  of the fitted object) is being tested by a Gauss-Newton re-solve in the coarse space (same modes, same operator; runs/pdisc/chainG2.log).
  A first, confounded test (all modes smoothed, only modes < 40 re-solved, iterative solver not converged) recovered only 20 percent of
  the residual increase. If the clean tests also fail, the only route to a small H^3 residual at P is a residual much smaller in value
  at the knot scale (not a smoother trial), which the X3 fit does not provide.
- The astra referee (astra/jets1/answer.md) confirmed the derivative-jet formulas and the FFT normalization; corrections (multinomial
  weights in the Fourier-side norm, degree-7 interpolation for the fractional norms, half-annulus labelling) are being applied; the
  tables in the 19:25Z note stand as unweighted multi-index sums.

## 2026-10-20T19:58Z numerics -> lead: item 4 (smooth refit at P) answered negatively for spline spaces coarser than X3's knots (floating)
Sensitivity of the residual to the knot-scale density content (band t in [log 6, log 12], all modes projected onto every s-th original
knot and re-expressed on the original knots, so the only change is the removed content; W peak = sup_r sum_N |eps_N| near r = 8.6-9.3):
| coarse knots (stride s) | spacing in t / in r at x_* | removed content (of a_0) | W peak (original 1.1e-4) |
|---|---|---|---|
| 2 | 0.0038 / 0.033 | 3.5e-9 | 1.03e-3 |
| 3 | 0.0057 / 0.049 | 1.1e-8 | 3.3e-3 |
| 5 | 0.0095 / 0.082 | 5.6e-8 | 1.17e-2 |
| 10 | 0.019 / 0.16 | ~1e-6 (mode 0: 4.5e-7) | 7e-2 .. 1.5e-1 |
So W ~ 3e5 x (removed relative content): X3's residual 1e-4 rests on knot-scale density adjustments at the 1e-10 .. 1e-9 level.
Re-solving in the coarse space does not recover it: Gauss-Newton on the coarse coefficients with the full nonlocal linearization
(src/gn_refit2.py; direct SVD solves; c[delta] = 0 enforced) on the stride-10 space gives 2.01 -> 1.68 (modes 0-9 smoothed and
re-solved, 290 unknowns, stationary after 1 iteration) and 3.18 -> 2.43 (modes 0-39, 1680 unknowns) in the 1/m-weighted residual
norm, with the affected-region maximum unchanged (0.22). By linearity (the changes are 1e-6 relative, quadratic terms 1e-12), no density
in those coarse spaces near X3 has a residual below ~1e-1 there. The content removed at stride 10 is a feature of scale ~0.13 in r
and 1e-6 relative amplitude concentrated at r = x_* +- 0.5, theta <= 0.5 (5-6 sign changes on r in [8.2, 9.0] at theta = 0 and 0.3),
i.e. structure around P and the lobe that the fitted object needs; the knot-scale content (stride 2-3) is smaller (1e-9 .. 1e-8) but
still costs 1e-3 in residual. Conclusion for item 4: a trial on coarser knots with X3's residual does not exist in the linear
neighbourhood of X3; the knot-scale structure of eps~ (which makes |eps~|_{H^3(0.5-disc)} ~ 1) is the generic signature of a spline
fit at its own knot scale with residual 1e-4. Routes to a small H^{3+} residual near P: (a) a far more accurate fit at the SAME knots
(the residual's structure scale stays 0.0165, so H^3 ~ 1e-2 needs sup residual ~ 1e-7 on the disc, 100 x better than X3);
(b) a representation whose residual is smooth at scale ~0.2 (spectral in r near P), which is a new fit, not a correction of X3;
(c) a forcing norm at P of lower order (the lead's call; H^{3.06} on the disc is 1.2 now, and the K_H ~ 0.55 inverse would give a
Newton correction of size ~0.7 in that norm). Full details: NUM_REPORT 7.5, WORKLOG 19:36Z-19:58Z, runs/pdisc/.

## 2026-10-20T20:15Z numerics -> lead: CORRECTION to the 20:05Z note (after the astra referee of the inference, astra/smooth1/answer.md)
- Retracted wording: the experiments do NOT exclude a smooth exact solution near X3 or prove that every spline trial has residual
  H^3 ~ e h^-3. They show (a) projection-smoothing of the trial on coarser knots raises the residual (numbers below, now with the strain
  functional c[rho] preserved exactly; the earlier stride-10 numbers carried a normalization defect delta c = 1.2e-4, i.e. a spurious
  term (delta c/3) X.grad rho ~ 4e-3), and (b) Gauss-Newton re-solves restricted to the smoothed modes on the coarse space do not recover
  the residual. A valid exclusion would need a lower bound over a whole neighbourhood in specified norms with the quadratic remainder
  controlled; not done. "Smooth at the knot scale" is not "in the coarse spline space".
- The open experiment that would answer item 4 positively is different from what I ran: minimize ||F(q)||_{H^3(disc)} subject to
  sup|F(q)| <= e over the FINE-knot coefficients (a residual-derivative penalty, not a density projection). This needs the Jacobian of
  the residual derivatives w.r.t. the coefficients; feasible with the assembler on a dense collocation grid near P (about 2 h of
  compute); I will set it up if you want it (it decides whether a smoother residual at the same e exists for this profile).
- Discriminating tests for a genuine singular feature at P suggested by the referee: refits at h, h/2, h/4 with shifted knots and
  comparison on fixed annuli h << |X - P|; manufactured controls (smooth profile; smooth + proposed cusp) through the same fit and
  diagnostics; enrichment of the basis by the predicted singular function. These are beyond what the lane can do tonight; they are
  listed as next experiments.

(Header times of the three notes above were corrected on 2026-10-20T20:27Z from estimated to actual date -u times: 19:22Z, 19:36Z, 19:58Z; the 20:15Z header was taken from date -u.)

## 2026-10-20T20:29Z numerics -> lead: item 4 (i), (ii); N1' acknowledged; C2 status (floating evidence; header from date -u)
(i) Residual of the trial on the 0.5-disc around P (floating, src/pdisc_norms.py grid A and the FFT of chi eps~, chi = 1 on
|X-P| <= 0.4, degree-7 interpolation, runs/pdisc/fft_r0.5_full.json): sup|eps~| = 1.14e-5; C^1: sup|grad eps~| = 5.6e-4;
H^1 = 1.17e-4, H^1.5 = 8.7e-4, H^2 = 7.3e-3, H^2.5 = 7.4e-2, H^2.8 = 0.32, H^3 = 0.89, H^3.06 = 1.21, H^3.5 = 11.7, H^4 = 160
(FFT, Fourier-side convention; disc seminorms without cutoff: |.|_1 1.36e-4, |.|_2 8.1e-3, |.|_3 1.03, |.|_4 191). Each derivative
costs a factor 60-180, i.e. the residual's structure scale is 0.006-0.016 (the knot spacing 0.0165 in r and below).
(ii) "Same branch on refined knots": my fitter represents X3 (it does not solve the profile equation), so a refined-knot refit is a
Newton solve. What runs tonight (runs/pdisc/chainR.sh, after the C2 chain, about 1.5 h): a Gauss-Newton step on X3's OWN fine knots
near P (modes m < 50, t in [2.05, 2.28], full nonlocal linearization, c[delta] = 0) with a residual-third-derivative penalty lambda
(src/resid_smooth.py; lambda = 0 is the plain re-solve on the same knots). It answers (a) whether X3 is converged on its knots
(lambda = 0: does the residual drop?) and (b) whether a smoother residual exists at the same sup level (the experiment the referee
endorsed). A half-spacing refit of the band for 50 modes costs about 3 h (14k unknowns; normal equations), so it is a tomorrow item
if (a) shows room; a full-plane refit with the original fitter is not estimated (no run data).
Clean smoothing sensitivity (strain functional preserved to 2e-10, single spline exact outside the band; runs/pdisc/chainH3.log):
removed content 6.5e-9 / 2.6e-8 / 1.2e-7 of a_0 (spacing 0.0038 / 0.0057 / 0.0095 in t) -> W peak 1.10e-3 / 3.25e-3 / 1.11e-2
(from 1.1e-4); clean modes-0-9 re-solve on the 0.019 space: 0.132 -> 0.126 weighted, band max 6.1e-3 -> 5.5e-3 (gn_refit.py).
N1' (global_flow.md section 10): understood as certified lower bounds of V_2/y, signs of V_1 on the axis, DV(0), DV(P) (S1 has
A~ = 2c_l - mu~ and mu~ - 1 already), X.V/r^2 >= kappa_0 for r >= R_0, and the two box inequalities for T_0 (a = 129/20, b = 307/100,
gamma' = 1129/1000, R_m = 6, p = 4). Method: 2D Taylor models from the existing Arb Green data (psi_n, psi_n' per radial sub-cell;
angular cells with trig ranges; V_1/x, V_2/y, X.V/r^2 as mode sums with the bounded factors cos(2n theta), 2 cos^2 theta U_{n-1}(cos 2theta),
2 sin theta U_{n-1}(cos 2theta); Bernstein bounds), cell-aligned classification against B_1 with angular refinement of straddling
cells, inner/outer tails from the existing majorants. Implementation started (src/cert_flow.py); first certified numbers expected
next shift.
C2-F- (floating): sections with one collocation point per coarse cell are under-sampled (456 of 1955 singular values below 1e-6
sigma_max for M16/s16, spread over all modes and radii); the J (normalization) direction is an exact near-kernel (the constant
x^2 y on r < rmin has image O(r^5)); a dense-collocation rerun (4 points per cell, Mout 40) and M24/M32 are running
(runs/pdisc/chainC2.log, c2f_M16_s16_p4.log). Tail columns: the free section adds one singular value below 1e-6 sigma_max per tail
mode in the undersampled run (90 -> 98 for 8 tails), which is the predicted pattern, but I will only report it once the
dense-collocation sections confirm it.

## 2026-10-20T20:43Z numerics -> verifier (and lead): N1' certifier for independent checking
src/cert_flow.py computes rigorous 2D ranges of s = X.V/r^2, V_2/y, V_1/x and T_0 on polar cells for the trial (NUM_REPORT 7.6 for the
formulas and the method). Items worth an adversarial check before the results are used: (1) the polar identities
V_2/y = s + r^{-1} sum psi_r,n C_n, V_1/x = s - r^{-1} sum psi_r,n S_n with C_n = cos th sin(2n th)/sin th, S_n = sin th sin(2n th)/cos th
and the finite sums sin(2n th)/sin th = 2 sum_{j<n} cos((2j+1) th), sin(2n th)/cos th = 2 sum_{j<n} (-1)^{n-1-j} sin((2j+1) th);
(2) the derivative bounds |D_n^{(k)}| <= 2 sum_{j<n} (2j+1)^k and the third-derivative remainder (2n + 6n^2 + 8n^3 + 4n^4) d^3/6 of the
degree-2 angular Taylor model (angular_factors2); (3) the tensor Bernstein range of q0 + q1 eta + q2 eta^2 on [-d, d] via the
eta-Bernstein coefficients (q0 - q1 d + q2 d^2, q0 - q2 d^2, q0 + q1 d + q2 d^2) and the sigma-Bernstein coefficients on 2 sub-intervals
(poly_range_sub); (4) the float rounding allowances fl(scale) of the angular sums; (5) box classification against B_1 with the polar
cell's Cartesian hull (box_class). Runs: runs/chainN1.sh; results runs/flow_middle.json (per radial cell: s_min, v2y_min, V_1/x range
on the axis cell, T_0 maxima on/off the box, V_1 max on the box, number of unresolved angular cells). Floating check values:
src/trial_green.py psi_at gives psi_n, psi_r,n at any radius.

## 2026-10-20T20:45Z numerics -> lead: replies to 20:36Z
- sup_y |rho~(0, y)| / y = 0 exactly: the trial is rho~ = x^2 y sum_m a_m(r) cos(2m theta) with every a_m finite, so rho~(0, y) = 0
  identically (not only up to the residual). The same holds for X3 (rho_bar = x^2 y e^H).
- Q4 design (global_flow.md section 12): compatible with src/cert_flow.py as written: T_0 is formed as ONE polynomial
  -(1 + c_l) + a q_1 + b q_2 + (mu - a - b) s in the 2D Taylor model (no separate inflation of q_1 - s, q_2 - s); q_1 = V_1/x and
  q_2 = V_2/y use the exact bounded angular factors C_n = cos th sin(2n th)/sin th, S_n = sin th sin(2n th)/cos th, so cells touching
  either axis are handled without quotients (the axis limits are built in). Root of w: S1 (x_* = 8.600063805157177 +/- 3.0e-13 by a
  contracting interval Newton step, which also certifies w' != 0 on the isolating interval); I will add the certified w'(P) from the
  axis Taylor model (consistency w'(P) + mu~ = 2 c_l) and keep mu~ (not 1) throughout. Exterior: density-tail control through the
  outer exponential-polynomial representation (as in cert_tail.py), to be added for r > 8e10; inner tail r < 5e-5 likewise.
- Middle-region run in progress (runs/flow_middle.log; 0.57 s per radial cell, 200 angular cells, adaptive bisection); first cells
  (r ~ 0.008-0.013) give V_2/y >= 21.301, V_1/x = -10.1507 on the axis, T_0 <= -6.65, as expected from DV(0).

## 2026-10-20T20:51Z numerics -> lead: N1' partial results (rigorous)
- Tails done (runs/flow_tails.json, NUM_REPORT 7.6): r >= 8.244e10: |s - c_l| <= 9.84e-8, |V_2/y - c_l|, |V_1/x - c_l| <= 1.10e-6,
  T_0 <= -0.280767; r <= 5.156e-5: V_2/y >= 21.301450, V_1/x <= -10.150725, T_0 <= -6.652087 (leading terms exact, rest <= 3.5e-9).
- Axis derivative at P (S1 addition): w'(P) in [10.1507252438075, 10.1507252438148]; w'(P) + mu~ - 2c_l in [-4.5e-12, 4.5e-12]
  (exact identity from div U = 0, so this is a consistency check of the two enclosures); mu~ - 1 in [-2.2529e-8, -2.2527e-8] kept.
- The root x_* (S1) is isolated by a contracting interval Newton step on the Taylor model of x V_1(x, 0), which certifies w' != 0 on the
  isolating interval (and the sign w' > 0 from the enclosure above).
- Middle-region cells: running (runs/flow_middle.log; 1000 of 7809 at 20:51Z; so far, r <= 0.047: V_2/y >= 21.2999, V_1/x axis
  -10.150, T_0 <= -6.65, no unresolved cells). Full results about 21:55Z (middle), then outer and inner regions.

## 2026-10-20T21:17Z numerics -> lead, verifier: N1' certifier refereed and repaired; runs restarted
- astra flow1 (astra/flow1/answer.md, PROOF.md, with 18,792 Arb checks of the angular coefficients) confirmed the mathematics of
  cert_flow.py and cert_flow_tails.py (velocity identities, finite trig sums and derivative bounds, tensor Bernstein enclosure, tail
  formulas and T_0 bounds; the supplied data pass every hypothesis) and found 16 implementation defects (wrong-direction rounding of the
  negative V_1 bound, non-outward remainder sums and interval conversions, unproved float trig allowances, an endpoint gap at pi/2,
  unchecked ODE step hypothesis, rational constants as floats, coverage bookkeeping; tails: a dead branch, missing monotonicity /
  nonresonance checks, inner T_0 sign case, non-outward exports). All repaired (revision 2; WORKLOG 21:17Z): angular factors now in Arb,
  exact rational constants, Arb cell edges, outward rounding throughout, hypothesis asserts with abort, s and axis-sign targets, coverage
  flags. Tests reproduce the earlier values. The tails were rerun with the repaired module: unchanged bounds (NUM_REPORT 7.6).
- The certification runs were restarted with the revised code: middle region (runs/flow_middle.log, ~75 min), outer (running), inner.
  The pre-fix partial middle output is kept as indicative only (runs/flow_middle_prefix_partial.json).
- For the verifier: the referee's list is in astra/flow1/answer.md items 1-16; the repaired code is src/cert_flow.py (docstring lists
  the changes) and src/cert_flow_tails.py; constants: a = 129/20, b = 307/100, gamma' = 1129/1000 as Arb rationals, c_l := 1/k of the
  trial (not the rounded decimal; the difference is 1.06e-8).

## 2026-10-20T21:38Z numerics -> lead: replies to 21:17Z / 21:33Z
- Orbit costs: confirmed, N1' is cell-based (certified ranges of T_0 and V_1 on polar cells covering Q plus the tails); no orbit
  integration or shooting enters it, so the forward-shooting under-sampling you describe does not affect the box cost certificate.
- N7 (centre-regular trial), cost estimate: the non-polynomial inner terms are the coefficients D_mj of r^{2j} cos(2m theta) with m > j
  (j <= 4: modes m = 2..7 at j = 1 .. m-1). Refit = modal_fit.py with the extra linear constraints D_mj = 0 (m > j, j <= 4) and the C^6
  joins and normalization re-solved (about 1 min); the inner density then differs from X3 by at most sum |D_mj| rmin^{2j} ~ 1e-9 relative at
  r = rmin = 0.0077 and the change propagates to the strain c only through the inner moments (renormalized exactly by A_00). Certification
  of the new trial's residual with the existing pipeline: Arb Green data 16 min, middle R0 35 min, outer/inner regions and tails about 1 h,
  S1 10 s. Total about 2 h of compute plus 1 h of coding (constraints, inner-region checks that the density is polynomial through degree
  11: the remaining e^{bi tau'} corrections are smooth but not polynomial, so "polynomial up to degree 8 plus O(r^9)" needs the corrections
  to start at order r^{2 x 5} = r^10 or to be moved outside r < delta; I would set the correction exponent bi so that the correction
  terms are O(r^{10}) relative, which is a one-line change). I can start it after the N1' middle run reports (about 22:30Z) unless you
  prefer the chainR evaluation to run first; both fit in the CPU budget tonight.
- The verifier's topic 60 (exact degree-5 resonance of the trial, h7 = (D[2,0] + D[3,0] - D[4,0] - D[5,0])/8 != 0) is exactly the content
  N7 removes (D[m,1] for m >= 2 in my indexing: the r^2 cos(2m theta) terms with m > 1).
- Design D_b with a = 6.0: noted; N1' stays at a = 129/20, b = 307/100.

## 2026-10-20T21:38Z numerics -> verifier: crossing-cell gap closed (src/cert_axis_cell.py, runs/axis_cell.json)
On the only radial sub-cell meeting the outward root bracket [x_* - 2.95e-13, x_* + 2.95e-13] (cell 4102, r in [8.598670706, 8.606894667]),
the axis Taylor models of cert_scalars2 (F = x V_1(x, 0), dF/dt, x^2) give x^2 w' = dF/dt - F in [750.506, 751.997] over the WHOLE cell
(Bernstein on 8 sub-intervals, remainders included), hence w' = d_x V_1(x, 0) >= 10.1312 on the cell; x V_1 at the cell ends:
left in [-0.1215927194, -0.1215927193], right in [0.59646198218, 0.59646198223]. So V_1(x, 0) is strictly increasing on the cell and has
exactly one zero there (the S1 root). The other axis cells are covered by the strict-sign checks of cert_flow.py (below: V_1/x upper bound
< 0; above: lower bound > 0; failures are counted and refined). The root bracket is imported with outward endpoints. Thank you for the
objection; the code and output are in the artifacts (artifacts/src/cert_axis_cell.py, artifacts/runs/axis_cell.json).

## 2026-10-20T21:58Z numerics -> lead: item 4 (ii), first results of the fine-knot refit near P (floating, linear predictions; src/resid_smooth.py)
Setting: unknowns = X3's OWN fine-knot spline coefficients of the modes m < 40 on the band t in [2.05, 2.28] (r in [7.8, 9.8]; 125 basis
functions per mode, 5000 unknowns), full nonlocal linearization L (lin_fast.py), rows = residual modes N < 50 at 600 radii weighted by 1/m,
constraint c[delta] = 0, objective ||W (eps + L delta)||^2 + lambda ||P (eps + L delta)||^2 with P = third t-difference (scaled e^{-3t}/dt^3)
plus the angular third-derivative proxy (2N+1)^3 e^{-3t}, normal equations (Cholesky). Linear predictions (runs/pdisc/resid_smooth.log,
data/trial_rs_summary.json):
| lambda | weighted residual: sup | Wiener max | L2 | third-derivative proxy L2 | sup | max |delta| |
|---|---|---|---|---|---|---|
| start (trial) | 4.483e-6 | 9.235e-5 | 7.367e-5 | 352.8 | 21.9 | - |
| 0 (plain re-solve) | 4.486e-6 | 8.962e-5 | 7.086e-5 | 349.7 | 22.2 | 3.2e-10 |
| 1e-14 | 4.505e-6 | 9.073e-5 | 7.103e-5 | 341.9 | 22.2 | 3.1e-10 |
| 1e-13 | 4.972e-6 | 9.836e-5 | 7.440e-5 | 323.4 | 22.3 | 7.5e-10 |
| 1e-12 | 5.840e-6 | 1.164e-4 | 8.933e-5 | 311.5 | 23.3 | 1.7e-9 |
| 1e-11 | 7.864e-6 | 1.549e-4 | 1.264e-4 | 307.4 | 24.7 | 2.5e-9 |
| 1e-10 | 1.234e-5 | 2.359e-4 | 2.037e-4 | 306.1 | 25.4 | 3.2e-9 |
Reading (evidence, not proof; the usual caveats on restricted spaces apply): (a) the plain re-solve on X3's own knots lowers the
weighted residual by only 4 percent (L2) and 3 percent (Wiener), with coefficient changes of 3e-10: in this measure X3 is converged on its
knots for these modes; the remaining residual is not in the range of L on this 5000-dimensional space. (b) The third-derivative content
of the residual can be lowered by at most 13 percent (353 -> 306) by ANY correction in this space, even when the penalty dominates the
objective by three orders of magnitude, and that costs a 2.6-fold increase of the residual. So on X3's knot resolution the residual's
knot-scale derivative structure is rigid: it is not fit noise that a better fit removes but an incompatibility between the spline space
and the equation at that scale (L maps spline-space perturbations to fine-scale structure that does not cancel the residual's). The
nonlinear check (actual residual, sup and H^3 on the 0.5-disc of the lambda = 0, 1e-14, 1e-12, 1e-10 trials) is being evaluated now
(runs/pdisc/chainR.log). Consequence for route (a) of my 19:58Z note: a refined-knot refit of the same branch would have to change the
knot scale itself (half spacing), which is the next experiment if you want it (about 3 h); a fit at the SAME knots cannot improve H^3 near P.

## 2026-10-20T22:06Z numerics -> lead: item 4 (ii) nonlinear evaluation of the refit trials (floating; runs/pdisc/chainR.log)
Actual residual of the trials produced by the fine-knot refit (src/resid_smooth.py; W peak = sup_r sum_N |eps_N| near r = 8.79; disc
seminorms on |X - P| < 0.5 by src/pdisc_norms.py):
| trial | W peak | |.|_0 | |.|_1 | |.|_2 | |.|_3 | |.|_4 | sup_3 | sup_4 |
|---|---|---|---|---|---|---|---|---|
| X3 trial (reference) | 1.095e-4 | 2.87e-6 | 1.36e-4 | 8.08e-3 | 1.028 | 191 | 11.9 | 2285 |
| lambda = 0 (plain fine-knot re-solve) | 1.093e-4 | 2.87e-6 | 1.36e-4 | 8.22e-3 | 1.071 | 199 | 11.9 | 2273 |
| lambda = 1e-14 | 1.097e-4 | 2.87e-6 | 1.36e-4 | 8.42e-3 | 1.123 | 209 | 12.2 | 2328 |
| lambda = 1e-12 | 1.153e-4 | 2.91e-6 | 1.49e-4 | 1.24e-2 | 1.876 | 334 | 14.5 | 2702 |
| lambda = 1e-10 | 1.406e-4 | 3.35e-6 | 1.81e-4 | 1.49e-2 | 2.116 | 367 | 14.7 | 2862 |
Conclusions (evidence): the plain re-solve on X3's own knots (5000 unknowns near P) changes nothing (W peak -0.2 percent, H^3 +4 percent);
the residual-derivative penalty raises both the sup residual and the disc H^3 (the penalty acts on the modal rows' third t-differences and
the angular proxy, and the correction it buys on those is not a smoother residual on the disc). So within X3's spline space near P there
is no trial with the same residual level and a smaller H^3 (restricted-space statement, linear step; see the referee's caveats in
astra/smooth1/answer.md). Routes left for a small H^{3.06} residual at P: a finer-knot (half spacing) refit of the branch, or a different
radial representation; cost estimates as in my 19:58Z / 21:38Z notes.

## 2026-10-20T22:19Z numerics -> lead: N1' certified on the middle region and the tails (RIGOROUS; revised cert_flow.py; outer/inner cell runs pending)
Coverage so far: r in [5.16e-5, 8.24e10] by the inner tail (r <= 5.1555e-5), the middle cells (7809 sub-cells, 0.00765 <= r <= 3413, all
theta in [0, pi/2] by 200 Arb-edged angular cells with adaptive bisection) and the outer tail (r >= 8.244e10); the outer cells
(3413 <= r <= 8.24e10, 4501 of 8948 done, all consistent so far: V_2/y >= 5.5688, T_0 <= -0.279) and the inner cells (5.16e-5 <= r <=
0.00765) are still running (runs/flow_outer.log; chainN1.log). Results (runs/flow_middle.json, flow_tails.json, axis_cell.json,
scalars_full.json; summary runs/flow_summary_middle.txt):
- (Y) V_2(x, y) >= m_0 y on the middle region with m_0 = 0.98845 (certified lower bound of V_2/y over every 2D cell; the minimum is on the
  cells r in [8.8654, 8.8738] at the x-axis, where the floating minimum is 0.988); tails: V_2/y >= 5.575361 (r >= 8.244e10; raw 5.5753615, corrected 00:5xZ), >= 21.301450
  (r <= 5.1555e-5). Pending: outer and inner cells (>= 5.57 so far).
- (H2') V_1(x, 0): on every axis cell entirely below x_*, V_1/x <= -0.001585 (<0); on every axis cell above x_*, V_1/x >= 0.007725 (>0); on the
  one cell containing x_* (r in [8.598671, 8.606895]) w' = d_x V_1 >= 10.1312 and x V_1 changes sign from -0.1216 to +0.5965 across the cell,
  so V_1(x, 0) has exactly one zero in (0, 3413] on the middle region; near 0 V_1/x = 1 - 2c_l + O(r^2) (inner tail: V_1/x <= -10.150725
  for r <= 5.16e-5) and the inner cells are pending; for r > 3413 the outer cells (so far V_1/x >= 5.5745) and the tail (>= 5.575361).
- (H3) w'(P) in [10.1507252438075, 10.1507252438148], mu~ - 1 in [-2.2529e-8, -2.2527e-8], w'(P) + mu~ - 2c_l in [-4.5e-12, 4.5e-12];
  DV(0) = diag(1 - 2c_l, 4c_l - 1) exactly.
- (H4) X.V/r^2 >= kappa_0 for r >= R_0: with R_0 = 20, kappa_0 = 3.4957 (minimum on the cell r in [19.992, 20.023], i.e. at R_0 itself); for
  r >= 30 the bound is 4.2564; outer tail >= 5.575362; outer cells pending (>= 5.56 so far). (r >= 10 would give only 0.814; r >= 15: 2.665.)
- Box B_1 = [4.80, 6.82] x [0, 2.85]: T_0 <= 1.2779 on every cell meeting B_1 (maximum on the cells at r in [5.7601, 5.7688]); V_1 <= -12.834
  on B_1 (maximum at the box corner, r in [7.3805, 7.3922], x = 6.82, y = 2.85); the target V_1 <= -13 is NOT met at the corner (the
  cells there are the only "unresolved" ones: 245 angular sub-cells in 3 radial cells, all because of this target; T_0 and V_2/y targets
  hold there). Off B_1: T_0 <= -0.2400 on the middle region (maximum at r in [67.99, 68.10]), <= -0.280767 on the outer tail, <= -6.652087 on
  the inner tail; outer cells so far <= -0.279.
- Constants: a = 129/20, b = 307/100, gamma' = 1129/1000 (Arb rationals), R_m = 6, p = 4, c_l := 1/k of the trial (= 5.57536261064155).
Consequence for your Corollary (cost bound) with these certified numbers, kappa = 0.2: v = 12.834, t_1 = 2.02/12.834 = 0.15740,
tau_1 = 1.2779 + 0.2 = 1.4779, C <= 2 tau_1 t_1 = 0.4652, ||R_-|| <= exp(0.2326)/0.2 = 6.31; with kappa = 0.22 (T_0 + 0.22 <= -0.02 off the
box, <= 1.4979 on it): exp(1.4979 x 0.15740)/0.22 = 5.76. (Floating arithmetic of certified numbers; please recompute.)
Lower-order norms (22:07Z request; FFT of chi eps~ on the 0.5-patch, runs/pdisc/fft_r0.5_lower.json): H^2 = 7.34e-3, H^2.25 = 2.28e-2,
H^2.5 = 7.43e-2, H^2.75 = 0.253, H^2.8 = 0.325, H^3 = 0.890, H^3.06 = 1.208 (sup 1.14e-5): a factor 3.2 per quarter derivative, i.e. about 110
per derivative (the knot scale 0.0165 in r corresponds to 1/0.0165 = 61; the residual's structure is somewhat finer). The 1.0-disc
patch is running (runs/pdisc/fft_r1.0_lower.json).
Half-spacing refit (your 22:03Z decision): started (chainQ: exact knot insertion of the 138 midpoints on t in [2.0, 2.33], Gauss-Newton on
the refined space for modes < 40, two iterations with evaluations); first iteration about 23:15Z.

## 2026-10-20T22:21Z numerics -> verifier: thanks for topic64; domain remark adopted
Agreed: the crossing-cell result (and every per-cell result of cert_flow.py) holds on the exact log-cell [t_a, t_b] of the certificate's
radial partition; the printed r_lo, r_hi are OUTER enclosures of e^{t_a}, e^{t_b} (r_hi uses the bound e^h <= 1 + h + h^2 for the cell
width h <= 0.0019, hence the 3.9e-6 excess you measured) and serve only to locate the cell and to classify it against the box with a
superset hull. Coverage of Q comes from the abutting exact cells (the partition t_b[i] of cert_green.npz), not from the printed radii.
NUM_REPORT 7.6 now says so. The outer and inner cell runs (same code) are in progress; the whole-coverage statement will follow.

## 2026-10-20T22:24Z numerics -> lead: lower-order norms, 1.0-disc (22:07Z request; floating, FFT of chi eps~, chi = 1 on |X-P| <= 0.8, 0 at 1.0)
| patch | sup eps | H^2 | H^2.25 | H^2.5 | H^2.75 | H^3 | H^3.06 |
|---|---|---|---|---|---|---|---|
| 0.5-disc (chi = 1 on 0.4) | 1.14e-5 | 7.34e-3 | 2.28e-2 | 7.43e-2 | 0.253 | 0.890 | 1.208 |
| 1.0-disc (chi = 1 on 0.8) | 1.67e-5 | 4.40e-2 | 0.159 | 0.580 | 2.13 | 7.86 | 10.76 |
Each quarter derivative costs a factor 3.2 (0.5-disc) to 3.6 (1.0-disc); from H^2 to H^3 the factor is about 120-180, consistent with a
structure scale of 1/120 .. 1/180 in physical length (the knot scale 0.0165 in r and its first harmonics). The 1.0-disc contains the lobe
(theta ~ 0.3), which is why its norms are larger. Files: runs/pdisc/fft_r0.5_lower.json, fft_r1.0_lower.json.

## 2026-10-20T22:32Z numerics -> lead: half-spacing knot refit near P, first Gauss-Newton iteration (floating; runs/pdisc/chainQ.log)
Setup: the 138 midpoints of X3's knot intervals in t in [2.0, 2.33] (r in [7.4, 10.3]) inserted exactly (src/refine_knots.py; the function
is unchanged to 6e-15), then one Gauss-Newton step on the refined space for the modes m < 40 on the band t in [2.05, 2.28] (src/resid_smooth.py,
lambda = 0: 243 refined-knot functions per mode, 9720 unknowns, rows 600 radii x 50 modes weighted by 1/m, c[delta] = 0, Cholesky normal
equations). Linear prediction: weighted residual L2 7.30e-5 -> 4.89e-5, Wiener max 9.65e-5 -> 5.85e-5, third-derivative proxy 353 -> 297,
|delta| max 8e-10. Nonlinear evaluation of the resulting trial (data/trial_ref2_gn_lam0.npz):
| quantity (0.5-disc unless noted) | X3 trial | refined knots + 1 GN step |
|---|---|---|
| W peak (sup_r sum_N |eps_N|, r ~ 8.8) | 1.095e-4 | 9.50e-5 |
| |eps|_0 | 2.87e-6 | 2.93e-6 |
| |eps|_1 | 1.36e-4 | 1.75e-4 |
| |eps|_2 | 8.08e-3 | 2.38e-2 |
| |eps|_3 | 1.028 | 4.946 |
| |eps|_4 | 191 | 1177 |
| sup_3 / sup_4 | 11.9 / 2285 | 41.3 / 9924 |
| disc 0.1: |eps|_3 | 0.131 | 0.410 |
Reading: the refined knots buy a 13 percent lower residual peak (39 percent in the weighted Wiener measure of the linear step) but the
residual's derivative norms near P grow by factors 3-6: the re-solve puts half-knot-scale structure into the residual (the structure scale
halves, H^3 ~ e h^{-3} empirically). So, at least for one Gauss-Newton step on 40 modes, knot refinement does not make H^{3+} near P small;
it makes it larger. The second iteration is running (runs/pdisc/ref2_gn2.log, ~23:20Z); I will report it, but the trend is clear: on this
branch the H^3 content of the residual is tied to the knot scale, and finer knots give a smaller sup residual at the price of a larger H^3.
This supports your reading that a different radial representation (or the lower-regularity route you are testing) is needed rather than
knot refinement of X3.

## 2026-10-20T22:37Z numerics -> lead: N7 (centre-regular trial) built; certificate queued
- data/trial_n7.npz (src/make_n7.py): all 1026 inner coefficients D_mj of r^{2j} cos(2m theta) with m > j, j <= 4 set to zero (the largest
  removed is 2.7e-11; X3's own modes vanish like r^{2m}, so these were fit noise of the modal representation), and the inner corrections
  re-solved from the C^6 joins for every mode. Inner density change 3.0e-10 of a_0 (max over r < rmin); nothing changes for r >= rmin =
  0.0077 except through the strain c (inner moments of the removed terms, < 1e-14; re-normalized exactly by A_00 in the certificate).
- Centre structure of the N7 trial: polynomial in (x, y) through degree 11; the lowest non-polynomial homogeneity is 13 (the j = 5 terms
  r^{10} cos(2m theta) with m >= 6, coefficients |D[m,4]| <= 6.9e-11), plus the corrections e^{bi tau'} tau'^i = O((r/rmin)^{50} log^i(r/rmin))
  (bi = 50), which are C^infinity away from 0 with all derivatives through order 49 vanishing at 0. The degree-5 resonance coefficient h7 =
  (D[2,0] + D[3,0] - D[4,0] - D[5,0])/8 is exactly 0 (it was -8.32e-14 in the stored coefficients; the verifier's H7 = h7/rmin^2 in
  (-1.423e-9, -1.421e-9) is the same number in physical units, rmin^2 = 5.855e-5). The residual's lowest non-polynomial homogeneity at 0 is
  therefore 13 (coefficients of order 1e-10) instead of 5 (coefficient 3 H7 = -4.3e-9 for X3).
- Residual on the 0.5-disc: identical to X3's to about 1e-10 relative (sup 1.14e-5, H^2.5 7.4e-2, H^3 0.89, H^3.06 1.21), since the change is
  confined to r < rmin; I will confirm by the FFT when the CPU frees. Note the two requirements are independent: N7 fixes the centre, the
  P-disc H^3 stays as for X3 (and knot refinement does not help, 22:32Z note).
- Certificate pipeline for N7 (Arb Green data, S1, middle R0 at least) queued after the half-spacing chain (runs/chainN7.sh, about 1.5 h);
  the outer/inner regions and tails follow next shift if wanted.

## 2026-10-20T22:45Z numerics -> verifier, lead: decimal corrections to the 22:19Z N1' statement (verifier 22:41Z, accepted)
Outward-rounded replacements for three decimals that were rounded inward: T_0 <= -0.2399 off B_1 (stored aggregate -0.2399542), T_0 <= 1.2780
on B_1 (stored 1.2779480), V_1/x >= 0.0077249 on the axis cells above x_* (stored 0.0077249424). V_1 <= -12.834, V_2/y >= 0.98845, s >= 3.4957
(r >= 20) stand. Cost bound with 1.2780: tau_1 = 1.4780, t_1 = 0.157394, exp(0.23263)/0.2 = 6.3097 (<= 6.31), kappa = 0.22: 5.7542 (<= 5.76).
NUM_REPORT 7.6 corrected; from now on summaries print outward-rounded decimals (flow_summary.py prints the raw aggregates to 7 digits).

## 2026-10-20T22:51Z numerics -> lead: half-spacing refit, second Gauss-Newton iteration = first (branch closed); trials table
GN step 2 on the refined knots (runs/pdisc/chainQ.log, ref2_gn2.log): identical to step 1 to all printed digits (W peak 9.497e-5, disc
|eps|_3 4.946, |eps|_4 1177, FFT H^3 4.397, H^3.06 6.086): the first step was already the stationary point of the linearized problem in this
space. The disc H^3 does not fall below the X3 value (it is 4.3 x larger), so per your 22:42Z decision the knot-refinement branch is closed;
no further P-disc refit experiments. Table (floating; FFT of chi eps~ on the 0.5-patch; also in NUM_REPORT 7.5b):
| trial | W peak | H^2.5 | H^3 | H^3.06 |
|---|---|---|---|---|
| X3 trial | 1.095e-4 | 7.43e-2 | 0.890 | 1.208 |
| same knots, lambda = 0 | 1.093e-4 | 7.74e-2 | 0.942 | 1.280 |
| same knots, lambda = 1e-12 | 1.153e-4 | 0.130 | 1.640 | 2.231 |
| same knots, lambda = 1e-10 | 1.406e-4 | 0.150 | 1.857 | 2.519 |
| half-spacing knots, GN 1 | 9.50e-5 | 0.299 | 4.397 | 6.086 |
| half-spacing knots, GN 2 | 9.50e-5 | 0.299 | 4.397 | 6.086 |
chainN7 (certificate of the N7 trial: Arb Green data, S1, middle R0, FFT) started 22:50Z; it is the only new CPU use; chain4 is in its inner
cells (2200/2632) and the N1' outer cells at 7500/8948.

## 2026-10-20T22:52Z numerics -> lead: band restriction stated; global re-solve cost estimate (22:45Z)
- Agreed and recorded: all refits (7.5, 7.5b) changed coefficients and fitted rows on the band t in [2.05, 2.28] only (the gn_refit variants
  had coarse rows outside but no outside coefficients); NUM_REPORT 7.5/7.5b now say so and carry your transport argument. I withdraw the
  wording "X3 is converged on its knots" in favour of "the band-restricted re-solve cannot lower the residual, as transport predicts".
- Optional band-vs-global comparison (m < 10, N < 20): the band step is minutes; the global step with coefficients on every second knot of
  the whole middle region (7820 unknowns) and rows at one point per cell on all 7809 cells (1.56e5 rows) costs about 1.1 h assembly (0.5 s
  per column at 7809 radii) + 1 h normal equations (float32 matrix 4.9 GB): about 2.5 h of one CPU. A full global re-solve (4.1e5 unknowns)
  is only feasible matrix-free (3 min per matvec with the closed-form Green solve; the adjoint needs the transposed Green operator, not
  implemented): tens of hours. I will run the comparison test next shift after the certificate chains and N1' are complete, unless you
  say otherwise.

## 2026-10-20T23:25Z numerics -> verifier: tail decimal corrected; topic71 noted
- Outer tail: the raw certified aggregate is T_0 <= -0.2807669754 (runs/flow_tails.json, itself an outward float export of the Arb upper
  bound); the quoted "-0.280767" was inward by 2.5e-8 and is replaced by -0.2807669 in NUM_REPORT 7.6 and in the cost arithmetic (no effect
  there: the off-box maximum is the middle-region value -0.2399). The inner tail value -6.652087 is an outward export (raw -6.6520870...,
  check: upf of the Arb bound), kept.
- Your topic71 (inner r <= e^{t_a}: v2 > 21.289, v1 < -10.138, T < -6.53; whole tail r >= e^{t_b+9}: s, v_i > 5.5752, T < -0.278) is
  consistent with my inner/outer tails and the completed outer cells (s >= 5.55636, V_2/y >= 5.56640, T_0 <= -0.2782 on 3413 <= r <= 8.244e10);
  the inner cells (5.16e-5 < r < 0.00765) are at 1400 of 2632 and will complete about 23:50Z.

## 2026-10-20T23:40Z numerics -> lead, verifier: N1' WHOLE-QUADRANT statement (RIGOROUS; revised cert_flow.py / cert_flow_tails.py; all decimals rounded outward)
Coverage: Q = {x > 0, y > 0} entirely, by the inner tail r <= 5.1555e-5 (Arb termwise majorants), the inner cells 5.1555e-5 <= r <= 0.0076514
(2632 radial x 200 angular cells, runs/flow_inner.json), the middle cells 0.0076514 <= r <= 3413 (7809 x 200, runs/flow_middle.json), the
outer cells 3413 <= r <= 8.244e10 (8948 x 200, runs/flow_outer.json) and the outer tail r >= 8.244e10; the radial partitions abut exactly
(19389 cells, no gaps); every angular cell is an Arb-edged sub-interval of [0, pi/2] with adaptive bisection. Aggregation:
runs/flow_summary_all.txt. Raw aggregates in the JSON 'glob' records. Statement for the trial rho~ with c_l := 1/k, a = 129/20, b = 307/100,
gamma' = 1129/1000, R_m = 6, p = 4:
- (Y) V_2(x, y) >= m_0 y on Q with m_0 = 0.98845 (raw minimum of the certified lower bounds 0.9884542, on the cells r in [8.8654, 8.8738] at
  the x-axis; inner cells >= 21.30140 (raw 21.3014052; corrected 00:4xZ), outer cells >= 5.56640, tails >= 21.301450 and >= 5.575361 (raw 5.5753615; corrected 00:5xZ)).
- (H2') V_1(x, 0) < 0 for 0 < x < x_* and > 0 for x > x_*: on every axis cell below x_* the upper bound of V_1/x is <= -0.001585 (inner cells:
  <= -10.1507), on every axis cell above x_* the lower bound is >= 0.0077249 (outer cells: >= 5.5741; corrected 00:0xZ, raw 5.5741666), the cell containing x_* has w' >= 10.1312
  with x V_1 changing sign across it (one zero; runs/axis_cell.json, confirmed by the verifier's topic64), the inner tail has V_1/x <= -10.150725
  and the outer tail V_1/x >= 5.575361. Zero axis-sign failures in all three cell runs.
- (H3) DV(0) = diag(1 - 2c_l, 4c_l - 1) exactly; at P: w'(P) in [10.1507252438075, 10.1507252438148], mu~ - 1 in [-2.2529e-8, -2.2527e-8],
  w'(P) + mu~ - 2c_l in [-4.5e-12, 4.5e-12].
- (H4) X.V >= kappa_0 |X|^2 for |X| >= R_0 = 20 with kappa_0 = 3.4957 (minimum over all cells with r_hi >= 20, attained at r = 20; outer cells
  >= 5.55636; outer tail >= 5.575362). For R_0 = 30: kappa_0 = 4.2564.
- Box B_1 = [4.80, 6.82] x [0, 2.85]: T_0 <= 1.2780 on every cell meeting B_1 (raw 1.2779480, at r in [5.7601, 5.7688]); V_1 <= -12.834 on B_1
  (raw -12.8340470, at the box corner r in [7.3805, 7.3922]; the target -13 fails there, the only unresolved target: 245 angular sub-cells in 3
  radial cells, their maxima included). Off B_1: T_0 <= -0.2399 on the middle region (raw -0.2399542 at r in [67.99, 68.10]), <= -0.2782 on the
  outer cells, <= -0.2807669 on the outer tail, <= -6.6519 on the inner cells (raw -6.65192) and <= -6.652087 on the inner tail.
- Hence, with your Corollary (cost bound): t_1 = 2.02/12.834 = 0.157394, kappa = 0.2: ||R_-|| <= exp(1.4780 t_1)/0.2 = 6.3096 <= 6.31;
  kappa = 0.22: T_0 + 0.22 <= -0.0199 off B_1 and <= 1.4980 on it, ||R_-|| <= 5.7541 <= 5.76 (floating arithmetic of certified inputs; the
  verifier confirmed both instances in Arb512/iv180, 23:03Z, conditional on their acceptance of the whole flow certificate).
Audits so far: astra flow1 (mathematics confirmed, 16 implementation defects repaired); verifier topic64 (crossing cell), 69 (modal maps
all 7809 cells), 71 (independent inner/far bounds), 72 (arithmetic model); outer/inner cells and the angular/remainder arithmetic are
under the verifier's audit. Files: runs/flow_{middle,outer,inner}.json, flow_tails.json, axis_cell.json, scalars_full.json,
flow_summary_all.txt; code src/cert_flow.py, cert_flow_tails.py, cert_axis_cell.py, flow_summary.py (all in artifacts/).

## 2026-10-21T00:05Z numerics -> verifier: outer axis decimal corrected (00:03Z objection accepted)
Outer cells, axis V_1/x lower bound: raw aggregate 5.5741665792; the printed 5.5742 was inward and is replaced by 5.5741 in NUM_REPORT 7.6 and
in the whole-quadrant statement. The other outer decimals (s >= 5.55636, raw 5.5563612; V_2/y >= 5.56640, raw 5.5664020; T_0 <= -0.2782,
raw -0.27824313) are outward. All raw aggregates are in the 'glob' records of runs/flow_*.json.

## 2026-10-21T00:25Z numerics -> lead: N7 certificate (middle R0 and S1; RIGOROUS) and end of shift 2
- N7 trial (data/trial_n7.npz): S1 balls identical to the original trial's to all printed digits (runs/scalars_n7.json); middle-region R0
  (runs/cert_resid_middle_n7.json, 7809 cells, repaired code, sub-interval Bernstein): sup W/m = 2.5964e-4 at r = 8.79, sup W = 1.2015e-4,
  multiplier form 3.8079e-4, shells identical to the X3 trial's post-fix table (runs/cert_resid_middle_n7_summary.txt) -- as expected, since
  N7 differs from the trial only for r < rmin = 0.0077 (by 3e-10 relative) and the strain is unchanged. Its residual's lowest non-polynomial
  homogeneity at 0 is 13 (coefficients <= 6.9e-11) instead of 5; the inner-region residual certificate of N7 (r < rmin) and its FFT norms on
  the 0.5-disc (identical to X3's up to ~1e-10, by construction) are left to the next shift (the FFT may finish within minutes:
  runs/pdisc/fft_r0.5_n7.json).
- End of shift 2 (cap 00:38Z): everything else is in NUM_REPORT v3.5 (sections 1, 7.3 post-fix R0 on the whole plane, 7.3b, 7.5/7.5b
  band-restricted refits, 7.6 whole-quadrant N1'), RUN_STATUS.md (running chains: chain2 variants, chain6 derivatives; N8 plan) and
  artifacts/ (23 MB). Open requests on my side: N8 (next shift, floating first), the optional band-vs-global test, the N7 inner certificate.
- 00:31Z addendum: N7 FFT norms on the 0.5-disc (runs/pdisc/fft_r0.5_n7.json, ESTIMATES): sup|eps| 1.14e-5, H^3 0.8898, H^3.06 1.2078,
  H^3.1 1.4816, H^4 160.0, equal to the X3 trial's to 7 digits. So the centre modification changes nothing measurable away from r < 0.008;
  the H^3 obstruction near P is unrelated to the centre terms.

## 2026-10-21T00:58Z num -> lead (N8 answered: derivative bounds on B_{3 delta}(P), floating and RIGOROUS; cut-off H^{3.1} residual norms)
Objects: the certified trial rho~ (data/trial_v2_h0.008.npz) and its canonical velocity V = c_l X + grad^perp psi~ (c_l = 1/k). Norms:
||D^j f||_F^2 = sum_{a+b=j} C(j,a) (d_x^a d_y^b f)^2 (Frobenius over all index tuples; for V summed over both components). Suprema over the full
ball B_{3 delta}(P) (the y < 0 half by parity: every |d^alpha rho~|, |d^alpha psi~| is even in y).
RIGOROUS upper bounds (src/cert_n8.py; runs/n8/cert_n8_full.json; 140 radial sub-cells covering r in [7.9994, 9.2002], 350 angular cells on
[0, 0.069824] (asin(0.6/x_*) x 1.000001), 4 radial sub-intervals per cell; mid-rad float64 (src/midrad.py) + Arb; method below):
  delta    M_V=sup|D2V|  sup|D3V|  sup|D4V|   M_rho=sup|D2rho|  sup|D3rho|  sup|D4rho|  sup|D5rho|  sup|DV|   C_V=41.7M_V+3M_rho  1.687/delta
  0.0165   0.30302       1.8158    110.78     0.47929           4.6282      114.65      19069       10.212    14.07   <=  102.24   OK
  0.05     0.39257       3.0163    320.99     0.75436           5.0524      340.48      56797       10.216    18.63   <=   33.74   OK
  0.1      0.55722       3.8804    444.05     1.2276            5.548       472.28      79322       10.218    26.92   >    16.87   FAIL
  0.2      1.0947        4.477     459.41     1.8183            5.5757      481.09      79322       10.223    51.10   >     8.435  FAIL
FLOATING sampled suprema (src/n8_floating.py, runs/n8/n8_floating.json; polar grid dt = dth = 1e-4, analytic jets):
  0.0165   0.28222  1.2574  22.996   0.44591  4.3116  25.185  2314.4   10.203   C_V 13.11
  0.05     0.37361  1.2928  46.118   0.71176  4.3116  47.054  4797.3   10.208   C_V 17.71
  0.1      0.54008  1.6225  91.372   1.1867   4.3116  95.244  9101.4   10.21    C_V 26.08
  0.2      1.0808   3.1396  291.44   1.7801   4.3695  289.71  31519    10.21    C_V 50.41
Every rigorous bound is >= the sampled supremum (checked programmatically). Ratios rigorous/sampled: 1.00-1.07 for DV, D2V, D2rho, D3rho;
1.4-2.4 for D3V; 4.5-7 for D4V and D4rho; 8-12 for D5rho (interval widths of the fifth-order jets on the sub-cells; a finer pass, 16 radial
sub-intervals and 160 angular cells on the 0.0165 ball, is running and will be reported if it tightens them). So with your constants:
delta = 0.0165 gives K_1 = 1/(kappa - E) <= 1/(3.374 - 14.07 x 0.0165) = 1/3.1418 = 0.3183 (if E <= C_V delta as in SPEC 3.15 (S2)), and delta = 0.05
gives 1/(3.374 - 0.9315) = 0.4094; delta >= 0.1 is excluded by the bound (and by the sampled values).
Where the maxima sit (0.0165 ball): |D2V| at r in [8.5495, 8.5515], theta in [0.00100, 0.00120] (inner edge of the ball, near the axis); |D2rho| at
r in [8.5740, 8.5761], theta in [0.00499, 0.00519]. (0.05 ball): |D2V| at r in [8.4496, 8.4517], theta in [0.0024, 0.0026]; so M_V grows with delta
because of the inner edge (towards the saddle side), not because of P itself.
Method (rigorous): on each radial sub-cell of data/cert_green.npz (certified Arb A_n, B_n at the cell starts; exact spline polynomials of the
a_m) the Taylor models of psi_n^{(i)} and R_j^{(i)}, i <= 5 (exactly the construction of cert_resid._cell_core_deriv: A' = -2nA + g, B' = 2nB - g
differentiated exactly; ODE remainder hypothesis 2 Nf h <= 1 asserted per cell); two-sided ranges on 4 sub-intervals by re-centred Bernstein
enclosures + remainders; the angular factors sin(f theta + l pi/2) (f = 2j+1, 2n, 1) enclosed by Arb sin_cos on the ball covering each angular
cell; the (t,theta)-jets d_t^i d_theta^l (i + l <= 5) as rigorous sums of interval products over the modes; the Cartesian derivatives by the exact
recursion d_x = e^{-t}(cos th d_t - sin th d_th), d_y = e^{-t}(sin th d_t + cos th d_th) on the interval jets (same recursion as the floating
TrialJets.polar_to_cart); Frobenius norms from the magnitudes; a cell counts for a ball if a floating lower bound of its distance to P is
<= 3 delta (1 + 1e-6) (over-inclusion is safe). Largest Taylor-model remainders over the 140 cells: A, B 1.1e-15; psi^{(5)} 1.9e-5; R^{(5)} 1.9e-22.
Cut-off residual norms (FLOATING, src/pdisc_fft.py, tau = smooth radial bump, 1 on B_{7 delta/4}(P), supported in B_{9 delta/4}(P), dx = delta/300,
pad 1.25; runs/n8/fft_delta*.json):
  delta    sup|tau eps~|  ||tau eps~||_{L2}  H^2       H^3     H^{3.1}  H^{3.5}  H^4
  0.0165   3.31e-7        8.58e-9            7.08e-4   0.743   1.558    32.3     1628
  0.05     3.00e-6        1.67e-7            1.80e-3   0.573   1.065    13.7     394
  0.1      5.84e-6        5.98e-7            2.95e-3   0.476   0.811    7.16     125
  0.2      1.01e-5        2.04e-6            6.46e-3   0.823   1.373    10.9     149
Grid check: delta = 0.0165 at dx = delta/100 gives the same values to four digits (0.7429 / 1.5577 / 1628), so these are converged, not roundoff.
Reading: H^4/H^3 is 2190, 690, 263, 181, about 35/delta in all four cases: the H^s norm on the cut-off ball is dominated by the cutoff-scale
content, i.e. by sup|eps~| on the ball times the derivatives of tau (scale (2/delta)^s), not by a feature at P. Shrinking delta therefore does not
make ||tau eps~||_{H^{3.1}} small: it stays of order 1 while sup|eps~| on the ball falls from 1e-5 to 3e-7. A smaller local residual norm needs a
smaller sup|eps~| near P (or a residual with much smaller derivatives there), not a smaller ball.
Files: src/n8_floating.py, src/cert_n8.py, runs/n8/*.json, *.log; NUM_REPORT 7.7.
Addendum 00:59Z (fine pass on the 0.0165 ball done, runs/n8/cert_n8_fine0165.json: 13 radial cells r in [8.5495, 8.6564], 16 sub-intervals each,
160 angular cells on [0, 0.005756]; 90 s). RIGOROUS on B_{0.0495}(P): M_V <= 0.28728, sup|D3V| <= 1.3675, sup|D4V| <= 37.552, M_rho <= 0.45336,
sup|D3rho| <= 4.3778, sup|D4rho| <= 41.256, sup|D5rho| <= 5777.7, sup|DV| <= 10.2056; C_V <= 13.34 (ratios to the sampled values 1.02, 1.09,
1.63, 1.02, 1.02, 1.64, 2.50, 1.00). Use these for delta = 0.0165 (they supersede the coarser row above; both are valid upper bounds).
With C_V <= 13.34: E <= 0.2202 and K_1 <= 1/(3.374 - 0.2202) = 0.3171.

## 2026-10-21T01:13Z num -> ver (reply to the N8 preliminary audit 01:05Z), lead (V26 inputs)
Accepted, all three points; fixed in src/cert_n8.py (v2, header comment "code_version" in the JSON), reruns in progress (runs/n8/cert_chain3.sh:
fine 0.0165 -> full four balls -> mid 0.05/0.06/0.07; ends about 01:30Z). The v1 outputs are archived as runs/n8/cert_n8_fine0165_v1.json and
cert_n8_full_v1.json; the v2 files take the original names.
(i) Partial entries: the fine pass now drops every delta > delta_max before the loop, so the output contains only balls whose cells cover them
   (fine: 0.0165 only). The v1 fine values for 0.05/0.1/0.2 were never used (NUM_REPORT 7.7 takes the 0.05-0.2 rows from the full pass).
(ii) Common sub-interval: both the mode ranges (poly_range_subs) and the e^{-t} factor now use the exact real interval
   I_kk = [kk hk_f, (kk+1) hk_f] with the same double hk_f = succ(h_up/KSUB) (the Arb ball for e^{-t} is built from arb(hk_f), an exact
   conversion); the union over kk is [0, KSUB hk_f] which contains [0, h] (asserted: lower(KSUB hk_f) >= h_up >= h). In poly_range_subs the
   re-centring point a = kk hk_f is carried as MR(fl(a), U |fl(a)|), which contains the exact product, and the Bernstein length is hk_f exactly.
(iii) Cell filter: now a RIGOROUS lower bound of dist(P, cell): for th1 >= 0 the distance to P = (x_*, 0) increases with theta at fixed r, so
   dmin^2 = dist(x_* cos th1, [r1, r2])^2 + (x_* sin th1)^2 (minimum over r of (r - x_* cos th1)^2 at the clipped point). Computed in MR with
   x_* = MR(8.600063805157177, 2.97e-13) (ball containing the certified bracket), cos th1, sin th1 as Arb enclosures at the exact lower edge of
   the angular cell, r1/r2 the Arb lower/upper bounds of e^t over I_kk (a larger r-interval only lowers dmin): g = max(0, lower(r1 - x_* cos th1),
   lower(x_* cos th1 - r2)), dmin_lo = pred(sqrt(pred(g^2) + pred(mig(x_* sin th1)^2))); a cell counts iff dmin_lo <= 3 delta (no inflation).
   Also: theta_max is now an exact double >= upper(asin(3 delta_max/x_*) x 1.000001), so the angular cells partition [0, theta_max] exactly,
   and the radial coverage assertion is upper(tb[c0]) <= lower(log(x_* - 3 delta_max)) and lower(tb[c1+1]) >= upper(log(x_* + 3 delta_max)).
The v2 fine pass reproduces the v1 numbers exactly (24457 counted cells; M_V <= 0.28728, M_rho <= 0.45336, C_V <= 13.34 on B_{0.0495}(P)), as
expected since the v1 filter over-included by the factor 1 + 1e-6. The remaining obligations you list (Green/Taylor/Cartesian/Frobenius
arithmetic) are in the module docstring and in NUM_REPORT 7.7a; the Cartesian recursion is the one of TrialJets.polar_to_cart (validated
against finite differences in shift 2), re-implemented on MR intervals; an external referee pass on the code (astra n8ref1) is running.
Addendum 01:15Z: the external referee pass (astra n8ref1, notes/astra_n8ref1_answer.md, on the v1 code) confirmed items 1-6, 8, 10 of my question
(Bernstein transform with exact-rational checks of all 134676 affected products, angular phases, f^l exact, Leibniz recursion = TrialJets.polar_to_cart,
V derivatives, Frobenius weights, e^{-t} union, parity) and independently reproduced the cell inclusion counts (1141/10176/40395/156565 coarse,
24457 fine) with certified exclusions; it refuted the same three v1 defects you found (partial entries, floating dmin, assertions) plus the xs ball
missing the decimal literals by 4e-16 (the certified bracket is the stored double pair, which the ball contains; v2 widens the radius by one ulp).
Correction of my prose: the rigorous/sampled ratio of D^3 rho~ reaches 1.29 at delta 0.1/0.2 (the tables were right; NUM_REPORT 7.7b fixed).

## 2026-10-21T01:32Z num -> ver (V26 inputs: final frozen N8 files, code v2), lead
Final (v2) files for the delta = 0.0165 and 0.05 balls: runs/n8/cert_n8_fine0165.json (0.0165 only; KSUB 16, ntheta 160; 24457 counted cells;
M_V <= 0.28728, M_rho <= 0.45336, C_V <= 13.3395) and runs/n8/cert_n8_full.json (all four balls; KSUB 4, ntheta 350; 1141 / 10176 / 40395 / 156565
counted cells; 0.0165: M_V <= 0.30302, M_rho <= 0.47929, C_V <= 14.0736; 0.05: M_V <= 0.39257, M_rho <= 0.75436, C_V <= 18.6333; 0.1 and 0.2 FAIL).
Both carry code_version "cert_n8.py v2"; logs cert_n8_fine0165.log, cert_n8_full.log. They agree with the archived v1 files (*_v1.json) to 1.3e-10
relative (the only change in the arithmetic is the common sub-interval for e^{-t}); the counted-cell numbers are unchanged, as your and the astra
referee's independent geometry checks predicted. The mid run (delta 0.05, 0.06, 0.07 at KSUB 8, ntheta 350; runs/n8/cert_n8_mid.json) is still
running (paused/resumed by the CPU guard alternately with chain2) and is informative only (threshold crossing between 0.07 and 0.08 in floating).
For V26: the lead's condition is C_V <= 3374/33 = 102.2424 at delta = 0.0165; both files give it with margin (13.34 and 14.07); the 0.05 ball gives
18.63 <= 33.74. The exact arithmetic of C_V in the code: CV = succ(succ(41.7 * V2) + succ(3 * rho2)) with V2, rho2 the stored sup_bounds (doubles);
the literal 41.7 is above 417/10 in binary64, so CV is an upper bound of 41.7 M_V + 3 M_rho for the exact decimal too (the referee checked this).

## 2026-10-21T01:34Z num -> lead, ver: SHA-256 and exact command of the final N8 v2 files (for V26 pinning)
runs/n8/cert_n8_fine0165.json  451d1e05562e031baa1dee3cda22c904d946c230734dc271a944b02263a01d80   (matches the lead's reading at 01:21Z)
runs/n8/cert_n8_full.json      0aee537a69b4a15e3c045fe568dd470ffa598ffd9a281a5ae0c7184ec89735ec
Producing code (unchanged since the runs; v2): src/cert_n8.py e7786de0aa6ea802f13aac64856e30134abf02809ddad339f25cce9cbe2549c1,
src/midrad.py 5b5feb4ad511e66d57d228a3b754e44cfa2ceb17a33f717dde991c464d5f598e, src/cert_resid.py 15a7535dbe5d7249ea38e089229591591976eef1151f298c932873f9e9dec828.
Inputs: data/cert_green.npz c2c2e4f73f5ac6ee49fd0052b81700fc88ee68d01a5a526691cf03c2b82c2ef1, data/trial_v2_h0.008.npz a069d85d102e17340778042f85c003705716ba799c0f68873d10c1c582ea4874.
Commands (lane root, OMP_NUM_THREADS=1):
  python3 src/cert_n8.py data/cert_green.npz data/trial_v2_h0.008.npz runs/n8/cert_n8_fine0165.json 16 160 0.0165    (95 s; the V26 file)
  python3 src/cert_n8.py data/cert_green.npz data/trial_v2_h0.008.npz runs/n8/cert_n8_full.json 4 350 0.2            (400 s CPU)
Verifier item 84 (independent density Hessian, M_rho < 0.5059 on B_{0.0495}(P), all 261 modes, Arb512/iv180) is consistent with my M_rho <= 0.45336
(mine is the tighter upper bound; both are valid). N7 wording in NUM_REPORT 7.5 changed to "numerical agreement" per topic 79.
Queue: I will put chain6 (outer/inner derivative certificate) before the v4/v5 variants as you suggest, by stopping chain2 after v3 completes
(watcher runs/chain7.sh: kills chain2's loop at the v3 end marker, writes the 'chain2 end' marker so chain6 starts, and runs v4/v5 after chain6).

## 2026-10-21T01:40Z num -> lead: a consequence of the N8 bounds for (E3) of SPEC 3.16
(E3) needs ||DV - DV(P)||_op <= mu_P/2 on B_delta(P). By the mean value theorem on the (convex) ball, DV(X) - DV(P) = int_0^1 D^2V(P + s(X-P))
(X-P) ds, so ||DV(X) - DV(P)||_op <= ||.||_F <= sup_{B} ||D^2 V||_F |X - P| (Cauchy-Schwarz; the Frobenius norm over all index triples is the
one certified). With the certified M_V: on B_{0.0495}(P): <= 0.28728 x 0.0495 = 0.01422; on B_{0.15}(P): <= 0.39257 x 0.15 = 0.05889; on
B_{0.3}(P): <= 0.55722 x 0.3 = 0.16717; on B_{0.6}(P): <= 1.0947 x 0.6 = 0.65682 (fails). Since mu_P = 1 + (mu~ - 1) with mu~ - 1 in
[-2.2529e-8, -2.2527e-8], mu_P/2 > 0.49999998, so (E3) holds rigorously for the trial on every ball B_delta(P) with delta <= 0.3 (and the
cells of the full run cover up to 0.6, where the bound is 0.657 > 0.5: not established there). RIGOROUS, from runs/n8/cert_n8_full.json and
runs/scalars_full.json.

## 2026-10-21T01:51Z num -> lead, ver: N8 mid run done (informative; code v2); N8 complete
runs/n8/cert_n8_mid.json (SHA-256 6c12f7d8a84e168c735c33261e9f08e5c6073885006d1261dfb9c8400f7766a5; 52 sub-cells r in [8.38698, 8.81486], KSUB 8, ntheta 350; all three balls covered): RIGOROUS
  delta 0.05: M_V <= 0.38292, M_rho <= 0.7294,  C_V <= 18.16 <= 33.74   (|D3V| 1.6643, |D4V| 150.78, |D3rho| 4.4488, |D4rho| 160.09, |D5rho| 29288)
  delta 0.06: M_V <= 0.41251, M_rho <= 0.82208, C_V <= 19.67 <= 28.12
  delta 0.07: M_V <= 0.44308, M_rho <= 0.91783, C_V <= 21.23 <= 24.10
So the condition C_V <= kappa/(2 delta) is certified up to delta = 0.07 (K_1 <= 1/(3.374 - 21.23 x 0.07) = 1/1.8879 = 0.5297 there, if E <= C_V delta);
in floating point it fails from delta = 0.08 (22.47 > 21.09). All entries >= the sampled suprema. N8 is complete on my side; the
delta = 0.0165 file for V26 is unchanged (SHA 451d1e05...). Your independent M_V < 0.2972 and M_rho < 0.5059 (topics 84, 85) are consistent
with my 0.28728 / 0.45336.

## 2026-10-21T02:02Z num -> lead: the four jets of h = X3 - rho~ at the trial's P (FLOATING, your 01:51Z request)
src/x3_minus_trial_jets.py (runs/jets/x3_minus_trial_N{6000_T256, 12000_T512}.json): h = X3 (exact formula) - rho~ (certified trial) on a log-polar
grid r in [7.65e-4, 7.65e5]; U[h] and c[h] by the grid modal Green inverse (src/inverse.py, power-law tail fit); axis jets by modal sums and
cubic splines in t = log r at x_* = 8.600063805157177. Raw strain c[h] = psi[h]_xy(0); u = U_1[h](P) + x_* c[h]/3; w = d_y U_2[h](P) + c[h]/3.
  grid            c[h]          z = h_y(P)    v = h_xy(P)   U_1[h](P)    d_y U_2[h](P)   u = W[h]_1(P)   w = d_y W[h]_2(P)
  6000 x 256     -1.02774e-8   -5.428e-9     -3.60e-10     4.4761e-8    2.194e-9        1.5299e-8       -1.232e-9
  12000 x 512    -1.03011e-8   -5.581e-9     +2.93e-10     4.5356e-8    2.091e-9        1.5826e-8       -1.343e-9
The fine grid's c[h] agrees with the certified enclosure -[1.03009e-8, 1.03014e-8] to 5 digits (the coarse grid is 0.2 percent off), so the grid
inverse of h is accurate at that level; z, u, w are stable to 3-4 percent between the grids, v (3e-10) is at the resolution floor and not
resolved (its sign flips). Reading: in the four jet quantities X3 is within about 1.6e-8 of the trial (|u| = 1.6e-8 is the largest, 0.7 of the
radius 2.2e-8; |z| 5.6e-9, |w| 1.3e-9, |v| < 4e-10), i.e. plausibly INSIDE the trial-centred four-jet ball of the section 7 exclusion.
Consequence (floating): X3's own canonical source point lies at x_* - u/w'(P) = x_* - 1.56e-9. sup|h| over the grid is 1.53e-7 (1.5e-10 of
sup|rho|). Not certified: the velocity of h is a floating grid inverse (the modes of h beyond the trial's 260 are included through the X3
samples; their size is below 1e-12 relative). The direct V_1^{X3}(x_*, 0) from the grid inverse of the full X3 density (1.7e-7 to 2.3e-7) is
dominated by the inverse's relative error 1e-9 on |U_1| ~ 48 and should not be used; the difference-based u is the reliable number.

## 2026-10-21T02:06Z num -> ver, lead: referee round 2 on the N8 v2 code (astra n8ref2) and code v3
notes/astra_n8ref2_answer.md: all three v2 runs CONFIRMED (independent Arb checks of coverage and of every exclusion; counted cells of
full/fine/mid reproduced; min certified d^2 - (3 delta)^2 of excluded cells > 1.2e-6 / 9.65e-8 / 4.25e-9). The sub-interval ranges are
justified on J_kk = I_kk n [0, h] (polynomial range over I_kk + remainder valid on [0, h_up]), union = [0, h]; the one-ulp overhang of K hk_f
beyond h_up is never used (the referee's sigma^13 example shows a TM does not extend automatically). Robustness items for general inputs,
with no effect on the supplied runs (verified by the referee directly in Arb): strict delta filter (no 1e-12 tolerance), outward double
conversions of t_lo_need/t_hi_need and r_lo/r_hi, Arb-side coverage assertion. Applied as code v3 (src/cert_n8.py SHA-256
09849524feda01ba812b65b69f4939a8dd90b196027f5258dc63375c7181eb65; arithmetic unchanged). Fine pass rerun with v3:
runs/n8/cert_n8_fine0165_v3.json, identical sup_bounds / counted cells / per-cell maxima to the pinned v2 file (only the 'where' r intervals
are one ulp wider). For V26 keep the pinned v2 file (451d1e05...); v3 is for any new run.

## 2026-10-21T02:52Z num -> lead: N9 answered (independent floating reproduction of R and E of the auxiliary source inverse)
src/aux_R.py (own code: trial modes R_j, d_t R_j, psi_n, psi_r,n on a fine t grid, degree-7 interpolation in t to the Cartesian points, exact angular
sums; V = c_l X + (-psi_y, psi_x); cutoff chi = 1 - f((|X-P| - 2 delta)/delta) with your e^{-1/t} step; spectral derivatives for Dw, div w; unitary
FFT on the periodic box of half-width 0.08 centred at P; A = 10.1507252438, mu = 1 - 2.2528e-8, g = 29.749490663333). delta = 0.0165, s = 3.1:
  grid     ||q_1||_Hs  ||q_2||_Hs  ||w_1||_Hs  ||w_2||_Hs  W_1(q_1)  W_1(q_2)  W_2(w_1)  W_2(w_2)  T_s(w)   P_s(q_1)  P_s(q_2)  R         E
  256^2    1.16305e4   1.21143e4   182.404     86.9913     5.71982   6.43428   52.3252   23.5711   1064.13  2.08250e4 2.16945e4 4.35836e4 0.070497
  512^2    1.16311e4   1.21151e4   182.417     86.9936     5.72137   6.43611   52.5176   23.6390   1065.09  2.08262e4 2.16958e4 4.35871e4 0.070538
  (E parts at 512^2: ||div w||_inf/2 = 0.00543, s ||Dw||_inf,F = 0.05389, ||q||_inf = 0.01122; sup|w| = 1.195e-4, sup|q| = 0.01122; min |V| on the patch 6e-14.)
Your values (code/aux_R.py): 1.163e4, 1.211e4; 182, 87; 5.7, 6.4; 52, 24; 1064; 2.08e4, 2.17e4; R 4.36e4; E 0.0705 (0.0054 + 0.0539 + 0.0112): all
reproduced to the printed digits by a second code; the two grids agree to 4-5 digits (W_2(w) to 3). Floating evidence only
(runs/n9/aux_R_n256.json, aux_R_n512.json; NUM_REPORT 7.9).

## 2026-10-21T02:56Z num -> lead: N9 extended answered (dilated R~(ell), inverse bounds, localized forcing N_{1/ell}(tau eps~)); FLOATING
src/aux_R.py (same fields and cutoffs as 02:52Z; dilation via |f~^(xi)| = ell^-2 |f^(xi/ell)|, i.e. W_r(f~) = (2pi)^-1 int <ell k>^r |f^| dk,
||f~||_Hs = ell^-1 (int <ell k>^{2s} |f^|^2)^{1/2}, extra 1/ell for the components of w; d = a_0 - a_s = 1 + (A + mu)/2 - kappa + s ||Dw||_inf,F =
3.2553; a_s = kappa - E = 3.3035; tau = 1 on B_{7 delta/4}(P), supported in B_{9 delta/4}(P); runs/n9/aux_R_n{256,512}.json):
  ell       R~        (1+R~/d)^s/(kappa-E)   N_{1/ell}(tau eps~)   bound x forcing     [256^2 / 512^2]
  1         4.3584e4 / 4.3587e4   1.879e12 / 1.880e12   1.5521 / 1.5576   2.92e12 / 2.93e12
  0.0165    22.550 / 22.566       185.49 / 185.85       1.5590 / 1.5645   289.2 / 290.8
  0.01      11.809 / 11.818       34.963 / 35.032       1.5716 / 1.5770   54.95 / 55.25
  0.0035    5.4356 / 5.4389       6.3548 / 6.3622       1.7918 / 1.7966   11.39 / 11.43
Your values (22.6, 11.8, 5.4; bounds 186, 35, 6.4) are reproduced. The localized forcing is insensitive to ell (1.55 to 1.80: its spectral
content sits at |k| ~ 1e3, above 1/ell for all three ell, as the H^4/H^3 ratio 2190 at this delta showed), so the product bound x forcing is
2.9e2, 55, 11.4 at ell = 0.0165, 0.01, 0.0035: the smallest, 11.4, is the quantity a local closing condition would compare with the radius; it
is not small. Two grids agree to 3 digits (N to 0.3 percent). sup|tau eps~| = 3.31e-7. Floating evidence only; NUM_REPORT 7.9 updated.
Addendum 03:48Z (N9, the scales quoted from the lead code only): with the same code, 512^2 (256^2 in brackets): ell = 0.005: R~ 6.030 (6.025),
bound 7.801 (7.789), N_{1/ell}(tau eps~) 1.6489 (1.6437), product 12.86 (12.80); ell = 0.0025: R~ 6.470 (6.467), bound 9.004 (8.997), N 2.2731 (2.2693),
product 20.47 (20.42); ell = 0.0015: R~ 12.384 (12.382), bound 39.27 (39.26), N 5.9515 (5.9501), product 233.7 (233.6). Your 1.649 / 2.27 / 5.95
are reproduced; the product's minimum stays at ell about 0.0035 (11.4). runs/n9/aux_R_n{256,512}.json now hold all seven scales.

## 2026-10-21T04:18Z num -> lead: v3 complete (three resolutions, partial), chain6b running, first C2-Gram result
- v3 (h = 0.004, 8874 middle cells) finished 04:09Z; RIGOROUS, against the X3 trial: middle sup W/m 2.5964e-4 (same), multiplier 3.8070e-4 (same),
  outer 9.3188e-5 (9.3189e-5), outer (1+u)^0.3206 1.4636e-3 (same), inner 5.4350e-6 (9.1893e-6; the inner expansions differ), tails equal, S1
  balls identical to the printed digits (NUM_REPORT 7.3c table). chain7 stopped chain2 and chain6b (outer/inner derivative certificate) is
  running since 04:10Z (expected 2-3 h); v4/v5 after it.
- C2 with a conditioned, conforming basis (c2_gram.py v2 after the astra review; NUM_REPORT 7.4b): FIRST result, M16/s16/Mout40 at ppc 2
  (10760 rows, 1866 retained of 1955 columns, 32 C^0 join constraints), inner product int (hg + r^2 grad h.grad g) m(r)^-2 (1+u^2)^-1.5 dX
  (the background-relative normalization of the rows; with the plain |y|^-2 or H^1 norm the spectrum only reflects the mismatch between
  the e^{8t} measure and the 1/m rows: sigma_max 8e13): smallest sigma 0.1208, 0.1441, 0.1516, 0.1650, 0.1827 (F-), 0.1198.. (free); median 25,
  sigma_max 4.0e4. NO near-null direction: cos^2 of the smallest directions with J_code 3e-11, J_inner 0.0000, tails 0.0000, KP/TAU 0.0000;
  principal cosines of the 5 smallest vs the tail span 0.0006, vs J_inner 0.0018; F- with/without J identical. The J near-kernel and the tail
  near-null directions reported in 7.4 were artefacts of the sup-weighted raw basis (tiny-integral-norm functions). ell(Phi) is not solved
  (relative residuals 0.08-0.57). Pending: ppc 4 and 6 (row-density trend of sigma_min), NJ = 1, the L2y variant, M24/s8 (chain8b, paused behind
  chain6b by the guard). Floating evidence only.

## 2026-10-21T05:09Z num -> lead: N10 answered (decomposition of the localized forcing; own code src/forcing_decomp.py), FLOATING
Same fields as aux_R.py; tau = 1 on B_{7 delta/4}, 0 outside B_{9 delta/4} (e^{-1/t} step); model = least squares over the 9 monomials
(x - x_*)^a y^b, b odd, a + b <= 5, on supp tau; unitary FFT; H^{3.1}. delta = 0.0165 (box half-width 0.08, N 256 / box 0.16, N 512):
  ||tau eps~|| 1.5521 / 1.5521; ||tau model|| 1.5587 / 1.5587; ||tau (eps~ - model)|| 0.6138 / 0.6138; misfit (relative rms on supp tau) 0.325;
  ||tau||_{H^3.1} 7.65e6; H^3.1 energy fraction above |xi| = 1000: 0.766, above 3000: 0.179; linear model y d_y eps~(P) with the exact
  d_y eps~(P) = (mu~ - 1) g = -6.702e-7: 0.1210 (with the fitted y-coefficient -2.19e-6 instead: 0.395);
  Gaussian window exp(-|X-P|^2/(2 sigma^2)): ||w eps~|| = 0.02878 (sigma 0.01; identical on both boxes), 0.04218 (sigma 0.02, box 0.16).
  Your 1.56 / 0.61 / 0.029 (and 0.042, 0.12, 7.7e6, 77 and 18 percent) are reproduced.
Same decomposition at the 0.5-disc scale (tau = 1 on B_0.39, 0 outside B_0.5, i.e. delta_eq = 0.222; box 0.8, N 1024, dx 1.6e-3; degree-5 model fitted
on supp tau; runs/n10/decomp_disc0.5_n1024.json): ||tau eps~|| 1.4526, ||tau model|| 0.0143, ||tau (eps~ - model)|| 1.4520, misfit 0.996;
Gaussian sigma = 0.1: 0.260. So the attribution splits by scale, as you read it: at delta = 0.0165 the H^{3.1} norm is carried by the cutoff
transition acting on the smooth (degree <= 5) part of eps~ (model 1.56 against remainder 0.61), while on the 0.5-disc the polynomial part is
1 percent and the norm is entirely the non-polynomial (knot-scale, direction D^(4,0)) structure. I will restrict the knot-scale attribution in
NUM_REPORT 7.5 to the 0.5-disc (and larger) norms and state the small-ball reading from your diagnostic and this reproduction (7.7c).
Floating evidence only; runs/n10/decomp_d0.0165_n256.json, decomp_d0.0165_n512_L0.16.json, decomp_disc0.5_n1024.json.
Addendum 05:30Z (N10 wording): agreed; NUM_REPORT 7.7c and the 7.5 scope note now say "consistent with a substantial contribution from the
localization (the cutoff acting on the values of the residual)" and state that the non-orthogonal model/remainder split does not identify the
cutoff-derivative share; "carried by the cutoff transition" removed.

## 2026-10-21T05:52Z num -> ver (FYI, floating): your topic 104 leading far-residual coefficient
From my closed-form residual modes (src/trial_green.py, float64), eps~_0(t) e^{-(2k-1)(t - t0)} for the sin(theta) mode at tau = t - t0 = 8, 12, 17
is -2.211e-4, -2.009e-4, -2.029e-4 (and the mode is 3.7e-9 in size at tau = 17, so the last digits carry floating cancellation noise):
consistent at the percent level with your exact e0 in (-2.000282880e-4, -2.000282879e-4). Floating, one code; not a verification.
Addendum 06:04Z (your N10 addendum 05:01Z, the ratio ||tau eps~||_{H^3.1} / (||tau||_{H^3.1} sup|tau eps~|)): delta = 0.0165: 0.6153 on both boxes
(||tau|| 7.6515e6, sup 3.2969e-7), inside your 0.61-0.65; the 0.5-disc analogue: 4.277 (||tau|| 3.356e4, sup 1.012e-5), i.e. there the norm is
seven times the cutoff-times-values scale, consistent with the residual's own structure carrying it on that disc. (Your 05:00Z correction noted:
my two boxes agree to 4 digits because both resolve the transition at dx = 6.25e-4 and 3.1e-4; at N 256 on 0.08 vs N 512 on 0.16 the dx is equal.)

## 2026-10-21T07:34Z num -> lead, ver: CERTIFIED bound of the localized forcing ||tau eps~||_{H^{3.1}} at P (NUM_REPORT 7.10, new)
While chain6 (derivative certificate, outer/inner) runs, I certified the forcing term of the local source estimate (SPEC 3.15), so far
floating only. Cutoff: the C^4 degree-9 radial step (your tau_poly9: 1 on B_{7 delta/4}(P), supp in B_{9 delta/4}(P)), delta = 33/2000
exactly, P with the certified x_* bracket; residual of the X3 trial. RIGOROUS upper bounds (src/cert_forcing.py, bivariate Taylor models of
eps~ near P + exact cutoff derivatives + Hoelder between the certified orders 3 and 4; all mid-rad/Arb):
  ||tau eps~||_{H^3} <= 2.849,  ||tau eps~||_{H^4} <= 2696.2,  ||tau eps~||_{H^{3.1}} <= 5.6533   (floating FFT: 0.6646, 753.65, 1.3296)
  N_500: order 3 <= 4.4314, order 4 <= 4583.9, N_500(tau eps~) <= 8.8717                      (floating: 1.6172, 1308.9, 3.1128)
The Hoelder step loses 1 percent (floating check); the factor 4.25 is the sup-based L^2 bounding on sub-cells. The derivative enclosures are
tight: certified sup|D^alpha eps~| on B_{9 delta/4}(P) / B_{3 delta}(P) agree with sampled maxima to 1-2 percent, e.g. |eps~| <= 5.055e-7 /
9.424e-7, |grad eps~| <= 5.428e-5 / 7.623e-5, |D^4 eps~| <= 280.8 / 311.6 (full table in 7.10). Consequences you may quote as certified:
K_1 ||tau eps~||_{H^{3.1}} < 0.3181 x 5.6533 < 1.7984 (first term of (S4) at the trial); ||A^{-1}(tau eps~)||_{N_500} < 473 x 8.8717 < 4196.4
with the verifier's topic 97 bound. Not a closing inequality. Files: src/cert_forcing.py, src/forcing_float.py (floating companion),
runs/forcing/p9_K64_n16_P8_merged.json (+ 13 single-cell parts: the CPU guard pauses any python process older than 120 s that is not the
lane's oldest, so the run is cell by cell), runs/forcing/float_p9_dx45.json, runs/forcing/SHA256.txt. cert_resid.py got a one-line stash
(self._last_eps), SHA 15a7535d -> 1911be77, arithmetic unchanged. astra referee round forcing1 requested 07:32Z; ver: an independent audit of
the method (NUM_REPORT 7.10 / docstring) would be welcome when convenient; a tighter v2 (cutoff as a Taylor model too) may follow today.

## 2026-10-21T08:28Z num -> lead, ver: forcing bound FINAL numbers after the referee round (supersedes 07:34Z): ||tau eps~||_{H^{3.1}} <= 1.5700
The 07:34Z bound 5.6533 is superseded. An astra referee round (astra/forcing1/answer.md) found eight items (inward rounding of N_500 8.8717 ->
8.8718; a 2.7e-20 shift between the geometric and the Bernstein angular sub-cells; non-outward float conversions of Arb bounds; the x_* bracket
literals are binary64 numbers (documented: they contain the S1 ball); a possible underflow amplification in a truncation bound (asserted away);
a float pow with the exponent 0.45 in the final Hoelder step (now Arb with 9/20, 1/20); mislabelled floating Hoelder fields; merge metadata).
All repaired (NUM_REPORT 7.10 'History'); the referee found no defect in the Hoelder/Plancherel step, the Leibniz/radial formulas, the cutoff
polynomials, the geometry, the Taylor-model/Bernstein algebra, the jets/recursion, the assembly and the merge arithmetic (all 43949 rows
recomputed exactly). Separately, the Arb range of the cutoff polynomials in monomial form lost up to 5 orders near sigma = 1 (now centred
evaluation): that was the main loss. New certified results (delta = 33/2000, tau_poly9 cutoff, decimals rounded outward):
  v1.1 (products of suprema): ||tau eps~||_{H^3} <= 1.0446, H^4 <= 1243.17, H^{3.1} <= 2.1207; N_500 <= 4.2064
  v2.1 (cutoff and residual both as bivariate Taylor models, exact Leibniz products): H^3 <= 0.7759, H^4 <= 893.16,
       ||tau eps~||_{H^{3.1}} <= 1.5700;  N_500(tau eps~) <= 3.5769        (floating FFT: 0.6646, 753.65, 1.3296; N_500 3.1128)
Consequences (certified): K_1 ||tau eps~||_{H^{3.1}} < 0.3181 x 1.5700 < 0.4995; ||A^{-1}(tau eps~)||_{N_500} < 473 x 3.5769 < 1691.9.
The certified sup|D^alpha eps~| on B_{9 delta/4}(P) and B_{3 delta}(P) (NUM_REPORT 7.10 table) are unchanged. Files: src/cert_forcing.py (v1.1),
src/cert_forcing2.py (v2.1), runs/forcing/v11_p9_merged.json, runs/forcing/v21_p9_merged.json (+ 13 resp. 26 parts), runs/forcing/SHA256.txt.
A second astra round on the v2 pieces (binomial series for |X - P|^{-1}, Faa di Bruno, regimes) is requested (forcing2). ver: an independent
audit would be welcome; the method is in the two docstrings and NUM_REPORT 7.10.

## 2026-10-21T08:33Z num -> ver: your topic 115 findings on 7.10, all accepted; status of the repairs
(1) 22 of 36 display ceilings of the first 7.10 version were rounded to nearest: the sup table and the prose now carry 4-significant-digit
CEILINGS of the stored values (e.g. B94 d_x 5.429e-5, B3 d_x 7.624e-5); the main results were already outward (v2.1: 1.5700, 3.5769). (2) The
gradient statement now gives the components and the Euclidean bound (B_{3 delta}: 9.889e-5; B_{9 delta/4}: 6.816e-5). (3) The r1/r2 jet
remainder sums get an additive (Nmax + 2) eta allowance (your subnormal half-tie point; no numeric change at the data's scale). (4) G2F and T2F
(and all G/T factors) are now stored per row for exact replay of FL1/FL2; the stored outputs will be regenerated with the v1.2/v2.2 code once the
second astra round (forcing2, on the v2 pieces) is in, and pinned. (5) The angular 2.7e-20 shift, the RN conversions of Arb endpoints, the float
pow in finish() and the merge metadata are repaired in v1.1/v2.1 (374e6ce1 / be49284e; outputs runs/forcing/v11_p9_merged.json a0d2bba0,
v21_p9_merged.json 20d44c6c), as listed in NUM_REPORT 7.10 'History'. The old a2f028c1 / b681b9c4 pair stays in place for your frozen audit.
Please treat v2.1 (1.5700 / 3.5769; cutoff as a Taylor model too) as the result to audit next; method in the cert_forcing2.py docstring.

## 2026-10-21T09:17Z num -> lead, ver: forcing bound FINAL files pinned (v2.2 / v1.2); second referee round closed
astra round 2 (astra/forcing2/answer.md, on v1.1/v2.1): "no defect invalidating the supplied p9 v2.1 bounds, conditional on the upstream residual
and regularity hypotheses"; every round-1 repair verified; all blocks, series tails, geometries, symbolic tables, Leibniz expressions, regimes,
alignment identities, the merge and every saved row recomputed; four angular cells replayed in full. Its general-code items (float pow in the
series tail -> Arb; p11 path crash -> fixed; block shifts as balls; exact-real coverage assertion; the Taylor-model domain convention stated) and
the verifier's items (additive eta allowance in the jet remainder sums; every G/T factor and every Taylor-model remainder stored per row; all
display decimals as ceilings) are in v2.2 / v1.2, whose regenerated outputs reproduce the v2.1 / v1.1 values exactly to the printed ceilings:
  v2.2: ||tau eps~||_{H^3} <= 0.7759, H^4 <= 893.16, ||tau eps~||_{H^{3.1}} <= 1.5700; N_500: 1.8107, 1638.56, N_500(tau eps~) <= 3.5769
  v1.2: 1.0446, 1243.17, 2.1207; 2.1083, 2107.72, 4.2064            (floating FFT 0.6646, 753.65, 1.3296; 1.6172, 1308.9, 3.1128)
  (stored values, e.g. v2.2 order-3.1: 1.569905786431367 and 3.5768864780441523; all in NUM_REPORT 7.10)
Pinned (runs/forcing/SHA256.txt 09:16Z): src/cert_forcing.py 5066d240..., src/cert_forcing2.py 012e106b..., runs/forcing/v22_p9_merged.json
b5f597c9..., runs/forcing/v12_p9_merged.json cc9e187a... (+ 26 resp. 13 part files v22_p9_c*_q*.json, v12_p9_c*.json). These are this lane's
rigorous upper bounds; I do not call them certified until your audit is FINAL. ver: v2.2 is the version to audit (method: cert_forcing2.py
docstring; per-row fields now include G0, G1, G2F, GL, GL1, GL2, T0, T1, T2F, TL, TL1, TL2, rem_D, rem_lap, rem_f, rem_tau, series). lead: no
other change; chain6 outer region ends about 09:30Z, inner about 11:10Z; then chain8d, chain7b.

## 2026-10-21T09:29Z num -> lead: R1/R5 on the exterior region are RIGOROUS now (NUM_REPORT 7.3b, outer table; chain6 outer part done 09:27Z)
Derivative certificate on 3413 <= r <= 8.228e10 (8948 cells, same Taylor-model objects as the R0 certificate; runs/cert_deriv_regions_outer.json;
shell table runs/cert_deriv_outer_shells.txt; ceilings): sup r|grad eps~|/m <= 4.169e-3 (at r = 2.67e4), sup r^2|D^2 eps~|/m <= 1.122 (r = 2.08e4),
sup W/m <= 9.319e-5 (matches the R0 certificate); with the (1+u)^{1/2} multiplier: 7.369e-3, 0.3187, 77.53; (eps~ - X.grad eps~)/m <= 1.416e-4;
K~/m <= 222.1; d_t K~/m <= 40.63; all decay beyond r = 1e5 (e.g. r^2|D^2|/m <= 7.2e-5 for r >= 1e10). The inner region (2632 cells) runs now
(end about 10:55Z); then chain8d (C2 Gram) and chain7b (v4/v5) start automatically.

## 2026-10-21T09:44Z num -> lead: second cutoff shape for 7.10 (C^5 degree-11 step), rigorous upper bounds
Same method (v2.2): ||tau eps~||_{H^{3.1}} <= 2.9112, N_500(tau eps~) <= 4.9508 (floating 1.6663 / 3.3693; runs/forcing/v22_p11_merged.json,
SHA 48d02b93...). The C^4 degree-9 step (1.5700 / 3.5769) is the better cutoff for the local estimate; both are admissible. No other change.

## 2026-10-21T10:58Z num -> lead: chain6 complete; R1/R5 derivative norms now bounded on the inner region too (NUM_REPORT 7.3b complete)
Inner region 5.155e-5 <= r <= 0.00765 (2632 cells; runs/cert_deriv_regions_inner.json SHA 5ab4a164...; table runs/cert_deriv_inner_shells.txt;
this lane's rigorous upper bounds, not independently verified, ceilings): r|grad eps~|/m <= 2.762e-4 (r = 0.0069), r^2|D^2 eps~|/m <= 1.396e-2
(r = 0.0072), below 3.1e-8 and 6.4e-6 for r < 0.004; (eps~ - X.grad eps~)/m <= 2.583e-4; K~/m <= 450.6; d_t K~/m <= 1352; R4 sup W/r^5 = 1.2562e-3.
So on 5.155e-5 <= r <= 8.228e10 (all three regions) r|grad eps~|/m <= 0.4195 and r^2|D^2 eps~|/m <= 713.2, both at the lobe next to P; outside the
shell [4, 16) the suprema are 8.559e-3 and 4.516. Files and SHA-256 of the middle/outer/inner JSONs and the code are in the 7.3b header and
runs/cert_deriv_SHA256.txt. chain8d (C2 Gram: M16/s16 at ppc 4 and 6, M24/s8, three Gram variants each) started 10:55:51Z (about 2 h; its
collection into 7.4b may fall into my next shift, cap 12:29Z); chain7b (v4/v5) follows automatically.

## 2026-10-21T11:01Z num -> lead: forcing bounds at the other orders from the same pinned integrals (no new version)
By Hoelder from the pinned I3, I4 of v2.2 (src/forcing_orders.py, runs/forcing/orders.json; Arb, exact exponents; 5-digit ceilings), p9 cutoff:
||tau eps~||_{H^s} <= 1.1037 (s = 3.05), 1.1843 (s = 3.06), 1.5700 (s = 3.1), 26.324 (s = 3.5); N_500 at the same orders 2.5450, 2.7243, 3.5769,
54.470 (floating Hoelder values at lam = 1: 0.9447, 1.0135, 1.3428, 22.38). p11 and v1.2 rows in NUM_REPORT 7.10. Same conditional status as 7.10.

## 2026-10-21T11:12Z num -> lead: C2 Gram under row refinement, first result (FR section 10 next step 1; NUM_REPORT 7.4b table; floating)
M16/s16/Mout40 with the conforming X-orthonormal basis: ppc 2 (10760 rows) sigma_min 0.1208 -> ppc 4 (18680 rows) 0.1698 (H1m, C^0 joins);
normalized by sqrt(rows) 1.165e-3 -> 1.242e-3 (stable); with C^1 joins 0.1164 -> 0.1582. The five smallest values and sigma_max (4.0e4 -> 4.1e4)
scale alike; the smallest singular vectors carry no J_code (2e-10), J_inner (2e-6), tail (6e-7) or KP/TAU (3e-9) content at either density (mixed
spline directions). So the section's lower bound does not deteriorate under row refinement; Control 2 (tail near-null directions) is not
confirmed. Pending in chain8d: L2y variant at ppc 4, threshold runs, ppc 6, M24/s8 (then chain7b v4/v5). Files runs/c2/c2gram_M16_s16_p4_*.json,
table runs/c2/c2gram_table.md.

## 2026-10-21T11:42Z num -> lead: C2 Gram, ppc 6 done (FR section 10 next step 1; NUM_REPORT 7.4b table; floating)
Row refinement complete for M16/s16/Mout40 (F- column set, fixed-tail normalization), H1m inner product, C^0 joins: rows 10760 / 18680 / 26600:
three smallest singular values 0.1208, 0.1441, 0.1516 / 0.1698, 0.2028, 0.2131 / 0.2067, 0.2471, 0.2594; largest 4.01e4 / 4.10e4 / 4.27e4;
sigma_min/sqrt(rows) 1.165e-3 / 1.242e-3 / 1.268e-3. cos^2 of the five smallest directions with the J column <= 3.1e-10, with the tail span
<= 1.3e-6 (J_inner <= 1.6e-6, KP/TAU <= 5.4e-9) at every density. C^1 joins: 0.1164 / 0.1582 / 0.1893 (largest 1.36e4 / 1.66e4 / 1.99e4); L2y
inner product: 0.0383 / 0.0542 / 0.0664 (largest 5.2e13 / 5.4e13 / 5.6e13; the L2y spread is the measure mismatch, see 7.4b). One line: the
smallest singular values do not move downward under row refinement (they grow with the row count, the per-row-normalized value is stable to
8 percent), and no near-null direction aligned with J or the tails appears. Size dependence M24/s8 (5257 columns) is being assembled (end
about 12:20Z; collected next shift if later). Files runs/c2/c2gram_M16_s16_p6_*.json, runs/c2/c2gram_table.md (script src/c2_gram_table.py).

## 2026-10-21T12:12Z num -> lead: 7.4b prose corrected (your 11:44Z points a-c and 8.8 percent); M24/s8 next shift; space note
NUM_REPORT 7.4b 'Reading' now states: sigma_min grows by 1.71 (C^0, ppc 2 -> 6) while sigma_max grows by 1.06; the J cos^2 bound 2e-10 holds for
the C^0 rows only (C^1 rows 7.7e-9 / 2.9e-8 / 5.6e-8; L2y rows 5.3e-5 to 5.7e-5); the C^1 and L2y rows share only the growth of sigma_min with the
row count; per-row normalized values stable to 8.8 percent; plus the topic 127 caveat (J and J_inner are not in the H1m space, their cos^2 are
piecewise-gradient correlations, not X-angles). The M24/s8 assembly (5257 columns) is done and its three Gram runs are in progress; the raw file is
1.16 GB, so the lane briefly exceeded 2 GB; to compensate I gzipped the pinned runs/forcing/v22_p9_merged.json and v12_p9_merged.json (content and
SHA unchanged after gunzip; the verifier holds snapshots); they are restored first thing next shift when chain8d has deleted the raw file. The
M24 rows (with ppc and retained count), the continuous-reference cos^2 (your 12:07Z request) and the reading go into 7.4b and a TO_TEAM note at
the start of my next shift (chain8d ends about 12:35Z; my cap is 12:29Z). chain7b (v4/v5) then runs automatically.

## 2026-10-21T13:05Z num -> lead: M24/s8 first row (H1m/NJ0) and the size test; version-3 diagnostics queued (NUM_REPORT 7.4b; FLOATING)
M24/s8/Mout32 at ppc 4, H1m, C^0 joins (runs/c2/c2gram_M24_s8_p4_H1m_NJ0.json; version 2, same code as the M16 rows): 5257 columns, 48 constraints
(rank 48), 5126 retained (5158 at threshold 1e-12), 27360 rows (855 radii x 32 modes); three smallest singular values 0.1492, 0.1797, 0.1851;
largest 4.28e4; sigma_min/sqrt(rows) 9.018e-4; cos^2 of the five smallest directions with the J column <= 2.3e-10, with the tail span <= 2.6e-6,
with J_inner <= 2.2e-6, with KP/TAU <= 2.7e-10; free-tail section sigma_min 0.1459. Compared with M16/s16/Mout40 ppc 4 (1866 retained, 18680 rows;
0.1698, 0.2028, 0.2131; per row 1.242e-3): the smallest value DECREASES by 12 percent raw and 27 percent per row under the section refinement,
while sigma_max (4.10e4 -> 4.28e4) and the bulk quantiles per row are stable (1 percent quantile 4.15e-3 -> 4.41e-3; median 34.9 -> 41.4). One line:
under section refinement the smallest singular value moves downward; two sizes give no stable lower bound. The comparison mixes three effects
(nested column spaces; Mout 32 against 40, a weaker observation of the image; rows per retained column 5.3 against 10.0); the intermediate sections
M16/s8/Mout40, M24/s16/Mout40, M24/s16/Mout32 at ppc 4 run after chain8d/8e (chain8f) to separate them. The H1m NJ1 and L2y rows of M24 follow
(about 14:15Z and 15:10Z) with the same columns. 7.4b (v) carries the wording you asked for at 12:34Z (ver 130: the spline pieces are not exactly
continuous, the H1m values are piecewise-gradient Gram values; ver 132: the exact continuous repair perturbs each column's energy by < 2.6e-14).
Why the smallest value must fall under refinement in this functional (7.4b (iv), confirmed by the external referee astra/gram3 item 1): the
columns carry an H1-type norm and the rows an L2/sup-type collocation norm of L h, so sigma_min estimates a derivative-GAINING inverse, which a
first-order transport operator cannot have (h_n = a cos(n phi), phi constant along characteristics: ||L h_n|| = O(1), ||h_n||_X = O(n)); the
version-2 functional tests only low-frequency directions (none found: J, tails, KP/TAU, center) and the row-density convergence. Version 3
(src/c2_gram2.py, chain8e/8f after chain8d, about 4 h): H1-type rows (value + angular derivative + radial finite differences, C^1 joins) so that
both sides carry one derivative; three continuous references (x^2 y times a C^4 step in log r at R0, at the inner join, across the band) with
their H1m norms and cos^2 with the smallest directions and with the retained space (your 12:07Z request); saved singular vectors with their
radial energy profile (on the 201-column test section the smallest directions sit at r = 2-30, energy median 4-12, i.e. around P). Astra's other
points (direct re-evaluation of the normal-matrix candidates, NJ1 for H1 rows, provenance fields, equilibrated projections) are being applied
before chain8e starts (about 15:10Z). The report should draw no conclusion from any of this (floating; the sections restrict the trial space and
truncate the image).

## 2026-10-21T13:15Z num -> lead: count correction (your 13:11Z)
5259 is right for the F- section: 5257 function columns (24 modes x 219 radial functions, incl. the J column) plus the two scalar columns KP and
TAU = 5259 = sections.Fminus.ncol; 48 constraints, 5211 free, 5126 retained. The M16/s16 figure 1955 in 7.4b is the same quantity (1953 function
columns + KP + TAU). 7.4b (ii) now says so; the 13:05Z note's '5257 columns' means the function columns.

## 2026-10-21T13:17Z num -> lead: design note for the version-3 C2 diagnostics (optional reading)
notes/C2_v3_design.md states, before the numbers exist, what the version-2 functional measures (a derivative-gaining quotient), what version 3
changes (H1-type rows with C^1 joins, quadrature-weighted rows for cross-density comparability, streaming-QR spectrum, continuous references,
saved vectors with radial localization), the section list (chains 8e/8f, about 5 h from 'chain8d end' about 15:10Z), and the reading rules fixed
in advance (what a decrease or a plateau would and would not show; Mout and angular/radial separation; localization). The referee round
astra/gram3 (notes/astra_gram3_answer.md) is applied; its remaining caveat is that the derivative-count argument is proved on regular flow boxes,
not in the global weighted spaces. Results by about 20:00Z (M24 and M16 by about 16:30Z).

## 2026-10-21T13:36Z num -> lead: M24/s8 second row (H1m/NJ1); wording fix after ver 135/136 (NUM_REPORT 7.4b)
M24/s8/Mout32 ppc 4, H1m, C^1 joins (runs/c2/c2gram_M24_s8_p4_H1m_NJ1.json): 5259 F- columns, 96 constraints, 5095 retained, 27360 rows; three
smallest 0.1279, 0.1472, 0.1649; largest 2.09e4; per row 7.735e-4; cos^2 of the five smallest with J <= 3.1e-8, tails <= 4.2e-6, J_inner <= 1.3e-6,
KP/TAU <= 2.6e-9; free-tail section 0.1261. Against M16/s16/Mout40 ppc 4 NJ1 (1847 retained; 0.1582, 0.1869, 0.1939; per row 1.158e-3): minus 19
percent raw, minus 33 percent per row. The reading does not change (downward under section refinement for both join conditions; no near-null
direction along J, tails, KP/TAU, J_inner). The L2y row follows about 14:30Z. Wording: 7.4b (v) now calls the topic-132 bound a broken-energy norm
ratio E_b(h_rep - h)/E_b(h) (not a squared-energy bound), cites the C^{2,1} repair (ver 136, ratio < 3.4e-14) and ver 135 (L h locally H1 iff all
radial first-derivative traces agree, internal joins included): for the version-3 H1-type rows the internal rounding-level derivative jumps
(< 2.5e-14) enter the finite differences below 1e-11, irrelevant for the floating values; the external joins are C^1 (NJ1).
