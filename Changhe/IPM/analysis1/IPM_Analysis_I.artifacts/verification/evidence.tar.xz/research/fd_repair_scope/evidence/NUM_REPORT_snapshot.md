# NUM_REPORT (ipmA-num): validated numerics for the a posteriori analysis of the IPM profile X3

Version 3.9, 2026-10-21T09:48Z (shift 4; T0 = 2026-10-20T12:44:25Z). Sections 2 to 6 are floating point (estimates,
labelled as such). Section 7 states what is enclosed rigorously and by which method. Paths are relative to the lane numerics.

## 1. Summary
- The published candidate X3 (c6g_shape.npz, md5 15f8095f7e79dbfa0c50d75e5fe8997a, verified) is reconstructed exactly
  from its coefficients and generator formula (src/x3.py; agreement 1.3e-13 with the published independent generator).
- The published residual tables are reproduced (i) by rerunning the published evaluator (bit-identical JSON at
  11250 x 384) and (ii) by an evaluator written here from scratch (own generator, own modal Green inverse): 16875 x 512
  and 22500 x 768 agree with the published maxima to 1-3 percent (section 3).
- An explicit modal re-representation of X3 was built (section 4): rho~ = x^2 y sum_{m<260} a_m(r) cos(2m theta) with
  a_m exponential-polynomial splines in t = log r. Its canonical velocity and psi_xy(0) are closed-form (section 5),
  the identity c_l = (1 + psi_xy(0))/3 holds exactly by construction (c_l = 1/k, k the stored exponent), the density
  is within 1e-9 of X3 and its sampled residual equals X3's region by region (section 6). This is the object of the
  rigorous statements.
- RIGOROUS (section 7): the scalars S1 (c~, c_l, A, x_*, mu~ - 1, g, g', A~, and w'(P) with the divergence identity to 4.5e-12),
  independently confirmed by the verifier; the residual bound R0 on the whole plane in three weighted forms (section 7.3, post-fix code and
  data: middle region sup W/m <= 2.5964e-4 at the lobe next to P, multiplier form 3.8070e-4; outer region 9.3189e-5 (multiplier 7.3680e-3 at
  r = 7.7e4, the far-field Theta_1 mismatch of X3); inner region 9.1893e-6; tails 1.06e-9 and 2.14e-6; R2 total 6.29e-4), independently
  confirmed by the verifier on the middle region (W/m < 2.916e-4) and the exterior/inner regions; the derivative norms R1/R3/R5 on the middle
  region (section 7.3b: r|grad eps~|/m <= 0.421, r^2|d^2 eps~|/m <= 719 at the lobe; order-5 Wiener sums on the P-disc up to 1.4e12); the
  the outer and inner derivative norms (shift 4, section 7.3b: on 3413 <= r <= 8.2e10, r|grad eps~|/m <= 4.169e-3 and r^2|D^2 eps~|/m <= 1.122; on
  5.2e-5 <= r <= 0.00765, 2.762e-4 and 1.396e-2; so R1 is bounded on the whole plane except the two tails, with the global suprema 0.4195 and 713.2 at
  the lobe next to P; this lane's rigorous bounds, not independently verified);
  N1' flow certificate for the lead's transport argument over the WHOLE quadrant (section 7.6: V_2/y >= 0.98845, the axis signs of V_1 with
  the single zero x_*, X.V/r^2 >= 3.4957 for r >= 20, T_0 <= 1.2780 and V_1 <= -12.834 on the box B_1, T_0 <= -0.2399 off it; implied
  transport-inverse bound 6.31 at kappa = 0.2, verifier-confirmed instances). Three resolutions (section 7.3c: v3 S1 and middle done, identical
  to the X3 trial's to the printed digits; v3 regions/tails and v4/v5 running) and the outer/inner derivative norms (chain6b, queued) are in
  progress in shift 3; the centre-regular trial N7 (section 7.5, data/trial_n7.npz) has its S1 and middle certificate (identical to the trial's).
- FLOATING (evidence only; sections 7.4, 7.5): near P the residual is small in value (1.1e-5 on the 0.5-disc) but of order 1 in H^3
  (H^3.06 = 1.21), because of knot-scale radial structure inherited from X3 (direction D^(4,0)); every mode carries knot-scale content
  that the operator sees at the 1e-3 .. 1e-1 level when removed (projection to 2 x .. 10 x coarser knots), and coarse-space
  Gauss-Newton re-solves do not recover the residual. The two external referee reports (astra/jets1, astra/smooth1) confirmed the
  derivative-jet formulas, the norm normalizations and the operator identity, and rejected the inference that this excludes a smooth
  exact solution (only restricted spaces were tested); the fine-knot refits (runs/pdisc/chainR.sh, chainQ) lowered the sup residual near P by
  13 percent and raised the H^3 content (7.5b), and the lead closed the band-restricted branch. Finite sections of L (C2, 7.4) with the
  sup-weighted raw basis are dominated by basis conditioning and the J near-kernel; sections with an X-Gram-orthonormalized basis (7.4b) replace
  that reading (row-density and size refinement in chain8d).
- RIGOROUS (shift 3, section 7.7, lead's N8 for the local source estimate SPEC 3.15): on B_{3 delta}(P) the Frobenius suprema of D^j V
  (j <= 4) and D^j rho~ (j <= 5) are enclosed by Taylor models + Arb angular enclosures + interval polar-to-Cartesian recursion: at
  delta = 0.0165, M_V = sup|D^2 V| <= 0.28728, M_rho = sup|D^2 rho~| <= 0.45336, C_V = 41.7 M_V + 3 M_rho <= 13.34 against the threshold 102.24
  (so K_1 = 1/(kappa - E) <= 0.3171 if E <= C_V delta); at delta = 0.05, C_V <= 18.16 against 33.74, and the condition is certified up to
  delta = 0.07 (21.23 against 24.10); delta >= 0.1 fails (in floating point from 0.08 on). The sampled values are within 3 percent of the
  second-order bounds. FLOATING (7.7c): the cut-off residual norm ||tau eps~||_{H^{3.1}} on the same balls is 1.56, 1.07,
  0.81, 1.37 (grid-converged), dominated by cutoff-scale content (H^4/H^3 = 35/delta): a smaller ball does not give a small local forcing norm.
- RIGOROUS (shift 3, section 7.3c): the half-knot-spacing variant v3 reproduces the X3 trial's certified scalars to the printed digits and
  its middle/outer residual certificate to four digits (sup W/m 2.5964e-4, multiplier 3.8070e-4, outer 9.3188e-5), so the certified residual
  level is X3's, not a fit artefact; v4/v5 follow. FLOATING (section 7.4b, shifts 3-5): in a conforming column basis orthonormalized in the
  background-relative H^1 inner product, the M16/s16 finite sections of L have smallest singular value 0.1208 / 0.1698 / 0.2067 at 10760 / 18680 /
  26600 rows (per row 1.165e-3 / 1.242e-3 / 1.268e-3, stable: converged in the row density) and NO near-null direction along J, J_inner, the tails
  or KP/TAU (cos^2 below 3e-6; the earlier J near-kernel of 7.4 was an artefact of the sup-weighted raw basis). Under SECTION refinement at the
  same collocation density (M24/s8/Mout32, 5126 retained, 27360 rows) the smallest value falls to 0.1492 (per row 9.018e-4, minus 27 percent) while
  the bulk of the spectrum is stable per row; a decrease is expected for this functional, which pairs an H1-type column norm with an L2-type image
  norm and so measures a derivative-gaining inverse that a transport operator cannot have (external referee astra/gram3). The version-3
  diagnostics (H1-type image rows with C^1 joins, continuous reference functions, saved singular vectors and their radial localization; chains
  8e/8f) are running; no conclusion about L is drawn from any of these floating sections (lead 12:34Z). FLOATING (7.8, 7.9): X3 lies within about 1.6e-8 of the trial in the four source jets; the auxiliary source
  inverse constants R = 4.36e4 (E = 0.0705), the dilated R~(ell) and the localized forcing N_{1/ell}(tau eps~) reproduce the lead's values,
  with the product inverse bound x forcing at best 11.4 (ell = 0.0035).
- RIGOROUS (shift 4, section 7.10): the localized forcing norm of the lead's local source estimate is certified: ||tau eps~||_{H^{3.1}} <= 1.5700
  and N_500(tau eps~) <= 3.5769 at delta = 33/2000 for the C^4 degree-9 radial cutoff (floating 1.3296 and 3.1128, so the certified bound is within
  18 percent), by Hoelder interpolation between certified order-3 and order-4 bounds built from bivariate Taylor models of the residual AND of the
  cutoff near P (one external referee round, eight items repaired); with the verifier's K_1 < 0.3181 the first term of the local estimate at the
  trial is < 0.4995 (certified). Certified C^4 bounds of eps~ on B_{3 delta}(P): |eps~| <= 9.425e-7, |grad eps~| <= 9.889e-5 (components 7.624e-5,
  6.299e-5), |d_x^4 eps~| <= 311.7 (every quoted certified decimal is an outward ceiling of the stored value).
- Shift 3 corrections: three more inward roundings in the N1' statement fixed (inner V_2/y >= 21.30140, outer tail V_2/y >= 5.575361, x_* radius
  3.0e-13); every other quoted flow decimal re-checked outward against the raw aggregates (WORKLOG 00:45Z).
- Nothing in this lane bears on the existence of an exact profile beyond the certified residual, derivative, flow and coefficient data of rho~.

## 2. Provenance and formula of X3
File: PDE_exploring/Changhe/IPM/case1/IPM_Setting_I.artifacts/a_coefficients/c6g_shape.npz,
md5 15f8095f7e79dbfa0c50d75e5fe8997a (control F3: c6gF_shape.npz, 0398af3f08a2a4f75e42c846edbaa375); both equal the
values in PROMPT.md section 2. Generator: a_generator/stationary.py with b_fit/solver.py; independent generator
d_evaluator/code/gen_shape.py. Stored scalars: k = 0.17936053129375418, c_l = 1/k = 5.575362610641546,
L = 7.651424601381517, c = 15.726087831924637, origin_radius 0.02 (in units of L), 201 x 375 spline coefficients,
6 Chebyshev coefficients, degree-7 clamped B-splines on 384 stored knots (the stored knots differ from the formula
linspace^1.3 by up to 0.25; 368 interior knots at radii 0.3895 to 3413 = 446.1 L).
Formula (u = r/L): q = 1 - (1+u^2)^(-(1-k)/2), chi = u^2/(u^2 + 0.02^2), s = u^2/(1+u^2), p3 = 6 + 2k/(2-k) = 6.19703,
  H = (k-3)/2 log(1+u^2) + sum_{m<=200} chi^{max(m-1,0)} b_m(q) cos(2m theta) + s^{p3/2} T(2q-1) |cos theta|^{p3-2} sin^2 theta,
  rho_bar = x^2 y e^H;  velocity by the canonical modal Green inverse; c_l fixed at the stored value.
Checked facts: p3 = 6.197030257 (prompt 6.19703); a(0) = e^{H(0)} = 1 to 1e-14 (b_m(0) = 0 because the first B-spline is
omitted); the canonical inverse of rho_bar gives c = 15.72608777 to 15.72608782 (own evaluator / published evaluator),
so (1 + c)/3 = 5.5753625910 to 5.5753626074 against the stored 5.5753626106 (defect 3.2e-9 to 2.0e-8 depending on the
inverse's radial resolution; the published value is 3.2e-9).

## 3. Reproduction of the published residual tables (floating point, sampled maxima)
Published evaluator rerun (runs/pubeval, 11250 x 384, 97 s): all 1591 numeric leaves of the reference JSON reproduced
(only timings differ). Own evaluator (src/x3.py + src/inverse.py + src/x3_resid.py; log-radial grid 1e-4 L to 1e6 L,
6-point Lagrange radial quadrature with exact exponential moments, power-law tail fit; c_l stored; both axis columns
set to their exact zero residual):
| region | N_f max 16875x512 | N_f 22500x768 | N_v max 16875 / 22500 | abs max 16875 / 22500 | published |
|---|---|---|---|---|---|
| r <= 0.1 | 2.6e-10 | 2.6e-10 | 5.6e-10 / 5.7e-10 | 3.8e-12 / 3.8e-12 | abs 1.7e-13 (axis-floor excluded there) |
| 0.1 <= r <= 2 | 2.3e-8 | 2.6e-8 | 4.5e-8 / 5.1e-8 | 1.05e-7 / 1.07e-7 | abs 8.9e-8 |
| 2 <= r <= 10 | 6.80e-7 | 7.16e-7 | 1.90e-7 / 2.01e-7 | 6.96e-5 / 5.61e-5 | N_f 6.84e-7 / 7.16e-7, abs 6.03e-5 / 5.82e-5 |
| X-P < 0.5 | 6.80e-7 | 7.16e-7 | 1.90e-7 / 2.01e-7 | 1.045e-5 / 1.12e-5 | N_f 6.84e-7, abs 1.05e-5 |
| 10 <= r <= 100 | 8.9e-8 (cut 8.2e-8) | 8.9e-8 | 7.1e-8 / 6.8e-8 | 1.98e-5 / 2.02e-5 | abs 1.99e-5 |
| 100 <= r <= 1000 | 1.59e-8 | 1.59e-8 | 6.5e-8 / 6.5e-8 | 6.26e-6 / 6.28e-6 | abs 6.03e-6 |
| 1000 <= r <= 1000 L | 1.36e-8 | 1.37e-8 | 2.21e-7 / 2.19e-7 | 3.09e-5 / 3.15e-5 | N_v 2.15e-7 / 2.18e-7 |
| r > 1000 L | 1.31e-7 | 1.32e-7 | 1.091e-6 / 1.095e-6 | 1.881e-4 / 1.893e-4 | N_v 1.09e-6 to 1.11e-6, abs 1.897e-4 |
Scalars: x_* = 8.600063801 (published 8.600063804), h(P) - 1 = 3.4e-8 / -1.6e-8 (published 3.1e-8 / -1.8e-8),
d_x V_1(P) - (2c_l - 1) = 3e-8 / -4e-9. Own inverse tests: psi = xy e^{-r^2} (max velocity error 4e-14, c error 5e-9 at
4000 radii), psi = xy (1+r^2)^{(k-1)/2} (relative velocity error 1e-11 at r = 0.1 to 1.6e-7 at r = 1e5, c error 2e-9).
These are sampled maxima on between-node grids, not bounds.

## 4. The explicit modal trial rho~ (data/trial_v2_h0.008.npz; src/modal_fit.py)
Definition. rho~(r, theta) = x^2 y sum_{m=0}^{M-1} a_m(r) cos(2 m theta), M = 260, with t = log r and
  r < rmin = 1e-3 L:  a_m = delta_{m0} + sum_{j=1}^{7} D_mj e^{2j (t - tmin)} + e^{bi (t - tmin)} sum_{i=0}^{6} Ei_mi (t - tmin)^i,  bi = 50;
  rmin <= r <= R0 = 446.1 L (X3's last knot): degree-7 B-spline in t on 1565 basis functions (knots: X3's knots mapped
     to t, intervals longer than 0.008 subdivided, uniform spacing 0.02 below X3's first knot);
  r > R0: a_m = sum_q A_mq e^{alpha_q (t - t0)} + e^{-bo (t - t0)} sum_{i=0}^{6} Eo_mi (t - t0)^i,  bo = 125.6,
     alpha_q = (k - 3) - j (1 - k) - 2 l for (j, l) in {(0..5, 0), (0..2, 1), (0, 2)} (X3's own far-field structure
     u^{k-3} (1 + nu + nu^2 + ...)(1 + u^-2 + ...), nu = u^{-(1-k)}).
Center: a_0(0) = 1 exactly and a_m(0) = 0 for m >= 1, so rho~ = x^2 y (1 + O(r^2)) with a continuous (not smooth:
the core polynomial terms r^{2j} cos(2m theta) with m > j are not C^infinity at 0, which is enough for P_2).
Joins: C^6 at rmin and R0 (the local corrections absorb the jet mismatch; without them the C^6 join to slowly decaying
power laws distorts the fit by 3e-7). Normalization: c[rho~] = int_0^oo r (a_0/4 + a_1/8 - a_2/8 - a_3/8) dr = 3/k - 1
(this is the published identity c = int rho_1 r^-2 dr written in the cosine modes; verified numerically to 1e-8).
Fit: least squares to the cosine modes of e^H of X3 on 80000 log-spaced radii (4096 angles), relative weighting by the
base factor (1+u^2)^{(k-3)/2}, join and normalization constraints exact (nullspace method, column scaling).
Quality (1500 random radii, direct X3 formula): relative error of a_m 5.1e-10 (values) and 1.3e-9 (t-derivatives)
in the middle region, 1.4e-13 inner, 8.5e-12 outer; dropped modes m >= 260 at most 1.9e-11; sum over modes of the
error 1.3e-9 (values), 8.6e-9 (derivatives). Joins hold to 6e-15; normalization to 1e-14. The density rho~ is within
1e-9 relative of rho_bar(X3) at 1638 radii x 2049 angles. Exactness convention for the certificate: the stored S, D and
A (except A_00) are the exact definition; Ei, Eo and A_00 are defined by the join and normalization equations and will be
recomputed in ball arithmetic (changes of order 1e-14).

## 5. Closed-form canonical inverse of rho~ (src/expoly.py, src/trial_green.py; float64 here; the Arb version is the certificate of section 7)
Every a_m is a finite sum of e^{alpha tau} tau^j on each radial cell, hence so are the sine modes R_j (coefficient of
sin((2j+1) theta) of rho~ = e^{3t} sum_j R_j), the modes f_n of d_x rho~ (sin(2n theta), n <= 261) and the Green
integrals A_n = r^{-2n} int_0^r s^{2n+1} f_n ds, B_n = r^{2n} int_r^oo s^{1-2n} f_n ds, psi_n = (A_n + B_n)/(4n),
psi_n' = (B_n - A_n)/(2r), c = (1/2) int_0^oo f_1/s ds. Convergence conditions at 0 and infinity (exponent > -2n-2,
< 2n-2) hold with margin (f_n ~ s^3 at 0, s^{k-1} at infinity). Cell recurrences use exact exponential moments; for
|lam| h < 1.5 the moments are evaluated by 32-node Gauss-Legendre to avoid the catastrophic cancellation of the closed
primitive (Arb at 200+ bits will use the closed form). Validation against the independent grid inverse (src/inverse.py)
applied to the same f_n: relative error of all psi_n, psi_n' at r = 0.003 to 8.6: 1.6e-11 to 8e-11; 2.5e-10 at r = 50,
1e-8 at 3000, 7e-8 at 3e4 (the grid's tail-fit error); c: 15.726087831925 (closed form) against 15.726087783 (grid).
Normalization identity of the trial: 3 c_l - 1 - c = -6.8e-14 with c_l = 1/k. The elliptic equation holds exactly
(Lap psi~ = -d_x rho~ mode by mode); there is no elliptic residual to enclose.

## 6. Residual of rho~ (floating point, runs/trial_v2_resid.json; src/trial_resid.py)
eps~ = (c_l X + U~).grad rho~ - rho~ = sum_{N<=521} eps_N(r) sin((2N+1) theta) at 1638 radii; sup over 2049 angles and
the Wiener norm W(r) = sum_N |eps_N(r)|; N_v as in the prompt with the axis columns excluded:
| region | sup eps (sampled) | W max | W/sup | N_v max | X3 published |
|---|---|---|---|---|---|
| r <= 0.1 | 9.0e-14 | 1.9e-13 | 3.1 | 4.8e-11 | abs 1.7e-13 |
| 0.1-2 | 8.90e-8 | 2.02e-7 | 3.5 | 5.5e-8 | abs 8.92e-8 |
| 2-10 | 5.39e-5 (r = 8.79) | 1.05e-4 | 4.5 | 1.99e-7 | abs 6.03e-5 / 5.82e-5, N_v 1.92e-7 / 2.01e-7 |
| 10-100 | 1.89e-5 | 3.68e-5 | 4.4 | 7.1e-8 | abs 1.99e-5 |
| 100-1000 | 6.29e-6 | 1.29e-5 | 3.0 | 6.6e-8 | abs 6.03e-6 |
| 1000-1000 L | 3.01e-5 | 5.37e-5 | 2.8 | 2.10e-7 | N_v 2.15e-7 |
| > 1000 L | 1.895e-4 (r = 4.05e4) | 4.27e-4 | 2.4 | 1.079e-6 | abs 1.897e-4, N_v 1.09e-6 |
So rho~ carries X3's residual (and X3's far-field Theta_1 mismatch; the lead decides whether to force the compatible
far field, which needs bandwidth 4M+3 and is not done). The Wiener norm exceeds the sampled sup by a factor 2.4-4.5.

## 7. Rigorous enclosures (the certificate)
All statements of this section are about the EXACT trial rho~ defined as follows (data/trial_v2_h0.008.npz with
data/cert_coeffs.json): the stored doubles S (spline coefficients, 260 x 1565), D (inner powers, 260 x 7), Aout (outer
power laws, 260 x 10, except A_00) and the knots are the definition; the join abscissae are tmin = knots[0] and
t0 = knots[-1] (stored doubles; rmin = e^{tmin} = 0.0076514, R0 = e^{t0} = 3413.0 = 446.1 L); the dependent coefficients
Ei (inner corrections), Eo (outer corrections) and A_00 are DEFINED as the unique solutions of the C^6 join equations at
tmin and t0 and of the normalization c[rho~] = 3/k - 1, computed in Arb at 256 bits (data/cert_coeffs.json, 60 digits;
they differ from the floating least-squares values by at most 1e-13 relative). k is the stored double; c_l := 1/k.
Consequences holding exactly: rho~ is C^6 across r = rmin and r = R0 and C^infinity elsewhere away from the axes
(C^6 in theta... no: rho~ is a finite trigonometric polynomial in theta times x^2 y, hence smooth in theta; in r it is
C^6 at the two joins and at the spline knots, C^infinity otherwise); a(0) = 1; Lap psi~ = -d_x rho~ with psi~ the closed-form
canonical inverse; c_l = (1 + psi~_xy(0))/3 and c_l k = 1 (so the leading far-field term of the residual vanishes identically).

### 7.1 Method
(a) Arb (python-flint, 256 bits): exact per-cell Taylor coefficients of the splines (Cox-de Boor derivative recursion);
    A_n(t), B_n(t) (n <= 261) at the 7810 boundaries of radial sub-cells of length <= 0.0019 in t = log r (so that
    2 n h <= 1), by the exact closed-form recurrences; the inner head (r < rmin) and outer tail (r > R0) integrals in
    closed form; c = psi~_xy(0); exactification of Ei, Eo, A_00. Export as (mid, rad) doubles with the conversion error
    added to the radius (src/cert_green.py; 16 min).
(b) Rigorous mid-rad arithmetic in numpy (src/midrad.py): round-to-nearest model with the inflation rules of Rump
    (beta = u/(1-u), underflow term eta, outward rounding by nextafter of every radius operation; tensor products with
    the gamma_{2K} bound for sums of K terms). Tested against Arb on random data and on exact-integer products.
(c) Taylor models (TM) of degree 12 on every sub-cell [t_a, t_a + h] (src/cert_resid.py): every modal function is enclosed
    by a polynomial in sigma = t - t_a with mid-rad coefficients plus a remainder bound valid on the whole sub-cell:
    exponentials by their Taylor series with the Lagrange remainder (|gamma| h <= 1); the spline part exactly; A_n, B_n by
    the Taylor recursion of the ODEs A' = -2n A + g, B' = 2n B - g from the certified boundary values, with the remainder
    h^{Q+1}/(Q+1)! [(2n)^{Q+1} sup|A| + sum_i (2n)^{Q-i} sup|g^{(i)}|] (all sups from the exponential-polynomial form of g);
    products of TMs with truncation and remainder propagation; the residual modes eps_N (N <= 522) as sums of two mode
    convolutions and the linear part; sup over the sub-cell of |eps_N| by the Bernstein coefficients of the polynomial
    plus the remainder; W(cell) = sum_N sup|eps_N| >= sup over the cell and over theta of |eps~|. Derivatives d_t^i eps_N
    (i <= 2 globally, <= 5 on the P-disc) by the same identities and Leibniz rules (src/cert_resid_deriv.py).
    Angular derivatives: sum_N (2N+1)^j sup|.|. Weights: m(r) = u^3 (1+u^2)^{(k-3)/2} is increasing, so inf over a cell is
    its value at the left end (Arb); far weight (1+u)^{gamma-k} bounded by its value at the right end.
(d) Coefficient transport: the exactified Ei, Eo, A_00 are exported as exact dyadic balls (integer mantissa and
    exponent of the midpoint and of the radius; src/cert_green.ball_dyadic) and re-imported losslessly (load_ball; round-trip
    containment verified for all 3640 coefficients). Two earlier exports (60 digits without radius; 100 digits with a
    5-digit nearest-rounded radius) were not enclosures (verifier 15:18Z, 15:41Z); all results depending on them are
    recomputed (chain4, chain2).
(e) Regions: middle [rmin, R0] (7809 sub-cells), outer tau in [0, 10] (r up to 7.5e7, 5263 sub-cells), inner tau' in
    [-2.5, 0] (1316 sub-cells); beyond, termwise majorants of the exponential-polynomial representation at the last
    boundary (src/cert_tail.py, src/cert_inner_tail.py), valid because every term decays relative to the weight (the
    exponent-k term of c_l X.grad rho~ - rho~ is zero by c_l k = 1; the exponent-3 term at the origin is proportional to
    3 c_l - 1 - c, a ball of radius 1e-24).
(f) External refereeing: astra (astra/cert1/answer.md, 16:0xZ) confirmed the analytic formulas of (c) and (e) (ODE remainder,
    exponential Taylor remainder, product remainder algebra, Bernstein theorem, tail decay conditions, cubic accounting of
    the inner tail) and found implementation defects (cancellation-unsafe rounding term in the polynomial product, Bernstein
    ratios and powers of h treated as exact in signed transformations, missing underflow allowances, a non-lower-bound
    helper, exponents of the outer basis exported without radius, a non-enclosing coefficient exporter, a missing factor 2
    in the tail majorants); all were repaired (WORKLOG 16:1xZ). A second referee round (astra/cert2/answer.md, 17:1xZ)
    confirmed the repairs, proved the series tail bound, the dyadic transport and the refined outer leading order, and found
    further defects (Bernstein ratio radii, float conversion of the series tail, non-outward summary endpoints, truncation
    underflow amplification, degree conditions of the inner tail, and an execution-order blocker of the middle-region CLI);
    all repaired (WORKLOG 17:1xZ). Every number in this section is from the repaired code unless marked "pre-fix"; the
    middle-region rerun (chain5), the inner/outer regeneration (chain4) and the variants (chain2) run with the final code.
(g) Validation of the machinery: on a 20-mode truncation of the trial the TM bounds reproduce the floating closed-form
    pipeline to 0.1 to 37 percent (sup over a cell against its midpoint value) with remainders <= 1e-12, and the derivative
    TMs reproduce finite differences to 1 percent (src/test_cert_small.py, src/test_cert_deriv.py).

### 7.2 Scalars (S1), rigorous, runs/scalars_full.json
| quantity | enclosure |
|---|---|
| c~ = psi~_xy(0) | 15.72608783192463802666938 +/- 4.6e-24 = 3 c_l - 1 (defect +/- 1.7e-50) |
| c_l = 1/k | [5.575362610641545, 5.575362610641548] |
| A = 2 c_l - 1 | [10.150725221283087, 10.150725221283098] |
| x_* (root of V~_1(x, 0)) | 8.600063805157177 +/- 2.94e-13 (interval Newton contracted at radius 1e-12) |
| mu~ - 1 = d_y V~_2(P) - 1 | [-2.25289e-8, -2.25272e-8] |
| A~ = 2 c_l - mu~ | [10.150725243810255, 10.150725243812035] |
| w'(P) = d_x V~_1(x_*, 0) | [10.150725243807495, 10.150725243814781]; w'(P) + mu~ - 2 c_l in [-4.54e-12, 4.52e-12] (divergence identity, certified consistency) |
| g = rho~_y(P) | [29.749490663330, 29.749490663337] |
| g' = rho~_xy(P) | [0.27341144397680667, 0.2734114439776933] |

### 7.3 Residual norms (R0, R1, R2, R4, R5)
RIGOROUS, POST-FIX (repaired code, chain5 rerun 22:54-23:38Z with the sub-interval Bernstein bound; runs/cert_resid_middle.json, 7809
sub-cells; summary runs/cert_summary_all.txt; src/cert_summary.py). W(r) := sum_N sup_cell |eps_N| >= sup_theta |eps~(r, theta)|;
m(r) = u^3 (1+u^2)^{(k-3)/2}; the three requested forms: divisor W/m (allowed growth gamma_Y = 0 ... for the shells), the multiplier
W (1+u)^{1/2}/m (allowed growth k - 1/2) and the secondary multiplier W (1+u)^{1/2-k}/m; each weight bounded at the right end of its cell.
| shell of r | max W/m (divisor) | at r | max W (1+u)^{1/2}/m | max W (1+u)^{1/2-k}/m | max W (absolute) | sum of L2 pieces |
|---|---|---|---|---|---|---|
| [0.00765, 0.0156) | 2.1899e-08 | 0.007721 | 2.1910e-08 | 2.1906e-08 | 2.250e-17 | 1.190e-21 |
| [0.0156, 0.0625) | 5.1779e-08 | 0.06248 | 5.1991e-08 | 5.1915e-08 | 2.819e-14 | 9.900e-19 |
| [0.0625, 0.25) | 5.1039e-07 | 0.2497 | 5.1867e-07 | 5.1568e-07 | 1.772e-11 | 1.265e-15 |
| [0.25, 1) | 7.0372e-06 | 0.9984 | 7.4834e-06 | 7.3201e-06 | 1.534e-08 | 3.181e-12 |
| [1, 4) | 1.9003e-05 | 3.951 | 2.3411e-05 | 2.1723e-05 | 1.887e-06 | 1.415e-10 |
| [4, 16) | 2.5964e-04 | 8.79 | 3.8070e-04 | 3.3187e-04 | 1.201e-04 | 3.255e-09 |
| [16, 64) | 2.0261e-05 | 16.07 | 3.5695e-05 | 2.9133e-05 | 1.735e-05 | 4.292e-10 |
| [64, 256) | 6.4954e-06 | 117.2 | 3.3222e-05 | 1.7685e-05 | 1.113e-05 | 4.181e-10 |
| [256, 1024) | 6.0920e-06 | 305.9 | 5.6438e-05 | 2.4758e-05 | 1.293e-05 | 4.202e-10 |
| [1024, 3413) | 5.5625e-06 | 3408 | 1.1761e-04 | 3.9362e-05 | 1.661e-05 | 3.086e-10 |
Whole middle region [0.0076514, 3413]: sup W/m = 2.5964e-4 at r in [8.790, 8.798] (the lobe next to P; the P-shell [x_*/2, 2x_*] has the
same maximum); multiplier forms 3.8070e-4 and 3.3187e-4 (same cell); sup W = 1.2015e-4; sum of the L2 pieces 4.9727e-9. Taylor remainders:
eps 2.11e-11, A/B 1.5e-14. (The pre-fix run gave 2.926e-4 with the plain Bernstein bound; the verifier's independent pass gives
W/m < 2.91625e-4, every one of my per-cell bounds at or above theirs.)
Outer and inner regions and tails: table below (chain4, 22:54Z). R2 total: (sum of all L2 pieces)^{1/2} = (4.9727e-9 + 3.906e-7 +
3.483e-16)^{1/2} = 6.29e-4 for ( int_{5.2e-5 < r < 8.2e10} |eps~/m|^2 dX/(1+u^2) )^{1/2}, dominated by the outer region (6.25e-4; middle
7.05e-5); the tails add at most their sup bounds times their measure (negligible). R4 (origin): sup W/r^5 = 1.2562e-3 on the inner cells (at
r = 5.155e-5) and <= 1.796 on the inner tail majorant.
R1/R3/R5 (derivatives, K~): section 7.3b; S1: section 7.2.
POST-FIX RESULTS OF chain4 (RIGOROUS; repaired code, regenerated inner/outer Arb data with exponent radii, T_out = 17, T_in = 5;
runs/cert_resid_regions.json, cert_tail.json, cert_tail_d05.json, cert_inner_tail.json; chain4 ended 22:53:54Z):
| region | cells | sup W/m (divisor form) | at r | sup W (1+u)^{1/2}/m | at r | sup W (1+u)^{0.3206}/m |
|---|---|---|---|---|---|---|
| outer 3413 < r < 8.244e10 | 8948 | 9.3189e-5 | 3.343e4 | 7.3680e-3 | 7.711e4 | (per cell in the JSON) |
| outer tail r >= 8.244e10 (refined termwise majorant) | - | 1.0649e-9 | - | 1.1053e-4 | - | 1.7542e-6 |
| inner 5.2e-5 < r < 0.00765 | 2632 | 9.1893e-6 | 0.007146 | 9.1893e-6 | - | - |
| inner tail r <= 5.2e-5 | - | 2.138e-6 (W/r^5 <= 1.796) | - | - | - | - |
These agree with and are slightly tighter than the verifier's independent exterior certificate (W/m < 9.4957e-5, weighted-half < 7.738e-3
on r >= 3413) and inner certificate (W/m < 9.3285e-6). The post-fix middle rerun (chain5, sub-interval Bernstein bound) is complete and
is the middle table above (sup W/m = 2.5964e-4 at the lobe; runs/cert_summary_all.txt).
Outer and inner regions: the first run (chain1) used Arb boundary values for the inner region in which the mode n = 27 was
wrong (the exponent mu = 2 - 2n + bi + 2 is about 7e-15 because bi = 1/h_first is not exactly 50, and the closed-form
primitive cancels catastrophically); the integrator now switches to a convergent series for |lam| max(|a|,|b|) < 1/2 and
the inner/outer data are regenerated (chain4). The outer region was unaffected (exponents far from zero): its pre-fix
bounds read W/m <= 5.6e-6 at R0 decreasing to 3.3e-7 at r = 7.5e7, and W (1+u)^0.5/m up to about 4.7e-3 near r = 2e4
(the far-field Theta_1 mismatch of X3, as predicted), to be confirmed by the rerun.
Tails (pre-fix data, repaired tail code): the termwise majorants at the ends of the Taylor-model regions are crude because
they lose the cancellation between the linear and the convolution terms: outer at r = 7.5e7: W/m <= 0.049 (Taylor cell there:
3.3e-7), weighted (1+u)^0.5: 152; inner at r = 6.3e-4: W/m <= 3.2e-4 (Taylor cell: 1.6e-9), W/r^5 <= 1.8. Hence the final
runs extend the Taylor-model regions to r = 8e10 (T_out = 17) and r = 5e-5 (T_in = 5), where the unweighted tail majorants
fall further; moreover the outer tail now keeps the exact e^{(2k-1) tau} coefficient of every residual mode and bounds only
the remaining terms termwise (src/cert_tail.py): on the pre-fix data at T_out = 10 this gives W/m <= 8.3e-7 (crude 0.049;
Taylor cell 3.3e-7) and, with the SPEC v2 weight (1+u)^0.3206, about 1.4e-4 (2.6e-3 with (1+u)^0.5), so the far tail no
longer dominates. Pre-fix picture of R0 by region (runs/cert_summary_prefix.txt): middle sup W/m 2.93e-4 (weighted 3.74e-4,
r = 8.79); outer sup W/m 9.3e-5 at r = 3.3e4, weighted 1.46e-3 at r = 5.2e4 (the Theta_1 mismatch band of X3); far tail as
above; inner: recomputed by chain4 (table above). This pre-fix picture is HISTORICAL and superseded by the post-fix tables above: the
certified R0 of the trial is 2.5964e-4 in the divisor form (sup W/m, attained next to P), 3.8070e-4 in the (1+u)^{1/2} multiplier form,
and 1.4636e-3 in the SPEC v2 multiplier form (1+u)^{0.3206} (attained in the far band r = 5.2e4).

### 7.3c Three resolutions (RES; chain2/chain7; src/variants_summary.py -> runs/variants_summary.txt, .json) (shift 3; v3 complete 04:09Z)
The same certificate pipeline is run on independently fitted variants of the trial: v3 (radial knot spacing h = 0.004, half of the X3 trial's
0.008; 8874 middle sub-cells), v4 (230 modes) and v5 (knot scheme 2) (both queued after the derivative certificate), and the centre-regular N7
(S1 and middle done). RIGOROUS results of v3 against the X3 trial (h = 0.008):

| quantity | X3 trial (h = 0.008) | v3 (h = 0.004) |
|---|---:|---:|
| x_* | 8.600063805157177 +/- 3.0e-13 | 8.600063805157177 +/- 3.0e-13 |
| mu~ - 1 | [-2.25290e-8, -2.25271e-8] | [-2.25290e-8, -2.25271e-8] |
| g = rho~_y(P) | [29.749490663330, 29.749490663337] | [29.749490663330, 29.749490663337] |
| w'(P) | [10.150725243807, 10.150725243815] | [10.150725243808, 10.150725243815] |
| middle sup W/m (lobe next to P) | 2.5964e-4 | 2.5964e-4 |
| middle multiplier form (1+u)^{1/2} W/m | 3.8070e-4 | 3.8070e-4 |
| middle sup W | 1.2015e-4 | 1.2015e-4 |
| middle L2 pieces | 4.973e-9 | 4.964e-9 |
| outer sup W/m (r >= R0) | 9.3189e-5 | 9.3188e-5 |
| outer (1+u)^{0.3206} W/m (SPEC v2 weight) | 1.4636e-3 | 1.4636e-3 |
| outer L2 | 3.906e-7 | 3.907e-7 |
| inner sup W/m (r < rmin) | 9.1893e-6 | 5.4350e-6 |
| inner L2 | 3.483e-16 | 6.850e-17 |
| outer tail (weighted) | 1.754e-6 | 1.755e-6 |
| inner tail W/m | 2.138e-6 | 2.138e-6 |

So the certified residual of the re-represented X3 does not depend on the fit resolution in the middle and outer regions (4 digits): it is X3's
own residual, not a fit artefact (the fit error is 1e-9 relative, section 4); the inner region (r < rmin, where the two trials' centre
expansions differ) is smaller for v3. v4 and v5 follow (chain7 after chain6b); N7 has S1 and middle identical to the X3 trial's (7.5).

## 7.4 C2 (floating point) status: finite sections of L, F- and free-tail column sets (evidence only)
Code: src/lin_assembly.py + src/lin_fast.py (fast assembly of L on single-mode exponential-polynomial basis functions; tested by the
exact identity L rho~ = 2 eps~ + rho~ - X.grad rho~/3 to 1e-12 and against the earlier finite_section2 Green data to 1e-16),
src/c2_fminus.py (lead's design, NOTES 16:58Z/17:31Z): h = x^2 y sum_{m<Mh} b_m(t) cos(2m theta) with b_m in {inner powers e^{2j tau'},
j = 1..7 (+ the constant for m = 0: the J direction); degree-7 B-splines on every stride-th knot; outer power laws with growth < k},
plus the scalar columns KP = d/dk' of the tail (x^2 y chi t e^{(k-3)(t-t0)} Theta_0~) and TAU (x^2 y chi e^{(k-3)(t-t0)} Theta_1,
Theta_1 = Theta_0~ cos 2theta), chi = sum of the last 10 B-splines (C^6 cutoff). Free section = F- plus the pure tails per mode.
Rows: residual modes N < Mout at 21 inner radii, ppc points per coarse cell, 40 outer radii, weighted by (1+u)^{1/2}/m(r); columns
weighted by the sup proxy max_t |b| e^{3t}/m x (1 + (2m)^2).
Results (runs/pdisc/c2f_*.json):
| section | columns | rows | sigma_max | sigma_1 (direction) | count sigma < 1e-6 sigma_max (dominant kinds) |
|---|---|---|---|---|---|
| M16 s16 ppc1 F- | 1955 | 160 x 24 | 1.49e4 | 4.6e-13 (J: 0.71 J + 0.29 mode-0 splines) | 456 (sp 308, out 83, in 64, J 1) |
| M16 s16 ppc1 free | 1971 | 160 x 24 | 1.49e4 | same | 471 (+ tail 8); tail-dominant sigmas 4.1e-4, 3.1e-5, 6.7e-6, 1.2e-7 |
| M16 s16 ppc4 F- | 1955 | 457 x 40 | 9.7e3 | 4.6e-13 (J) | 220 (sp 75, out 81, in 64) |
| M16 s16 ppc4 free | 1971 | 457 x 40 | 9.7e3 | same | 222 (+ tail 1: sigma 5.3e-3) |
| M8 s30 ppc1 F- / free | 611 / 619 | 114 x 16 | 2.9e3 | 1.2e-13 (J) | 90 / 98 |
Reading. (a) sigma_1 ~ 1e-13 is the J direction: J minus the sum of the mode-0 splines is the constant x^2 y on r < rmin alone, whose
image is O(r^5) because (3c_l - 1) x^2 y + U~.grad(x^2 y) = 0 at the origin (the normalization identity), with a large sup-proxy
weight: the unnormalized section has the J near-kernel that SPEC 3.6 describes. (b) The remaining near-null directions are basis
conditioning, not operator properties: the inner powers e^{2j tau'} (all concentrated at tau' = 0) and the 9 outer power laws per
mode are near-collinear in the sampled, sup-weighted matrix (their counts, 64 and 81, do not change with the row density), while
the spline-dominated count falls from 308 to 75 when the collocation density is quadrupled (under-sampling). (c) Tails: with one
point per cell the free section adds one singular value below 1e-6 sigma_max per tail mode (8 of 8; 16 of 16 at M16), as the
lead's formal-kernel picture predicts, but with dense collocation only one tail-dominated near-null direction remains
(sigma = 5.3e-3 = 5e-7 sigma_max for 16 tails), so the prediction is NOT confirmed at this resolution; the sections would need a
well-conditioned (orthonormalized, X-norm-weighted) column basis before the tail question can be read off the spectrum. (d) The
ell(Phi) least-squares test (dk, dtau for tail increments) is not meaningful at this conditioning (values of order 1e5 with rcond
1e-6); not reported as evidence. Production sections M24/s8 and M32/s8 (ppc 1) are running (runs/pdisc/chainC2.log) and are
expected to show the same pattern.

### 7.4b C2 with a well-conditioned, conforming column basis (shift 3-5; src/c2_gram.py v2, src/c2_gram2.py v3; FLOATING, evidence only; in progress)
Method (after the astra review notes/astra_c2gram1_answer.md): the raw finite section of c2_fminus.py (columns h_c = x^2 y f_c(t) a_c(theta):
inner powers e^{2j tau'}, coarse degree-7 B-splines, outer power laws, J = x^2 y on r < R0, the scalar tail columns KP, TAU, and the free tails;
rows = residual modes N < Mout at collocation radii incl. 10 inside the cutoff transition, weight (1+u)^{1/2}/m(r)) is re-expressed in an
X-orthonormal basis: inner product <h, g>_X = int (h g + r^2 grad h . grad g) m(r)^{-2} (1 + u^2)^{-3/2} dX with m the background scale (the
same relative normalization as the rows; the separable Gram uses exact angular matrices and composite Gauss-Legendre radial quadrature with
every piece endpoint as a breakpoint, checked against a 48-point rule to 7e-15); columns equilibrated to unit X-norm; C^0 join matching at
tmin and t0 imposed per mode through the constraint nullspace (32 constraints at M16, all independent); eigen-cut of the equilibrated Gram at
1e-10 (retained dimension reported; the discarded directions are near-dependent combinations within the Hilbert-matrix-like inner-power and
outer-power families); whitening error checked with the refined quadrature (4e-7); then the SVD of the row-weighted section. Reference
directions for the smallest singular vectors (cos^2 of the X-angle, pseudo-inverse projections): the section's J column, J_inner = x^2 y
1_{t < tmin} (the inner scaling direction, a function outside the section), the free tails, KP/TAU, the kinds and the modes; principal cosines
of the 5 smallest directions against the tail span and J_inner.

First production result (M16/s16/Mout40, ppc 2: 10760 rows, 1955 columns, 1866 retained; runs/c2/c2gram_M16_s16_p2_H1m_NJ0.json):
smallest singular values 0.1208, 0.1441, 0.1516, 0.1650, 0.1827 (F-), 0.1198, 0.1435, 0.1511, 0.1632, 0.1807 (free); quantiles 1% 0.41,
5% 1.18, 25% 6.4, median 25, sigma_max 4.0e4. No direction is near-null: the smallest directions have cos^2 with J_code 3e-11, with J_inner 0,
with the tail span 0, with KP/TAU 0, with the spline span 0.02 (mixed directions); principal cosines of the 5 smallest against the tail span
0.0006 and against J_inner 0.0018; removing J changes nothing (the J column is not a near-kernel direction in this norm: its X-norm is 5.4e9,
J_inner's 5.9). The ell(Phi) least squares does not solve the homogeneous equation (relative residuals 0.08-0.57). Reading (preliminary): the
J near-kernel and the tail near-null directions of 7.4 were artefacts of the sup-weighted raw basis (functions with tiny integral norm but
O(1) sup weight); in the background-relative H^1 norm with a conforming basis the section is bounded below by about 0.12 at this row density.
Variants at the same row density (ppc 2): with C^1 join matching (NJ = 1; 1847 retained) the smallest singular values are 0.1164, 0.1380,
0.1437, 0.1591, 0.1767 (F-), sigma_max 1.36e4, again no reference-direction content (principal cosines vs tails 0.001, vs J_inner 0.0008); with
the plain face-weighted L^2 inner product (L2y: |y|^{-2} (1+u^2)^{-1.129}, no 1/m^2 normalization) the smallest value is 0.038 against
sigma_max 5.2e13, the spread reflecting the mismatch between the e^{6t} measure and the 1/m row weight rather than the operator (so only the
H1m numbers are read). Per-resolution table (chain8d, started 10:55Z; rows are added as the sections finish; FLOATING, evidence only; the column sigma_min/sqrt(rows)
normalizes the discrete least-squares functional by the number of collocation rows, since the row weights carry no quadrature measure, so that
sections of different row density are comparable; the cos^2 columns are the squared X-cosines of the smallest singular directions with the
reference directions, as requested for FINAL_REPORT section 10 next step 1):
| section (M16/s16/Mout40 unless noted) | rows | Gram / joins | retained | 3 smallest singular values (F-) | sigma_min/sqrt(rows) | largest | cos^2 of the 5 smallest directions with the J column (max) | with the tail span (max) | with J_inner, KP/TAU (max) | sigma_min (free tails) |
|---|---:|---|---:|---|---:|---:|---:|---:|---|---:|
| ppc 2 (M16_s16_p2) | 10760 | H1m / NJ0 | 1866 | 0.1208, 0.1441, 0.1516 | 1.165e-03 | 4.01e+04 | 7.3e-11 | 1.6e-07 | 1.6e-06, 6.2e-10 | 0.1198 |
| ppc 2 (M16_s16_p2) | 10760 | H1m / NJ1 | 1847 | 0.1164, 0.1380, 0.1437 | 1.122e-03 | 1.36e+04 | 7.7e-09 | 4.1e-07 | 3.2e-07, 1.8e-09 | 0.1151 |
| ppc 2 (M16_s16_p2) | 10760 | L2y / NJ0 | 1859 | 0.0383, 0.2259, 0.3799 | 3.692e-04 | 5.22e+13 | 5.3e-05 | 2.6e-07 | 1.9e-18, 7.3e-08 | 0.0382 |
| ppc 4 (M16_s16_p4) | 18680 | H1m / NJ0 | 1866 | 0.1698, 0.2028, 0.2131 | 1.242e-03 | 4.10e+04 | 1.7e-10 | 6.1e-07 | 1.6e-06, 2.4e-09 | 0.1667 |
| ppc 4 (M16_s16_p4) | 18680 | H1m / NJ1 | 1847 | 0.1582, 0.1869, 0.1939 | 1.158e-03 | 1.66e+04 | 2.9e-08 | 1.2e-06 | 5.8e-07, 6.2e-09 | 0.1546 |
| ppc 4 (M16_s16_p4) | 18680 | L2y / NJ0 | 1859 | 0.0542, 0.3077, 0.5161 | 3.969e-04 | 5.36e+13 | 5.6e-05 | 2.7e-07 | 1.9e-18, 6.8e-08 | 0.0542 |
| ppc 6 (M16_s16_p6) | 26600 | H1m / NJ0 | 1866 | 0.2067, 0.2471, 0.2594 | 1.268e-03 | 4.27e+04 | 3.1e-10 | 1.3e-06 | 1.6e-06, 5.4e-09 | 0.2015 |
| ppc 6 (M16_s16_p6) | 26600 | H1m / NJ1 | 1847 | 0.1893, 0.2222, 0.2318 | 1.161e-03 | 1.99e+04 | 5.6e-08 | 1.9e-06 | 7.7e-07, 1.1e-08 | 0.1837 |
| ppc 6 (M16_s16_p6) | 26600 | L2y / NJ0 | 1859 | 0.0664, 0.3701, 0.6204 | 4.072e-04 | 5.59e+13 | 5.7e-05 | 2.7e-07 | 1.8e-18, 6.7e-08 | 0.0664 |
| M24/s8/Mout32 ppc 4 (M24_s8_p4) | 27360 | H1m / NJ0 | 5126 | 0.1492, 0.1797, 0.1851 | 9.018e-04 | 4.28e+04 | 2.3e-10 | 2.6e-06 | 2.2e-06, 2.7e-10 | 0.1459 |
Eigen-cut independence (ppc 4, H1m/NJ0): with the Gram threshold 1e-12 (1887 retained) or 1e-8 (1837 retained) instead of 1e-10 (1866) the
three smallest values are 0.1698/0.2027/0.2130 and 0.1699/0.2028/0.2131 (whitening errors 2.6e-5 and 2.4e-8), so the retained dimension does
not affect the small singular values.
Reading (13:05Z; M16/s16 at ppc 2/4/6 complete; M24/s8/Mout32 at ppc 4: the H1m/NJ0 row is in, the NJ1 and L2y rows follow when chain8d writes
them, about 14:15Z and 15:10Z):
(i) Row refinement at fixed section (M16/s16, H1m/NJ0): sigma_min grows 0.1208 -> 0.1698 -> 0.2067 (factor 1.71) while sigma_max grows by
1.06 (4.01e4 -> 4.27e4); per row (sigma_min/sqrt(rows)) 1.165e-3 -> 1.242e-3 -> 1.268e-3, stable to 8.8 percent: the discrete least-squares
functional converges in the row density at fixed section, and the smallest value does not move downward under row refinement. The C^1-join rows
(0.1164 -> 0.1582 -> 0.1893) and the L2y rows (0.0383 -> 0.0542 -> 0.0664) share only the growth of sigma_min with the row count (the L2y
spectrum is a different quadratic form, see above). The J cos^2 bound 2e-10 holds for the C^0 rows only (C^1 rows 7.7e-9 / 2.9e-8 / 5.6e-8;
L2y rows 5.3e-5 to 5.7e-5); over all H1m rows the maxima are J 5.6e-8, tail span 1.9e-6, J_inner 1.6e-6.
(ii) Section refinement at the same four collocation points per cell (the lead's size test): M16/s16/Mout40 (1955 F- columns = 1953 function columns + KP + TAU, 32 constraints, 1866
retained, 18680 rows) -> M24/s8/Mout32 (5259 F- columns = 5257 function columns + KP + TAU, 48 constraints, 5211 free, 5126 retained, 27360 rows), H1m/NJ0: the three smallest values go 0.1698,
0.2028, 0.2131 -> 0.1492, 0.1797, 0.1851 (minus 12 percent), per row 1.242e-3 -> 9.018e-4 (minus 27 percent), while sigma_max goes 4.10e4 ->
4.28e4 and the bulk of the spectrum is stable per row (1 percent quantile 0.567 -> 0.730, i.e. 4.15e-3 -> 4.41e-3 per row; median 34.9 -> 41.4;
the fraction of singular values below 1e-3 sigma_max 52 -> 51 percent). With C^1 joins (NJ1; 96 constraints, 5095 retained) the same
comparison reads 0.1582, 0.1869, 0.1939 -> 0.1279, 0.1472, 0.1649 (minus 19 percent), per row 1.158e-3 -> 7.735e-4 (minus 33 percent), sigma_max
1.66e4 -> 2.09e4, 1 percent quantile 0.69, median 40.6; cos^2 of the five smallest directions with J <= 3.1e-8, tails <= 4.2e-6, J_inner <= 1.3e-6,
KP/TAU <= 2.6e-9 (runs/c2/c2gram_M24_s8_p4_H1m_NJ1.json). So under section refinement the smallest singular value DOES move downward, for both
join conditions, and with two sizes the test gives no stable lower bound. Three effects are mixed in this comparison: the column spaces are nested (the stride-16
B-spline space lies in the stride-8 one, modes below 16 in modes below 24), so the infimum over the larger space cannot be larger; the image is
observed on fewer modes (Mout 32 against 40), which by itself can only lower the projected residual; and the row density per retained column
differs (10.0 against 5.3). The intermediate sections M16/s8/Mout40, M24/s16/Mout40 and M24/s16/Mout32 at ppc 4 (chain8f) separate them.
(iii) Reference-direction content of the five smallest singular vectors at M24 (H1m/NJ0): cos^2 with the J column <= 2.3e-10, with the tail span
<= 2.6e-6, with J_inner <= 2.2e-6, with KP/TAU <= 2.7e-10 (as at M16); principal cosines of the five-smallest subspace against the tail span
<= 2.1e-3, against J 2.5e-5, against J_inner 1.9e-3. Nothing aligned with the normalization, tail or scalar directions appears. (The version-2 cos^2 with the
multi-column spans 'kinds' and 'modes', e.g. spline span 0.007 to 0.20 and single-mode spans below 0.005, used an unequilibrated pseudo-inverse of
ill-conditioned sub-Grams and are NOT reliable (astra/gram3, item 6): on the fixture the equilibrated projection gives spline-span cos^2 1.00
where version 2 gave 0.2 to 0.5. Version 3 recomputes them with equilibration; the single-column and tail-span values above are unaffected.) The ell(Phi) least squares again does not solve the homogeneous equation (relative residuals
0.03 to 0.46).
(iv) What this functional measures (and why its smallest value must fall under refinement). The columns are normalized in an H1-type norm X (h and
r grad h, weight m^-2 (1+u^2)^-3/2) while the rows are collocation values of L h with the weight (1+u)^{1/2}/m of the SPEC residual norm: no
derivative and no quadrature measure (a discrete proxy of a weighted sup norm of L h; the per-row normalization sigma_min/sqrt(rows) compares row
densities but still depends on the distribution of the collocation radii and on Mout). The smallest singular value therefore estimates the infimum
of ||L h||_{Y-proxy}/||h||_X over the section, an inverse that GAINS one derivative. A first-order transport operator has no such inverse: for
h_n = a cos(n phi) with phi constant along the characteristics, V.grad h_n = (V.grad a) cos(n phi) has an O(1) L2 norm while ||h_n||_X = O(n); the
order-zero nonlocal term U[h].grad rho~ does not change this count (external referee astra/gram3, item 1). Hence a decrease of sigma_min with the
resolution is expected whatever L does at low frequency; the version-2 functional can test only the low-frequency directions (J, tails, KP/TAU,
center) and the convergence in the row density, it cannot certify a lower bound, and its decrease is not evidence of a kernel. Version 3 of the
code (src/c2_gram2.py; chains 8e/8f) adds (a) an H1-type row functional (value rows times sqrt(1 + (2N+1)^2) for the angular derivative plus
radial finite differences between consecutive collocation radii, run with C^1 joins so that L h is continuous across the external joins; the
spectrum from the normal matrix with the smallest candidates re-evaluated directly), with one derivative on both sides, (b) three continuous
reference functions (x^2 y times a C^4 degree-9 polynomial step in log r: at the outer cutoff, at the inner join, and across the band) with their
H1m norms, the cos^2 of the smallest directions with them and their cos^2 with the retained space, (c) the saved smallest singular vectors with
their radial X-energy profile (src/c2_vec_profile.py). Their results are added to this section as they arrive (tables runs/c2/c2gram2_table.md,
c2gram2_rowsH1_table.md).
(v) Caveats (verifier topics 127 to 132; lead 12:34Z). The J column and J_inner jump at a circle and are not in the H1m space, so their cos^2
values above are correlations of piecewise gradients, not X-angles; the central coefficient a(0) is unbounded in H1m (h_eps = x^2 y (1 -
r^2/eps^2)_+^6 has a(0) = 1 and H1m norm below L^3 eps), so this Gram cannot test the center direction by norm control; the saved spline pieces
have value jumps of order 1e-20 at interior piece endpoints (dyadic rounding of the stored coefficients, topic 130), so the encoded columns are
not exactly in H1m and every H1m value in this section is a piecewise-gradient Gram value; the exact continuous (C^0) repair of the pieces has broken-energy norm ratio E_b(h_rep - h)/E_b(h) below 8.5e-15 (M16) and 2.6e-14 (M24) per
column (topic 132; a norm ratio, not a bound on the squared energy), and an exact C^{2,1} repair exists with the same ratio below 3.4e-14 (topic
136); these are far below the quadrature check of the whitening (3e-7), so the floating spectra are those of a repaired continuous section up to
perturbations below the printed digits (a floating statement; no transfer bound is claimed). For the version-3 H1-type rows the verifier's topic
135 (L h is locally H1 iff EVERY radial first-derivative trace of h agrees, internal spline joins included) means that exact H1 membership of the
image needs the C^2 repair; the saved pieces' internal derivative jumps are below 2.5e-14 (topic 135), so the finite-difference rows see them as
contributions below 1e-11, irrelevant for the floating values, while the external joins are made C^1 explicitly (NJ1). Even a stable plateau of finite-section values would not prove a continuous lower bound or surjectivity, and a
decreasing sequence would not prove a kernel: the sections restrict the trial space (which raises the infimum) and observe the image on N < Mout
modes only (which lowers it); the finite numbers supply candidate directions and consistency checks, nothing more (astra/gram3, item 5).
FINAL_REPORT draws no conclusion from the C2 sections (lead 12:34Z).

## 7.5 Residual near the source point P in Sobolev norms (floating point, evidence only; shift 2; all refits in this section are BAND-RESTRICTED, see 7.5b)
Scope note (shift 3, 05:09Z, reworded 05:30Z): the knot-scale attribution of the H^3 content below holds for the 0.5-disc (and larger)
norms; on small cut-off balls (delta = 0.0165) the H^{3.1} norm is consistent with a substantial contribution from the localization (the
cutoff acting on the values of the smooth part of eps~), the split not being identified by the norms (7.7c, decomposition table).
Request of the lead (NOTES 18:05Z, 18:40Z): the F- forcing space at P is H^s on a disc with 3 < s < 3.406, so the residual must be
measured there, not only in sup norm. Method (src/trial_jets.py): analytic (t, theta)-jets of eps~ to order 4 (a_m^{(i)} exact from the
representation, Green functions through A_n' = -2n A_n + g_n, B_n' = 2n B_n - g_n, g_n = e^{2t} f_n, Leibniz over the products), exact
angular derivatives, Cartesian derivatives by the chain-rule recursion; L^2 norms over regions by trapezoid quadrature on polar grids
(src/pdisc_norms.py; dt = 1e-5 to 2e-7, dtheta = 1e-4 to 2e-6); fractional norms of a cut-off patch by FFT (src/pdisc_fft.py).
Validation: order 0 agrees with the modal residual; d_t^i and D^alpha agree with finite differences (7-point, h = 1e-4 / 1e-3) to
1e-7 .. 1e-3 relative through order 4; the formulas were refereed by astra (astra/jets1/answer.md: jet algebra, Green ODEs, recursion,
FFT normalization all confirmed; corrections on norm conventions and interpolation adopted, see WORKLOG 19:40Z).
Results for the trial rho~ (P = (x_*, 0), x_* = 8.600064). Seminorms |eps|_k = (sum_{|alpha|=k} ||D^alpha eps~||^2_{L^2})^{1/2}
(unweighted multi-index sum; the Fourier-side convention with binomial weights is also stored in the JSON files); sup_k = max over
|alpha| = k of the sampled sup:
| region | area | |.|_0 | |.|_1 | |.|_2 | |.|_3 | |.|_4 | sup_0 | sup_3 | sup_4 |
|---|---|---|---|---|---|---|---|---|---|
| disc, X-P < x_*/4 = 2.15 | 14.5 | 1.19e-5 | 1.27e-3 | 2.07e-1 | 37.3 | 6.92e3 | 5.0e-5 | 259 | 5.0e4 |
| disc, X-P < 1 | 3.14 | 5.96e-6 | 3.92e-4 | 5.22e-2 | 9.34 | 1.77e3 | 1.7e-5 | 77 | 1.5e4 |
| disc, X-P < 0.5 | 0.785 | 2.87e-6 | 1.36e-4 | 8.08e-3 | 1.03 | 191 | 1.1e-5 | 11.9 | 2.3e3 |
| disc, X-P < 0.1 | 0.0314 | 1.7e-7 | 8.1e-6 | 8.4e-4 | 0.131 | 23.6 | 3.1e-6 | 2.8 | 552 |
| annulus 2^-3 .. 2^-2 | 0.147 | 9.3e-7 | 4.3e-5 | 3.1e-3 | 0.448 | 81.1 | 7.6e-6 | 5.0 | 953 |
| annulus 2^-7 .. 2^-6 | 5.8e-4 | 1.9e-9 | 4.1e-7 | 5.6e-5 | 9.2e-3 | 1.70 | 2.1e-7 | 0.76 | 152 |
| annulus 2^-11 .. 2^-10 | 2.2e-6 | 8.5e-13 | 2.4e-9 | 2.9e-6 | 3.0e-4 | 0.072 | 1.4e-9 | 0.22 | 52 |
| thin annulus r - x_* < 0.01, theta in [0.2, pi/2] (right half) | 0.47 | 3.2e-6 | 1.8e-4 | 1.4e-2 | 1.91 | 318 | 1.6e-5 | 24 | 4.4e3 |
(full tables with all dyadic annuli j = 2..10: runs/pdisc/norms_A.json, norms_B.json, norms_C.json, norms_D.json; notes/TO_TEAM.md 19:25Z.)
FFT of chi eps~ (chi = 1 on X-P <= 0.4, C^infinity to 0 at 0.5; cubic interpolation of the modes in t, superseded by the degree-7 rerun
in runs/pdisc/fft_r0.5_k7.json): H^3 = 0.89, H^3.03 = 1.04, H^3.06 = 1.21, H^3.1 = 1.48, H^3.2 = 2.47, H^3.4 = 6.95, H^3.5 = 11.7,
H^4 = 160; 87 percent of the H^3 norm squared comes from |xi| > 100 and 27 percent from |xi| > 200 (wavelengths 0.016 to 0.06).
Lower orders (degree-7 interpolation, runs/pdisc/fft_r0.5_lower.json, fft_r1.0_lower.json): 0.5-patch H^2 = 7.34e-3, H^2.25 = 2.28e-2,
H^2.5 = 7.43e-2, H^2.75 = 0.253; 1.0-patch (chi = 1 on 0.8, sup 1.67e-5) H^2 = 4.40e-2, H^2.25 = 0.159, H^2.5 = 0.580, H^2.75 = 2.13,
H^3 = 7.86, H^3.06 = 10.76: a factor 3.2-3.6 per quarter derivative.
Interpretation. The residual is small in value (1e-5 on the 0.5-disc) but its H^3 norm there is of order 1 and H^{3.06} about 1.2,
because the residual has radial structure on the knot scale (knot spacing 0.0019 in t = 0.0165 in r near x_*; dominant direction
D^(4,0), 189 of the 191 of |.|_4). The local H^3 density decreases toward P (annuli), so the structure is not concentrated at P.
Cause (src/axis_diag.py, src/wiggle_diag.py): the fourth derivative of the axis trace g(x) = rho~_y(x, 0) is continuous but swings
between -319 and +708 inside the knot interval containing x_* with alternating per-interval means (-279, +234, +377, -136), against a
smooth level of 10 to 40; X3's own formula reproduces these values by finite differences to 0.03-1 percent, so this is X3's knot-scale
structure, not an artefact of the modal re-representation; there is no power law in |x - x_*| (no cusp signature; a spline cannot show
one anyway). The knot-scale content of the modes a_m(t) is 4.5e-7 relative for a_0, 6.5e-6 of itself for a_1, 1.2e-2 for a_20 and
17-50 percent for m >= 50.
Smoothing experiments (src/smooth_band.py, src/smooth_band2.py; runs/pdisc/chainS.log, chainM.log): projecting the modes on coarser
knots on the band t in [log 6, log 12] (all modes) raises the sup residual from 1.1e-4 (W peak) to 1.3e-2 (spacing 0.01), 1.05e-1
(0.02), 4.5e-1 (0.04); the 0.5-disc |.|_3 becomes 2.35 / 1.90 / 1.65 and |.|_4 87 / 40 / 24. Smoothing a single mode range (every 10th
knot) gives W peak 7.2e-2 for modes 0-9 alone, 9.1e-2 for 10-39, 6.9e-2 for 40-99, 6.8e-2 for 40-259: every mode range carries
knot-scale content that the operator sees at the 1e-1 level, although it is below 5e-7 relative in the lowest modes. So X3's residual
of 1e-4 is achieved by knot-scale adjustments of the density of relative size 1e-7 to 1e-6; whether a trial that is smooth at a coarser
scale can reach a comparable residual is being tested by a Gauss-Newton re-solve in the coarse space (src/gn_refit2.py, src/lin_fast.py;
runs/pdisc/chainG2.log): the clean re-solves of the smoothed modes on the coarse spaces recover only 10-25 percent of the weighted
residual increase (runs/pdisc/gnC.log, gnA.log, gnb10.log), and a fine-knot re-solve on X3's OWN knots near P (src/resid_smooth.py:
40 modes, 125 fine-knot functions per mode, 5000 unknowns, full nonlocal L, c[delta] = 0) lowers the weighted residual by only 3-4
percent (coefficient changes 3e-10), i.e. X3 is converged on its knots in this measure; adding a penalty on the residual's third
t-derivative (plus the angular third-derivative proxy) lowers that proxy by at most 13 percent (353 -> 306) at the price of a 2.6-fold
larger residual (data/trial_rs_summary.json; linear predictions). The nonlinear evaluations (runs/pdisc/chainR.log) confirm: lambda = 0 gives W peak
1.093e-4 (reference 1.095e-4) and disc |eps|_3 = 1.071 (reference 1.028); lambda = 1e-14 / 1e-12 / 1e-10 give W peak 1.097e-4 / 1.153e-4 /
1.406e-4 and |eps|_3 = 1.123 / 1.876 / 2.116, i.e. the penalty worsens both. Half-spacing knot refinement on the band (src/refine_knots.py,
exact insertion of 138 midpoints in t in [2.0, 2.33]) followed by one Gauss-Newton step on the refined space (9720 unknowns, modes m < 40):
W peak 1.095e-4 -> 9.50e-5 (13 percent lower; linear prediction of the weighted Wiener measure 39 percent) but disc |eps|_3 1.028 -> 4.946
and |eps|_4 191 -> 1177 (sup_3 11.9 -> 41.3): the re-solve puts half-knot-scale structure into the residual, so finer knots lower the sup
residual and raise the H^3 content (runs/pdisc/chainQ.log; both iterations are in the table of 7.5b). The external referee
(astra/smooth1) correctly notes that these are restricted-space experiments and not an exclusion of a smooth exact solution; they do show
that neither projection nor re-solving on X3's knot resolution yields a residual that is small in H^3 near P.

### 7.5b Trials near P: residual peak and fractional norms on the 0.5-disc (floating; lead's request 22:42Z)
BAND RESTRICTION (lead 22:45Z): every refit in this section (coarse-space re-solves of 7.5, same-knot and half-spacing Gauss-Newton steps)
changed the coefficients only on the band t in [2.05, 2.28] (r in [7.8, 9.8]) and fitted rows only there (plus coarse rows outside in the
gn_refit variants). Every characteristic of V in the open quadrant leaves P and exits that band, so a band-supported correction cannot cancel
a transport residual (along a characteristic from P the correction obeys (d/dt - 1) delta = -(eps + N[delta]); with delta = 0 at the band
exit it is the outflow solution, not C^1 at P unless one condition per characteristic holds; with delta regular at P it is nonzero at the
exit). The rigidity measured here is therefore what transport alone predicts; it does not show that X3 is converged on its knots nor that
the spline space is incompatible with the equation. A global re-solve (all radii, inward axis segment included) is the test that would
decide route (a); its cost is estimated at the end of this subsection.
W peak = sup_r sum_N |eps_N| near r = 8.8 (src/pdisc_explore.py); H^s = FFT norm of chi eps~ with chi = 1 on |X - P| <= 0.4 and 0 at 0.5
(src/pdisc_fft.py, degree-7 interpolation); the same-knot refits are src/resid_smooth.py on X3's knots (40 modes, band t in [2.05, 2.28],
lambda = weight of the residual third-derivative penalty), the half-spacing rows are the Gauss-Newton iterations on the refined knots
(src/refine_knots.py + resid_smooth.py). Pending entries are filled when their FFT runs finish (runs/pdisc/fft_r0.5_*.json).
| trial | W peak | H^2.5 | H^3 | H^3.06 |
|---|---|---|---|---|
| X3 trial (reference) | 1.095e-4 | 7.43e-2 | 0.890 | 1.208 |
| same knots, lambda = 0 | 1.093e-4 | 7.74e-2 | 0.942 | 1.280 |
| same knots, lambda = 1e-12 | 1.153e-4 | 0.130 | 1.640 | 2.231 |
| same knots, lambda = 1e-10 | 1.406e-4 | 0.150 | 1.857 | 2.519 |
| half-spacing knots, GN step 1 | 9.50e-5 | 0.299 | 4.397 | 6.086 |
| half-spacing knots, GN step 2 | 9.50e-5 | 0.299 | 4.397 | 6.086 (identical to step 1: stationary) |
(Disc seminorms |eps|_3 without cutoff for the same rows: 1.028, 1.071, 1.876, 2.116, 4.946, 4.946.) The knot-refinement branch is closed
(lead 22:42Z): on this branch, band-restricted, finer knots lower the residual peak and raise its H^3 content.
N7, the centre-regular trial (data/trial_n7.npz, src/make_n7.py; lead 21:17Z/22:03Z): the 1026 inner coefficients D_mj of the non-polynomial
terms r^{2j} cos(2m theta) with m > j, j <= 4 (all <= 2.7e-11; X3's modes vanish like r^{2m}) set to zero and the inner corrections re-solved
from the C^6 joins; inner density change 3.0e-10 of a_0; the inner density is a polynomial through degree 11 plus degree >= 13 terms
(|D[m,4]| <= 6.9e-11) and the O((r/rmin)^{50} log^i) corrections; the degree-5 resonance coefficient (verifier topic 60: H7 = h7/rmin^2 in
(-1.423e-9, -1.421e-9), h7 = -8.32e-14 in the stored coefficients) is exactly zero. RIGOROUS S1 of N7 (runs/scalars_n7.json, Arb data
data/cert_n7_green.npz): identical balls to the original trial to all printed digits (x_*, mu~ - 1, w'(P), g, c = 3c_l - 1 exactly).
RIGOROUS middle R0 of N7 (runs/cert_resid_middle_n7.json, 7809 cells): sup W/m = 2.5964e-4 at r = 8.79, sup W = 1.2015e-4, multiplier
form 3.8079e-4, shells identical to the X3 trial's post-fix table (runs/cert_resid_middle_n7_summary.txt), as expected (the two trials
agree for r >= rmin to 3e-10 and have the same strain c to all printed digits). These are NUMERICAL agreements, not identities: N7's
density differs from the first trial's only for r < rmin, but its exact canonical exterior velocity is not identical to the first trial's
(verifier topic 79: the C^6 rejoin changes the exterior stream coefficient at frequency 522 by r_-^{526} S r^{-522}/16 with S a nonzero
rational, a term of order 1e-1100 that no printed digit can show). Not yet certified for N7: the inner region r < rmin (where it differs) and
the outer region/tails; its FFT residual norms on the 0.5-disc (runs/pdisc/fft_r0.5_n7.json, ESTIMATES, same grid/padding as the X3 trial's
run) are sup|eps| = 1.14e-5, L2 = 2.436e-6, H^2 = 7.339e-3, H^3 = 0.8898, H^3.06 = 1.2078, H^3.1 = 1.4816, H^4 = 160.0: equal to the X3
trial's values to 7 digits (relative difference <= 1e-7; numerical agreement, see above).
Feasibility of a global re-solve in X3's own spline space (estimate): full space 260 modes x 1565 functions = 4.1e5 unknowns, rows 7809
cells x 2 x 522 modes = 8e6: a dense matrix is out of reach; matrix-free LSQR needs one full closed-form Green solve plus residual modes at
all collocation radii per matvec (about 3 min; the adjoint matvec needs the transpose of the Green operator, not implemented) and hundreds of
iterations: tens of hours. Reduced comparison test (lead 22:45Z, optional): modes m < 10 with every second knot (7820 unknowns), rows at one
point per cell for N < 20 (1.56e5 rows): matrix 1.2e9 entries (float32: 4.9 GB), assembly about 1.1 h (0.5 s per column at 7809 radii),
normal equations 9.5e12 flops (about 1 h): roughly 2.5 h of one CPU for the global step, versus minutes for the band step with the same
columns restricted to the band. Not started (CPU reserved for the certificate chains and N1'); planned for the next shift if the lead
confirms.

Feasibility and cost estimate of a GLOBAL re-solve in the trial's own spline space (lead 22:45Z; estimate only, nothing run). Unknowns: the
trial has 260 modes x 1565 radial spline coefficients (S in data/trial_v2_h0.008.npz; knots 1573, degree 7 in t = log r on [log rmin, log R0])
plus the inner (D, Ei: 260 x 7 each) and outer (Aout 260 x 10, Eo 260 x 7) expansion coefficients: about 4.1e5 unknowns and the scalar c_l.
One linearized-operator matvec (src/lin_fast.py structure: radial Green sweeps O(N_t) per mode for psi[h], angular products as convolutions
O(M^2) or FFT O(M log M) per radius, transport term by exact spline derivatives) costs about N_t M^2 ~ 1600 x 260^2 = 1.1e8 flops with
convolutions (a few 0.1 s in numpy, less with FFT); the normal equations are ill-conditioned (J near-kernel, c_l soft direction, basis
conditioning seen in 7.4), so a matrix-free LSQR/LSMR Gauss-Newton step needs 1e3-1e4 iterations: 0.3-3 h per GN step on one core, several
steps, plus the fitting rows (the residual on a fine (t, theta) grid, 1e6-1e7 rows) and the centre/source constraints. Feasible in principle
(1-2 days of one core, or hours on the GPU with the convolutions as batched matmuls), not within this run under the one-job CPU guard with the
certificate chains pending. Expected effect, if the lead's transport reading is right: a residual near P limited by the spline space and X3's
far-field closure rather than by the band restriction; the band-vs-global comparison with m < 10 (design above) is the cheap test of that
reading and remains the first experiment to run when CPU is free.

## 7.6 N1': rigorous bounds on the trial velocity field for the lead's global-flow argument (src/cert_flow.py; COMPLETE for the whole quadrant)
Request (lead 20:01Z; notes/global_flow.md section 10): certified (Y) V_2 >= m_0 y on Q = {x > 0, y > 0}; (H2') signs of V_1(x, 0);
(H3) DV(0), DV(P); (H4) X.V >= kappa_0 |X|^2 for |X| >= R_0; V_1 <= -13 and T_0 <= 1.23 on B_1 = [4.80, 6.82] x [0, 2.85];
T_0 <= -0.22 on Q minus B_1, with T_0 = -(1 + c_l) + a (V_1/x - s) + b (V_2/y - s) + mu(r) s, s = X.V/r^2, a = 129/20, b = 307/100,
mu(r) = gamma' + (a + b - gamma')/(1 + (r/R_m)^p), gamma' = 1129/1000, R_m = 6, p = 4.
Formulas (U = grad^perp psi, U_r = -psi_theta/r, U_theta = psi_r, psi = sum_n psi_n(r) sin 2n theta):
  s = c_l - r^{-2} sum_n 2n psi_n cos(2n theta);  V_2/y = s + r^{-1} sum_n psi_r,n C_n(theta);  V_1/x = s - r^{-1} sum_n psi_r,n S_n(theta),
  C_n = cos theta sin(2n theta)/sin theta = 2 cos theta sum_{j<n} cos((2j+1) theta),  S_n = sin theta sin(2n theta)/cos theta
  = 2 sin theta sum_{j<n} (-1)^{n-1-j} sin((2j+1) theta)  (both bounded by 2n; third derivatives bounded by 2n + 6n^2 + 8n^3 + 4n^4).
Method: on each radial sub-cell of the certificate (7809 middle, 8948 outer to r = 8e10, 2632 inner to r = 5e-5) Taylor models in
sigma = t - t_a of 2n psi_n e^{-2t} and psi_r,n e^{-t} from the Arb boundary values (same ODE recursion as the residual certificate);
on each angular cell [th_a, th_b] (200 cells on [0, pi/2], bisected adaptively up to 7 levels where a target inequality fails) a
second-order Taylor model of each angular factor about the centre with the third-derivative remainder; the mode sums are then
polynomials in (sigma, eta) with mid-rad coefficients and a tensor Bernstein enclosure (eta on [-d, d], sigma on 2 sub-intervals)
gives two-sided ranges of s, V_2/y, V_1/x and T_0 on the 2D cell (all operations in the rigorous mid-rad arithmetic of src/midrad.py,
constants from Arb). Box classification of each polar cell against B_1 (in / out / straddling, the latter bisected). Validation:
the floating values at cell midpoints (src/trial_green.py) lie inside the certified ranges on all tested cells; the certified
extrema are within 5e-4 .. 5e-3 of the floating extrema (e.g. r = 8.60: V_2/y min 0.9993 certified vs 0.9998 floating; r = 34.8:
T_0 max -0.2796 vs -0.2805). External audit: astra flow1 (astra/flow1/answer.md, PROOF.md; 18,792 Arb checks of the angular coefficients) confirmed the
mathematics (identities, derivative bounds, tensor Bernstein enclosure, tail formulas, T_0 bounds; the data satisfy every hypothesis)
and listed 16 implementation defects (rounding directions, float trig allowances, interval conversions, endpoint and hypothesis checks,
coverage bookkeeping, a dead branch and missing monotonicity checks in the tails); all were repaired in revision 2 of src/cert_flow.py and
src/cert_flow_tails.py (angular factors in Arb, exact rational constants, Arb cell edges, outward rounding throughout, asserts with
abort). Every number reported here is from the revised code (the tails were rerun: unchanged).
Tails (RIGOROUS, src/cert_flow_tails.py revision 2, Arb 256 bits, runs/flow_tails.json; termwise majorants of the exponential-polynomial
representations with verified monotonicity and nonresonance): for r >= R_T = 8.244e10, |s - c_l| <= 9.84e-8 and |V_2/y - c_l|,
|V_1/x - c_l| <= 1.10e-6, so s >= 5.575362, V_2/y >= 5.575361 (raw 5.5753615; the earlier 5.575362 was inward, corrected 00:5xZ) and T_0 <= -0.2807669 (raw -0.28076698; the limit -(1 + c_l) + gamma' c_l is
-0.280778). For r <= r_T = 5.1555e-5 the leading (a_0 = 1, n = 1) terms are exact (the e^{2 tau'} coefficient of psi_1 comes from the B
transient: 2 psi_1 e^{-2t} -> c with c_lead = 15.726087831925 = c to 12 digits) and the rest is <= 3.53e-9, so V_2/y >= 21.301450
(4c_l - 1), V_1/x <= -10.150725 (1 - 2c_l), T_0 <= -6.652087.
Status: middle and outer cell runs complete, inner running; results in runs/flow_*.json; aggregation by src/flow_summary.py.
Certified scalars for N1' (S1, runs/scalars_full.json): x_* = 8.600063805157177 +/- 3.0e-13 (raw radius 2.9402e-13) isolated by a contracting interval
Newton step (so w' != 0 on the isolating interval); w'(P) = d_x V~_1(x_*, 0) in [10.1507252438075, 10.1507252438148];
mu~ = d_y V~_2(P) with mu~ - 1 in [-2.2529e-8, -2.2527e-8]; divergence identity w'(P) + mu~ - 2 c_l in [-4.5e-12, 4.5e-12];
DV(0) = diag(1 - 2c_l, 4c_l - 1) exactly (c~ = 3c_l - 1 certified).
Crossing cell (RIGOROUS, src/cert_axis_cell.py, runs/axis_cell.json; closes the verifier's 21:34Z coverage objection): on the radial
sub-cell containing x_* (r in [8.598670706, 8.606894667]) x^2 w' = dF/dt - F in [750.506, 751.997] over the whole cell, so w' >= 10.1312
there, and x V_1(x, 0) is negative at its left end ([-0.1215927194, -0.1215927193]) and positive at its right end ([0.5964619822, ...]):
exactly one zero of V_1(x, 0) in the cell; all other axis cells receive strict-sign checks in cert_flow.py.
CERTIFIED RESULTS (middle region 0.00765 <= r <= 3413, all of theta in [0, pi/2], 7809 radial x 200 angular cells with adaptive bisection;
plus the tails; the outer and inner cell runs are complete (below); runs/flow_middle.json, runs/flow_summary_all.txt):
  (Y)  V_2/y >= 0.98845 on the middle region (minimum on the cells r in [8.8654, 8.8738] at the x-axis; floating minimum 0.988);
       V_2/y >= 5.575361 for r >= 8.244e10 and >= 21.301450 for r <= 5.1555e-5.
  (H2') V_1/x <= -0.001585 on every axis cell below x_*, >= 0.0077249 on every axis cell above x_* (middle region); the cell containing x_*
       has w' >= 10.1312 and a sign change of x V_1 (section above), so V_1(x, 0) has exactly one zero in [0.00765, 3413];
       V_1/x <= -10.150725 for r <= 5.1555e-5 and >= 5.575361 for r >= 8.244e10.
  (H4) X.V/r^2 >= 3.4957 on the cells with r_hi >= 20 (minimum at r = 20), >= 4.2564 for r >= 30, >= 5.575362 for r >= 8.244e10.
  B_1 = [4.80, 6.82] x [0, 2.85]: T_0 <= 1.2780 on the cells meeting B_1 (maximum at r in [5.7601, 5.7688]); V_1 <= -12.834 on B_1 (maximum
       at the box corner, r in [7.3805, 7.3922]; the requested -13 is not attained there); T_0 <= -0.2399 on the middle region off B_1
       (maximum at r in [67.99, 68.10]), <= -0.2807669 for r >= 8.244e10, <= -6.652087 for r <= 5.1555e-5.
  Bookkeeping: 245 angular sub-cells in 3 radial cells (r in [7.357, 7.392], the box corner) reached the maximal bisection depth without
  meeting the V_1 <= -13 target; their certified maxima are included in the numbers above; no other target failed; 0 axis-sign failures.
  Constants: a = 129/20, b = 307/100, gamma' = 1129/1000 (Arb rationals), R_m = 6, p = 4, c_l := 1/k.
  Domain convention (verifier topic64): every per-cell statement holds on the exact log-cell [t_a, t_b] of the certificate's radial
  partition (abutting cells cover [t_min, t_0] exactly); the printed r_lo, r_hi are outer enclosures of e^{t_a}, e^{t_b} (r_hi uses
  e^h <= 1 + h + h^2, an excess of about 4e-6 at r ~ 8.6) used only to locate cells and for the superset box classification.
  Decimals are rounded outward from the stored aggregates (runs/flow_middle.json glob: T0_max_out = -0.2399542, T0_max_in = 1.2779480,
  axis above min = 0.0077249424; verifier 22:41Z caught three inward roundings in the first printing).
  Independent checks (verifier): topic69 (my modal R, dR, F maps on all 7809 middle cells, 4.9e7 exact comparisons), topic72 (the mid-rad
  matmul error model), topic73 (the angular factors: exact identities, derivative bounds, 51000 angular nodes, 4176 remainders, 519129
  coefficient boxes at 221 centres), topic64 (crossing cell), topic71 (independent inner and far-tail bounds consistent with mine);
  23:03Z: the middle coverage (39046 checks over all 7809 cells, R_0 = 20 crossing) passed; the box-cost
  instances exp((1.278 + 0.2) t_1)/0.2 = 6.3095658 < 6.31 and exp((1.278 + 0.22) t_1)/0.22 = 5.7540536 < 5.76 (t_1 = 2.02/12.834) were
  confirmed in Arb512/iv180, conditional on acceptance of the whole flow certificate (verifier: the finite flow scalars of all 19389 cells
  and the tails are CONFIRMED (topics 71, 75); the full radial Taylor models and the field inequalities remain OPEN on their side).
  OUTER CELLS DONE (runs/flow_outer.json, 8948 cells, complete_region True, 6629 s): on 3413 <= r <= 8.244e10, X.V/r^2 >= 5.55636,
  V_2/y >= 5.56640, V_1/x >= 5.5741 on the axis cells (all above x_*; raw aggregate 5.5741666), T_0 <= -0.2782 (all cells are off B_1), no unresolved cells, no
  axis-sign failures (raw aggregates; rounded outward).
  INNER CELLS DONE (runs/flow_inner.json, 2632 cells, complete_region True, 1789 s): on 5.1555e-5 <= r <= 0.0076514, V_2/y >= 21.30140 (raw aggregate 21.3014052; the earlier 21.30141 was inward, corrected 00:4xZ after the verifier's note),
  V_1/x <= -10.1507 on the axis cells (all below x_*), T_0 <= -6.6519, no unresolved cells, no axis-sign failures.
  WHOLE-QUADRANT STATEMENT (all of Q = {x > 0, y > 0} covered by the two tails and the 19389 radial cells x 200+ angular cells, no gaps;
  runs/flow_summary_all.txt; notes/TO_TEAM.md 23:4xZ): (Y) with m_0 = 0.98845; (H2') axis signs with the single zero x_*; (H3) as above;
  (H4) with R_0 = 20, kappa_0 = 3.4957 (R_0 = 30: 4.2564); B_1: T_0 <= 1.2780, V_1 <= -12.834; off B_1: T_0 <= -0.2399 (middle), -0.2782
  (outer cells), -0.2807669 (outer tail), -6.6519 (inner cells), -6.652087 (inner tail). Implied cost bound (lead's Corollary):
  ||R_-|| <= 6.31 at kappa = 0.2 and <= 5.76 at kappa = 0.22 (verifier-confirmed instances, conditional on their acceptance of the
  whole certificate).

## 7.7 N8: derivative bounds of V and rho~ on B_{3 delta}(P) (RIGOROUS) and cut-off Sobolev norms of the residual (floating) (shift 3)
Request (lead 00:06Z, SPEC v3.17 section 3.15 (S2), (S4)): on the balls B_{3 delta}(P), P = (x_*, 0), delta in {0.0165, 0.05, 0.1, 0.2}, the suprema
M_V = sup ||D^2 V||_F, M_rho = sup ||D^2 rho~||_F, sup ||D^j V||_F (j = 3, 4), sup ||D^j rho~||_F (j = 3, 4, 5), with
||D^j f||_F^2 = sum_{a+b=j} C(j,a) (d_x^a d_y^b f)^2 (Frobenius norm over all index tuples; for V summed over both components), and
C_V = 41.7 M_V + 3 M_rho against kappa/(2 delta) = 1.687/delta; plus the floating ||tau eps~||_{H^{3.1}} for a smooth radial cutoff tau = 1 on
B_{7 delta/4}(P), supported in B_{9 delta/4}(P). Objects: the certified trial rho~ (data/trial_v2_h0.008.npz), V = c_l X + grad^perp psi~ with
psi~ its canonical inverse, c_l = 1/k. Parity: rho~ and psi~ are odd in y, so every |d_x^a d_y^b rho~|, |d_x^a d_y^b psi~| is even in y and the
quadrant theta in [0, theta_max] covers the ball.

### 7.7a RIGOROUS upper bounds (src/cert_n8.py)
Method. (1) Radial sub-cells of data/cert_green.npz (the certified Arb data of the trial: A_n, B_n at every sub-cell start, exact spline
polynomials of the a_m); on each sub-cell [t_a, t_a + h] the Taylor models (degree 12 in sigma = t - t_a, with remainder) of psi_n^{(i)} and
R_j^{(i)}, i <= 5, by exactly the construction of cert_resid._cell_core_deriv (A' = -2n A + g, B' = 2n B - g differentiated exactly; the
R_j^{(i)} are exact exponential-polynomials; the ODE remainder hypothesis 2 Nf h <= 1 is asserted per cell). (2) Each sub-cell is split into KSUB
equal sub-intervals; on each, two-sided ranges of every mode derivative by the re-centred Bernstein enclosure plus remainder (an MR interval per
(sub-interval, mode, i)). (3) Angular cells [theta_k, theta_{k+1}], theta_k = k theta_max/ntheta (exact reals as Arb balls); the ranges of
sin(f theta + l pi/2) (f = 2j+1 for rho~, 2n for psi~, f = 1 for the coordinate factors; l <= 6) are Arb enclosures of sin and cos on the ball
covering the cell (rigorous, second-order tight at critical points). (4) The (t, theta)-jets d_t^i d_theta^l rho~ = sum_j R_j^{(i)} (2j+1)^l
sin((2j+1) theta + l pi/2), and likewise for psi~ with 2n, as rigorous sums (midrad.MR.sum) of interval products over the modes, on every
(sub-interval x angular cell). (5) Cartesian derivatives by the exact recursion d_x = e^{-t}(cos th d_t - sin th d_th),
d_y = e^{-t}(sin th d_t + cos th d_th) applied to the interval jets (the same recursion as the floating TrialJets.polar_to_cart; the coefficient
fields e^{-t}, cos(th + b pi/2), sin(th + b pi/2) are interval ranges over the cell); d^alpha V_1 = -d^alpha psi~_y, d^alpha V_2 = d^alpha psi~_x
for |alpha| >= 2 (plus c_l on the diagonal for |alpha| = 1). (6) Frobenius norms from the magnitudes (|mid| + rad) of the entries, per cell; a cell
counts for the ball B_{3 delta}(P) if a RIGOROUS lower bound of its distance to P is <= 3 delta (over-inclusion is safe): for th1 >= 0 the
distance to P = (x_*, 0) increases with theta at fixed r, so dmin^2 = dist(x_* cos th1, [r1, r2])^2 + (x_* sin th1)^2, evaluated in mid-rad
arithmetic with x_* the certified bracket, cos th1 and sin th1 as Arb enclosures at the exact lower edge of the angular cell and r1, r2 the Arb
bounds of e^t over the radial sub-interval; the maximum over the counted cells is the bound. The radial sub-intervals used for the mode ranges
and for the coordinate factor e^{-t} are the same exact intervals I_kk = [kk hk_f, (kk+1) hk_f], hk_f = succ(h/KSUB), whose union contains
[0, h]. Coverage: r in [7.99935, 9.20025] (sub-cells 4027..4166, abutting; upper(t_start) <= lower(log(x_* - 0.6)), lower(t_end) >=
upper(log(x_* + 0.6))) and theta in [0, theta_max] with theta_max an exact double >= upper(asin(0.6/x_*)) x 1.000001 (= 0.069824; the tangent
angle of the ball seen from the origin) contain B_{0.6}(P) and hence all four balls; a run reports only the balls its cells cover (code v2,
2026-10-21T01:1xZ, after the verifier's preliminary audit; the v1 outputs, archived as runs/n8/*_v1.json, used a floating filter inflated by
1 + 1e-6 and gave the same numbers). All arithmetic: src/midrad.py (mid-rad float64 with outward
rounding; the dot-product model audited by the verifier, topic 72) and Arb (python-flint, 128 bits) for e^{-t}, sin, cos, asin, log.

Results (code v2; runs/n8/cert_n8_full.json: 140 radial sub-cells, KSUB = 4, ntheta = 350, 1030 s wall under the box CPU guard; the 0.0165 row
from the finer pass runs/n8/cert_n8_fine0165.json: 13 sub-cells r in [8.5495, 8.6564], KSUB = 16, ntheta = 160 on [0, 0.005756], 95 s; the
coarse-pass values for the 0.0165 ball are M_V <= 0.30302, M_rho <= 0.47929, C_V <= 14.07, also valid. The v2 outputs agree with the archived v1
outputs (runs/n8/*_v1.json, floating filter inflated by 1 + 1e-6) to 1.3e-10 relative (full) and 4e-11 (fine), with identical counted-cell
numbers 1141 / 10176 / 40395 / 156565 and 24457, which the referee reproduced independently):

| delta | cells counted | M_V = sup\|D^2 V\|_F | sup\|D^3 V\|_F | sup\|D^4 V\|_F | M_rho = sup\|D^2 rho~\|_F | sup\|D^3 rho~\|_F | sup\|D^4 rho~\|_F | sup\|D^5 rho~\|_F | sup\|DV\|_F | C_V | 1.687/delta | |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| 0.0165 (fine) | 24457 | 0.28728 | 1.3675 | 37.552 | 0.45336 | 4.3778 | 41.256 | 5777.7 | 10.2056 | 13.34 | 102.24 | OK |
| 0.05 | 10176 | 0.39257 | 3.0163 | 320.99 | 0.75436 | 5.0524 | 340.48 | 56797 | 10.216 | 18.63 | 33.74 | OK |
| 0.1 | 40395 | 0.55722 | 3.8804 | 444.05 | 1.2276 | 5.548 | 472.28 | 79322 | 10.218 | 26.92 | 16.87 | FAIL |
| 0.2 | 156565 | 1.0947 | 4.477 | 459.41 | 1.8183 | 5.5757 | 481.09 | 79322 | 10.223 | 51.10 | 8.435 | FAIL |
| 0.05 (mid) | 57668 | 0.38292 | 1.6643 | 150.78 | 0.7294 | 4.4488 | 160.09 | 29288 | 10.212 | 18.16 | 33.74 | OK |
| 0.06 (mid) | 82953 | 0.41251 | 2.0303 | 219.27 | 0.82208 | 4.4488 | 232.53 | 36745 | 10.213 | 19.67 | 28.12 | OK |
| 0.07 (mid) | 112816 | 0.44308 | 2.0581 | 219.34 | 0.91783 | 4.4488 | 232.9 | 40398 | 10.214 | 21.23 | 24.10 | OK |

The three "mid" rows are from runs/n8/cert_n8_mid.json (code v2; 52 radial sub-cells r in [8.38698, 8.81486], KSUB = 8, ntheta = 350 on
[0, 0.024421]; 1105 s wall under the CPU guard); they refine the 0.05 row and extend the certified admissible range of the lead's condition
C_V <= kappa/(2 delta) to delta = 0.07 (21.23 <= 24.10). In floating point the condition fails from delta = 0.08 on (C_V 22.47 against 21.09,
runs/n8/n8_floating_scan.json), so the largest admissible delta lies in [0.07, 0.08). Every rigorous entry is >= the sampled supremum
(ratios 1.02-1.03 at order 2, up to 8.4 at order 5 for these KSUB = 8 runs).

All entries are upper bounds, rounded up at the fifth significant digit. Largest Taylor-model remainders over the 140 cells: A, B 1.1e-15;
psi^{(5)} 1.9e-5; R^{(5)} 1.9e-22. Consequences for SPEC 3.15 (if E <= C_V delta as in (S2)): at delta = 0.0165, E <= 0.2202 and
K_1 = 1/(kappa - E) <= 1/(3.374 - 0.2202) = 0.3171; at delta = 0.05, K_1 <= 1/(3.374 - 0.9315) = 0.4094; delta >= 0.1 is excluded by the bound
(and already by the sampled values below). Location of the maxima: on the 0.0165 ball |D^2 V| peaks at r in [8.5495, 8.5515], theta in
[0.00100, 0.00120] (the inner edge of the ball near the axis) and |D^2 rho~| at r in [8.5740, 8.5761], theta in [0.00499, 0.00519]; on the
0.05 ball |D^2 V| peaks at r in [8.4496, 8.4517], theta in [0.0024, 0.0026]: M_V grows with delta through the inner (saddle-side) edge, not
through a feature at P.

### 7.7b FLOATING sampled suprema (src/n8_floating.py, runs/n8/n8_floating.json; evidence only)
Polar grid dt = dth = 1e-4 over the same region (1399 x 700 points), analytic jets to order 5 (src/trial_jets.py), sampled suprema on the
grid points inside each ball (no remainder):

| delta | points | M_V | sup\|D^3 V\| | sup\|D^4 V\| | M_rho | sup\|D^3 rho~\| | sup\|D^4 rho~\| | sup\|D^5 rho~\| | sup\|DV\| | C_V |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 0.0165 | 5265 | 0.28222 | 1.2574 | 22.996 | 0.44591 | 4.3116 | 25.185 | 2314.4 | 10.203 | 13.11 |
| 0.05 | 47967 | 0.37361 | 1.2928 | 46.118 | 0.71176 | 4.3116 | 47.054 | 4797.3 | 10.208 | 17.71 |
| 0.1 | 191607 | 0.54008 | 1.6225 | 91.372 | 1.1867 | 4.3116 | 95.244 | 9101.4 | 10.21 | 26.08 |
| 0.2 | 767136 | 1.0808 | 3.1396 | 291.44 | 1.7801 | 4.3695 | 289.71 | 31519 | 10.21 | 50.41 |

Consistency: every rigorous bound is >= the sampled supremum on the same ball (checked programmatically for all entries; the referee
confirmed it for every common entry, see below). Ratios rigorous/sampled: 1.00-1.07 for DV, D^2 V, D^2 rho~ (1.02 on the fine 0.0165 pass);
D^3 rho~ 1.02 (fine) to 1.29; D^3 V 1.09 (fine) to 2.4; D^4 V and D^4 rho~ 1.6 (fine) to 7.2; D^5 rho~ 2.5 (fine) to 11.84. The looseness
at high order comes from the interval widths of the fifth-order jets over the sub-cells (frequency powers magnify the angular widths, modewise
interval products lose cancellation, repeated differentiation adds dependency) and shrinks with KSUB and ntheta, as the fine pass shows.

Referee (astra n8ref1, notes/astra_n8ref1_answer.md, on the v1 code): CONFIRMED the Bernstein re-centring and scaling (and checked all 134676
affected coefficient products against exact rational targets), the angular phase bookkeeping and outward conversions, the mode-sum jets and
the exact representability of f^l (exhaustively compared with integer powers), the Leibniz recursion (agrees with TrialJets.polar_to_cart) and
its pointwise-containment justification, the V derivatives, the Frobenius weights, the e^{-t} union enclosure, the parity reflection, and
independently reproduced the inclusion counts (1141, 10176, 40395, 156565 coarse; 24457 fine) with certified exclusions of all other cells
(squared-distance excess > 1.2e-6 coarse, > 9.65e-8 fine). REFUTED (v1): the fine output's entries for delta > 0.0165 (not covered; a certified
counterexample point Q = (8.60719, 0.14978) has rho~(Q) = 4.45 against the listed 1.48), the floating dmin (overestimate by 3.3e-14, not a lower
bound), the self-comparing adjacency assertion and a dead assertion, and the ball xs built from the double bracket (misses the decimal literals
by 4e-16; the certified bracket is the pair of doubles stored in runs/axis_cell.json, which the ball does contain; v2 uses a radius one ulp
larger, which also contains the decimal literals). All of these are repaired in v2 (entries for delta > delta_max are dropped; rigorous MR
filter; contiguity assertion; dead assertion removed); the v2 fine pass reproduces the v1 numbers exactly.
Referee round 2 (astra n8ref2, notes/astra_n8ref2_answer.md, on the v2 code and the three v2 outputs): CONFIRMED the v2 coverage and filter
changes for all three runs (independent Arb checks of the radial and angular coverage with margin > 2e-5 in t, of every excluded cell with
exact rational arithmetic, 374880 squared-distance steps; counted cells 1141/10176/40395/156565, 24457, 57668/82953/112816 reproduced),
the common sub-interval construction (every shift enclosed; K hk_f = succ(h_up) > h_up by binary scaling), the tangent-angle formula and the
downward rounding of the filter; and gave the clean justification of the sub-interval ranges: at every sigma in J_kk = I_kk n [0, h] the
polynomial part lies in its Bernstein range over I_kk and the Taylor remainder (derived on [0, h_up]) applies, and the union of the J_kk is
[0, h]; the remainder is never used beyond h (the referee's counterexample sigma^13 shows that a Taylor model does NOT automatically extend
to the one-ulp overhang, which is why this restriction matters). Robustness items for general inputs (no effect on the supplied runs, each
verified directly in Arb by the referee): the delta filter tolerance (1 + 1e-12) could admit d one ulp above delta_max; the double
conversions of the coverage bounds t_lo_need/t_hi_need and of r_lo/r_hi were not forced outward (they happened to be exact or inward by
< 2e-16, against margins > 2e-5); the coverage assertion compared a float conversion. These are repaired in code v3 (arithmetic unchanged;
runs/n8/cert_n8_fine0165_v3.json, 88 s: identical sup_bounds, counted cells and per-cell maxima to the v2 file; only the reported r
intervals of the maxima are one ulp wider). The frozen certificate files remain the v2 outputs pinned by the verifier; v3 is the code to use
for any new run. The x_* ball covers the certified double bracket (axis_cell.json) but not the exact decimals of its shortest representation
(4e-16 outside); the double pair is the certified object.

### 7.7c Cut-off residual norms near P (FLOATING, src/pdisc_fft.py; evidence only)
tau(X) = Q((|X - P| - 7 delta/4)/(delta/2)) with Q the C^infty step e^{-1/(1-u)}/(e^{-1/(1-u)} + e^{-1/u}); f = tau eps~ on a Cartesian grid of
spacing dx = delta/300 (box half-width 1.25 x 9 delta/4, n = 2048), eps~ from the residual modes on a dt = 1e-5 grid (degree-7 interpolation in
t) summed with sin((2N+1) theta); ||f||_{H^s}^2 = (2 pi)^{-2} int (1 + |xi|^2)^s |f^|^2 by FFT (runs/n8/fft_delta*.json):

| delta | sup\|tau eps~\| | L^2 | H^2 | H^3 | H^{3.1} | H^{3.5} | H^4 | H^4/H^3 | fraction of H^3 norm^2 above \|xi\| = 800 |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 0.0165 | 3.31e-7 | 8.58e-9 | 7.08e-4 | 0.743 | 1.558 | 32.3 | 1628 | 2190 | 0.843 |
| 0.05 | 3.00e-6 | 1.67e-7 | 1.80e-3 | 0.573 | 1.065 | 13.7 | 394 | 690 | 0.186 |
| 0.1 | 5.84e-6 | 5.98e-7 | 2.95e-3 | 0.476 | 0.811 | 7.16 | 125 | 263 | 0.006 |
| 0.2 | 1.01e-5 | 2.04e-6 | 6.46e-3 | 0.823 | 1.373 | 10.9 | 149 | 181 | 0.000 |

Grid check (delta = 0.0165): dx = delta/100 (n = 1024) and dx = delta/600 (n = 4096) give the same L^2, H^3, H^{3.1}, H^4 to four digits
(8.575e-9, 0.7429, 1.5577, 1628) and the same high-frequency fraction 0.843: the values are converged and are not floating-point roundoff.
Reading: H^4/H^3 is about 35/delta in all four cases, consistent with a substantial contribution from the localization (the cutoff acting on
the values of the residual; the derivatives of tau scale like (2/delta)^s) rather than from a feature at P; the split between cutoff
derivatives and residual variation is not identified by these norms. Shrinking the ball does not make ||tau eps~||_{H^{3.1}} small: it stays
of order 1 while sup|eps~| on the ball falls from 1.0e-5 (delta = 0.2) to 3.3e-7 (delta = 0.0165). A
small local forcing norm in the sense of SPEC 3.15 needs a much smaller sup|eps~| near P (the trial's residual there is 1e-7 .. 1e-5), not a
smaller ball. These are floating values (sampled field, discrete Fourier transform), cited as evidence only.

Decomposition of the localized forcing (lead's N10, 04:57Z; own code src/forcing_decomp.py, runs/n10/*.json; FLOATING): model = least-squares
polynomial in (x - x_*, y), odd in y, degree <= 5, fitted on supp tau.

| scale | ||tau eps~||_{H^3.1} | ||tau model|| | ||tau (eps~ - model)|| | relative rms misfit | Gaussian window ||w eps~|| |
|---|---:|---:|---:|---:|---:|
| delta = 0.0165 (tau: 7/4, 9/4 delta; boxes 0.08/N256 and 0.16/N512 agree) | 1.5521 | 1.5587 | 0.6138 | 0.325 | 0.02878 (sigma 0.01), 0.04218 (sigma 0.02) |
| 0.5-disc (tau = 1 on B_0.39, 0 outside B_0.5; box 0.8/N1024) | 1.4526 | 0.0143 | 1.4520 | 0.996 | 0.260 (sigma 0.1) |

At delta = 0.0165 the linear model y d_y eps~(P) with the certified d_y eps~(P) = (mu~ - 1) g = -6.702e-7 has norm 0.1210; the H^{3.1} energy
fraction above |xi| = 1000 is 0.766 (above 3000: 0.179); ||tau||_{H^3.1} = 7.65e6. The lead's values (1.56, 0.61, 0.029, 0.042, 0.12) are
reproduced. The normalization ratio ||tau eps~||_{H^3.1} / (||tau||_{H^3.1} sup|tau eps~|) is 0.615 at delta = 0.0165 (lead: 0.61-0.65 across
delta = 0.0165, 0.033, 0.066) and 4.28 on the 0.5-disc. Reading (the model/remainder split is not orthogonal, so it does not identify how much
of the norm comes from the derivatives of the cutoff versus the variation of the residual): on the small ball the numbers are consistent with a substantial contribution from the
localization (the cutoff acting on the values of the smooth part of eps~); on the 0.5-disc the polynomial part is 1 percent of the norm and
the non-polynomial knot-scale structure carries it (7.5). The knot-scale attribution of 7.5 therefore applies to the 0.5-disc (and larger)
norms, not to the small cut-off balls.

## 7.8 X3 minus the trial: the four jets at P (FLOATING, evidence only; lead's request 01:51Z; shift 3)
h = X3 - rho~ with X3 from its exact formula (src/x3.py) and rho~ the certified trial; on a log-polar grid r in [7.65e-4, 7.65e5] (Nr x Nt =
6000 x 256 and 12000 x 512), U[h] and the raw strain c[h] = psi[h]_xy(0) by the grid modal Green inverse (src/inverse.py, power-law tail fit);
axis jets by modal sums, cubic splines in t at x_* (src/x3_minus_trial_jets.py; runs/jets/x3_minus_trial_N*.json). Definitions: z = h_y(P),
v = h_xy(P), u = W[h]_1(P) = U_1[h](P) + x_* c[h]/3, w = d_y W[h]_2(P) = d_y U_2[h](P) + c[h]/3 (on the axis U_1 = -sum_n 2n psi_n/r,
d_y U_2 = sum_n 2n (psi_n/r)').

| grid | c[h] | z = h_y(P) | v = h_xy(P) | U_1[h](P) | d_y U_2[h](P) | u = W[h]_1(P) | w = d_y W[h]_2(P) |
|---|---:|---:|---:|---:|---:|---:|---:|
| 6000 x 256 | -1.02774e-8 | -5.428e-9 | -3.60e-10 | 4.4761e-8 | 2.194e-9 | 1.5299e-8 | -1.232e-9 |
| 12000 x 512 | -1.03011e-8 | -5.581e-9 | +2.93e-10 | 4.5356e-8 | 2.091e-9 | 1.5826e-8 | -1.343e-9 |

The fine grid's c[h] agrees with the certified enclosure of c[X3 - rho~] (-[1.03009e-8, 1.03014e-8], section 7.2/5) to five digits; z, u, w are
stable to 3-4 percent between the grids; v is at the resolution floor (sign flips). Reading: in these four quantities X3 lies within about
1.6e-8 of the trial (|u| = 1.6e-8, 0.7 of the radius 2.2e-8 of the lead's trial-centred jet exclusion; |z| = 5.6e-9, |w| = 1.3e-9,
|v| < 4e-10), so X3 is plausibly inside that ball; X3's own canonical source point would sit at x_* - u/w'(P) = x_* - 1.56e-9. sup|h| on the
grid is 1.53e-7 (1.5e-10 of sup|rho|). Floating: the velocity of h is a grid inverse (relative accuracy about 1e-9 on the big fields, which
is why the direct V_1^{X3}(x_*, 0) from the inverse of the full X3 density, 1.7e-7 to 2.3e-7, is not usable; the difference-based u is).

## 7.9 N9: the constants R and E of the auxiliary source inverse at P (FLOATING, independent code; lead's request 02:42Z; shift 3)
src/aux_R.py reproduces, with the trial's modal representation (fine t grid, degree-7 interpolation to the Cartesian points, exact angular
sums) and spectral derivatives, the constants of FR 5(o) / SPEC 3.15 (S2)-(S3) at delta = 0.0165, s = 3.1, cutoff theta = chi(|X - P|) with
chi = 1 on [0, 2 delta], 0 on [3 delta, inf) (e^{-1/t} step), w = theta (V - diag(A, mu)(X - P)), q = theta (grad rho~ - (0, g)), unitary FFT,
W_r(f) = (2 pi)^{-1} int <k>^r |f^|, P_s(f) = s 2^{s-2} (W_1(f) + alpha_{s-1} ||f||_{H^s}), T_s(w) = s(s-1) 2^{s-4} sum_i (W_2(w_i) + beta_{s-1} ||w_i||_{H^s}),
R = T_s(w) + P_s(q_1) + P_s(q_2), E = ||div w||_inf/2 + s ||Dw||_{inf,F} + ||q||_inf (runs/n9/aux_R_n{256,512}.json):

| grid | ||q_1||_{H^s} | ||q_2||_{H^s} | ||w_1||_{H^s} | ||w_2||_{H^s} | W_1(q_1), W_1(q_2) | W_2(w_1), W_2(w_2) | T_s(w) | P_s(q_1), P_s(q_2) | R | E |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 256^2 (dx 6.25e-4) | 1.16305e4 | 1.21143e4 | 182.404 | 86.9913 | 5.71982, 6.43428 | 52.3252, 23.5711 | 1064.13 | 2.08250e4, 2.16945e4 | 4.35836e4 | 0.070497 |
| 512^2 (dx 3.125e-4) | 1.16311e4 | 1.21151e4 | 182.417 | 86.9936 | 5.72137, 6.43611 | 52.5176, 23.6390 | 1065.09 | 2.08262e4, 2.16958e4 | 4.35871e4 | 0.070538 |

The lead's values (code/aux_R.py in the lead's lane: 1.163e4, 1.211e4; 182, 87; 5.7, 6.4; 52, 24; 1064; 2.08e4, 2.17e4; R 4.36e4; E 0.0705) are
reproduced to the printed digits; the two grids agree to 4-5 digits. E = 0.0705 here is the actual value of the energy perturbation for this
cutoff (compare the Taylor bound E <= C_V delta <= 0.2202 of section 7.7, which is an upper bound for all admissible cutoffs with C_theta = 2);
R = 4.36e4 enters the auxiliary inverse norm bound (1/a_s)(1 + R/(a_0 - a_s))^s of SPEC 3.15 (S6): with a_s = kappa - E = 3.374 - 0.0705 = 3.3035
and d = a_0 - a_s = 1 + (A + mu)/2 - kappa + s ||Dw||_inf,F = 3.2553 it is 1.9e12 at s = 3.1 (floating), i.e. the auxiliary inverse is bounded
but with a uselessly large constant in the unscaled H^{3.1} norm. The lead's dilation corollary (V31, under verification) rescales the operator
by D_ell u(Y) = u(P + ell Y): R~(ell) uses W_r(f~) = (2 pi)^{-1} int <ell k>^r |f^| dk, ||f~||_{H^s} = ell^{-1} (int <ell k>^{2s} |f^|^2)^{1/2} with an
extra 1/ell for the components of w, and the forcing is measured in N_{1/ell}(f)^2 = int (ell^{-2} + |k|^2)^s |f^|^2 dk. With the same code
(runs/n9/aux_R_n{256,512}.json; tau = 1 on B_{7 delta/4}(P), supported in B_{9 delta/4}(P)):

| ell | R~(ell) | (1 + R~/d)^s/(kappa - E) | N_{1/ell}(tau eps~) | bound x forcing |
|---|---:|---:|---:|---:|
| 1 | 4.3584e4 / 4.3587e4 | 1.879e12 / 1.880e12 | 1.5521 / 1.5576 | 2.92e12 / 2.93e12 |
| 0.0165 | 22.550 / 22.566 | 185.5 / 185.9 | 1.5590 / 1.5645 | 289.2 / 290.8 |
| 0.01 | 11.809 / 11.818 | 34.96 / 35.03 | 1.5716 / 1.5770 | 54.95 / 55.25 |
| 0.005 | 6.0253 / 6.0300 | 7.789 / 7.801 | 1.6437 / 1.6489 | 12.80 / 12.86 |
| 0.0035 | 5.4356 / 5.4389 | 6.355 / 6.362 | 1.7918 / 1.7966 | 11.39 / 11.43 |
| 0.0025 | 6.4672 / 6.4695 | 8.997 / 9.004 | 2.2693 / 2.2731 | 20.42 / 20.47 |
| 0.0015 | 12.382 / 12.384 | 39.26 / 39.27 | 5.9501 / 5.9515 | 233.6 / 233.7 |

(256^2 / 512^2 grids.) The lead's floating values (R~ 22.6, 11.8, 6.0, 5.4; bounds 186, 35, 6.4; forcing 1.565, 1.577, 1.649, 1.797, 2.27, 5.95) are reproduced. The localized forcing is
insensitive to ell (its spectral content sits at |k| ~ 1e3, above 1/ell for all three ell, see 7.7c), so the product "inverse bound x forcing",
which a local closing condition would compare with the radius, is at best 11.4 (ell = 0.0035): not small. Floating evidence only.

## 7.10 Rigorous upper bound of the localized forcing norm at P (this lane's computation, RIGOROUS method; independent audit of the final version pending: the verifier's topics 115/117 audited the superseded v1.0; shift 4; src/cert_forcing.py, src/cert_forcing2.py; runs/forcing/)
Quantity (SPEC 3.15, the forcing term of the lead's local source estimate, so far only floating in SPEC/FR): F_s = ||tau eps~||_{H^s} with
s = 31/10, the inhomogeneous norm ||f||_{H^s}^2 = int (1 + |xi|^2)^s |f^(xi)|^2 dxi (unitary Fourier transform), and the dilated norm
N_lam(f)^2 = int (lam^2 + |xi|^2)^s |f^|^2 at lam = 500 (= N_{1/ell} at ell = 1/500, the scale of the verifier's certified auxiliary inverse
bound, SPEC 3.15 / 7.9). Cutoff: tau(X) = S(sigma), sigma = (|X - P| - 7 delta/4)/(delta/2), S(sigma) = step(1 - sigma),
step(u) = 126 u^5 - 420 u^6 + 540 u^7 - 315 u^8 + 70 u^9 (the lead's tau_poly9; C^4; tau = 1 on B_{7 delta/4}(P), supp tau in B_{9 delta/4}(P),
admissible for SPEC 3.15), delta = 33/2000 exactly, P = (x_*, 0) with x_* in the certified bracket [8.60006380515688, 8.600063805157474] of 7.2
(these are the binary64 numbers of runs/axis_cell.json; the S1 ball 8.600063805157177 +/- 2.94e-13 lies inside; asserted in the code). The
residual eps~ is that of the X3 trial rho~ (data/trial_v2_h0.008.npz, Arb data data/cert_green.npz).
Method (docstrings of src/cert_forcing.py (v1) and src/cert_forcing2.py (v2)): (1) Hoelder in the Fourier variable,
(lam^2+|xi|^2)^{3.1} = [(.)^3]^{0.9} [(.)^4]^{0.1}, so N_lam^2 <= I3^{0.9} I4^{0.1} with I3 = lam^2 ||(lam^2 - Lap) f||_2^2 + ||grad (lam^2 - Lap) f||_2^2
and I4 = ||(lam^2 - Lap)^2 f||_2^2 (Plancherel; f = tau eps~ is in W^{4,infty} with compact support). (2) The L^2 norms are bounded by sums over
polar sub-cells about the origin (13 spline sub-cells of the certificate x 16 angular cells, each split 64 x 8) covering B_{3 delta}(P)
(coverage asserted as in 7.7) of area x sup^2, the lower half-plane by parity. (3) The Cartesian derivatives of eps~ (|alpha| <= 4) from
BIVARIATE Taylor models in (t - t_a, theta - theta_c): the per-mode Taylor models of d_t^i eps_N (i <= 4; cert_resid._cell_core_deriv, the same
objects as the derivative certificate 7.3b) summed over the modes with the Taylor coefficients of (2N+1)^j sin((2N+1)(theta_c + phi) + j pi/2) in
phi (Arb values at theta_c; remainder (2N+1)^{j+9} w^9/9!), which keeps the angular cancellation that the Wiener sums W_i_j of 7.3b lose; the
Cartesian recursion of 7.7 applied to the bivariate models; suprema by tensor-Bernstein coefficients on the sub-cells after exact re-centring.
(4) v1: pointwise Leibniz bounds for f = tau g (g = eps~) in terms of products of suprema (tau's radial derivatives from the exact integer
polynomials S^{(j)}, Arb ranges on each sub-cell's sigma range in centred form, rho >= max(dist_min, 7 delta/4)). v2: on each block (2 x 2 per
cell) tau and all its Cartesian derivatives are bivariate Taylor models too (q = |X - P|^2 as a BiTM; q^{-1/2} by the binomial series with a
certified tail; sigma and S^{(j)}(sigma) by exact polynomial composition; d^k/dq^k by Faa di Bruno; D^alpha tau = sum_k S^_k P_{alpha,k}(u, v)
with symbolic integer polynomials), the Leibniz products f, grad f, Lap f, grad Lap f, Lap^2 f are formed exactly as BiTMs and bounded per fine
sub-cell; sub-cells entirely inside (tau = 1) use the bounds of g, sub-cells straddling the ends of the transition use the v1 bounds. All
arithmetic rigorous (src/midrad.py mid-rad float64 with outward rounding; Arb for transcendental values; Arb with the exact exponents 9/20,
1/20 in the final Hoelder step).

RESULTS (delta = 33/2000, cutoff p9; 13 radial cells ci 4096..4108, r in [8.54945, 8.65643], theta_max 0.0057558, 16 angular cells, fine
sub-cells 64 x 8 per cell, Qs = 12, Qp = 8; v2: blocks 2 x 2 per cell, series length 16, regimes inside 26079 / transition 16502 / straddle 1368 /
outside 62547 sub-cells; floating values from src/forcing_float.py, FFT on a 4096^2 grid, dx = 2.27e-5). ROUNDING: every rigorous decimal in the
two tables below is rounded UPWARD (a ceiling of the stored JSON value); the floating values are rounded to nearest and are not bounds:
| quantity | RIGOROUS v2.2 upper bound (runs/forcing/v22_p9_merged.json) | RIGOROUS v1.2 upper bound (runs/forcing/v12_p9_merged.json) | floating (FFT) |
|---|---:|---:|---:|
| ||tau eps~||_{H^3} | 0.7759 | 1.0446 | 0.6646 |
| ||tau eps~||_{H^4} | 893.16 | 1243.17 | 753.65 |
| ||tau eps~||_{H^{3.1}} | **1.5700** | 2.1207 | 1.3296 (lead's floating 1.33 reproduced; Hoelder bound of the floating I3, I4: 1.3428) |
| N_500, order 3 | 1.8107 | 2.1083 | 1.6172 |
| N_500, order 4 | 1638.56 | 2107.72 | 1308.9 |
| N_500(tau eps~), order 3.1 | **3.5769** | 4.2064 | 3.1128 |
Second cutoff shape (same method, v2.2, 26 half-cell runs 09:22Z-09:43Z; runs/forcing/v22_p11_merged.json, SHA-256
48d02b93a9c4d6f2db458df247473c642b61efb3ace66738ab67fef3460e8d1c; floating runs/forcing/float_p11_dx90.json, FFT 2048^2, dx 4.5e-5): the C^5 degree-11
step p11, step(u) = 462 u^6 - 1980 u^7 + 3465 u^8 - 3080 u^9 + 1386 u^10 - 252 u^11 (same radii 7 delta/4, 9 delta/4). Ceilings (rounded UPWARD) and floating:
| quantity (p11 cutoff) | RIGOROUS v2.2 upper bound | floating (FFT) |
|---|---:|---:|
| ||tau eps~||_{H^3}, H^4, H^{3.1} | 1.4436, 1605.54, **2.9112** | 0.8253, 1015.0, 1.6663 |
| N_500: order 3, order 4, order 3.1 | 2.4697, 2587.88, **4.9508** | 1.7348, 1576.6, 3.3693 |
(stored: 1.4435908732415141, 1605.5390013838633, 2.9111313478268608; 2.46965764535627, 2587.8751684282747, 4.9507091269616197). The steeper C^5 step
has a larger forcing norm (floating 1.67 against 1.33) and a larger sup-based loss (factor 1.75 against 1.18): the p9 cutoff is the better choice
for the local estimate, and both are admissible for SPEC 3.15 (tau = 1 on supp chi, supp tau in B_{9 delta/4}; the (S4) constants use cutoff
derivatives through order 5, which both steps have in W^{5,infty}).
Rigorous suprema (upper bounds, rounded UPWARD) of |d_x^a d_y^b eps~| (identical in all versions v1.1-v2.2; sampled maxima of the floating evaluator on polar
grids in parentheses, rounded to nearest; every sample is inside its bound):
| alpha (a,b) | sup on B_{9 delta/4}(P) | sup on B_{3 delta}(P) |
|---|---:|---:|
| (0,0) | 5.055e-7 (4.997e-7) | 9.425e-7 (9.353e-7) |
| (1,0), (0,1) | 5.429e-5 (5.356e-5), 4.122e-5 (4.039e-5) | 7.624e-5 (7.581e-5), 6.299e-5 (6.221e-5) |
| (2,0), (1,1), (0,2) | 8.311e-3 (8.290e-3), 2.228e-3 (2.228e-3), 2.943e-3 (2.919e-3) | 9.136e-3 (9.082e-3), 2.967e-3 (2.959e-3), 3.535e-3 (3.532e-3) |
| (3,0), (2,1), (1,2), (0,3) | 1.495 (1.486), 0.3289 (0.3289), 0.1381 (0.1381), 0.1985 (0.1981) | 1.648 (1.647), 0.3289, 0.1381, 0.2063 (0.2063) |
| (4,0), (3,1), (2,2), (1,3), (0,4) | 280.9 (280.2), 54.57 (54.57), 13.63 (13.63), 7.371 (7.371), 10.74 (10.67) | 311.7 (311.1), 54.57, 13.63, 7.371, 12.70 (12.68) |
Every certified entry is the 4-significant-digit CEILING of the JSON value (the verifier found 22 of 36 entries of the first version rounded to
nearest, i.e. inward; corrected 08:33Z). Euclidean gradient bounds (from the two component suprema): |grad eps~| <= 6.816e-5 on B_{9 delta/4}(P),
<= 9.889e-5 on B_{3 delta}(P).
So the enclosures of the residual derivatives are tight (1-2 percent), and the rigorous H^{3.1} bound is within 18 percent of the floating
value (the remaining slack is the sup-versus-L^2 bounding on the fine sub-cells and the straddling sub-cells). The stored values behind the
ceilings (v2.2): I3 = 0.60188503371042545, I4 = 797718.94142901117, order-3 0.77581249906818694, order-4 893.15113022881599, order-3.1
1.569905786431367 (lam = 1); 3.2785862643663934, 2684872.1006275327, 1.8106866831029587, 1638.5579332533632, 3.5768864780441523 (lam = 500);
v1.2: 1.0909844782969449, 1545466.3072703849, 1.0445020240750831, 1243.1678516074912, 2.1206614142028606; 4.4446342205920883, 4442472.3427096438,
2.108230115663869, 2107.7173298878683, 4.2063697756527541. The v2.1 -> v2.2 and v1.1 -> v1.2 code changes (below) left the ceilings unchanged.
Consequences (with the verifier's certified constants; the forcing bound itself awaits their audit): K_1 < 0.3181 (ver topic 86) gives for the
first term of the local estimate (S4) at the trial, tau L h = -tau eps~ for the Newton correction, K_1 ||tau eps~||_{H^{3.1}} < 0.3181 x 1.5700
< 0.4995 (floating 0.42); the certified auxiliary inverse bound < 473 in N_500 (ver topic 97) gives ||A^{-1}(tau eps~)||_{N_500} < 473 x 3.5769
< 1691.9 (with the floating forcing: about 1472), an auxiliary-inverse response bound only. These quantify the forcing in the lead's local source
estimate; they are not a closing inequality (the local estimate is a priori, no global inverse exists, FINAL_REPORT section 10). The sup table is
also a rigorous C^4 bound of the residual near P
(for example |eps~| <= 9.425e-7, |d_x eps~| <= 7.624e-5, |d_y eps~| <= 6.299e-5, |grad eps~| <= 9.889e-5 on B_{0.0495}(P)).
History and referee round (shift 4). A first complete run (v1.0, runs/forcing/p9_K64_n16_P8_merged.json, 07:31Z) gave 5.6533 (N_500 8.8718);
the external referee round astra/forcing1 (answer 07:5xZ, astra/forcing1/answer.md) found: (1) N_500 quoted 8.8717 for the JSON value
8.87174795 (inward rounding); (2) the geometric angular sub-cells were shifted by w_up - dtheta/2 ~ 2.7e-20 from the Bernstein sub-cells (the
geometry now IS the Bernstein sub-cell, with the distance minimum at theta = 0 for sub-cells straddling the axis); (3) non-outward float
conversions of Arb bounds in Cutoff.quantities (fixed with outward conversions; its counterexample, a point just inside the outer radius
rejected as outside, no longer occurs); (4) the x_* bracket literals are binary64 numbers (documented and asserted against the S1 ball, above);
(5) a possible amplified underflow of the degree weights in the BiTM truncation bound (asserted away: weights > 2^-900); (6) finish() used a
float pow with the inexact exponent 0.45 (now Arb with the exact exponents 9/20, 1/20, outward); (7) the floating JSON's hoelder_bound fields
had an extra square root (recomputed); (8) merge metadata (radial_cells, partial) copied from the first part and incomplete compatibility checks
(fixed; merge now checks that the parts cover (radial cells x angular cells) exactly once). The referee found no defect in the Hoelder/Plancherel
step, the Leibniz and radial formulas, the cutoff polynomials, the geometry and area formulas, the BiTM/Bernstein algebra, the jets and the
recursion, the assembly, the merge arithmetic and the residual interface, and verified all 43949 saved rows (exact rational recomputation of
every row's contribution below the accumulated outputs). Independently of the referee, the Arb range evaluation of the cutoff polynomials in
monomial form at a ball lost up to five orders of magnitude near sigma = 1 (T0 = sup tau came out as 1.08); it is now evaluated in centred form
(Taylor shift to the sub-interval midpoint), which is tight to 1e-4; this, not the enclosures, was the main loss of v1.0 (5.6533 -> 2.1207).
The verifier's own audit of v1.0 (their topics 115, 117, 07:42Z-08:25Z) confirmed the finite components (all 106496 geometry boxes, the
cutoff ranges, the 43949 row aggregates) and found 22 of 36 display ceilings of the first table rounded to nearest (all tables now carry
ceilings), a gradient statement that mixed the component bound with the Euclidean norm (corrected), the jet-remainder sums' relative-only
rounding rule not outward for subnormal operands (an additive (Nmax + 2) eta allowance was added; the referee of round 2 checked all 390 sums of
v2.1 exactly: outward), and missing per-row Hessian inputs (every G/T factor and every Taylor-model remainder entering a product rule is now
stored per row). Round 2 (astra/forcing2/answer.md, on v1.1/v2.1): "no defect invalidating the supplied p9 v2.1 bounds, conditional on the
upstream residual and regularity hypotheses"; all round-1 repairs pass; the 789 executed series tails, all 832 blocks (largest accepted ratio
0.5954 and largest tail 0.0317 occur in blocks whose fine sub-cells are all inside, where the cutoff model is not used; the largest ratio in a
block with transition sub-cells is 0.3508 with tail 1.1e-6), all 106496 sub-cell geometries, the 15 symbolic Faa di Bruno tables, the Leibniz
expressions, the regime logic (the unclipped outward sigma interval decides the regimes), the alignment identities (exact for 2 x 2 blocks), the
merge (208 pairs) and every saved row were recomputed; four angular cells were fully replayed (2048 rows, all matching). Its general-code items
(the series tail used a float pow; the p11 cutoff path crashed; the block shifts bs hb are exact only for nbs, nbp <= 2; the fine-step coverage
assertion was a float test; the Taylor-model domain convention (remainder valid on parent domain cap block, outward sub-cells overhang by about
1e-19) should be stated) are repaired or stated in v2.2 / v1.2, whose outputs reproduce the v2.1 / v1.1 values.
Other fractional orders from the same pinned integrals (src/forcing_orders.py, runs/forcing/orders.json; Hoelder N <= I3^{(4-s)/2} I4^{(s-3)/2} in
Arb with exact exponents; ceilings with 5 significant digits; this covers the lead's proposed order s = 3.06 and the window [3.05, 3.1] of the
verifier's topic 97 inverse bounds): p9, lam = 1: s = 3.05: 1.1037, s = 3.06: 1.1843, s = 3.1: 1.57, s = 3.5: 26.324; p9, lam = 500: s = 3.05: 2.545, s = 3.06: 2.7243, s = 3.1: 3.5769, s = 3.5: 54.47; p11, lam = 1: s = 3.05: 2.05, s = 3.06: 2.199, s = 3.1: 2.9112, s = 3.5: 48.143; p11, lam = 500: s = 3.05: 3.4967, s = 3.06: 3.7485, s = 3.1: 4.9508, s = 3.5: 79.945; v1.2 (p9), lam = 1: s = 3.05: 1.4883, s = 3.06: 1.5976, s = 3.1: 2.1207, s = 3.5: 36.035.
Floating Hoelder values from the floating integrals for comparison (p9, lam = 1): s = 3.05: 0.9447, 3.06: 1.0135, 3.1: 1.3428, 3.5: 22.38.
Upstream dependencies and hypotheses (what 7.10 inherits; for the verifier's conditional verdict). (i) The per-mode Taylor models of d_t^i eps_N
(i <= 4) on the 13 spline sub-cells ci 4096..4108 come from cert_resid._cell_core_deriv (src/cert_resid.py 1911be77..., identical arithmetic to
the pinned 15a7535d... audited in two astra rounds, cert1/cert2, and used for 7.3/7.3b), evaluated on data/cert_green.npz
(c2c2e4f73f5ac6ee49fd0052b81700fc88ee68d01a5a526691cf03c2b82c2ef1: the Arb boundary values A_n, B_n of the canonical Green functions at the
sub-cell starts and the exact spline polynomials of the trial, src/cert_green.py) and data/trial_v2_h0.008.npz
(a069d85d102e17340778042f85c003705716ba799c0f68873d10c1c582ea4874). These are the same objects as the R0 certificate of 7.3 (whose middle-region
values the verifier reproduces with their independent second method, in progress) and the derivative certificate 7.3b; their validity rests on
the Taylor-model method of 7.1 (ODE recursion for A_n, B_n with certified remainders; exponential-polynomial residual products; mid-rad float64
and Arb). (ii) The identification of eps~ = sum_N eps_N(t) sin((2N+1) theta) with the canonical residual of the trial (closed-form canonical
inverse, section 5; normalization c_l = 1/k exact, 7.2). (iii) Regularity: tau in C^4 (p9) or C^5 (p11), eps~ in C^5 between the spline knots and
C^4 across them, so f = tau eps~ is in W^{4,infty} with compact support and the Plancherel identities for the orders 3 and 4 hold. (iv) The
certified bracket of x_* (7.2, S1) and delta = 33/2000 exactly. Everything else (angular Taylor coefficients, Cartesian recursion, cutoff
polynomials, geometry, Bernstein bounds, Hoelder, merge) is internal to cert_forcing2.py and was checked in the two astra rounds and in the
verifier's finite audits (topics 115, 117-122). The astra round-2 verdict is stated conditional on (i)-(iii). Verifier topic 122 (FINAL 10:13Z,
research/forcing_v22 in their lane): "CONFIRMED v2.2 finite components, physical forcing OPEN": all 43949 rows pass two independent aggregations,
the six ceilings pass exact comparisons, all 263694 cutoff range checks pass two methods, nine pinned replays reproduce every result field,
137235 pointwise inequalities and 331 series tails per method pass; OPEN on their side are (i) above (the residual Taylor models, which their
topics 98/99/101 and a residual-jet reconstruction would cover) and the composed F enclosures as mathematical objects, i.e. the statement
"1.5700 bounds the physical norm" remains conditional on the certificate method of 7.1.
Reproducibility: the CPU guard pauses any python process of this lane older than 120 s that is not the lane's oldest running one
(bin/cpu_guard.py), so the computation is run in pieces (v1: cell by cell, about 50 s each; v2: cell by angular half, about 45 s each) and merged:
```
for ci in $(seq 4096 4108); do python3 src/cert_forcing.py data/cert_green.npz data/trial_v2_h0.008.npz runs/forcing/v12_p9_c$ci.json 33/2000 p9 64 16 8 8 $ci $ci; done
python3 src/cert_forcing.py merge runs/forcing/v12_p9_merged.json runs/forcing/v12_p9_c4*.json
for ci in $(seq 4096 4108); do for q in "0 7" "8 15"; do set -- $q; python3 src/cert_forcing2.py data/cert_green.npz data/trial_v2_h0.008.npz runs/forcing/v22_p9_c${ci}_q$1.json 33/2000 p9 64 16 8 8 2 2 16 $ci $ci $1 $2; done; done
python3 src/cert_forcing2.py merge runs/forcing/v22_p9_merged.json runs/forcing/v22_p9_c4*_q*.json
python3 src/forcing_float.py data/trial_v2_h0.008.npz 0.0165 p9 4.5e-5 runs/forcing/float_p9_dx45.json      # floating comparison, 140 s
```
SHA-256 (runs/forcing/SHA256.txt, 09:16Z; FINAL code and outputs): src/cert_forcing.py (v1.2) 5066d240ea60b89d137025f60fbda4e631b7cf7e67f8ef5968bab307bbeddcd9;
src/cert_forcing2.py (v2.2) 012e106b568ec68876058ee0588aa64cfbe9c846dc44523c164424015c238197; src/forcing_float.py
aa67a9b40ccdbfdce011e76c7ad30bf7c6a5ec75e5ee96617ff340cade748a80; src/cert_resid.py 1911be775730931d0753099ec74272a08cb10945f33d2183fe37c9d08f2e6053
(= the pinned version 15a7535d... plus the one-line stash `self._last_eps = eps`, arithmetic unchanged); runs/forcing/v22_p9_merged.json
b5f597c90a0928dd9a5ea87af12953bcc33f46321ef60c3d5b014d9bef3a7201; runs/forcing/v12_p9_merged.json cc9e187aac3b2b01023ed99363b261c6f0658d5f7a56e87960dee134488fa0b0.
Earlier versions kept for the audit record: v1.0 a2f028c1... / p9_K64_n16_P8_merged.json b681b9c4... (5.6533); v1.1 374e6ce1... / v11_p9_merged.json
a0d2bba0... (2.1207); v2.1 be49284e... / v21_p9_merged.json 20d44c6c... (1.5700). Commands below produce the v1.2 / v2.2 files (names v12_*, v22_*).

## 8. Reproducibility (all commands from the lane root; single-threaded; times on this machine)
```
python3 src/x3.py                                              # reconstruction test vs gen_shape.py (0.1 s)
python3 src/inverse.py                                         # manufactured inverse tests (1 s)
python3 src/x3_resid.py 16875 512 1e-4 1e6 runs/resid_N16875_q512.json      # 8 s
python3 src/x3_modes.py 80000 4096 1e-4 1e5 260 data/x3_modes_N80000_q4096_M260.npz   # 34 s, 320 MB (regenerable)
python3 src/modal_fit.py data/x3_modes_N80000_q4096_M260.npz 0.008 0.02 data/trial_v2_h0.008.npz   # 55 s
python3 src/trial_green.py data/trial_v2_h0.008.npz             # closed-form inverse vs grid inverse (2 min)
python3 src/trial_resid.py data/trial_v2_h0.008.npz 1200 runs/trial_v2_resid.json   # 1 min
python3 src/midrad.py; python3 src/cert_spline.py data/trial_v2_h0.008.npz
```
Published evaluator rerun: runs/pubeval (copy of d_evaluator/code; gen_audit.sh, see WORKLOG 12:51Z).
Environment: python 3.9, numpy 2.0.2, scipy 1.13.1, python-flint 0.6.0 (Arb), mpmath 1.3.0; CPU single thread.

#### 7.3b Derivative norms (R1, R3, R5): this lane's RIGOROUS upper bounds (method of 7.1; NOT independently verified, lead 10:24Z); middle region runs/cert_deriv_middle.json (7809 cells, 3.3 h; SHA-256 7408d122c9a8d0a214c48717cf4f43396533d811c992d47d70f1402febabe499), outer region runs/cert_deriv_regions_outer.json (SHA-256 92a27641050b4b9e4ec497237bc83ccc6b643e1b72521f309b52ec4206551f7f), inner region (see below); code src/cert_resid_deriv.py (SHA-256 38e45bcd4400d119fb0a887794c4866bcc1d61eed1c3d69f58616eb7c95d5ac8) with cert_resid._cell_core_deriv, summaries src/cert_deriv_summary.py and src/deriv_region_shells.py (SHA-256 0b96cf4f3a26d116ac1c7f43f7940e2533b3e214a9e93bd5320f9037ecf8cc0d)
Per sub-cell (length <= 0.0019 in t = log r) the Taylor models of d_t^i eps_N give W_i_j := sum_N (2N+1)^j sup_cell |d_t^i eps_N(t)|
>= sup over the cell and over theta of |d_t^i d_theta^j eps~| (i + j <= 2 everywhere; i + j <= 5 on the 377 cells meeting the disc
|X - P| < x_*/4, i.e. r in [6.44, 10.75]). Cartesian derivatives follow from d_x = e^{-t}(cos th d_t - sin th d_th),
d_y = e^{-t}(sin th d_t + cos th d_th): r |grad eps~| <= W_1_0 + W_0_1 and r^2 |d^2 eps~| (any second derivative) <=
W_2_0 + 2 W_1_1 + W_0_2 + W_1_0 + 2 W_0_1 pointwise on the cell. Division by the certified cell minimum m_inf of m(r). Maxima per
dyadic shell (summary runs/cert_deriv_summary.txt, src/cert_deriv_summary.py):
| shell of r | W_0_0/m | W_1_0/m | W_0_1/m | W_2_0/m | W_1_1/m | W_0_2/m | W_eps - d_t eps/m | W_K/m | W_dtK/m |
|---|---|---|---|---|---|---|---|---|---|
| [0.00765, 0.0156) | 2.19e-8 | 2.56e-6 | 8.18e-8 | 9.61e-4 | 9.98e-6 | 3.03e-6 | 2.56e-6 | 450.4 | 1351 |
| [0.0156, 0.0625) | 5.18e-8 | 2.78e-7 | 2.48e-7 | 5.71e-6 | 2.26e-6 | 4.93e-6 | 2.33e-7 | 450.4 | 1351 |
| [0.0625, 0.25) | 5.10e-7 | 4.34e-6 | 5.24e-6 | 3.38e-5 | 5.17e-5 | 1.32e-4 | 4.00e-6 | 450.4 | 1351 |
| [0.25, 1) | 7.04e-6 | 6.39e-5 | 4.08e-4 | 1.37e-3 | 7.63e-3 | 9.86e-2 | 6.05e-5 | 450.5 | 1350 |
| [1, 4) | 1.90e-5 | 7.39e-4 | 3.04e-3 | 8.97e-2 | 9.48e-2 | 8.42e-1 | 7.67e-4 | 450.8 | 1330 |
| [4, 16) | 2.60e-4 | 3.78e-1 | 4.23e-2 | 5.85e+2 | 6.16e+1 | 1.02e+1 | 4.27e-1 | 418.9 | 2119 |
| [16, 64) | 2.03e-5 | 3.94e-3 | 5.03e-3 | 1.09 | 1.04 | 1.50 | 4.33e-3 | 195.2 | 261 |
| [64, 256) | 6.50e-6 | 8.82e-5 | 1.64e-3 | 5.00e-3 | 3.04e-2 | 6.33e-1 | 9.09e-5 | 211.7 | 67.5 |
| [256, 1024) | 6.09e-6 | 2.56e-5 | 1.53e-3 | 5.12e-4 | 9.62e-3 | 6.05e-1 | 2.65e-5 | 218.7 | 47.1 |
| [1024, 3413.1) | 5.56e-6 | 1.70e-4 | 1.19e-3 | 5.47e-2 | 5.05e-3 | 4.66e-1 | 1.66e-4 | 220.8 | 42.0 |
(W_0_0/m here is from the derivative run with the plain Bernstein bound; the R0 table of 7.3 uses the sub-interval bound.)
R1: sup over rmin <= r <= R0 of r |grad eps~| / m <= 0.421 and of r^2 |d^2 eps~| / m <= 7.19e2, both attained in the shell [4, 16)
(the lobe next to P, r ~ 8.8); away from that shell r|grad eps~|/m <= 9e-3 and r^2|d^2 eps~|/m <= 3.7.
R5: ||eps~ - X.grad eps~||_{R0 norm} = sup W_eps_minus_dteps/m <= 0.427 (middle region); ||K~||_{R0 norm} = sup W_K/m <= 450.8 with
K~ = rho~ - X.grad rho~ (K~ is of the size of rho~ itself, L^3 m ~ 448 m at small r), ||d_t K~||/m <= 2119.
R3 (P-disc cells, absolute Wiener sums, not divided by m; maxima over the 377 cells): W_0_0 1.20e-4 (r = 8.790), W_1_0 1.75e-1,
W_0_1 1.95e-2, W_2_0 2.71e2, W_1_1 2.84e1, W_0_2 4.56, W_3_0 4.33e5, W_2_1 4.43e4, W_1_2 6.36e3, W_0_3 1.81e3, W_4_0 7.50e8,
W_3_1 6.92e7, W_2_2 9.84e6, W_1_3 1.82e6, W_0_4 6.98e5, W_5_0 1.45e12, W_4_1 1.20e11, W_3_2 1.56e10, W_2_3 2.82e9, W_1_4 5.02e8,
W_0_5 2.72e8 (all attained at r = 8.57 to 8.79, the lobe); K~: W_K 88.8, W_dtK 988. These are upper bounds; the floating direct
evaluation of section 7.5 (sup of D^alpha eps~ on the lobe disc: 6.7e-5, 1.1e-2, 1.87, 330, 6.2e4 for |alpha| = 0..4) shows that
they are within a factor 2-4 of the actual suprema (e.g. r^4 sup|D^4 eps~| ~ 8.8^4 x 6.2e4 = 3.7e8 against W_4_0 = 7.5e8), so the
large high-derivative norms near P are real, not an artefact of the majorants (answering the verifier's 18:12Z caution).
OUTER REGION (3413 <= r <= 8.228e10; RIGOROUS; chain6b/6c, cert_resid_deriv.py regions only, 8948 cells, 18985 s, done 09:27Z; runs/cert_deriv_regions_outer.json;
table runs/cert_deriv_outer_shells.txt from src/deriv_region_shells.py; all entries 4-significant-digit CEILINGS of the certified per-cell values;
wf = the certified cell maximum of the multiplier (1+u)^{1/2}; r|grad eps~| <= W_1_0 + W_0_1 and r^2|D^2 eps~| <= W_2_0 + 2W_1_1 + W_0_2 + W_1_0 + 2W_0_1 as above):
| shell of r (cell starts) | cells | sup W/m | sup r|grad eps~|/m | sup r^2|D^2 eps~|/m | sup wf W/m | sup wf r|grad|/m | sup wf r^2|D^2|/m | sup (W_eps - d_t eps)/m | sup W_K/m | sup W_dtK/m |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| [3.4e+03, 1e+04) | 566 | 2.951e-05 | 0.002959 | 0.997 | 0.001068 | 0.1071 | 36.07 | 0.0001416 | 221.6 | 40.63 |
| [1e+04, 1e+05) | 1212 | 9.319e-05 | 0.004169 | 1.122 | 0.007369 | 0.3187 | 77.53 | 9.968e-05 | 222 | 40.16 |
| [1e+05, 1e+06) | 1212 | 6.364e-05 | 0.002778 | 0.6704 | 0.007284 | 0.3179 | 76.73 | 8.942e-05 | 222.1 | 39.88 |
| [1e+06, 1e+07) | 1212 | 1.147e-05 | 0.0005602 | 0.1317 | 0.004149 | 0.2028 | 47.65 | 1.869e-05 | 222.1 | 39.83 |
| [1e+07, 1e+08) | 1212 | 1.738e-06 | 8.835e-05 | 0.02071 | 0.001989 | 0.1012 | 23.7 | 2.855e-06 | 222.1 | 39.83 |
| [1e+08, 1e+09) | 1212 | 2.622e-07 | 1.344e-05 | 0.003148 | 0.0009488 | 0.04864 | 11.4 | 4.303e-07 | 222.1 | 39.83 |
| [1e+09, 1e+10) | 1212 | 3.968e-08 | 2.034e-06 | 0.0004762 | 0.0004542 | 0.02328 | 5.451 | 6.508e-08 | 222.1 | 39.83 |
| [1e+10, 1e+11) | 1110 | 6.089e-09 | 3.085e-07 | 7.201e-05 | 0.0002205 | 0.01117 | 2.607 | 9.945e-09 | 222.1 | 39.83 |
whole file: sup W/m 9.319e-05 at r = 3.343e+04; sup r|grad|/m 0.004169 at r = 2.671e+04; sup r^2|D^2|/m 1.122 at r = 2.083e+04; multiplier forms 0.007369, 0.3187, 77.53; (W_eps - d_t eps)/m 0.0001416; W_K/m 222.1; W_dtK/m 40.63
Taylor remainders of the outer cells: eps 1.6e-13 (i = 0, 1), 5.2e-11 (i = 2); A/B 7.5e-5 absolute (the outer A_n, B_n are large; the W bounds include them
and reproduce the R0 certificate's 9.3189e-5). So on the whole exterior R1: r|grad eps~|/m <= 4.169e-3 (at r = 2.67e4) and r^2|D^2 eps~|/m <= 1.122
(at r = 2.08e4), both in the far-field Theta_1 mismatch band of X3; with the (1+u)^{1/2} multiplier 0.3187 and 77.53. R5 on the exterior:
||eps~ - X.grad eps~||/m <= 1.416e-4, ||K~||/m <= 222.1, ||d_t K~||/m <= 40.63.
INNER REGION (5.155e-5 <= r <= 0.007651; this lane's RIGOROUS upper bounds, same method; 2632 cells, 5277 s, done 10:55Z; runs/cert_deriv_regions_inner.json,
SHA-256 5ab4a164ea9424ef64dba4af7296080f035165764545ef91e111404634d21bb4; table runs/cert_deriv_inner_shells.txt; ceilings as above):
| shell of r (cell starts) | cells | sup W/m | sup r|grad eps~|/m | sup r^2|D^2 eps~|/m | sup wf W/m | sup wf r|grad|/m | sup wf r^2|D^2|/m | sup (W_eps - d_t eps)/m | sup W_K/m | sup W_dtK/m |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| [5e-05, 0.0001) | 349 | 1.498e-09 | 8.607e-09 | 1.323e-07 | 1.5e-09 | 8.615e-09 | 1.324e-07 | 6.045e-09 | 450.6 | 1352 |
| [0.0001, 0.0002) | 365 | 1.499e-09 | 9.285e-09 | 3.346e-07 | 1.5e-09 | 9.294e-09 | 3.349e-07 | 6.073e-09 | 450.6 | 1352 |
| [0.0002, 0.0005) | 482 | 1.596e-09 | 1.385e-08 | 1.629e-06 | 1.598e-09 | 1.386e-08 | 1.631e-06 | 6.404e-09 | 450.6 | 1352 |
| [0.0005, 0.001) | 365 | 1.73e-09 | 2.377e-08 | 4.763e-06 | 1.732e-09 | 2.38e-08 | 4.768e-06 | 6.624e-09 | 450.6 | 1352 |
| [0.001, 0.002) | 365 | 2.117e-09 | 3.093e-08 | 6.368e-06 | 2.119e-09 | 3.096e-08 | 6.375e-06 | 8.439e-09 | 450.6 | 1352 |
| [0.002, 0.004) | 365 | 2.171e-09 | 2.814e-08 | 4.808e-06 | 2.174e-09 | 2.817e-08 | 4.814e-06 | 1.028e-08 | 450.6 | 1352 |
| [0.004, 0.00766) | 341 | 9.19e-06 | 0.0002762 | 0.01396 | 9.203e-06 | 0.0002766 | 0.01398 | 0.0002583 | 450.6 | 1352 |
whole file: sup W/m 9.19e-06 at r = 0.007146; sup r|grad|/m 0.0002762 at r = 0.006932; sup r^2|D^2|/m 0.01396 at r = 0.007214; multiplier forms 9.203e-06, 0.0002766, 0.01398; (W_eps - d_t eps)/m 0.0002583; W_K/m 450.6; W_dtK/m 1352
Taylor remainders of the inner cells: eps <= 1.1e-18 (i = 0, 1), 1.1e-18 (i = 2); A/B 5.5e-32. On the inner region R1: r|grad eps~|/m <= 2.762e-4 (at
r = 0.00693, the last cells before rmin) and r^2|D^2 eps~|/m <= 1.396e-2 (at r = 0.00721); for r < 0.004 they are below 3.1e-8 and 6.4e-6; R5:
||eps~ - X.grad eps~||/m <= 2.583e-4, ||K~||/m <= 450.6, ||d_t K~||/m <= 1352 (K~ is of the size of rho~ itself at small r, as in the middle region).
R4 (origin): sup W/r^5 = 1.2562e-3 on the inner cells (at r = 5.155e-5; runs/cert_summary_all.txt). With the middle (7809 cells), outer (8948) and
inner (2632) regions, the first and second derivative norms of the residual are now bounded rigorously on the whole plane except the two tails
(r < 5.155e-5 and r > 8.228e10, where only the zeroth-order majorants of 7.3 are available): sup over 5.155e-5 <= r <= 8.228e10 of r|grad eps~|/m
<= 0.4195 and of r^2|D^2 eps~|/m <= 713.2, both attained at the lobe next to P (r = 8.78); away from the shell [4, 16) the suprema are 8.559e-3 and
4.516 (middle shell [16, 64)), 4.169e-3 and 1.122 (outer), 2.762e-4 and 1.396e-2 (inner). Whole-plane status: chain6 complete (chain6b/6c).

- N8 (shift 3): `python3 src/n8_floating.py data/trial_v2_h0.008.npz runs/n8/n8_floating.json 1e-4 1e-4` (10 s, floating);
  `python3 src/cert_n8.py data/cert_green.npz data/trial_v2_h0.008.npz runs/n8/cert_n8_full.json 4 350 0.2` (400 s, RIGOROUS, all four balls);
  `python3 src/cert_n8.py data/cert_green.npz data/trial_v2_h0.008.npz runs/n8/cert_n8_fine0165.json 16 160 0.0165` (90 s, RIGOROUS, fine pass);
  `bash runs/n8/fft_chain.sh` (the four cut-off FFT norms, 6 min, floating; dx variants: `python3 src/pdisc_fft.py data/trial_v2_h0.008.npz 0.028875 0.037125 0.000165 out.json 1.25`).

- 7.8: `python3 src/x3_minus_trial_jets.py 12000 512 1e-4 1e5 runs/jets/x3_minus_trial_N12000_T512.json` (94 s, floating; 6000 256 for the coarse row).


SHA-256 of the key files at 2026-10-21T02:06Z (shift 3; code and data as used for the certificates of sections 7.2, 7.3, 7.6, 7.7):

| file | SHA-256 |
|---|---|
| src/cert_n8.py | 09849524feda01ba812b65b69f4939a8dd90b196027f5258dc63375c7181eb65 |
| src/midrad.py | 5b5feb4ad511e66d57d228a3b754e44cfa2ceb17a33f717dde991c464d5f598e |
| src/cert_resid.py | 15a7535dbe5d7249ea38e089229591591976eef1151f298c932873f9e9dec828 |
| src/cert_green.py | 7f1c067b15d087b0688e3b4f1dc0b3abaf301a421b600ce96f5cedf662d6f8f0 |
| src/n8_floating.py | 01a6e4314655f0db620f935237d37d792e7ebc27a2909d5b2272f803bc72ed70 |
| src/pdisc_fft.py | 0813c9525cef2260da6aa9093ba79e626d07405c143c5a397f0e59b6417bb749 |
| src/x3_minus_trial_jets.py | 28aad784cd26149fa12d43f4cedef9ee963136e89e3efbe8123268e576c5e002 |
| src/cert_flow.py | bb47a2d7a46807b02c0e943d7b50d31fb31b6a42c4be55fdbbf1c3a2b90031f6 |
| src/cert_scalars2.py | b048d14fb3fa205c1e88a5f510f901fdc0e72b7de7a914df202f362401aedcd1 |
| data/cert_green.npz | c2c2e4f73f5ac6ee49fd0052b81700fc88ee68d01a5a526691cf03c2b82c2ef1 |
| data/trial_v2_h0.008.npz | a069d85d102e17340778042f85c003705716ba799c0f68873d10c1c582ea4874 |
| data/trial_n7.npz | d026c5cfa9892683e1d8b07562bbfb506629cab76be20d5b9fa9c0bdf241443f |
| runs/n8/cert_n8_fine0165.json | 451d1e05562e031baa1dee3cda22c904d946c230734dc271a944b02263a01d80 |
| runs/n8/cert_n8_full.json | 0aee537a69b4a15e3c045fe568dd470ffa598ffd9a281a5ae0c7184ec89735ec |
| runs/n8/cert_n8_mid.json | 6c12f7d8a84e168c735c33261e9f08e5c6073885006d1261dfb9c8400f7766a5 |
| runs/n8/cert_n8_fine0165_v3.json | 1e71e1309125eb189648cfbd9f1c5c1abbb5f492cf6efd9ad52e876ec70855e5 |
| runs/n8/n8_floating.json | 61c8f08d9a2e0f61ccb376c9be6868c9a01ef4e41b7116222dcc1c62d375b124 |
| runs/scalars_full.json | c831175d41bde3377869e8461bc32057edff11a6bef1d69aa7f12b4134777fd2 |
| runs/cert_resid_middle.json | 88d2149248eaec2d868c7152859ba71d627e1162e2fa35ae2105a38531e1dd7a |
| runs/cert_resid_regions.json | e8848beb995140e70ee2615ef66a3961234d85e121031edb80d8ae60e6066177 |
| runs/flow_middle.json | 300282f24a6c3ac8e667408de21bc59ded25ea90bda564f6573c5f06c430cac9 |
| runs/flow_outer.json | 897c5021e5c509eac72181d2ff519f7c0ccddfab86867b9beec7c9cf5db78d8e |
| runs/flow_inner.json | c243f6f2f9e86b99e08d4ce370da0ade37ee5ca04dc848d92dcbbbf4a809699f |
| runs/flow_tails.json | c0d4bd4a33566bf4accbeb2554a8f1dc42ba3fda966c28d87ab93c0c8cf75498 |
| runs/axis_cell.json | e4403c8f23ad66544c348fb1f3c2674d6356ab8b8a989b95c73f13f8633b248b |

Note: src/cert_n8.py is now v3 (robustness items, arithmetic unchanged); the v2 outputs runs/n8/cert_n8_{fine0165,full,mid}.json were produced by the v2 source with SHA-256 e7786de0aa6ea802f13aac64856e30134abf02809ddad339f25cce9cbe2549c1 (TO_TEAM 01:34Z); the v3 fine output reproduces them.

- 7.9: `python3 src/aux_R.py 512 0.08 0.0165 3.1 runs/n9/aux_R_n512.json` (42 s, floating; 256 for the coarse row).
- 7.10 (shift 4): the cell-by-cell loops and merge commands are listed at the end of section 7.10 (src/cert_forcing.py v1.2, src/cert_forcing2.py
  v2.2, src/forcing_float.py; about 11, 20 and 2.5 min; every python process must stay under 120 s because of the box CPU guard).
- 7.3b regions (shift 4): `python3 src/deriv_region_shells.py runs/cert_deriv_regions_outer.json 3400 1e4 1e5 1e6 1e7 1e8 1e9 1e10 1e11`
  (per-shell ceilings; seconds), likewise for runs/cert_deriv_regions_inner.json and runs/cert_deriv_middle.json.

## 9. Open items (numerics lane) (updated shift 5, 13:15Z)
1. Three resolutions (RES, section 7.3c): v3 complete; v4 and v5 full pipelines run in chain7d after the C2 chains (8d, 8e, 8f; about 7 h,
   expected to end during the night 10-21/10-22); if the run ends first, section 7.3c stays at two resolutions (v2, v3) plus the N7 trial.
2. N8 (section 7.7): complete; the verifier closed the condition on their own independent bounds (M_V < 0.2972, M_rho < 0.5059).
3. C2 (section 7.4b, floating): row refinement at M16/s16 complete (stable per row); the size test M16/s16 -> M24/s8 shows a 27 percent decrease
   per row of the smallest singular value (first row reported 13:05Z; NJ1 and L2y rows of M24 follow from chain8d). Pending: version-3
   diagnostics (H1-type image rows with C^1 joins, quadrature-weighted rows, continuous references, saved vectors with radial localization) on
   M24/s8, M16/s16 (ppc 2/4/6) and the intermediate sections M16/s8/Mout40, M24/s16/Mout40, M24/s16/Mout32, M24/s8/Mout40 (chains 8e/8f, about
   5 h). The lead's report mentions version 3 only if reported by 2026-10-22T06Z. No conclusion about the invertibility of L follows from any of
   these sections (restricted trial space, truncated image, floating).
4. Derivative certificate 7.3b and forcing bound 7.10: this lane's rigorous upper bounds; the verifier's queue (46, 98, 99, 101, 107) does not
   verify them at the physical level in this run (ver 11:58Z).
5. Far field: fitted (X3's Theta_1 mismatch retained) vs forced Theta_1 (lead's decision; not done). Band-vs-global Gauss-Newton comparison (7.5b
   design, about 2.5 h CPU) and the N7 inner-region certificate: optional, not started. Conforming B-spline reconstruction of the section
   columns (lead 12:34Z, optional): not started; the verifier's topic 132 quantifies the single-column repair (< 2.6e-14 relative energy change).
6. Rigorous forcing bound at other delta (about 9 x the work at delta = 0.05): routine, not needed for the report (lead 10:24Z).
