# Squared regional values and published root ceilings

2026-10-22T10:21:24.887004+00:00

The complete actual review correctly states that each published ceiling squared exceeds its corresponding sum. Its preceding sentence saying that adding the printed regional table cannot exceed the ceilings is false if read literally. The table entries bound squared norms; their sum is compared with q squared, or their square root with q. For example the first displayed sum is about70.2263 and q about8.3801. The phrase Both engines agree also need not mean equality of bound endpoints; the construction takes their maximum and does not require equal upper bounds. The independent FLINT and integer-root recheck confirms all four strict root inequalities. These corrections do not change either numerical result.
