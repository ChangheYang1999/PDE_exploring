# SPEC (ipmA-lead): target theorem, spaces, splitting, bounds and owners

Version 1, 2026-10-20T14:15Z (shift 1). Supersedes nothing. Changes will be logged at the end of this file.

## 0. Decisions in one paragraph
Primary target: a `P_2` existence theorem near X3, proved in a SMALLER class `S` (C^{4,alpha} near the axis source P,
weighted near 0 and infinity) where the linearization can be invertible; `S` is inside `P_2`, so a solution in `S` is a
`P_2` solution. The `P_infty` exclusion route via `B_3` is NOT pursued as a decisive route: the earlier smooth-setting
study established that the `B_3` functional is ill-conditioned in the origin layer (relative 1e-8 changes of the axis
data in a bump at x = 0.5 move `B_3` by 0.046 natural units), that its certified exclusion radii were 1e-6 to 4.5e-6 in
its weighted norm while equally good fits were 9 to 67 apart in that norm, and that compatible axis data can have
`B_3` of either sign. A ball of that size does not contain the numerical-uncertainty ball, so a `B_3` exclusion would be
a formal one (PROMPT line 14). We only reproduce the `B_3` formula and its value as a diagnostic. The realistic outcome
is UNRESOLVED with (a) a certified residual of an explicit trial in the norms below, (b) a conditional theorem that
isolates exactly one missing linear estimate, (c) rigorous structural results (kernel at P, index, dissipativity map)
explaining why that estimate is hard. A YES is attempted only if (b)'s hypothesis can actually be verified.

## 1. The equation and notation (fixed)
- IPM-SS: `(c_l X + U).grad rho = rho`, `U = grad^perp psi = (-psi_y, psi_x)`, `-Lap psi = d_x rho` on R^2 with the
  canonical inverse (Green formula of PROMPT, no harmonic `lambda x y`). `rho` even in x, odd in y,
  `rho = x^2 y a`, `a(0) = 1`. `c := psi_xy(0)`; the x^2 y coefficient of the equation is `3 c_l - c - 1 = 0`, so
  `c_l = (1 + c)/3` is not free.
- `V = c_l X + U`. At 0: `DV(0) = diag(1 - 2c_l, 4c_l - 1)`. Axis source `P = (x_*, 0)`, `A := 2c_l - 1` (eigenvalue in
  `s = x - x_*`), `d_y V_2(P) = 1` (forced, see 3.3), `g_* = rho_y(P)`. `k := 1/c_l` (far exponent, `rho ~ r^k`).
- X3 values (floating point, verifier has c to 4e-13): `c = 15.7260878216...`, `c_l = 5.57536260...`, `x_* = 8.60006`,
  `A = 10.1507`, `g_* = 29.75`, `L = 7.6514`, `p_3 = 6 + 2/A = 6.19703`.
- Size function: `m(r) := u^3 (1 + u^2)^((k-3)/2)`, `u = r/L` (the natural size of X3: `rho/(x^2 y)` is O(1)).

## 2. The trial (decided)
- The rigorous object is the EXPLICIT MODAL TRIAL `rho~ = x^2 y sum_{m<M} a_m(r) cos(2 m theta)` of the numerics lane:
  even polynomial core for `r < r_min` (`a(0) = 1` exactly), degree-7 exponential-polynomial splines in `t = log r`,
  far form `u^(k-3)[A_m0 + A_m1 nu + A_m2 nu^2 + A_m3 nu^3 + B_m0 u^-2 + B_m1 u^-2 nu]`, `nu = u^(k-1)`.
  Its Green integrals are closed form, so the elliptic equation holds exactly; `c~` is a closed-form number and
  `c_l := (1 + c~)/3` is imposed exactly; `c_l k = 1` exactly. The only residual is the transport residual
  `eps~ = (c_l X + U~).grad rho~ - rho~ = sum_N eps_N(r) sin((2N+1) theta)`.
- `Theta_1` (the `A_m1` far coefficients): FITTED, with the far mismatch kept in the residual and certified (forcing
  needs bandwidth 4M+3; its relative size decays like `r^(k-1)`, which the transport inverts at rate `1 - c_l`). The
  forced variant is optional, for comparison only.
- Dependent coefficients (joins, normalization) are recomputed by exact formulas in the certificate, so the stored
  trial is the object; the fit itself need not be rigorous.
- At least three resolutions (M, spline subdivision, R0) to show stability of every certified number.

## 3. The admissible class S and the analytic set-up

### 3.1 Why a class smaller than P_2 is needed (structural facts, to be verified)
F1 (frozen operator at P). Linearizing at the axis source with `grad rho~(P) = (0, g_*)` gives the frozen operator
`L_P h = A s d_s h + y d_y h - h - g_* M h`, `M` = Fourier multiplier `xi^2/|zeta|^2` (since `U_2[h] = -M h`). For
packets concentrated where `|s| << |y|` one has `M ~ 1`, and `|y|^(1+g_*) F(s/|y|^A)` are approximate kernel elements:
quasi-homogeneous of degree `1 + g_*`, isotropic regularity `C^{(1+g_*)/A} = C^{3.03}`. Claim: `L` has an
infinite-dimensional kernel (or at least is not Fredholm) on `C^{2,alpha}`-type spaces near P for every alpha < 1.
Consequence: no NK argument closes in a `C^{2,alpha}` norm at P; we work in `C^{4,alpha}` (anything above 3.03) near P.
F2 (transport alone). `L_0 = V~.grad - 1` on functions that are C^1 at P and grow at most like `r^(k+delta)`: kernel
`span(rho~_V)` (the transported eigenfunction, `= rho~` up to the residual), cokernel one-dimensional (the resonant
`(0,1)` jet at P: `(A s d_s + y d_y - 1) y = 0`). Arbitrary data at P (a function of the trajectory label) give
kernel elements that are only `C^{1/A}` at P. At the origin saddle the local homogeneous solutions are
`|x|^a |y|^b sgn y` with `(1-2c_l) a + (4c_l-1) b = 1`: `(a,b) = (2,1)` (the x^2 y mode), `(p_3, 3)`, `(10.39, 5)`, ...;
these are `C^{2,alpha}`, so the class must allow `y^3 |x|^{p_3}` terms (the `B_3` term) and their `log|x|` variations
when `c_l` moves.
F3 (far field). Changing `c_l` changes `k`; a correction contains `(k_new - k) r^k log r Theta_0`. So the solution space
carries the weight `m(r) (1 + log(1+u))` and the residual space the decaying weight `m(r) (1+u)^(-delta)`,
`0 < delta < 1 - k`; the direction `G = X.grad rho~` (size `m`) is added to the residual space by hand (one scalar).
F4 (energy). `<(V.grad - 1)h, h>_w = -int w h^2 [1 + c_l + (1/2) V.grad log w]` (`div V = 2 c_l`). The coupling
`U[h].grad rho` has symbol `(a xi eta - b xi^2)/|zeta|^2` with `(a,b) = grad rho`, max eigenvalue
`(|grad rho| - rho_y)/2`. Weighted-L^2 dissipativity needs
`D_w(X) := 1 + c_l + (1/2) V.grad log w - (|grad rho| - rho_y)/2 > 0`; derivative energies are indefinite at P and at
the origin; singular power weights on the axes break the A_2 boundedness of the Riesz-type map `h -> U[h]`.
(The verifier has refuted positivity of the density energy for all c_l <= 6: consistent with F4.)

### 3.2 Class S (solution space X and residual space Y), version 1
`h` even in x, odd in y, `h = x^2 y b`, with the normalization `b(0) = 0` (removes the scaling kernel
`K = rho - X.grad rho ~ -2 x^2 y`; the x^2 y coefficient of `L h` is identically 0). Norm (to be tuned):
- near P (disc `D_P = {|X - P| < x_*/4}`): `C^{4,alpha}` (alpha = 1/2, any alpha > 0 works above 3.03);
- near 0 (`r < r_0`): `b` in a Kondratiev-type space allowing `y^2 |x|^{p} (log|x|)^j` terms, `p` near `p_3`;
  concretely `sum_{j<=4} sup r^j |grad^j b| / r^{beta}` with `0 < beta < p_3 - 6 = 0.197` for the part beyond the
  quadratic jet;
- elsewhere on compacts: `C^{1,alpha}` (only transport regularity is needed away from P and 0, but S must be stable
  under the transport inverse, which propagates the regularity at P along trajectories: the default is C^{4,alpha}
  locally everywhere, weighted);
- at infinity: `sup |h| / (m (1 + log(1+u)))` plus the same for `r^j grad^j h`, j <= 4.
`Y`: same structure with weight `m (1+u)^(-delta)` at infinity and one less derivative, plus `span(G)`.
These choices are the lead's working hypothesis; Section 4.2 lists what decides them.

### 3.3 Operator splitting
`F(rho, c_l) = (c_l X + U[rho]).grad rho - rho`, `c_l = (1 + c[rho])/3`, `c[rho] = psi[rho]_xy(0)`.
At `rho~ + h`: `F = eps~ + L h + N(h)` with
  `L h = (V~.grad - 1) h + U[h].grad rho~ + (c[h]/3) G`,  `G = X.grad rho~`,
  `N(h) = U[h].grad h + (c[h]/3) X.grad h` (loses one derivative).
Quasilinear scheme (no Nash-Moser): `h_{n+1}` solves
  `(V_n.grad - 1) h_{n+1} + U[h_{n+1}].grad rho~ + (c[h_{n+1}]/3) G = -eps~`,  `V_n = c_l(h_n) X + U[rho~ + h_n]`,
i.e. `L_{V_n} h_{n+1} = -eps~` (the full transport velocity is in the operator; the remaining coupling is order 0 in h).
Bounded in X (high norm), contracting in a low norm X_low (one derivative less), limit in X by weak-* compactness.
Scalar conditions handled by the scheme: the source P moves with V_n (X is C^{4,alpha} on the whole disc D_P, so no
moving-point issue); `d_y V_2(P) = 1` must hold at the exact solution (else `rho ~ |y|^{1/mu}` at P, not C^1): this is
the cokernel condition of F2 and is absorbed by the nonlocal term `g_* d_y U_2[h](P)` (a global functional of h).

### 3.4 Conditional theorem (target of the final report; to be made fully explicit)
T1. Suppose: (H1) `||eps~||_Y <= eps` (certified); (H2) for every `V` with `||V - V~||_{X_V} <= r_V`, `L_V : X -> Y` is
invertible with `||L_V^{-1}||_{Y->X} <= K` and `||L_V^{-1}||_{Y_low->X_low} <= K_low`; (H3) explicit tame bounds
`||U[h]||_{X_V} <= C_U ||h||_X`, `||U[h].grad g||_{Y_low} <= C_N ||h||_{X_low} ||g||_X`, `|c[h]| <= C_c ||h||_{X_low}`.
If `2 K eps <= r` with `r C_U <= r_V` and `K_low C_N r < 1`, then there is an exact solution `rho = rho~ + h`,
`||h||_X <= 2 K eps`, in class S, hence in `P_2`.
Everything except (H2) is computable. (H2) is the missing estimate; the final report must say what is known about it.

## 4. Bounds and owners

### 4.1 Numerics lane (num): certified residual of rho~ and coefficient data
R0  `sup_r W(r)/m(r)`, `W(r) = sum_N |eps_N(r)|` (Wiener in theta), reported by region: `r < r_min`; dyadic shells of
    `[r_min, R0]` (especially `[0.5 x_*, 2 x_*]`); `r > R0` (with the far weight `(1+u)^delta`, delta = 0.5).
R1  The same for `r d_r eps~` and `d_theta eps~` (first derivatives; needed for Y).
R2  `( int |eps~/m|^2 dX/(1+u^2) )^{1/2}` (explicit exponential-polynomial integrals).
R3  Local data at P: rigorous Taylor bounds of `eps~` up to order 4 on `D_P`, and of `rho~`, `V~` up to order 5.
R4  Origin: `sup_{r < r_1} W(r)/r^5` (eps~ = O(r^5) since the x^2 y coefficient is exactly 0).
S1  Scalars with balls: `c~`, `c_l`, `x_*` (interval Newton on `V~_1(x,0)`), `mu := d_y V~_2(P)` (report `mu - 1`),
    `g_*`, `A`, far data `Theta_0`, the `B_3` estimator (diagnostic only).
C1  Floating-point maps (not certified yet) of `D_w(X)` of F4 for w in {1, m^-2, m^-2 (1+u)^(-2 delta)} and of
    `(|grad rho~| - rho~_y)/2`; report the set where `D_w < 0`.
C2  Finite-section study of L (floating point): Galerkin matrix of L on modes x radial splines, in a C^{2,alpha}-like
    norm and in the S-like norm, at three resolutions; smallest singular values and near-null vectors. Prediction (F1):
    sigma_min -> 0 with resolution in the C^{2,alpha}-like norm with near-null vectors concentrating at P; bounded
    below in the S-like norm if (H2) is true.
Priority: R0, S1, R2, then C1, C2, then R1, R3, R4.

### 4.2 Verifier (ver): independent reproduction and audit
V1  Independent reproduction of S1 (already done for c) and of R0/R2 on a sample of cells with independent code.
V2  Adversarial audit of F1 (packets at P, non-Fredholm in C^{2,alpha}), F2 (transport kernel/cokernel in C^1 at P,
    local saddle solutions), F3 and F4 (energy identity), and of the axis reduction / B_3 formula (diagnostic).
V3  Audit of T1 (the quasilinear scheme closes as stated, with the constants as defined), then of any (H2) evidence.
V4  Reproduce the C2 singular-value trend with an independent discretization (floating point is acceptable: it is
    evidence, labeled as such).

### 4.3 Lead
L1 Proofs of F1-F3 in final form; L2 the explicit constants C_U, C_N, C_c of (H3) in the chosen norms; L3 the best
available statement about (H2): either a proof in a restricted setting or a precise obstruction; L4 FINAL_REPORT.md.

## Change log
- v1 2026-10-20T14:15Z: initial.
