# Near/far splitting of the velocity and the coupling on an x-face collar (gap G1, face part, local)

Lead note, written 2026-10-20 (shift 1, after 17:40Z); revision 2 at 17:59Z after the single-model astra audit
collar1 (section 8; revision 1 kept in notes/collar_coupling_v1_backup.md). Status: Lemma NF (audited VALID, with a
pointwise-trace qualification), Lemma E (audited VALID after restricting (E3) to `j < 3`) and Corollary CC (revision 1
INVALID as stated; repaired here by two added hypotheses, finite strain and Sobolev edge data, and a finite-regularity
profile hypothesis) are EXACT with proofs below; verifier check pending (V10). The derivative version (section 5) is
a SKETCH. Floating sanity checks: code/check_collar.py, constants: code/collar_constants.py. Notation of
notes/weighted_velocity.md (W1, W1') and notes/conormal_framework.md (section 2.3).

## 0. Summary
notes/weighted_velocity.md 4.2 shows that the coupling is not bounded on the pure edge weight `L^2_b` (dilation
counterexample), because the edge coefficients `u_{i,j}[h]` are controlled there only in homogeneous Sobolev norms.
Here the composite norm is used instead: `L^2_b` on a bounded neighbourhood N of a collar `I x {0}`, the far weight
`(1 + |X|)^{-2 gamma'}` with `gamma' < 2` elsewhere, and the solution's own edge component `y c(x)` in `L^2` of `c`. Then:
- (Lemma NF) the velocity on the collar splits as `sum_{j<3} chi_0(y) y^j u_{i,j}[h](x) + R_i` with a FIXED cutoff
  `chi_0`, the edge coefficients are in inhomogeneous `H^{b-j-1/2}(R)` plus a smooth part, and `R_i` is in `L^2_b` of
  the collar, all with explicit constants. The far part converges because the parity-symmetrized kernel decays like
  `|W|^{-3}`.
- (Lemma E) the velocity of an edge component `phi(y) c(x)` has an exact y-Taylor structure with bounded multipliers:
  no loss of derivatives and no low-frequency problem.
- (Corollary CC) on the collar, if `N_c(h) < inf` (finite strain), `W[h].grad rho = chi_0(y) y q[h](x) + R_W[h]` with
  `R_W[h]` in `L^2_b`, and the edge forcing `q[h] = w_{1,0} r_1' + w_{2,1} r_1` splits into a near part in `H^{b-3/2}`
  (gain `b - 3/2` derivatives over `h_rem`), an edge part of order ZERO relative to the edge coefficient `c` (so in
  `H^{b-3/2}` only if `chi_1 c` is), a `C^4` far part and the strain part. Revision 1 claimed `q in H^{b-3/2}` for
  `c in L^2`; that is false (astra collar1 Q6: jump data).
- So on bounded collars avoiding P and the corner the frequency-adapted extension and the commutator estimates of
  weighted_velocity 4.3 are not needed. The constants depend on the collar size `d`, on `x_2` and on `gamma'`; the
  dilation family of 4.2 has unbounded composite norm, so there is no contradiction.
Not covered (section 6): the P disc and its transition to the collar, the corner, the conic region at large `x`, the
y-face (analogue, with the local term of `U_2`), derivative and Hoelder versions.

## 1. Setting
- `5/2 < b < 7/2` (the composite window of conormal 2.3 has `3 + alpha < s < b < 3.406`); `0 < gamma' < 2`.
- Parity class: h even in x, odd in y. `Q = {x > 0, y > 0}`; for such h, `||h||_{L^2(R^2)} = 2 ||h||_{L^2(Q)}`.
- Collar: `I = [x_1, x_2]`, `0 < d`, `I_t := [x_1 - t, x_2 + t]`, with `I_{2d} subset (0, inf)`, i.e. `x_1 > 2d`. Regions
  `N := (I_{2d} cup -I_{2d}) x (-2d, 2d)`, `N_1 := (I_d cup -I_d) x (-d, d)`, `N_0 := I x (-d/2, d/2)`.
  For `z in N_0` and `W notin N_1`: `|z - W| >= d/2` (either `|Re W - Re z| >= d` or `|Im W - Im z| >= d/2`).
- Cutoffs: `chi` smooth, even, `0 <= chi <= 1`, `chi = 1` on `[-1, 1]`, `supp chi subset [-2, 2]`. Near cutoff
  `chi_N(X) := chi_1(x) chi_2(y)` with `chi_2(y) = chi(y/d)`, `chi_1` even, `0 <= chi_1 <= 1`, `= 1` on `I_d cup -I_d`,
  supported in `I_{2d} cup -I_{2d}` (so `0 <= chi_N <= 1`; otherwise insert `||chi_N||_inf`, `||1 - chi_N||_inf`). Splitting cutoff `chi_0(y) := chi(y/delta_0)`, `delta_0 := d/4` (so `supp chi_0 subset [-d/2, d/2]`).
- `L^2_b(S) := L^2(S, |y|^{-2b} dx dy)`.
- Hypothesis on h: on N, `h = phi_e(y) c(x) + h_rem`, with `phi_e(y) = y chi(y/d_e)` for some `d_e > 0` (edge component;
  `c = 0` allowed), `c` even and in `L^2(I_{2d} cup -I_{2d})`, `h_rem in L^2_b(N)`; and
  `Z_f(h) := ||(1 + |X|)^{-gamma'} h||_{L^2(R^2 \ N_1)} < inf`.
  For the coupling (Corollary CC) also `N_c(h) < inf` (below); this is NOT implied by the other hypotheses: for a radial
  cutoff `eta` near 0 with support disjoint from N, `h = eta(r) r sin(3 theta)` has the parity, is in `L^2`, vanishes on
  N, has finite `Z_f`, and its strain integral is a positive multiple of `int_0 dr/r = inf` (astra collar1 Q6).
- Velocity. Complex form: for `h in L^2` with compact support and `z notin supp h`,
  `f[h](z) := U_2[h](z) + i U_1[h](z) = (1/(2 pi)) int h(W) (z - W)^{-2} dA(W)`
  (since `K_2 + i K_1 = ((s^2 - t^2) - 2ist)/(2 pi |Z|^4) = 1/(2 pi Z^2)`, `Z = s + it`; floating check code/check_NF.py).
  For parity h, summing the four reflections gives `f[h](z) = (1/(2 pi)) int_Q h(W) G(z, W) dA(W)` with
  `G(z, W) = (z - W)^{-2} - (z - conj W)^{-2} + (z + conj W)^{-2} - (z + W)^{-2} = 4i sum_{n odd} (n+1) z^n Im(W^{-n-2})`
  for `|z| < |W|`. For h in the class above, U[h] on `N_0` is DEFINED by `U[h] := U[chi_N h] + U^sym[(1 - chi_N) h]`, where
  `U[chi_N h]` is the canonical velocity of the compactly supported `L^2` function `chi_N h` (`L^2_b(N) subset L^2(N)`)
  and `U^sym` is given on `N_0` by the symmetrized integral, absolutely convergent AFTER symmetrization (the four
unsymmetrized integrals need not converge separately) (section 2, (F1)). For compactly
  supported `L^2` data this is the canonical velocity; for the growth class it is the parity-symmetrized definition
  (the one whose strain functional converges for growth below 1, SPEC 1). Two admissible `chi_N` give the same U on
  `N_0`: their difference times h is supported outside `N_1`, where both integrals converge absolutely.
- Strain. For `h in C_c^infty(R^2 \ {0})` with the parity, the series gives `U_1(x, 0) = (2/pi) sum_{n odd} (n+1) x^n M_n`,
  `M_n = int_Q h Im(W^{-n-2})`, so `c[h] = psi_xy(0) = -d_x U_1(0,0) = -(4/pi) M_1`, i.e.
  `c[h] = (4/pi) int_Q h sin(3 theta) r^{-3} dA`, hence `|c[h]| <= (1/pi) int_{R^2} |h| |X|^{-3} dX =: N_c(h)`.
  (Floating checks: code/check_NF.py, code/check_collar.py (3).) c extends continuously to `{N_c(h) < inf}`; this is
  finite in the composite space when the corner weight makes `int |h| r^{-3}` converge near 0 and `gamma' < 2`.

## 2. Lemma NF (near/far splitting of the velocity on the collar)
Let h be as in section 1 with `c = 0` (edge components: Lemma E), `h_n := chi_N h`, `h_f := (1 - chi_N) h`. Constants:
`c_{j,b} = Gamma(2b+1)^{1/2} 2^{-b-1}/j!` (W1(b)), `e_{j,b,d} = (2 (2d)^{2b+1}/(2b+1))^{1/2}/(2 j!)`,
`M_{j} := max(c_{j,b}, e_{j,b,d})`, `sigma_j := b - j - 1/2`, `C_{3,b}` of W1(a).
(N1) Near edge coefficients. `u_{i,j}[h_n] in H^{sigma_j}(R)` (inhomogeneous, `||u||^2 = (2pi)^{-1} int <xi>^{2 sigma} |u^|^2`),
  `||u_{i,j}[h_n]||_{H^{sigma_j}(R)} <= 2^{sigma_j/2} M_j ||h_n||_{L^2_b}` and `||u_{i,j}[h_n]||_{L^2(R)} <= M_j ||h_n||_{L^2_b}`,
  with `||h_n||_{L^2_b} <= ||h||_{L^2_b(N)}`.
(N2) Near remainder (fixed cutoff). `R^n_i := U_i[h_n] - sum_{j<3} chi_0(y) y^j u_{i,j}[h_n]` satisfies
  `||R^n_i||_{L^2_b(R^2)} <= K_n ||h_n||_{L^2_b}`, `K_n := C_{3,b} + sum_{j<3} (2/(2b - 2j - 1))^{1/2} delta_0^{j - b + 1/2} M_j`.
(F1) Far part. `f_f := f[h_f]` is holomorphic on `N_0` and for every `m >= 0`, `z in N_0`: `|f_f^{(m)}(z)| <= A_m Z_f(h)`,
  `A_m := ((m+1)!/(2 pi)) (2/d)^{m+2} (pi rho_0^2)^{1/2} (1 + rho_0)^{gamma'} + g_m J/(4 pi)`,
  `R_B := (x_2^2 + d^2/4)^{1/2}`, `rho_0 := 2 R_B`, `g_0 := (128/9) R_B`, `g_m := 4 (m+1)! 2^{m+2} rho_0^{1-m}` (`m >= 1`),
  `J^2 := (1 + 1/rho_0)^{2 gamma'} (pi/2) rho_0^{2 gamma' - 4}/(4 - 2 gamma')`.
  Since `d_x = d_z`, `d_y = i d_z` on holomorphic functions, `|d^alpha U_i[h_f]| <= A_{|alpha|} Z_f(h)` on `N_0`, and
  `u_{i,j}[h_f] := d_y^j U_i[h_f](., 0)/j!` is `C^infty` on I with `|d_x^n u_{i,j}[h_f]| <= A_{n+j} Z_f(h)/j!`.
(F2) Far remainder. `R^f_i := U_i[h_f] - sum_{j<3} chi_0(y) y^j u_{i,j}[h_f]` satisfies on `N_0`
  `||R^f_i||_{L^2_b(N_0)} <= K_f Z_f(h)`, `K_f := (A_3/6) (2 |I| (d/2)^{7-2b}/(7-2b))^{1/2}
   + sum_{j<3} (A_j/j!) (2 |I| delta_0^{2j-2b+1}/(2b-2j-1))^{1/2}`.
(P) Parity: `u_{2,0} = u_{1,1} = u_{2,2} = 0` for each part; `u_{2,1} = -u_{1,0}'` (incompressibility).
So on `N_0`: `U_i[h] = sum_{j<3} chi_0 y^j u_{i,j}[h] + R_i`, `||R_i||_{L^2_b(N_0)} <= K_n ||h_rem||_{L^2_b(N)} + K_f Z_f(h)`.

Proof. (N1) For `g in D_0` supported in N (dense in `L^2_b(N)` for the norm of `L^2_b`, by cutting away from `y = 0` and
mollifying), weighted_velocity section 1 gives `u_{1,j}^(xi) = -(i xi |xi|^j/(2 j!)) int (sgn y')^{j+1} e^{-|xi||y'|} g^(xi, y') dy'`
and the analogue for `u_{2,j}`. W1(b) gives `|u^(xi)| <= c_{j,b} |xi|^{-sigma_j} ||g^(xi, .)||_{L^2(|y|^{-2b} dy)}`. Since
`supp g subset {|y| <= 2d}`, Cauchy-Schwarz with `e^{-|xi||y'|} <= 1` gives
`|u^(xi)| <= (|xi|^{j+1}/(2 j!)) (int_{|y'| <= 2d} |y'|^{2b})^{1/2} ||g^(xi, .)|| = e_{j,b,d} |xi|^{j+1} ||g^(xi, .)||`.
For `|xi| >= 1`, `<xi>^{sigma} c |xi|^{-sigma} <= 2^{sigma/2} c`; for `|xi| < 1`, `<xi>^{sigma} e |xi|^{j+1} <= 2^{sigma/2} e`.
Plancherel in x (`(2 pi)^{-1} int ||g^(xi, .)||^2 dxi = ||g||_{L^2_b}^2`) gives both bounds. The map `g -> u_{i,j}[g]`
is continuous from `L^2_b(N)` into `H^{sigma_j}`. For `u_{1,0}` also pointwise: for `b > 1` the kernel integral
`U_1(x, 0) = int (x - x') y'/(pi |X - X'|^4) g dX'` converges absolutely (`int_N |x-x'|^2 |y'|^{2+2b} |X-X'|^{-8}` is finite iff
`b > 1`), so the extension to `h_n` is the canonical trace. For a kernel differentiated j times the weighted square
singularity is `int_0 r^{2b-2j-3} dr`, finite iff `b > j + 1`; so a pointwise canonical `u_{1,2}` is not justified for
`b <= 3`, and the higher coefficients are meant in the `H^{sigma_j}` / `L^2_loc` sense (astra collar1 Q2). (N2) `R^n_i = T_3 U_i[h_n] + sum_{j<3} (1 - chi_0(y)) y^j u_{i,j}[h_n]`.
W1(a) (with W1(d) for the extension to `L^2_b`) bounds the first term by `C_{3,b} ||h_n||_{L^2_b}`, valid for
`5/2 < b < 7/2`. For the others, `1 - chi_0 = 0` on `|y| <= delta_0`, so
`||(1 - chi_0) y^j u||_{L^2_b}^2 <= ||u||_{L^2(R)}^2 int_{|y| >= delta_0} |y|^{2j-2b} dy = ||u||_{L^2}^2 2 delta_0^{2j-2b+1}/(2b-2j-1)`.
The identity `U_i = sum_j y^j u_{i,j} + T_3 U_i` holds on `D_0` and passes to `h_n` because every term is continuous
from `L^2_b(N)` into `L^2_loc` (U: Riesz transforms on `L^2`; `u_{i,j}`: into `L^2(R)`; `T_3 U_i`: into `L^2_b`).
(F1) Write `f_f(z) = (1/2pi) int_{|W| < rho_0} h_f (z - W)^{-2} dA + (1/2pi) int_{Q, |W| >= rho_0} h_f G(z, W) dA`. Mid part:
`|d_z^m (z - W)^{-2}| = (m+1)! |z - W|^{-m-2} <= (m+1)! (2/d)^{m+2}` on `supp h_f` (section 1), and
`int_{|W| < rho_0} |h_f| <= Z_f (1 + rho_0)^{gamma'} (pi rho_0^2)^{1/2}` by Cauchy-Schwarz. Far part: for `|z| <= R_B`,
`|W| >= rho_0`, `t := |z|/|W| <= 1/2`. From the series, `|G| <= 4 |W|^{-2} sum_{n odd} (n+1) t^n = 8 t |W|^{-2}/(1 - t^2)^2
<= (128/9) R_B |W|^{-3}`, and for `m >= 1`
`|d_z^m G| <= 4 |W|^{-2-m} sum_{n >= m} ((n+1)!/(n-m)!) t^{n-m} = 4 |W|^{-2-m} (m+1)! (1 - t)^{-m-2} <= g_m |W|^{-3}`
(`(d/dt)^{m+1} (1 - t)^{-1}`, then `|W|^{1-m} <= rho_0^{1-m}`). Cauchy-Schwarz on Q:
`int_{Q, |W| >= rho_0} |h_f| |W|^{-3} <= ||(1+|W|)^{-gamma'} h_f||_{L^2(Q)} J <= Z_f J/2` (using `0 <= 1 - chi_N <= 1` and
`supp h_f subset R^2 \ N_1`), with
`(1 + |W|)^{2 gamma'} <= (1 + 1/rho_0)^{2 gamma'} |W|^{2 gamma'}` for `|W| >= rho_0`; `J < inf` iff `gamma' < 2`. The
threshold is sharp for the class: at `gamma' = 2`, `h = r sin(3 theta)/log r` (large r) has finite weighted norm
(`int dr/(r log^2 r)`) while the leading symmetrized kernel at real `x > 0` gives `int dr/(r log r) = inf` (astra collar1 Q4). Differentiation under
the integral is justified by these dominating bounds. (F2) On `N_0`, Taylor's theorem in y with
`|d_y^3 U_i[h_f]| <= A_3 Z_f` gives `|T_3 U_i[h_f](x, y)| <= |y|^3 A_3 Z_f/6`; integrate `|y|^{6-2b}` over `|y| < d/2`
(finite since `b < 7/2`). The cutoff terms as in (N2), with `|u_{i,j}[h_f]| <= A_j Z_f/j!` on I. (P) h odd in y makes
`U_1` even and `U_2` odd in y (each part keeps the parity: `chi_N` is even in both variables); `div U = 0` at `y = 0`
gives `u_{1,0}' + u_{2,1} = 0`. QED.

## 3. Lemma E (velocity of an edge component)
Let `phi in C_c^infty(R)` be odd, `c in L^2(R)` even, `h_e := phi(y) c(x)`. Then for every real s and `j <= 3`:
(E1) `u_{i,j}[h_e]^(xi) = c^(xi) (K^i_xi * phi^{(j)})(0)/j!`, with `K^2_xi(t) = -(|xi|/2) e^{-|xi||t|}`,
  `K^1_xi(t) = (i xi/2) sgn(t) e^{-|xi||t|}`; hence `|u_{i,j}[h_e]^(xi)| <= |c^(xi)| min(||phi^{(j)}||_inf, (|xi|/2) ||phi^{(j)}||_{L^1})/j!`
  and `||u_{i,j}[h_e]||_{H^s} <= (||phi^{(j)}||_inf/j!) ||c||_{H^s}`.
(E2) `||T_3 U_i[h_e]||_{L^2_b(R x (-delta, delta))} <= (||phi'''||_inf/6) (2 delta^{7-2b}/(7-2b))^{1/2} ||c||_{L^2}` for every `delta > 0`.
(E3) for `j < 3` (not `j = 3`: then `int^inf y^{6-2b} dy = inf`, and parity does not remove `u_{2,3}`, astra collar1 Q5):
  `||(1 - chi_0) y^j u_{i,j}[h_e]||_{L^2_b} <= (2 delta_0^{2j-2b+1}/(2b-2j-1))^{1/2} (||phi^{(j)}||_inf/j!) ||c||_{L^2}`.
Proof. `h_e in L^2(R^2)`, and the partial Fourier formulas of weighted_velocity section 1 hold for every `L^2` density
(the y-Fourier transform of `(|xi|/2) e^{-|xi||t|}` is `xi^2/(xi^2 + eta^2)`), so `U_i[h_e]^(xi, y) = c^(xi) (K^i_xi * phi)(y)`.
`K * phi` is smooth with `d_y^j (K * phi) = K * phi^{(j)}` and `||K^i_xi||_{L^1} = 1`, `||K^i_xi||_inf = |xi|/2` for
`xi != 0` (at `xi = 0` the multipliers are set to 0, so uniformly `||K^i_xi||_{L^1} <= 1`); Young's
inequality gives (E1). Taylor's theorem gives `|T_3 (K * phi)(y)| <= |y|^3 ||phi'''||_inf/6` uniformly in xi; Plancherel in
x gives (E2), and (E3) is as in (N2). QED.
Remarks. (1) The multipliers are bounded uniformly in xi, so an edge component with `c in H^s` produces edge velocity
coefficients in `H^s` and an `L^2_b` remainder controlled by `||c||_{L^2}`: no derivative loss and no low-frequency
problem. This PRESERVES assigned regularity; it gives no positive regularity from `c in L^2` (for `phi = y chi(y/eps)`
the `u_{2,1}` multiplier is `-1 + O(e^{-eps |xi|})`, so `u_{2,1}[h_e] = -c + smooth`; astra collar1 Q6). The trace-loss objection to a fixed-cutoff extension (an `H^s` function has `d_y h(., 0)` only in `H^{s-3/2}`)
concerns the converse direction (extracting `c` from an arbitrary `H^s` function); it does not arise when c is a
component of the space. (2) In the collar setting take `phi = chi_2 phi_e` and `c chi_1` in place of c; then
`chi_N h = phi(y) (chi_1 c)(x) + chi_N h_rem` and Lemmas NF and E apply to the two terms.

## 4. Corollary CC (the coupling on the collar)
Let `rho` be odd in y and `C^6` on a neighbourhood of `N-bar` (the trial's splines are `C^6` at the joins; so all
statements below are finite-regularity statements), `r_1 := rho_y(., 0)`,
`r_3 := d_y^3 rho(., 0)/6`, `S_1 := sup_{N_0} |d_x d_y^5 rho|/120`, `S_2 := sup_{N_0} |d_y^5 rho|/24`, so that on `N_0`
`|rho_x - y r_1' - y^3 r_3'| <= S_1 |y|^5`, `|rho_y - r_1 - 3 y^2 r_3| <= S_2 |y|^4`. Let h be as in section 1,
in addition `N_c(h) < inf`, `W[h] = U[h] + (c[h]/3) X`, `w_{1,0} := u_{1,0}[h] + (c[h]/3) x`, `w_{2,1} := u_{2,1}[h] + c[h]/3`,
`u_{i,j}[h]` the sum of the near, edge and far coefficients. Then on `N_0`
  `W[h].grad rho = chi_0(y) y q[h](x) + R_W[h]`, `q[h] := w_{1,0} r_1' + w_{2,1} r_1`,
  `R_W[h] = chi_0 y^3 (u_{1,0} r_3' + u_{1,2} r_1' + 3 u_{2,1} r_3) + chi_0 E + R_1 rho_x + R_2 rho_y
            + (c/3)[(1 - chi_0) y (x r_1' + r_1) + y^3 (x r_3' + 3 r_3) + x (rho_x - y r_1' - y^3 r_3') + y (rho_y - r_1 - 3 y^2 r_3)]`,
  `E := u_{1,0} (rho_x - y r_1' - y^3 r_3') + y^2 u_{1,2} (rho_x - y r_1') + y u_{2,1} (rho_y - r_1 - 3 y^2 r_3)`,
with `R_i` the total remainders of Lemmas NF and E. Consequently, with `||g||_{L^2(I)}` norms of the coefficients and
`k_p := (2 (d/2)^{2p+1-2b}/(2p+1-2b))^{1/2}` (`p = 3, 5`; `||chi_0 y^p g(x)||_{L^2_b(N_0)} <= k_p ||g||_{L^2(I)}`):
  `||R_W[h]||_{L^2_b(N_0)} <= k_3 (||r_3'||_inf ||u_{1,0}|| + ||r_1'||_inf ||u_{1,2}|| + 3 ||r_3||_inf ||u_{2,1}||)
     + k_5 (S_1 ||u_{1,0}|| + (||r_3'||_inf + S_1 (d/2)^2) ||u_{1,2}|| + S_2 ||u_{2,1}||)
     + ||rho_x||_inf ||R_1|| + ||rho_y||_inf ||R_2|| + (|c[h]|/3) C_rho`,
with (astra collar1 Q6, checked here term by term against the bracket)
  `C_rho := (2 delta_0^{3-2b}/(2b-3))^{1/2} ||x r_1' + r_1||_{L^2(I)} + k_3 ||x r_3' + 3 r_3||_{L^2(I)}
           + k_5 (S_1 ||x||_{L^2(I)} + S_2 |I|^{1/2})`.
Every quantity on the right is bounded by Lemmas NF and E in terms of
`||h_rem||_{L^2_b(N)} + ||chi_1 c||_{L^2} + Z_f(h) + N_c(h)`. The edge forcing: with `r~` a compactly supported `C^5(R)` extension of `r_1` from I (`r_1 in C^5(I)`; Whitney
extension), `q[h] = q_n + q_e + q_f + q_c` on I, where `q_n = r~' u^n_{1,0} - r~ (u^n_{1,0})'` lies in `H^{b-3/2}(R)` with
`||q_n||_{H^{b-3/2}} <= (mu_{b-3/2}(r~') + mu_{b-3/2}(r~)) 2^{(b-1/2)/2} M_0 ||h_rem||_{L^2_b(N)}`, `mu_s(g)` the norm of
multiplication by g on `H^s(R)` (finite for `g in C^2_c`, since `0 < s = b - 3/2 < 2`); the edge part
`q_e = r~' u^e_{1,0} + r~ u^e_{2,1}` (with `u^e = u[phi(y) chi_1 c]`) satisfies, by (E1) with `j = 0, 1`,
`||q_e||_{H^s} <= (mu_s(r~') ||phi||_inf + mu_s(r~) ||phi'||_inf) ||chi_1 c||_{H^s}` for every `0 <= s <= 2`: it is
order ZERO in c: `chi_1 c in H^{b-3/2}` suffices for `q_e in H^{b-3/2}` and must be ADDED as a hypothesis for the
Sobolev conclusion (counterexample for `c in L^2`: `c = 1_{[a_0, a_1]}` even-extended, `rho = y`; astra collar1 Q6);
`q_f in C^4(I)` with `|d_x^n q_f| <= C(n, r_1) Z_f(h)`, `n <= 4`; and `q_c = (c[h]/3)(x r_1' + r_1)`.
Proof. Insert `U_1 = chi_0 (u_{1,0} + y^2 u_{1,2}) + R_1`, `U_2 = chi_0 y u_{2,1} + R_2` (parity (P)) and
`X.grad rho = x rho_x + y rho_y` and expand; the displayed identity is algebra. The `L^2_b(N_0)` bounds follow from
`int_{|y| < d/2} |y|^{2p - 2b} dy = 2 (d/2)^{2p+1-2b}/(2p+1-2b)` (finite since `b < 7/2 <= p + 1/2`) and from the
remainder bounds. The `H^{b-3/2}` bound of `q_n` uses (N1) with `sigma_0 = b - 1/2` and `||u'||_{H^{b-3/2}} <= ||u||_{H^{b-1/2}}`.
QED.
Remark (orders). `q_n` gains `b - 3/2` derivatives over `h_rem` (between 1 and 2 in the window), consistent with the
high-frequency statement of weighted_velocity 4.1, now with inhomogeneous norms. The edge-generated forcing `q_e` is of
order zero in the edge coefficient c. If the edge component `c_1` solves the axis transport equation where `w` is
bounded away from 0 (`w c_1' + (mu - 1) c_1 = q + ...`), the transport gains one derivative (conditionally on the
regularity of the coefficients and of the other right-hand-side terms): `q in H^sigma` gives `c_1 in H^{sigma+1}`
locally, and `q_e` returns `c_1` at order zero. So the edge loop is consistent with `c_1 in H^{b-1/2}` on compact
subintervals avoiding the zeros of w. This is bookkeeping, not an invertibility statement.

## 5. Derivatives (SKETCH, not proved here)
The composite target norm uses `(y d_y)^m` and ordinary x-derivatives. x-derivatives commute with U and with the
splitting; the terms where they fall on `chi_1` are supported in `N \ N_1` (near-type data, same bounds). `(y d_y)^m` of
the near remainder is W1(c); of the far part it is smooth; of `chi_0 y^p g(x)` it is `y^p` times
`sum (p^l chi_0 + ...)` with `(t chi')` supported in `delta_0 <= |y| <= 2 delta_0`. The constants are not written out.

## 6. What remains of G1 after this note
- P disc: the velocity lemmas have no singularity at `x_* = 8.60006`; the issue is whether their weighted hypotheses
  hold on all of N, including any overlap with the ordinary `H^s` patch at P. There is no general inclusion of `H^s`
  into the face remainder space after removing the available jets when `b > s`: for `s - 1/2 < alpha < b - 1/2`,
  `F = g(x) eta(y) sgn(y) |y|^alpha` is in `H^s`, has no available normal jets, and `int_0 y^{2 alpha - 2b} dy = inf`
  (revision 1 said "an `H^s` function is not in the face remainder space", which is false as worded: `g(x) y^3 eta(y)`
  is in both; astra collar1 Q7). The transition is a realization question, not a velocity estimate.
- Corner: `I_{2d} subset (0, inf)` keeps the collar away from the origin; the corner (product weight) still needs the
  Mellin analysis (weighted_velocity section 5).
- Large x: the constants grow with `x_2` (through `rho_0` and J); the conic region `|y| < eps x`, `x -> inf` needs the
  conic version (dilation-covariant collars `I = [R, 2R]`, `d ~ R`). For `h_R = a_R H(X/R)`:
  `U[h_R](R X) = a_R U[H](X)`, `u_{i,j}[h_R](R x) = a_R R^{-j} u_{i,j}[H](x)`, `||h_R||_{L^2_b(R D)} = |a_R| R^{1-b} ||H||_{L^2_b(D)}`,
  `||(1 + r)^{-gamma'} h_R||_{L^2(R D)} = |a_R| R^{1-gamma'} ||(R^{-1} + r)^{-gamma'} H||_{L^2(D)}` (revision 1's "R = 1 case
  plus `R^{gamma'}`" omitted the Jacobian). A global conic estimate further needs cross-annulus estimates and their
  summation, edge norms for the nonseparable extension `y chi(y/x) c(x)`, and scaled profile bounds (rho is not
  homogeneous); per-annulus bounds by the whole input norm do not sum. NOT done.
- y-face: the same argument with x and y exchanged, Taylor order `N = 6` for the corner window `5.5 < a < 6.5`
  (W1 with `N = 6`), but a literal exchange misses the local term: after Fourier transformation in y,
  `U_2 = -h + eta^2 (eta^2 - d_x^2)^{-1} h`, and the `-h` term must be carried separately. NOT written.
- Derivatives (section 5) and Hoelder versions, if the low norm is Hoelder; the edge and strain hypotheses above; global
  localization and transition mapping estimates.
- The near/far constants are crude (code/collar_constants.py, floating evaluation of the closed forms: for
  `b = 3.403`, `gamma' = 1.15`, `I = [1, 7]`, `d = 0.45`: `K_n ~ 1.21e3`, `A_0 ~ 1.76e3`, `K_f ~ 9.3e6`; revision 1 quoted
  `d = 1/2`, which violates `x_1 > 2d`, astra collar1), adequate for boundedness, useless for a closing inequality
  without sharpening (the mid-region L^1 bound by Cauchy-Schwarz and `(2/d)^{m+2}` dominate).

## 7. Floating sanity checks (NOT rigorous)
code/check_collar.py: (1) `|d_z^m G|/bound <= 0.98` over 20000 random `(z, W)` with `|z| <= |W|/2`, `m = 0..4`;
(2) `sup |d_y^j m_i(xi, .)|/||phi^{(j)}||_inf <= 0.98` for `xi in {0.01, 0.3, 1, 5, 40}`, `j = 0..3` (and the low-frequency
decay is visible); (3) strain formula: `c = 0.0422508` (FFT, periodic box 40) versus `0.0422468`
(`(4/pi) int_Q h sin(3 theta) r^{-3}`), difference consistent with the periodic box. code/check_NF.py: complex
velocity formula and `c = -4 M_1/pi` (agreement to 1e-9 on the same grid).

## 8. Audit record
astra collar1 (2026-10-20, collected 17:58Z; single model: the second model was unavailable, no substitute). Q1
complex velocity, reflection series, strain formula: VALID. Q2 (N1): VALID for the norm bounds and the `L^2_loc`
identity; pointwise canonical traces only for `b > j + 1` (qualified in the proof). Q3 (N2): VALID; the dilation family
has `Z_f(h_R) ~ R^{b - gamma'} -> inf`, so no conflict with weighted_velocity 4.2. Q4 (F1), (F2): VALID, constants
confirmed (`K_n = 944.716367`, `A_0 = 1425.570012`, `K_f = 5576526.535` at the revision-1 example), an equality
corrected to an inequality, sharpness of `gamma' < 2` for the class. Q5 Lemma E: (E1), (E2) VALID, (E3) restricted to
`j < 3`. Q6 Corollary CC: INVALID as stated (infinite strain possible; `L^2` edge data give no `H^{b-3/2}` forcing;
`C^6` profile gives `q_f in C^4` only and an extension from I, not `I_{2d}`); algebra and remainder constants VALID,
explicit `C_rho` supplied; repaired in section 4. Q7 section 6: the `H^s` assertion false as worded (replaced by the
failure of a general inclusion), the large-x scaling incomplete, the y-face local term `-h` missing, the list
incomplete; all corrected. The example `d = 1/2` violated `x_1 > 2d`.
