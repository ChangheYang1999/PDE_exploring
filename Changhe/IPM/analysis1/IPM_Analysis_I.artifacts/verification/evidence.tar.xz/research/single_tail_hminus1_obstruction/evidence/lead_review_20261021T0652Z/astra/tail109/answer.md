I read all seven requested files. **With the mandatory addenda included, all three claims are valid.**

| Claim | Verdict |
|---|---|
| (a) Exact, nonzero, \(T\)-independent coefficient \(L_d\) | **VALID** |
| (b) \(L^2\) membership, failure of \(\dot H^{-1}\), and \(r\epsilon_T\notin L^2\) | **VALID** |
| (c) Necessity of removing the \(d\) density row within the specified finite class | **VALID** |

The addendum’s restriction on the class in (c) is essential. A hypothesis consisting only of a pointwise remainder bound would require repair.

**The exponent bookkeeping is correct.** For a pure density row,
\[
(c_0X\cdot\nabla-1)(r^aA)=(a/k-1)r^aA.
\]
The parities imply that \(\partial_x\rho\) has stream frequencies \(\sin(2n\theta)\), \(n\ge1\). Since
\[
-\Delta\!\left(r^{a+1}\sin(2n\theta)\right)
=\bigl((2n)^2-(a+1)^2\bigr)r^{a-1}\sin(2n\theta),
\]
a nonresonant particular stream has power \(a+1\), and its velocity has power \(a\).

The stream exponents for the four displayed density rows are
\[
k+1,\quad 2k,\quad 3k-1,\quad k-1.
\]
Their absolute values are below \(2\), so none is resonant. I also checked the actual lower rows directly from the NPZ: all **4,437 Green-denominator checks** passed. For the more general finite class, a lower-row resonance introduces finite logarithmic factors at that lower power; it cannot promote a term to power \(d\).

The permitted decaying homogeneous streams are \(r^{-2n}\sin(2n\theta)\), with velocity powers \(-2n-1\le-3\). Parity excludes the zero-frequency logarithmic stream, and the canonical choice excludes growing harmonic streams.

Thus an ordered particular product has power \(a+b-1\). The complete list above \(a_3\) is
\[
(k,k)\longmapsto\beta,\qquad
(k,\beta),(\beta,k)\longmapsto a_2.
\]
The next products,
\[
(\beta,\beta),\quad(k,a_2),\quad(a_2,k),
\]
all have power \(a_3\). Products involving \(d\) have power at most
\[
k+d-1=2k-3<a_3,
\]
and homogeneous-velocity products have power at most \(k-4<a_3\). A lower density power \(\lambda\le a_3\) gives
\(k+\lambda-1<a_3\).

I checked all **121 ordered pairs** of the eleven actual exterior exponents: none lands at \(d\). Consequently
\[
C_d=(d/k-1)D_d=-\frac2kD_d.
\]

Compact changes to the density—including the strain compensator—produce an exterior harmonic stream with only the allowed decaying modes. Their residual contributions therefore cannot change the coefficient at \(d\). This also justifies the claimed independence from \(T\).

**The frequency-one projection and numerical coefficient are correct.** From
\[
\cos^2\theta\sin\theta=\frac{\sin\theta+\sin3\theta}{4},
\]
the contributions to \(\sin\theta\) are:

- \(m=0\): \(A_{0,6}/4\);
- \(m=1\): \(-A_{1,6}/8+A_{1,6}/8=0\);
- \(m=2\): \(-A_{2,6}/8\);
- \(m\ge3\): zero.

Reading the binary64 entries as exact rationals, I obtained
\[
\boxed{b_d=-\frac{6077384870622209}
{39614081257132168796771975168}}.
\]
A separate Laurent multiplication and product-to-sum calculation agreed exactly for all 261 resulting sine coefficients.

Using the exact input
\[
t_+=\frac{2289893859708677}{281474976710656},
\qquad
L_d=-\frac{2b_d}{k}\exp((5-k)t_+),
\]
I independently certified
\[
\boxed{
184130.68809691860443309136512698
<L_d<
184130.68809691860443309136512700.
}
\]
Numerically,
\[
L_d\approx184130.6880969186044330913651269810406907132.
\]
The certification used an exact rational Taylor sum through degree \(256\), with a geometric upper bound on its positive remainder.

**The annular argument proves failure of \(\dot H^{-1}\).** For the stated \(g\), set
\[
\Phi_S(X)=g(r/S)\sin\theta.
\]
Direct calculation gives
\[
\|\nabla\Phi_S\|_2^2
=\pi\int_1^2\left(s|g'(s)|^2+\frac{g(s)^2}{s}\right)\,ds,
\]
independent of \(S\).

Let \(I_a=\int_1^2g(s)s^{a+1}\,ds>0\). The uniform exterior expansion yields, for each fixed \(T\),
\[
\langle\epsilon_T,\Phi_S\rangle
=\pi C_{2,0}I_{a_2}S^{3k}
+\pi L_dI_dS^k
+O\!\left(S^{4k-1}(1+\log S)^{12}\right).
\]
Here \(3k>k>0\), while \(4k-1<0\).

If \(C_{2,0}\ne0\), the first term dominates. If \(C_{2,0}=0\), the nonzero second term dominates. These cases are exhaustive, and in both the absolute pairing is unbounded against tests of fixed gradient norm. This directly contradicts the defining bounded-functional condition for \(\dot H^{-1}\). No evaluation of \(C_{2,0}\), or assumption about its sign, is needed.

**The integrability and necessity arguments also hold.** Distinguish \(C_{2,0}\), used above, from the whole angular function \(C_2\). If \(C_2\not\equiv0\), uniform angular asymptotics give
\[
\|\epsilon_T(r,\cdot)\|_{L^2_\theta}\ge c r^{a_2}
\]
for sufficiently large \(r\). If \(C_2\equiv0\), the same conclusion holds with exponent \(d\), because \(C_d\ne0\). In either case,
\[
\|r\epsilon_T\|_2^2\ge c^2\int^\infty r^{2a+3}\,dr=\infty,
\qquad a=a_2\ \text{or}\ d>-2.
\]
Unweighted square integrability follows because \(a_2,d<-1\), the remainder decays faster, and the residual is locally square integrable. Its inhomogeneous \(H^{-1}\) membership then follows from \(L^2\) membership.

For (c), a precise sufficient formulation of the addendum’s class is an exterior expansion
\[
\rho=r^kA_0+r^\beta A_1+r^{a_2}A_2+r^dA_d
+\sum_{j=1}^{J}\sum_{p=0}^{q_j}
r^{\lambda_j}(\log r)^p B_{jp}(\theta),
\qquad \lambda_j\le a_3,
\]
with finite angular polynomials, the stated parities and regularity, and the canonical Green inverse. The displayed four leading rows have no logarithms.

The residual’s only powers above \(a_3\) are then \(\beta,a_2,d\). Each exceeds \(-2\). Weighted integrability forces their coefficients to vanish successively, starting with the largest power. The coefficient at \(d\) is exactly \(-2A_d/k\); hence \(A_d=0\).

The mandatory addendum supplies this intended restriction. **If the theorem were instead stated using only a pointwise \(O(r^{a_3})\) remainder, the repair would be to impose the explicit finite expansion above, or quantitative derivative and canonical-inverse remainder estimates.**

I found no remaining overstatement in the combined proof and addendum. The conclusions concern fixed \(T\) and asymptotic radii. They do not establish that the \(a_2\) coefficient is nonzero, make removal of \(d\) sufficient by itself, or provide a finite-radius residual bound.

The [standalone audit and verification files](analysis/astra/tail109/single_tail_referee/PROOF.md) are saved in my folder. My attempted Opus 5.5 consultation failed during Bedrock credential retrieval, before any model ran; no new Opus review was obtained.