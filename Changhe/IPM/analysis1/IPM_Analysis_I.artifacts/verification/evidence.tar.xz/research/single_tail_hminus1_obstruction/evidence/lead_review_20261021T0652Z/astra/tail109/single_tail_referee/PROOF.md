# Independent proof audit of the single-tail obstruction

Final independent verdict: (a) VALID; (b) VALID; (c) VALID with the mandatory
addendum included. The mathematical argument was written before the new
computation. That computation has now verified the nonvanishing coefficient
directly from the original NPZ, removing this conditional hypothesis for
the explicit trial. The earlier modal definition and local regularity
remain the stated dependencies.

## Statement, hypotheses, notation, and dependencies

Let \(0<k<1/4\), \(c_0=1/k\), and
\[
 \beta=2k-1,\qquad a_2=3k-2,\qquad d=k-2,\qquad a_3=4k-3.
\]
Assume the density is even in \(x\), odd in \(y\), locally regular enough
that its residual is locally square integrable, and uses the canonical
finite-mode Green inverse of \(-\Delta\psi=\partial_x\rho\),
\(U=(-\psi_y,\psi_x)\), with no growing homogeneous stream terms.

For the explicit single-tail trial, its exterior density is
\[
 \rho_T=r^kD_0+r^\beta A_1+r^{a_2}D_2+r^dD_d+R,
\]
where \(A_1\) cancels the residual at \(\beta\). The remainder is a finite
sum of lower powers with finite logarithmic polynomials, the largest
power is at most \(a_3\), and all derivatives used below are obtained
by differentiating that expansion. The original fast joined row has
logarithmic degree at most six. Its canonical inverse is the corresponding
Green expansion, including its decaying homogeneous terms.

The exact modal input gives
\[
 D_d=R_b^{5-k}\cos^2\theta\sin\theta
       \sum_{m=0}^{259}A_{m,6}\cos(2m\theta),\qquad
 R_b=\exp(t_+).
\]
Normalization changes only column zero and a fast joined row. The
single-tail correction changes only the exterior \(\beta\) row;
its strain compensator is compactly supported.

Dependencies read in full: `single_tail_hminus1_obstruction/PROOF.md`
and its addendum; `normalized_tail_repair/PROOF.md` and its addendum;
`hminus1_tail_repair/PROOF.md` and its addendum;
`tail_forcing_norms/PROOF.md`, all under the submitted `ipmA-ver/research`.
The modal exterior definition and local regularity are used as stated
dependencies, rather than a new audit of the entire earlier project.

We prove: the \(r^d\sin\theta\) residual coefficient is
\[
 L_d=-\frac2kR_b^{5-k}b_d,\qquad
 b_d=\frac{2A_{0,6}-A_{2,6}}8.
\]
If \(b_d\ne0\), the residual belongs to \(L^2\) and inhomogeneous
\(H^{-1}\), but not homogeneous \(\dot H^{-1}\), and \(r\epsilon_T\)
does not belong to \(L^2\). In the same finite exterior class, allowing
arbitrary coefficients at \(k,\beta,a_2,d\), weighted integrability
forces the entire density coefficient at \(d\) to be zero.

## Velocity powers and exponent isolation

Euler differentiation gives
\[
 (c_0X\cdot\nabla-1)(r^aA)=(a/k-1)r^aA.
\]
The density parities give only odd sine frequencies in \(A\);
\(\partial_x(r^aA)\) has only modes \(\sin(2n\theta)\), \(n\ge1\).
For a forcing coefficient \(F_n r^{a-1}\sin(2n\theta)\),
\[
 -\Delta\bigl(r^{a+1}\sin(2n\theta)\bigr)
   =\bigl((2n)^2-(a+1)^2\bigr)r^{a-1}\sin(2n\theta).
\]
Nonresonant particular streams therefore have power \(a+1\), and
velocities have power \(a\). At resonance \(a+1=\pm2n\), solving the
Euler equation introduces a finite logarithmic polynomial at the same
power, and cannot create a larger power.

The stream exponents of the four displayed rows are
\(k+1,2k,3k-1,k-1\), all of absolute value less than two.
Thus these rows are nonresonant. The homogeneous stream basis allowed
by parity is \(r^{\pm2n}\sin(2n\theta)\). Canonical growth excludes
the positive powers, leaving velocity powers \(-2n-1\le-3\).
There is no zero-frequency logarithmic stream under these parities.
If two densities agree outside a compact set, their stream difference
is harmonic there and has just these allowed decaying terms.

An ordered product between a velocity of power \(a\) and the gradient
of a density of power \(b\) has power \(a+b-1\). Among \(k,\beta,a_2,d\)
and any lower powers, the only products strictly above \(a_3\) are
\[
 (k,k):\beta,\qquad (k,\beta),(\beta,k):a_2.
\]
The next products are
\[
 (\beta,\beta),(k,a_2),(a_2,k):a_3.
\]
Every product involving \(d\) is at most \(k+d-1=2k-3<a_3\).
Any lower row \(\lambda\le a_3\) paired with the largest row has power
\(k+\lambda-1\le k+a_3-1<a_3\).
Every homogeneous-velocity product has power at most \(k-4<a_3\).

In particular no nonlinear term contributes at \(d\), since
\[
 a_3<d<a_2<-1,\qquad d>-2,\qquad a_3<-2.
\]
The cancelled \(\beta\) term and the zero Euler coefficient at \(k\)
give
\[
 \epsilon_T=r^{a_2}C_2+r^dC_d
       +O\bigl(r^{a_3}(1+\log r)^q\bigr),\qquad
 C_d=-\frac2kD_d.
\]
Here the angular bound is uniform, \(q\) is finite, and constants may
depend on fixed \(T\). For the submitted finite nonresonant data,
\(q=12\) suffices. Any lower-power resonance in the general class only
changes the finite \(q\), not the conclusion. Compact modifications
change homogeneous coefficients, not \(C_2\) or \(C_d\).

## Frequency-one projection

The exact identity
\[
 \cos^2\theta\sin\theta=\tfrac14(\sin\theta+\sin3\theta)
\]
and \(\sin p\theta\cos q\theta
=\tfrac12[\sin((p+q)\theta)+\sin((p-q)\theta)]\)
give contributions to \(\sin\theta\) only from:

- \(m=0\): \(A_{0,6}/4\);
- \(m=1\): \(-A_{1,6}/8+A_{1,6}/8=0\);
- \(m=2\): \(-A_{2,6}/8\).

Thus the displayed formulas for \(b_d,L_d\) follow exactly.

## Homogeneous negative-norm obstruction

Define
\[
 \|f\|_{\dot H^{-1}}=
 \sup_{\phi\in C_c^\infty,\ \|\nabla\phi\|_2\le1}|\langle f,\phi\rangle|.
\]
Take \(g\ge0\), nonzero, in \(C_c^\infty((1,2))\), and set
\(\Phi_S(X)=g(|X|/S)\sin(\arg X)\). These are smooth annular tests,
have zero integral, and satisfy
\[
 \|\nabla\Phi_S\|_2^2
   =\pi\int_1^2\left(s|g'(s)|^2+g(s)^2/s\right)\,ds,
\]
independently of \(S\).

Writing \(C_{2,0}=\pi^{-1}\int C_2(\theta)\sin\theta\,d\theta\),
and \(I_a=\int_1^2g(s)s^{a+1}\,ds>0\), the residual expansion gives
\[
 \langle\epsilon_T,\Phi_S\rangle
  =\pi C_{2,0}I_{a_2}S^{3k}
   +\pi L_d I_dS^k
   +O(S^{4k-1}(1+\log S)^q).
\]
For fixed \(T\), the error tends to zero. If \(C_{2,0}\ne0\), the
first term dominates. If \(C_{2,0}=0\), the nonzero second term
dominates. In both cases the absolute pairing is unbounded while
the gradient norm is constant. This proves failure of \(\dot H^{-1}\)
without assumptions about a pointwise realization of its dual.

## Weighted integrability and the finite-class necessity

If \(C_2\not\equiv0\), the uniform asymptotics imply, for all large \(r\),
\(\|\epsilon_T(r,\cdot)\|_{L^2_\theta}\ge c r^{a_2}\).
Otherwise the same lower bound holds with \(d\), since \(C_d\ne0\).
Consequently
\[
 \|r\epsilon_T\|_2^2\ \ge\
 c^2\int^\infty r^{2a+3}\,dr=\infty
 \quad\text{for }a=a_2\text{ or }d,\quad a>-2.
\]
The unweighted integral converges because both displayed exponents
are less than \(-1\), with a still smaller remainder. Local square
integrability is a stated regularity dependency. \(L^2\) embeds
continuously into inhomogeneous \(H^{-1}\) by Cauchy--Schwarz.

For clarity, a sufficient precise finite-class definition is: outside
some radius the density is the four pure displayed rows plus a finite
sum
\[
 \sum_{j=1}^J\sum_{p=0}^{q_j}
 r^{\lambda_j}(\log r)^p B_{jp}(\theta),\qquad \lambda_j\le a_3,
\]
with finite odd-sine polynomials, appropriate local regularity, and
the canonical Green inverse just described. This realizes the mandatory
addendum's intended restriction. More general remainders require
explicit differentiated and Green-inverse estimates; a pointwise
\(O(r^{a_3})\) condition alone is insufficient.

Before any cancellations the residual's only rows above \(a_3\) have
powers \(\beta,a_2,d\). A nonzero row at any of these powers prevents
weighted integrability because each exceeds \(-2\). Descending through
these distinct powers therefore forces all three residual rows to
vanish. The last is exactly \(-2/k\) times the \(d\) density row,
so that density row must be zero. Necessity is for the full angular
row, not only its frequency-one component.

## Exact numerical method and limits

The separate verification script reads each binary64 input as an exact
rational. One projection uses the closed formula; the other multiplies
Laurent polynomials for the two cosines and one sine against all 260
column entries. It also checks every ordered pair of the eleven actual
exterior exponents and every required Green denominator.

For a library-independent transcendental bound, put
\(x=(5-k)t_+>0\) and \(S_N=\sum_{j=0}^N x^j/j!\).
If \(x<N+2\), the positive Taylor series and its tail ratios give
\[
 S_N<e^x<
 S_N+\frac{x^{N+1}}{(N+1)!}\frac1{1-x/(N+2)}.
\]
All terms and both endpoints are rational. Multiplication by the
positive rational \(-2b_d/k\) encloses \(L_d\). Exact comparison against
the two decimal rationals tests the submitted strict interval.

This argument is for each fixed \(T\), as \(r\to\infty\). It does not
evaluate \(C_2\), estimate a finite-radius residual, bound a full norm
numerically, establish stationarity, or classify other tail types.
It gives no necessity for a nonzero \(a_2\) correction. The canonical
velocity itself may grow like \(r^k\); only its homogeneous exterior
ambiguity is required to decay.

## Completed verification

The original source SHA-256 is
`a069d85d102e17340778042f85c003705716ba799c0f68873d10c1c582ea4874`.
The exact inputs read directly from that NPZ give
\[
 t_+=\frac{2289893859708677}{281474976710656},\qquad
 b_o=\frac{2210212141903103}{17592186044416},
\]
and
\[
 b_d=-\frac{6077384870622209}{39614081257132168796771975168}.
\]
The closed projection, full Laurent product, and full product-to-sum
projection agree exactly for all 261 output sine coefficients.
All 121 ordered exterior exponent pairs were checked, as were 4,437
nonzero Green denominators. No pair attains \(d\).

Using the exact Taylor bound above with \(N=256\) proves the strict interval
\[
184130.68809691860443309136512698<L_d
<184130.68809691860443309136512700.
\]
More decimal digits, each certified by exact rational comparison, appear
in `verification/recomputed.json`. The computation used about 34 MiB of
maximum resident memory and ran serially.

No mathematical repair remains necessary when the mandatory addendum is
read as part of the theorem. The bare statement (c), if detached from
its addendum and read as a pointwise-remainder assertion, would be
insufficiently specified. The explicit finite-sum formulation above is
a precise way to incorporate the addendum into the statement itself.

An attempted new collaboration requested `us.anthropic.claude-opus-5-5`
using the existing Python Bedrock configuration. It failed with
`CredentialRetrievalError` before invocation. No actual model ran and no
Opus mathematical review was received in this audit; no other model was
substituted. The request and availability metadata are retained in
`verification/`. The submitted addendum's two earlier Opus refusals are
also not mathematical reviews.
