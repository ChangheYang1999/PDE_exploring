# Lead mathematical review of ver topic 109 (single_tail_hminus1_obstruction)

Reviewed files: PROOF.md SHA 5428643bf837a0f4506c6487221fff4b7948f553593f185de532e3fcb194e758, ADDENDUM.md and
PUBLICATION.md as present at 2026-10-21T06:45Z.

Reviewers:
1. The lead lane itself, model Claude Opus 5.5 (us.anthropic.claude-opus-5-5), 2026-10-21T06:45Z to 06:52Z.
2. Astra (GPT-6 astra through Codex, high reasoning effort), tag tail109, question notes/q_tail109/question.md,
   answer astra/tail109/answer.md, received by 2026-10-21T06:51Z. Its attempt to consult Opus failed before any
   model ran; that is not part of the review.

Lead checks (by hand, then numerically):
- Exponents: beta = 2k-1, a2 = 3k-2, d = k-2, a3 = 4k-3, with a3 < d < a2 < -1, d > -2, a3 < -2 for 0 < k < 1/4.
  Density powers k - j(1-k) - 2l; (0,1) gives d; (1,1) gives 2k-3 < a3.
- Linear factor: (c0 X.grad - 1) r^a A = (a/k - 1) r^a A; at d it is -2/k.
- Velocity of r^a A has power a (stream power a+1; the four stream powers k+1, 2k, 3k-1, k-1 are not even
  integers of absolute value at least 2, so no resonance). Decaying homogeneous streams under the parities are
  r^{-2n} sin(2n theta), n >= 1, velocity power at most -3. Products have power a+b-1; the only ones above a3 are
  (k,k) at beta and (k,beta), (beta,k) at a2; products involving d have power at most 2k-3 < a3. No term at d
  except the linear one. Compact density changes add only decaying homogeneous velocity outside their support.
- Projection: cos^2 sin = (sin + sin 3 theta)/4; sin theta coefficient of cos^2 sin cos(2m theta) is 1/4, 0, -1/8
  for m = 0, 1, 2 and 0 for m >= 3. So b_d = (2 A_{0,6} - A_{2,6})/8.
- Annular tests: ||grad Phi_S||_2 is scale invariant in 2D; pairing exponents a2+2 = 3k, d+2 = k > 0,
  a3+2 = 4k-1 < 0; the two cases C_{2,0} != 0 and C_{2,0} = 0 are exhaustive. Correct proof that eps_T is not
  a bounded functional on dot H^1.
- r eps_T: integral of r^{2a+3} diverges for a > -2 (a = a2 or d). eps_T in L^2 since a2 < -1.
- Necessity (c): with the class as made precise in ADDENDUM.md (finite expansion with differentiated
  asymptotics; arbitrary pointwise O-remainders excluded), the residual powers above a3 are beta, a2, d, all
  above -2, and the d row is -(2/k) times the density row. Correct.
- Numerics (notes/fr109/check_bd.py, lead, independent code): NPZ SHA a069d85d...; exact rational
  b_d = -6077384870622209/39614081257132168796771975168 (agrees); quadrature of the sin theta coefficient
  -1.5341476257329656e-13 (agrees); mpmath iv at 60 digits:
  L_d in [184130.688096918604433091365126981040690713, 184130.68809691860443309136512698104069071320]
  (agrees with ver's enclosure). R_b = exp(t_plus) about 3412.967, R_b^{5-k} about 1.0764e17.

Verdict: (a), (b), (c) VALID as stated in PROOF.md with the ADDENDUM.md restriction of the class in (c). No
overstatement found. Astra reaches the same verdicts independently (VALID, VALID, VALID) and recomputes b_d and the
same L_d enclosure by an exact Taylor sum. The conclusions are for fixed T and r -> infinity; nothing about the a2
row, a finite-radius bound, a neighbourhood of X3, or an endpoint follows.
