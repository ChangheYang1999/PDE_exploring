# Independent preliminary reconstruction, before proof and code

S1: at s=31/10 the homogeneous energy bound is affine in xi^2/r^2.
Slow margin is 1+A/2+(1/2-s)mu, minimum1687/500 atA10,mu101/100.
Fast margin is1+(1/2-s)A+mu/2+g, minimum159/40=3.975 atA51/5,mu99/100,g29.
Inhomogeneous factor r^2/(1+r^2)<=1 decreases the positive transport term.
S2: first-order multiplier Taylor term is -s d_jw_i partial_ij J^(s-2).
Hessian bound s(s-1)<eta>^(s-2), integral(1-t) and convex split yieldtheprinted
s(s-1)2^(s-4). W2 plus beta_(s-1)H^s give the claimed low-orderremainder.
Taylor w: |V-Dz|<=M_V|z|^2/2, derivative<=M_V|z|. div(V-Dz)=0,
so E coefficient41.7 at Ctheta2 checks exactly.
S3: U vector symbol (xi eta/r2,-xi²/r2) has angular derivative norm1;
pointwise commutator split high |eta|>=1, |k|<=|eta|/2; complementarylargek
andloweta separately. Kernelderivatives via (x+iy)^-2 are correct.
Raw sigma=psi_xy is used with ell=X.grad rho/3. DO NOT silently call sigma
PROMPT c[h]=sigma/3. The source uses raw c notation; rewrite explicitly.
Kernelstrain sin3theta/(pi r3) absolute<=1/(pi r3); nearP area estimateisC_c.
S4: global localization identity correct since theta1 on suppchi; outside
chi all transport terms vanish but nonlocaltermsare retained. Q=g+sumBq
bounds multiplication of nearcommutator, farcommutator=-chi U hfar.
Cutofflambda_A supporteddelta<r<2delta, in/outbufferdelta/8. Offdiagonal
J^s kernel by heat continuation yields D_s; all constants explicit.
Potential risks to interrogate: arbitrary extension infima with zeta/chi,
inhomogeneous low-frequency multiplier at0, exact K1 without cutoffnorm,
semigroup/domain proof beyond an energy bound; asymptoticK2/K3/K4 claims;
normalization atorigin versus sourceP. No actual coefficientboundsorouter
inverse provided; no IPM endpoint. Mainlocalestimate shouldbeproved first;
optionalauxiliarysemigroup existence needs a real domain/core argument.
