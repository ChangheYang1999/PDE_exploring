You are an independent mathematical researcher and referee, consulted by another researcher working on the problem described below. Be skeptical, concrete and complete; check every step you rely on; say plainly when something is wrong, unproved, or only conditional. Your final message is your answer: make it self-contained.

Machine rules (no exceptions): never start a server or anything that listens on a port; never run JavaScript tooling (node, npm, npx, pnpm, yarn, vite, playwright); no GPU; wrap shell commands in `timeout 540`; single-threaded computations under 2 GB RAM. Write files only in your current directory. Do not modify any other file.

Question:

Context. Self-similar profiles of the 2D incompressible porous media (IPM) equation in the full plane:
F(rho) = (c_l X + U[rho]).grad rho - rho = 0, U = (-psi_y, psi_x), -Lap psi = d_x rho, so U[h]^ = (xi eta, -xi^2)/|zeta|^2 h^,
rho even in x, odd in y, rho = x^2 y a near 0, a(0) = 1. Linearization at a smooth trial rho~ (with its own V):
  L h = (V.grad - 1) h + U[h].grad rho~ + (c[h]/3) X.grad rho~,  V = c_l X + U[rho~],  div V = 2 c_l,  c[h] = psi[h]_xy(0).
Trial values: c_l = 5.5754, A = 2 c_l - 1 = 10.1507, b_0 = 1 + c_l = 6.5754. The axis source P~ = (x_*, 0), x_* = 8.6001, is a
zero of V with DV(P~) = diag(A_P, mu_P), A_P in (10.1494, 10.1525), mu_P = 1 - 2.25e-8 (floating), grad rho~(P~) = (0, g),
g = 29.75; rho~ and V are C^5 near P~ with certifiable sup bounds on derivatives (interval Taylor models; not yet computed).
P~ is a hyperbolic source node; every orbit of V in the open quadrant leaves P~ and goes to infinity or (along the x-axis
segment) to the saddle at 0.
Established (treat as given unless you find an error): the frozen operator L_P = A s d_s + mu y d_y - 1 - g M, M = xi^2/|zeta|^2
(s = x - x_*), is bijective on ordinary H^sigma for 0 <= sigma < s_fast = (g + b_0)/A = 3.5786 with the energy identity
  Re <L_P h, h>_{H^sigma} = int <zeta>^{2 sigma} beta |h^|^2 (inhomogeneous version: with the factor |zeta|^2/<zeta>^2 on the
  stretching part),  beta = -(A + mu)/2 - 1 + sigma (A xi^^2 + mu eta^^2) - g xi^^2  (xi^, eta^ unit),
and uniform margins b - sigma mu >= 1687/500, b + g - sigma A >= 159/40 at sigma = 31/10, b = 1 + (A + mu)/2, over the box
10 <= A <= 51/5, 99/100 <= mu <= 101/100, 29 <= g <= 30; inverse norm <= 500/1687 on H^{31/10}. Above s_fast no ordinary H^sigma
graph realization of the variable-coefficient operator plus finite rank is Fredholm. In Hoelder spaces the frozen inverse loses
(sigma - 1)/A derivatives (so a realization with C^{2,alpha} control near P must be Sobolev of order 3 < sigma < s_fast there).
The bounded inverse of pure transport V.grad - 1 reads forcing along forward orbits (from downstream): h(z) = -int_0^inf e^{-t}
f(Phi_t z) dt; a cutoff chi decreasing away from P has V.grad chi <= 0, the unfavourable sign in a weighted energy identity.

The issue. Every candidate global realization of L needs, near P~, an estimate for the actual variable-coefficient operator
(not the frozen one) in ordinary H^sigma, 3 < sigma < s_fast, with EXPLICIT constants (it is for a computer-assisted proof;
non-explicit constants such as unspecified Kato-Ponce or Garding constants are useless), and a clear statement of what it
needs from the neighbouring region.

Questions. Give proofs with explicit constants, state hypotheses exactly, separate proved statements from heuristics.
Q1. Local a priori estimate. Fix sigma in (3, s_fast) (for definiteness sigma = 31/10), a radius delta and smooth radial
cutoffs chi = 1 on B_delta(P~), supp chi in B_{2 delta}(P~), chi~ = 1 on supp chi. Prove an estimate of the form
  ||chi h||_{H^sigma} <= K_1 ||chi~ L h||_{H^sigma} + K_2 ||h||_{H^sigma(B_{2 delta} \ B_delta)} + K_3 ||h||_{H^{sigma-1}(B_{3 delta})} + K_4 N_far(h)
for all h in a stated class (for example h in H^sigma_loc with a global weighted L^2 or L^1 bound N_far(h) controlling the
nonlocal tails of U and c), with K_1 = 1/(kappa - E(delta)), kappa the frozen margin, and E(delta) an explicit perturbation
bound in terms of: sup norms of D^j V and D^j rho~ on B_{3 delta} (state which j), delta, and the cutoff derivatives. Treat
explicitly: (i) the transport perturbation w = V - DV(P~) (X - P~), w = O(|X - P~|^2): the commutator [Lambda^sigma, w.grad]
(for example by a Fourier-side Taylor bound of <zeta>^sigma - <zeta'>^sigma and Wiener-algebra norms ||<k>^m w^||_{L^1} of a
localized w, or by an integer-order energy identity plus interpolation if that gives better constants; say which is
sharper and give the constants); (ii) the coupling: U[u].grad rho~ = -g M u + U[u].(grad rho~ - (0, g)) with u = chi h, and
the commutators [U, chi] (order -1) and the strain term c[chi h] - chi c[h] (c is evaluated at the distant origin); (iii) the
cutoff term (V.grad chi) h, which is of order zero in h and supported on the annulus. Is K_2 necessarily of order one (the
outflow term), and can it be reduced by choosing chi with V.grad chi small relative to chi (for example chi a function of
an adapted Lyapunov function of the source)? (iv) the deviation of A_P, mu_P from the box centre (covered by the box).
Q2. Size. With E(delta) <= C_V delta (C_V explicit in sup |D^2 V|, sup |D^2 rho~|, ...), estimate how small delta must be for
E(delta) <= kappa/2, and what then happens to K_2, K_3 (powers of 1/delta). Give the formulas so that the values can be
filled in from certified coefficient bounds.
Q3. Transition. For the assembled realization, the annulus term must be supplied by an estimate in the neighbouring
(outflow) region, typically a weighted transport energy estimate with weight e^{+phi}, V.grad phi >= 2(E + kappa_0)^+ along
the flow, of local order sigma or a b-type order. State precisely what that outer estimate must provide (norm, order,
region overlap) so that the two combine into an estimate on B_{2 delta} union the outer region without circularity, and
whether the downstream reading of the transport inverse makes the combination triangular (source estimate last).
Q4. Existence, not only a priori. Does the frozen bijectivity plus the local estimate give a local solution operator (for
example by a parametrix: solve the frozen problem for chi~ f, correct by the perturbation in a Neumann series), with explicit
bounds? What compatibility with the outer solution is needed (the outer solution reads data from downstream, the source
problem from the whole plane through M)?
Q5. Any obstruction: does the nonlocal term, the cusp (Hoelder order (1 + g)/A of the frozen inverse for smooth forcing) or
mu_P != 1 at the trial (distance 2.25e-8) spoil an explicit H^sigma local estimate below threshold? Is the order sigma = 31/10
(or any order in (3, s_fast)) compatible with the requirement that the commutator constants stay small on a disc whose
radius is not tiny compared with the knot spacing 0.0165 of the trial (structure of the trial's coefficients at that scale
makes sup |D^j V| large for j >= 3 or 4)?

Answer in text with formulas; do not start servers, run JavaScript tooling or Lean, or write outside your working area.
