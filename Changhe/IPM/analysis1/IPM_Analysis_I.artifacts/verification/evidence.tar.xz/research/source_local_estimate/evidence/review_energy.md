# An explicit local source estimate in inhomogeneous Sobolev spaces

Status at proof writing: independent analytical reconstruction of V23/S1-S5.
The scalar arithmetic and external review are pending. Section 10 separately
states what has and has not been proved about an auxiliary inverse. Nothing
here supplies the global inverse required by IPM Analysis I.

## 1. Statement, normalization, and domain

All functions are on R^2. Use the unitary Fourier transform
fhat(xi)=(2pi)^(-1) integral exp(-i X.xi) f(X)dX and J^r=(1-Delta)^(r/2).
The H^r norm is ||J^r f||_2. For an open set Omega its restriction norm is
the infimum of whole-plane extension norms. Vector norms are Euclidean
sums of component squares; derivative tensors use the Frobenius norm.

Set s=31/10 and t=s-1=21/10. Let P=(p,0), p>0. Suppose, on B_(3delta)(P),
V is C^4, rho is C^5, and

    V(P)=0, DV(P)=D=diag(A,mu), grad rho(P)=aP=(0,g),
    div V=A+mu,
    10<=A<=51/5, 99/100<=mu<=101/100, 29<=g<=30,
    0<delta<=1, 3delta<p/2.                                  (1)

No stationarity of rho is assumed. Let a=grad rho and ell=X.a/3.
The canonical order-zero velocity has vector Fourier symbol

    m(xi,eta)=(xi eta/(xi^2+eta^2), -xi^2/(xi^2+eta^2)).        (2)

Its arbitrary value at the single frequency zero is immaterial in L2.
Write sigma[h]=psi[h]_xy(0) for RAW strain. The normalized linearization
in this note is

    Lh=V.grad h-h+a.U[h]+ell sigma[h].                       (3)

Thus the scaling functional called c[h] in PROMPT.md is sigma[h]/3.
The source document's symbol c in ell*c must mean raw sigma. We use (3)
throughout to avoid a hidden factor of three.

Initially take h in C_c^infinity with h(0)=grad h(0)=0. This guarantees
absolute convergence of the strain kernel integral below. Conclusions
extend by limits in the explicitly displayed norms, with sigma and U
defined by those limits. No density claim about another IPM domain is made.

Choose smooth cutoffs valued in [0,1], centred at P:

    chi=1 on B_(5delta/4), supp chi inside B_(7delta/4),
    tau=1 on supp chi, supp tau inside B_(9delta/4),
    theta=1 on B_(2delta), supp theta inside B_(3delta),
    zeta=1 on B_(5delta/2), supp zeta inside B_(3delta).        (4)

All displayed inclusions are strict support inclusions, so products extend
smoothly by zero. Put

    w=theta(V-D(X-P)), q=theta(a-aP),
    Aop=D(X-P).grad-1-gM+w.grad+q.U,
    Mhat=xi^2/(xi^2+eta^2).                                 (5)

The theorem below is a local a priori estimate whenever E<kappa, with
kappa=1687/500 and E in (12). Every constant is defined here.

## 2. Frozen energy margin

For Schwartz u, Fourier integration by parts gives

 Re <(D z.grad-1-gM)u,u>_(H^s)
 = integral [-(A+mu)/2-1
       +s(A xi^2+mu eta^2)/(1+xi^2+eta^2)
       -g xi^2/(xi^2+eta^2)] |J^s uhat|^2.                  (6)

This follows from (z_i partial_i u)^hat=-partial_i(xi_i uhat),
with the constant translation P contributing an imaginary multiplier.
The positive transport fraction is no larger than its homogeneous value.
For nonzero frequency put theta0=xi^2/(xi^2+eta^2). The homogeneous
coefficient is affine in theta0. Its negative at theta0=0 and 1 is

    kslow=1+A/2+(1/2-s)mu,
    kfast=1+(1/2-s)A+mu/2+g.

Their exact box minima are respectively1687/500 and159/40. Therefore
(6)<=-kappa||u||_(H^s)^2. The zero frequency has measure zero.
The fast box margin at a variable s is35595/1000-(51/5)s;
its zero is2373/680. This does not extend the uniform box estimate to
the larger threshold of the exact central source parameters.

## 3. Explicit multiplication and transport commutators

For a compact coefficient f define

 W_r(f)=(2pi)^(-1) integral <k>^r |fhat(k)|dk,
 alpha_r=1/[2 sqrt(pi(r-1))], r>1,
 beta_r=1/[2 sqrt(pi(r-1)(r-2))], r>2,
 P_s(f)=s 2^(s-2)[W_1(f)+alpha_(s-1)||f||_(H^s)],
 B_s(f)=||f||_infinity+P_s(f), M_r(f)=2^(r/2)W_r(f).          (7)

Polar integration proves integral(1+|xi|^2)^(-r)d xi=pi/(r-1)
and integral|xi|^2(1+|xi|^2)^(-r)d xi=pi/[(r-1)(r-2)]. Cauchy-Schwarz
therefore gives (2pi)^(-1)||vhat||_1<=alpha_r||v||_(H^r),
and (2pi)^(-1)|| |xi|vhat||_1<=beta_r||v||_(H^r).

For s=3.1, the mean value theorem and the convex inequality
(a+b)^(s-1)<=2^(s-2)(a^(s-1)+b^(s-1)) give

 |<eta+k>^s-<eta>^s|
 <=s 2^(s-2)(|k|<eta>^(s-1)+|k|^s).

Apply the L1*L2 and L2*L1 forms of Young's inequality to the two terms,
including the (2pi)^(-1) convolution factor. This proves

 ||[J^s,f]v||_2<=P_s(f)||v||_(H^(s-1)),
 ||fv||_(H^s)<=||f||_infinity||v||_(H^s)
                      +P_s(f)||v||_(H^(s-1)),
 ||fv||_(H^r)<=M_r(f)||v||_(H^r), r>=0.                     (8)

The last bound uses <eta+k><=sqrt(2)<eta><k>. In particular B_s(f)
is a valid full H^s multiplier bound, because H^s controls H^(s-1).

To isolate the leading transport derivative, Taylor expand j_s=<eta>^s.
Its Hessian is s<eta>^(s-2)I+s(s-2)<eta>^(s-4) eta eta^T, with operator
norm at most s(s-1)<eta>^(s-2). Integral Taylor remainder and
<eta+vk><=<eta>+v|k| yield

 |j_s(eta+k)-j_s(eta)-Dj_s(eta).k|
 <=s(s-1)2^(s-4)|k|^2[<eta>^(s-2)+|k|^(s-2)].

Here integral_0^1(1-v)dv=1/2 and v^(s-2)<=1 explain the coefficient.
Multiplying by |eta_i| and using the two Young inequalities proves

 [J^s,w.grad]u=-s sum_(i,j)(partial_j w_i)partial_ij J^(s-2)u+Rw u,
 ||Rw u||_2<=T_s(w)||u||_(H^(s-1)),
 T_s(w)=s(s-1)2^(s-4) sum_i[W_2(w_i)+beta_(s-1)||w_i||_(H^s)]. (9)

The sign follows independently by the Fourier factor
(ik_j)(-eta_i eta_j) times -s. Moreover
sum_ij||partial_ij J^(s-2)u||_2^2<=||u||_(H^s)^2, so pointwise
Cauchy-Schwarz controls the leading term by s||Dw||_(infinity,F)||u||_(H^s).

All constants use finite derivatives. Indeed

 W_r(f)<=alpha_(n-r)||f||_(H^n), n-r>1,
 ||f||_(H^n)^2=sum_(|gamma|<=n) n!/[(n-|gamma|)!gamma!] ||D^gamma f||_2^2, (10)

by Cauchy-Schwarz and the multinomial expansion of(1+|xi|^2)^n.
Use support area and derivative suprema for the latter terms. Also
||f||_(H^s)<=||f||_(H^3)^(4-s)||f||_(H^4)^(s-3), with constant1 by Holder
in Fourier space. Coefficients w,q in compact C^4 have the required norms;
W2(w) uses H4, W1(q) uses H3, and Hs uses H4. The given rho C5 suffices.

## 4. Perturbed energy and its small coefficient

The transport part w.grad contributes -div w/2 after integrating the
principal term, and the commutator (9) contributes the remaining terms.
The vector U symbol has norm at most1. Apply (8) to each q_i U_i u, using
pointwise |q.U J^s u|<=|q| |U J^s u| for its leading term. Thus

 Re <Aop u,u>_(H^s)
 <=-(kappa-E)||u||_(H^s)^2+R||u||_(H^(s-1))||u||_(H^s),     (11)
 E=||div w||_infinity/2+s||Dw||_(infinity,F)+||q||_infinity,
 R=T_s(w)+sum_i P_s(q_i).                                   (12)

Write M_V=sup_B ||D²V||_F, M_rho=sup_B ||D²rho||_F,
C_theta=delta||grad theta||_infinity. Taylor's integral formula gives
|V-Dz|<=M_V|z|²/2 and ||DV-D||_F<=M_V|z|. Since div(V-Dz)=0,

 ||Dw||_(infinity,F)<=[3+(9/2)C_theta]M_V delta,
 ||div w||_infinity<=(9/2)C_theta M_V delta,
 ||q||_infinity<=3M_rho delta.

Consequently

 E<=C_V delta,
 C_V=[3s+(9/2)(s+1/2)C_theta]M_V+3M_rho.                   (13)

For C_theta=2 this is41.7 M_V+3M_rho. If delta<=kappa/(2C_V), then
(kappa-E)^(-1)<=1000/1687. At delta33/2000 the sufficient exact
threshold is C_V<=3374/33, approximately102.2424. Any actual use requires
certified coefficient bounds on that containing disc; none are supplied here.

