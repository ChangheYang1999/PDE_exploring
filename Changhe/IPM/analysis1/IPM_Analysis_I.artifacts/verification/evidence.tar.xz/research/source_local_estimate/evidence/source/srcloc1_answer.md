An explicit local estimate is possible. The essential point is to put only first derivatives of the transport perturbation, and the value of the coupling perturbation, into the coefficient that must be small. Higher coefficient derivatives can be assigned to an \(H^{\sigma-1}\) remainder.

There are three qualifications:

- A bound controlling the nonlocal velocity near \(P\) need not control the strain evaluated at the origin.
- Multiplication by \(\chi\) is not a contraction on \(H^\sigma\). Obtaining exactly \(K_1=(\kappa-E)^{-1}\), with your larger forcing cutoff, requires additional bookkeeping.
- The local estimate alone neither supplies the annular data nor proves surjectivity of an assembled global operator.

Below is one complete, conservative set of constants. These are sufficient constants, not optimized ones.

I derive the commutator bounds directly. Taylor expansion of fractional multiplier symbols is also the basis of refined fractional Leibniz estimates, but no unspecified constant from that literature is used here. ([arxiv.org](https://arxiv.org/pdf/1609.01780))

Throughout, \(P=\widetilde P\), \(z=X-P\), \(s=\sigma=31/10\), and \(t=s-1=21/10\).

---

**The precise hypotheses and norms.**

Write
\[
D=\operatorname{diag}(A_P,\mu_P),\qquad
a(X)=\nabla\widetilde\rho(X),\qquad
a_P=(0,g),\qquad
\ell(X)=\frac13X\cdot a(X).
\]
Assume, exactly,
\[
V(P)=0,\quad DV(P)=D,\quad a(P)=a_P,\quad
\operatorname{div}V=\operatorname{tr}D.
\]
Assume \(V\in C^4(B_{3\delta}(P))\), \(\widetilde\rho\in C^5(B_{3\delta}(P))\), with certified derivative bounds, and
\[
0<\delta\le1,\qquad 3\delta<|P|/2.
\]
The stated \(C^5\) hypothesis on \(V\) is more than this proof needs.

Use the unitary Fourier transform
\[
\widehat f(\xi)=(2\pi)^{-1}\int_{\mathbb R^2}e^{-ix\cdot\xi}f(x)\,dx,
\qquad J^r=(1-\Delta)^{r/2}.
\]
For an open set \(\Omega\), use the restriction norm
\[
\|h\|_{H^r(\Omega)}
=\inf\{\|H\|_{H^r(\mathbb R^2)}:H|_\Omega=h\}.
\]
This fixes the meaning of the annular norm and its constants.

Initially take \(h\in C_c^\infty(\mathbb R^2)\), with
\[
h(0)=0,\qquad \nabla h(0)=0.
\]
Your condition \(h=x^2y\,b\) near the origin suffices. The result extends to the completion of this class in the displayed graph and right-hand-side norms; no density assertion for some other proposed domain is implicit.

For the estimate with exactly your prescribed \(K_1\), choose the following admissible cutoffs:
\[
\begin{aligned}
&0\le\chi\le1,\quad
\chi=1\text{ on }B_{5\delta/4},\quad
\operatorname{supp}\chi\subset B_{7\delta/4},\\
&0\le\tau=\widetilde\chi\le1,\quad
\tau=1\text{ on }\operatorname{supp}\chi,\quad
\operatorname{supp}\tau\subset B_{9\delta/4},\\
&0\le\theta\le1,\quad
\theta=1\text{ on }B_{2\delta},\quad
\operatorname{supp}\theta\subset B_{3\delta},\\
&0\le\zeta\le1,\quad
\zeta=1\text{ on }B_{5\delta/2},\quad
\operatorname{supp}\zeta\subset B_{3\delta}.
\end{aligned}
\tag{1}
\]
All balls here and below are centred at \(P\). Cutoff derivatives through order five suffice.

These buffers are a choice within the radii in your question. For arbitrary already-supplied cutoffs, the basic estimate below still holds, but the immediate forcing coefficient is a cutoff multiplier norm times \((\kappa-E)^{-1}\).

Define
\[
\begin{aligned}
N_{\rm far}(h)
={}&
\int_{|X-P|\ge5\delta/2}
       \frac{|h(X)|}{|X-P|^2}\,dX\\
&+\int_{\mathbb R^2\setminus B_{3\delta}(P)}
       \frac{|h(X)|}{|X|^3}\,dX .
\end{aligned}
\tag{2}
\]
The second integral deliberately includes the origin. Its local integrability follows from the imposed vanishing of \(h\).

Without that vanishing condition, replace the strain part of this definition by a bound that explicitly controls \(c[h]\), for example by including \(|c[h]|\). A velocity-tail norm alone is insufficient.

---

**Explicit Fourier estimates used in the proof.**

For compactly supported \(f\), set
\[
W_r(f)=\frac1{2\pi}\int\langle k\rangle^r|\widehat f(k)|\,dk,
\]
and define
\[
\alpha_r=\frac1{2\sqrt{\pi(r-1)}}\quad(r>1),\qquad
\beta_r=\frac1{2\sqrt{\pi(r-1)(r-2)}}\quad(r>2).
\]
Cauchy–Schwarz gives
\[
\frac1{2\pi}\|\widehat v\|_1\le\alpha_r\|v\|_{H^r},
\qquad
\frac1{2\pi}\||\xi|\widehat v\|_1\le\beta_r\|v\|_{H^r}.
\tag{3}
\]

Introduce the explicitly computable quantities
\[
\begin{aligned}
P_s(f)&=s2^{s-2}
       \left(W_1(f)+\alpha_{s-1}\|f\|_{H^s}\right),\\
B_s(f)&=\|f\|_\infty+P_s(f),\\
M_r(f)&=2^{r/2}W_r(f).
\end{aligned}
\tag{4}
\]
Then
\[
\begin{aligned}
\|[J^s,f]v\|_2&\le P_s(f)\|v\|_{H^{s-1}},\\
\|fv\|_{H^s}&\le
 \|f\|_\infty\|v\|_{H^s}
 +P_s(f)\|v\|_{H^{s-1}},\\
\|fv\|_{H^r}&\le M_r(f)\|v\|_{H^r}.
\end{aligned}
\tag{5}
\]

For completeness, the first inequality follows from
\[
\left|\langle\eta+k\rangle^s-\langle\eta\rangle^s\right|
\le s2^{s-2}
\left(|k|\langle\eta\rangle^{s-1}+|k|^s\right),
\]
followed by the two versions of Young’s convolution inequality. The other two follow by adding \(fJ^sv\), and from
\(\langle\eta+k\rangle\le\sqrt2\langle\eta\rangle\langle k\rangle\).

All quantities in (4) can be bounded from finitely many sup norms. In particular,
\[
W_r(f)\le\alpha_{n-r}\|f\|_{H^n},
\qquad n-r>1,
\tag{6}
\]
and, for integer \(n\),
\[
\|f\|_{H^n}^2
=\sum_{|\gamma|\le n}
 \frac{n!}{(n-|\gamma|)!\gamma!}\|D^\gamma f\|_2^2.
\tag{7}
\]
Thus each \(L^2\) derivative norm can be replaced by
\(|\operatorname{supp}f|^{1/2}\|D^\gamma f\|_\infty\).
For \(3<s<4\), the sharper bound
\[
\|f\|_{H^s}\le
\|f\|_{H^3}^{\,4-s}\|f\|_{H^4}^{\,s-3}
\tag{8}
\]
has constant one.

These formulas make the constants below directly usable with interval derivative bounds.

---

**The transport perturbation and the small coefficient.**

Extend the perturbations by
\[
w=\theta\bigl(V-Dz\bigr),\qquad q=\theta(a-a_P),
\]
and consider the whole-plane auxiliary operator
\[
\mathcal A=L_P+w\cdot\nabla+q\cdot U.
\tag{9}
\]
Only known coefficients inside \(B_{3\delta}\) enter these extensions.

The useful transport expansion is
\[
[J^s,w\cdot\nabla]u
=-s\sum_{i,j}(\partial_jw_i)\,
       \partial_{ij}J^{s-2}u+\mathcal R_wu,
\tag{10}
\]
where
\[
\|\mathcal R_wu\|_2\le T_s(w)\|u\|_{H^{s-1}},
\]
with
\[
T_s(w)=s(s-1)2^{s-4}
 \sum_{i=1}^2
 \left(W_2(w_i)+\beta_{s-1}\|w_i\|_{H^s}\right).
\tag{11}
\]

Here is the remainder calculation. The Hessian of
\(j_s(\eta)=\langle\eta\rangle^s\) has operator norm at most
\(s(s-1)\langle\eta\rangle^{s-2}\). Consequently,
\[
\begin{aligned}
&|j_s(\eta+k)-j_s(\eta)-Dj_s(\eta)\cdot k|\\
&\qquad\le
s(s-1)2^{s-4}|k|^2
\bigl(\langle\eta\rangle^{s-2}+|k|^{s-2}\bigr).
\end{aligned}
\]
After multiplication by \(|\eta_i|\), the first term uses
\(W_2(w_i)\|u\|_{H^{s-1}}\); the second uses
\(\|w_i\|_{H^s}(2\pi)^{-1}\||\eta|\widehat u\|_1\).
Equation (3) proves (11).

Using the Frobenius norm for matrices,
\[
\left\|
\sum_{i,j}(\partial_jw_i)\partial_{ij}J^{s-2}u
\right\|_2
\le \|Dw\|_{\infty,F}\|u\|_{H^s}.
\tag{12}
\]
Indeed,
\[
\sum_{i,j}\|\partial_{ij}J^{s-2}u\|_2^2
\le\|u\|_{H^s}^2.
\]

Also, the vector multiplier of \(U\) has Euclidean norm at most one. Applying (5) to \(q\cdot Uu\) therefore gives
\[
\operatorname{Re}\langle\mathcal Au,u\rangle_{H^s}
\le-(\kappa-E)\|u\|_{H^s}^2
  +R\|u\|_{H^{s-1}}\|u\|_{H^s},
\tag{13}
\]
where
\[
\boxed{
\begin{aligned}
E&=\frac12\|\operatorname{div}w\|_\infty
       +s\|Dw\|_{\infty,F}+\|q\|_{\infty},\\
R&=T_s(w)+\sum_{i=1}^2P_s(q_i).
\end{aligned}}
\tag{14}
\]
Here
\[
\kappa=\frac{1687}{500}=3.374.
\]

This is the principal estimate. High derivatives occur in \(R\), not in \(E\).

To express \(E\) using Taylor bounds, let
\[
M_V=\sup_{B_{3\delta}}\|D^2V\|_F,\qquad
M_\rho=\sup_{B_{3\delta}}\|D^2\widetilde\rho\|_F,\qquad
C_\theta=\delta\|\nabla\theta\|_\infty.
\]
Since \(\operatorname{div}(V-Dz)=0\),
\[
\begin{aligned}
\|Dw\|_{\infty,F}
 &\le \left(3+\frac92C_\theta\right)M_V\delta,\\
\|\operatorname{div}w\|_\infty
 &\le\frac92C_\theta M_V\delta,\\
\|q\|_\infty&\le3M_\rho\delta.
\end{aligned}
\]
Thus
\[
\boxed{
E\le C_V\delta,\qquad
C_V=
\left[3s+\frac92\left(s+\frac12\right)C_\theta\right]M_V
+3M_\rho.}
\tag{15}
\]

This is sharper for absorption than putting a full Wiener norm of the commutator into \(E\). Such a bound retains terms like \(W_s(w)\), which need not tend to zero under localization. The separation in (10) is what avoids that problem.

Interpolating coercive integer-order estimates at orders \(3\) and \(4\) would not justify this argument: order \(4\) is above the stated frozen threshold.

---

**The nonlocal commutator and the strain.**

There is an elementary global estimate
\[
\boxed{
\|[U,\chi]v\|_{H^s}
\le C_UW_s(\chi)\|v\|_{H^{s-1}},
\qquad C_U=2\,3^s.}
\tag{16}
\]
The norm on the left is the vector Sobolev norm.

To check it, write the vector symbol as \(m(\xi)\). It satisfies
\[
|m|\le1,\qquad \|Dm(\xi)\|_{\rm op}\le|\xi|^{-1}.
\]
Splitting into
\(|\eta|\ge1,\ |k|\le|\eta|/2\), and its complement, gives
\[
\langle\eta+k\rangle^s|m(\eta+k)-m(\eta)|
\le2\,3^s\langle k\rangle^s\langle\eta\rangle^{s-1}.
\]
Young’s inequality proves (16), including the low-frequency part.

For explicit tail bounds, the off-diagonal kernels of \(U\) are
\[
K_1(X)=-\frac{xy}{\pi|X|^4},\qquad
K_2(X)=\frac{x^2-y^2}{2\pi|X|^4}.
\]
The local distributional term in \(U_2\) does not contribute across separated supports. For every multi-index \(\gamma\),
\[
|D^\gamma K_i(X)|
\le\frac{(|\gamma|+1)!}{2\pi}|X|^{-2-|\gamma|}.
\tag{17}
\]
One checks this by differentiating the real and imaginary parts of
\((x+iy)^{-2}/(2\pi)\).

Set \(v=\zeta h\) and \(h_{\rm far}=(1-\zeta)h\). On \(B_{9\delta/4}\),
\[
|D^\gamma U_i[h_{\rm far}]|
\le k_{|\gamma|}N_{\rm far}(h),
\quad
k_j=\frac{100(j+1)!}{2\pi}\left(\frac4\delta\right)^j.
\tag{18}
\]
Indeed, for source points in \(h_{\rm far}\),
\[
|X-Y|\ge |Y-P|/10,\qquad |X-Y|\ge\delta/4.
\]

The following finite formula will abbreviate the resulting product bounds. For \(f\) supported in \(B_{9\delta/4}\), define
\[
\mathcal T_m(f)=\frac{9\sqrt\pi\,\delta}{4}
\left[
\sum_{|\gamma|\le m}
\frac{m!}{(m-|\gamma|)!\gamma!}
\left(
\sum_{\beta\le\gamma}
{\gamma\choose\beta}\|D^\beta f\|_\infty
k_{|\gamma-\beta|}
\right)^2
\right]^{1/2}.
\tag{19}
\]
Then, for \(r\le m\),
\[
\|fU_i[h_{\rm far}]\|_{H^r}
\le\mathcal T_m(f)N_{\rm far}(h).
\tag{20}
\]
This is just Leibniz’s rule and (7).

For the strain, the off-diagonal kernel has absolute value at most
\[
\frac1{\pi|X|^3}.
\]
Because \(h(0)=\nabla h(0)=0\), its integral against \(h\) is absolutely convergent and the local distributional contributions vanish. Hence
\[
\boxed{
|c[h]|\le C_c\|h\|_{H^t(B_{3\delta})}
            +\frac1\pi N_{\rm far}(h),
\qquad
C_c=\frac{3\delta}{\sqrt\pi(|P|-3\delta)^3}.}
\tag{21}
\]
Likewise, for \(u=\chi h\),
\[
|c[u]|
\le
\frac{2\delta}{\sqrt\pi(|P|-2\delta)^3}\|u\|_2.
\tag{22}
\]

In particular, the requested finite-rank commutator is explicitly lower order:
\[
\begin{aligned}
\|\theta\ell(c[u]-\chi c[h])\|_{H^s}
\le{}&
\|\theta\ell\|_{H^s}
\frac{2\delta}{\sqrt\pi(|P|-2\delta)^3}\|u\|_2\\
&+\|\chi\ell\|_{H^s}
\left(C_c\|h\|_{H^t(B_{3\delta})}
+\frac{N_{\rm far}(h)}\pi\right).
\end{aligned}
\tag{23}
\]
It is important here that \(c[u]\) is a scalar evaluated at the distant origin. It is not a local order-zero multiplier.

---

**The local a priori estimate, first with the natural forcing cutoff.**

Use the abbreviations
\[
\begin{aligned}
S&=\|\chi h\|_{H^s},\\
A_h&=\|h\|_{H^s(B_{2\delta}\setminus B_\delta)},\\
H_h&=\|h\|_{H^t(B_{3\delta})},\qquad N=N_{\rm far}(h),\\
Z&=M_t(\zeta),\qquad C_\chi=M_t(\chi),\\
Q&=g+\sum_iB_s(q_i),\qquad
b_\chi=\|\chi\ell\|_{H^s},\\
T&=V\cdot\nabla\chi.
\end{aligned}
\]
Define
\[
\boxed{
\begin{aligned}
d_A&=B_s(T),\\
d_H&=RC_\chi+QC_UW_s(\chi)Z+b_\chi C_c,\\
d_N&=\sum_i\mathcal T_4(\chi a_i)+b_\chi/\pi.
\end{aligned}}
\tag{24}
\]
Then
\[
\boxed{
(\kappa-E)S
\le
\|\chi Lh\|_{H^s}+d_AA_h+d_HH_h+d_NN.}
\tag{25}
\]

Here is the complete localization identity behind it:
\[
\mathcal A(\chi h)
=\chi Lh+Th+(a_P+q)\cdot[U,\chi]h-\chi\ell\,c[h].
\tag{26}
\]
For the near part of the commutator, apply (16) to \(\zeta h\), followed by (5) for multiplication by \(q\). For its far part,
\[
[U,\chi]h_{\rm far}=-\chi U[h_{\rm far}],
\]
so (20) applies. The transport cutoff term uses
\[
\|Th\|_{H^s}\le B_s(T)A_h,
\]
by extending \(h\) from the annulus and taking the infimum over extensions. Finally,
\(\|\chi h\|_{H^t}\le C_\chi H_h\), and (21) handles the strain. Substitution into (13) proves (25).

Thus, already for arbitrary admissible cutoffs,
\[
S\le\frac{B_s(\chi)}{\kappa-E}\|\tau Lh\|_{H^s}
+\frac{d_AA_h+d_HH_h+d_NN}{\kappa-E}.
\tag{27}
\]
Replacing \(B_s(\chi)\) by \(1\) without further argument would be an error.

---

**Obtaining exactly \(K_1=(\kappa-E)^{-1}\).**

Here the buffers in (1) are useful.

Choose smooth radial \(\lambda_{\rm in},\lambda_{\rm out}\), valued in \([0,1]\), such that
\[
\begin{aligned}
&\lambda_{\rm in}=1\text{ on }B_\delta,\quad
 \operatorname{supp}\lambda_{\rm in}\subset B_{9\delta/8},\\
&\lambda_{\rm out}=0\text{ on }B_{15\delta/8},\quad
 \lambda_{\rm out}=1\text{ outside }B_{2\delta}.
\end{aligned}
\]
Put
\[
\lambda_A=1-\lambda_{\rm in}-\lambda_{\rm out},
\qquad p=\lambda_A\tau,\qquad F=\tau Lh.
\]
Then \(p\) is supported in the prescribed annulus.

Off the diagonal, the kernel of \(J^s\) satisfies
\[
|K_{J^s}(X)|\le D_s|X|^{-2-s},
\quad
D_s=\frac{2^s\Gamma(1+s/2)}
           {\pi|\Gamma(-s/2)|}.
\tag{28}
\]
For example, this follows by inserting the heat kernel into
\[
K_{J^s}(X)
=\frac1{4\pi\Gamma(-s/2)}
 \int_0^\infty u^{-2-s/2}e^{-u-|X|^2/(4u)}\,du,
\quad X\ne0,
\]
and dropping \(e^{-u}\).

The inner and outer commutators have support separation at least \(\delta/8\). Integrating the bound in (28), and using (5) for the annular part, gives
\[
\|\chi F\|_{H^s}
\le\|F\|_{H^s}
 +P_s(\chi)\|pLh\|_{H^t}
 +J_\delta\|F\|_2,
\tag{29}
\]
where
\[
J_\delta=\frac{4\pi D_s}{s}\left(\frac8\delta\right)^s.
\tag{30}
\]
To see the separation explicitly,
\[
[J^s,\chi](\lambda_{\rm in}F)
=(1-\chi)J^s(\lambda_{\rm in}F),
\]
and
\[
[J^s,\chi](\lambda_{\rm out}F)
=-\chi J^s(\lambda_{\rm out}F).
\]
Each is bounded by convolution with the kernel restricted to
\(|X|\ge\delta/8\). Their sum accounts for the factor in (30).

The two additional forcing norms in (29) require no new unknown norm. Define
\[
\boxed{
\begin{aligned}
e_A&=\sum_iM_t(pV_i),\\
e_H&=M_t(p)+Z\sum_iM_t(pa_i)+\|p\ell\|_{H^t}C_c,\\
e_N&=\sum_i\mathcal T_4(pa_i)+\|p\ell\|_{H^t}/\pi,\\
f_H&=Z\bigl(\|\tau V\|_\infty+1+\|\tau a\|_\infty\bigr)
                   +\|\tau\ell\|_2C_c,\\
f_N&=\sum_i\mathcal T_0(\tau a_i)+\|\tau\ell\|_2/\pi.
\end{aligned}}
\tag{31}
\]
Then
\[
\|pLh\|_{H^t}\le e_AA_h+e_HH_h+e_NN,
\qquad
\|F\|_2\le f_HH_h+f_NN.
\tag{32}
\]
For the transport part of the first inequality, extend \(h\) from the annulus in \(H^s\). For the other terms, write
\(Uh=U(\zeta h)+U[h_{\rm far}]\), and apply (5), (20), and (21). This proves every term in (31).

Combining (25), (29), and (32) proves your requested estimate:
\[
\boxed{
\|\chi h\|_{H^s}
\le K_1\|\widetilde\chi Lh\|_{H^s}
   +K_2A_h+K_3H_h+K_4N_{\rm far}(h),}
\tag{33}
\]
with
\[
\boxed{
\begin{aligned}
K_1&=\frac1{\kappa-E},\\
K_2&=\frac{d_A+P_s(\chi)e_A}{\kappa-E},\\
K_3&=\frac{d_H+P_s(\chi)e_H+J_\delta f_H}{\kappa-E},\\
K_4&=\frac{d_N+P_s(\chi)e_N+J_\delta f_N}{\kappa-E}.
\end{aligned}}
\tag{34}
\]
Equations (4), (6)–(8), (11), (14), (19), (21), (24), and (31) specify all constants. No Kato–Ponce, extension, or Gårding constant remains unspecified.

The coefficient inputs required are \(D^jV\), \(j\le4\), and
\(D^j\widetilde\rho\), \(j\le5\), on \(B_{3\delta}\), together with the stated cutoff derivatives.

---

**The size question and the outflow term.**

A sufficient condition for \(E\le\kappa/2\) is
\[
\boxed{\delta\le\frac{\kappa}{2C_V}
                   =\frac{1.687}{C_V}.}
\tag{35}
\]
Use coefficient bounds certified on a fixed containing ball when selecting \(\delta\); otherwise (35) is an implicit condition to verify.

Under this condition,
\[
K_1\le\frac{1000}{1687}\approx0.592768.
\]
For example, if \(C_\theta=2\), then
\[
C_V=41.7M_V+3M_\rho.
\tag{36}
\]

The other constants grow as the cutoffs shrink. Their exact values are (34). To make the powers transparent, for
\[
f_\delta(X)=\delta^p f^{(\delta)}((X-P)/\delta)
\]
one has, for \(\delta\le1\),
\[
W_r(f_\delta)\le\delta^{p-r}W_r(f^{(\delta)}),
\qquad
\|f_\delta\|_{H^r}\le
\delta^{p+1-r}\|f^{(\delta)}\|_{H^r}.
\tag{37}
\]
For fixed cutoff shapes and uniformly bounded rescaled coefficient shapes, the conservative constants above give
\[
K_2=O(\delta^{3-2s}),\qquad
K_3=O(\delta^{3-3s}),\qquad
K_4=O(\delta^{-s-2}).
\tag{38}
\]
At \(s=3.1\), these are respectively
\[
O(\delta^{-3.2}),\qquad
O(\delta^{-6.3}),\qquad
O(\delta^{-5.1}).
\]
These statements describe the scaling of this particular explicit bound; the constants for computation are the formulas above. These powers are not claimed optimal.

The intrinsic transport cutoff coefficient is
\[
T=V\cdot\nabla\chi,
\]
whose amplitude is generally of order the expansion rates, not \(O(\delta)\). The additional negative powers in \(K_2\) reflect multiplication and localization in ordinary inhomogeneous Sobolev norms.

There is a direct obstruction to eliminating this outflow cost by demanding
\[
V\cdot\nabla\chi\ge-\varepsilon\chi.
\]
Along any orbit that reaches the exterior of the cutoff in finite time, this inequality would imply
\(\chi(\Phi_tz)\ge e^{-\varepsilon t}\chi(z)>0\), a contradiction.

Even an additive bound on \(|V\cdot\nabla\chi|\) cannot be arbitrarily small on a fixed factor-two annulus. For the frozen fast-axis orbit, traversal takes
\[
T_{\rm cross}=\frac{\log2}{A_P},
\]
and the cutoff falls by one. Hence
\[
\sup|V\cdot\nabla\chi|\ge\frac{A_P}{\log2}
\]
in that frozen calculation. Perturbing \(V\) changes this by a controlled \(O(M_V\delta)\) amount.

An adapted Lyapunov cutoff can improve constants and distribute the transition more evenly. A substantially smaller outflow coefficient requires a longer transition in flow time. It is not obtained merely by shrinking the disc.

---

**What the neighbouring estimate must provide.**

Let \(O(h)\) be the proposed outer norm. At minimum, it must give a certified bound
\[
\|h\|_{H^s(B_{2\delta}\setminus B_\delta)}
\le C_AO(h).
\tag{39}
\]
It must also overlap the inner region sufficiently to reconstruct \(h\) by smooth partitions. The resulting multiplication constants must be included.

An outer \(H^{s-\varepsilon}\) estimate or \(C^{2,\alpha}\) estimate does not supply (39). A \(b\)-Sobolev norm suffices only if, on this overlap, its vector fields span the ordinary tangent space with a certified quantitative conversion to ordinary \(H^s\). Degenerating frame coefficients can introduce further powers of \(\delta^{-1}\).

A precise condition excluding circularity at the highest order is the following. Suppose, after collecting lower-order and tail quantities into \(R_0(h)\),
\[
\begin{aligned}
S(h)&\le aF+bO(h)+dR_0(h),\\
O(h)&\le cF+\varepsilon S(h)+eR_0(h).
\end{aligned}
\tag{40}
\]
Then the estimates combine if
\[
\boxed{b\varepsilon<1.}
\tag{41}
\]
For example,
\[
S(h)\le
\frac{(a+bc)F+(d+be)R_0(h)}{1-b\varepsilon}.
\tag{42}
\]
Here \(b\) includes \(K_2C_A\). Because \(K_2\) may be large, saying that \(\varepsilon\) is merely “small” is insufficient.

The genuinely triangular case is \(\varepsilon=0\): prove the outer estimate first, then the source estimate. This is consistent with downstream reading of the pure transport inverse. It is not automatically a triangular solution procedure for the nonlocal operator.

With separated supports, the effect of the source on the outer region through \(U\) is smoothing and can be put into lower-order terms. That can yield triangularity at the highest order. The lower-order and finite-rank coupling still has to be solved.

For your proposed weight, specify the convention. With squared norm
\[
\int e^\phi|v|^2,
\]
integration by parts gives
\[
\begin{aligned}
\operatorname{Re}\int_\Omega e^\phi(V\cdot\nabla v)\bar v
={}&-\frac12\int_\Omega e^\phi
(\operatorname{div}V+V\cdot\nabla\phi)|v|^2\\
&+\frac12\int_{\partial\Omega}e^\phi(V\cdot n)|v|^2.
\end{aligned}
\tag{43}
\]
Thus your factor-two condition on \(V\cdot\nabla\phi\) is consistent with this convention. But the outer proof must additionally control:

- downstream boundary or infinity contributions;
- commutators at order \(s\);
- the nonlocal coupling in the chosen weighted space;
- the strain functional;
- conversion of its overlap norm to (39).

A favourable scalar weight derivative does not establish those bounds.

Finally, eliminating highest-order circularity still leaves \(R_0(h)\). A full inverse estimate needs a separate bound for it, or a compactness/Fredholm argument with the remaining kernel explicitly excluded.

---

**Existence requires another argument, but one can give an explicit auxiliary inverse.**

The proposed Neumann-series argument on \(H^s\) is not justified by \(E<\kappa\). The term \(w\cdot\nabla\) is unbounded from \(H^s\) to \(H^s\), and (13) is an energy estimate, not an operator-norm estimate for
\[
(w\cdot\nabla+q\cdot U)L_P^{-1}.
\]
A bound for this composition would require a separate proof.

For the particular whole-plane extension \(\mathcal A\) in (9), however, there is an alternative existence proof with explicit bounds.

Put
\[
a_s=\kappa-E,\qquad
a_0=b-\frac12\|\operatorname{div}w\|_\infty-\|q\|_\infty,
\qquad b=1+\frac{\operatorname{tr}D}{2}.
\]
If \(a_s>0\), then
\[
a_0-a_s=b-\kappa+s\|Dw\|_{\infty,F}>0.
\tag{44}
\]

The globally Lipschitz vector field \(Dz+w\) defines a transport group. The Fourier energy calculation above bounds that group on \(H^s\); the remaining operator \(-gM+q\cdot U\) is bounded on \(H^s\), with bound
\[
g+\sum_iB_s(q_i).
\]
Thus the Duhamel equation gives a strongly continuous semigroup
\(S_{\mathcal A}(t)\) on \(H^s\). This construction can be justified first for smoothed coefficients and then by the same uniform energy bounds.

For a semigroup trajectory, let
\[
x(t)=\|S_{\mathcal A}(t)u\|_{H^s},\qquad
y(t)=\|S_{\mathcal A}(t)u\|_2.
\]
The \(L^2\) energy estimate and (13) give
\[
y(t)\le e^{-a_0t}y(0),\qquad
x'(t)\le-a_sx(t)+R\,x(t)^{1-1/s}y(t)^{1/s},
\]
where interpolation has constant one. Applying this inequality to \(x^{1/s}\) yields
\[
\|S_{\mathcal A}(t)\|_{H^s\to H^s}
\le
\left(1+\frac{R}{a_0-a_s}\right)^s e^{-a_st}.
\tag{45}
\]
Consequently,
\[
\boxed{
\mathcal A^{-1}f=-\int_0^\infty S_{\mathcal A}(t)f\,dt,\qquad
\|\mathcal A^{-1}\|_{H^s\to H^s}
\le
\frac1{a_s}
\left(1+\frac{R}{a_0-a_s}\right)^s.}
\tag{46}
\]
This is a genuine existence result for the extended operator. It does not require \(R\) to be small, although its bound can be large.

Adding a localized finite-rank term \(\ell_\delta c\), with
\(\ell_\delta=\theta\ell\), requires another check. Since \(s>2\),
\[
|c[u]|\le\beta_s\|u\|_{H^s}.
\]
The rank-one perturbation is invertible precisely when
\[
\boxed{1+c[\mathcal A^{-1}\ell_\delta]\ne0.}
\tag{47}
\]
Its inverse is given by the rank-one inverse formula. A certified lower bound for the absolute value in (47) gives an explicit inverse bound. Frozen bijectivity does not certify this denominator.

Most importantly, the inverse in (46) solves an auxiliary whole-plane problem. It does not automatically match a prescribed outer solution. For an assembled solution, the inner and outer representatives must agree on the overlap, and \(U[h]\) and \(c[h]\) must be computed from that same global \(h\).

A global parametrix therefore needs a certified error bound, or an equivalent global solvability argument. The support condition \(u=\chi h\) cannot simply be ignored when applying the whole-plane inverse: \(M\) does not preserve support.

---

**The remaining possible obstructions.**

The nonlocal term does not obstruct the local estimate under the stated tail assumptions. In fact, the frozen term \(-gM\) is essential to the favourable fast-direction margin. Its localization error is controlled by (16)–(23).

The stated Hölder cusp does not contradict the \(H^{3.1}\) estimate. Your quoted cusp exponent is approximately
\[
\frac{1+g}{A}\approx3.02935.
\]
The given frozen Sobolev theorem is the relevant input here; cusp order alone is not a substitute for a Sobolev calculation. In particular, \(H^{3.1}\) supplies \(C^{2,\alpha}\) control for every \(\alpha<0.1\), which is compatible with that cusp.

The deviation \(\mu_P-1\) also does not damage the estimate if the certified parameters lie in the box. The correct frozen operator uses \(A_P,\mu_P,g\), not the box centre; no additional perturbation term is then needed.

There is, however, an exact residual identity worth recording:
\[
\partial_yF(\widetilde\rho)(P)=(\mu_P-1)g.
\tag{48}
\]
An exact profile with \(g\ne0\) must have \(\mu_P=1\). The quoted trial deviation gives approximately
\[
-6.69375\times10^{-7}
\]
for this residual derivative. That is consistent with a trial profile, but the floating-point value is not a certificate.

Likewise, if \(c_l=5.5754\) is read literally, then \(2c_l-1=10.1508\), rather than \(10.1507\). The box absorbs this numerical discrepancy, but a certificate should use consistent interval data.

For other \(s\in(3,s_{\rm fast})\), replace \(\kappa\) by a positive certified frozen margin. The broad box stated in the question is not uniformly coercive all the way to the central value \(3.5786\). Its fast-direction margin is
\[
35.595-10.2s,
\]
which vanishes at approximately \(3.48971\). Larger orders require narrower parameter enclosures.

Finally, no conclusion about compatibility with the knot spacing follows before the coefficient bounds are computed. Keeping \(\delta=0.0165\) under (35) requires
\[
\boxed{C_V\le102.2424.}
\tag{49}
\]
For \(C_\theta=2\), this means
\[
41.7M_V+3M_\rho\le102.2424.
\]
Large third and fourth derivatives do not force a smaller radius through \(E\) in this proof. They can nevertheless make \(K_3\), the auxiliary inverse bound, and the eventual global verification impractical. Smoothness through the required order must also hold across every knot intersecting the disc.

Thus the local analytic estimate is available with explicit constants. Whether it is useful for this trial remains conditional on the certified coefficient bounds, the outer estimate, and the remaining global solvability checks.

The requested Opus 5.5 cross-review was unavailable: the permitted Python Bedrock attempt failed because the configured profile had no available credentials. No substitute model was used.