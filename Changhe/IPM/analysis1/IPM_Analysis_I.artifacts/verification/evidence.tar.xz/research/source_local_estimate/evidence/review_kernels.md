# An explicit local source estimate in inhomogeneous Sobolev spaces

Status at proof writing: independent analytical reconstruction of V23/S1-S5.
The scalar arithmetic and external review are pending. Section 10 separately
states what has and has not been proved about an auxiliary inverse. Nothing
here supplies the global inverse required by IPM Analysis I.

## 1. Statement, normalization, and domain

All functions are on R^2. Use the unitary Fourier transform
fhat(xi)=(2pi)^(-1) integral exp(-i X.xi) f(X)dX and J^r=(1-Delta)^(r/2).
The H^r norm is ||J^r f||_2. For an open set Omega its restriction norm is
the infimum of whole-plane extension norms. Vector norms are Euclidean
sums of component squares; derivative tensors use the Frobenius norm.

Set s=31/10 and t=s-1=21/10. Let P=(p,0), p>0. Suppose, on B_(3delta)(P),
V is C^4, rho is C^5, and

    V(P)=0, DV(P)=D=diag(A,mu), grad rho(P)=aP=(0,g),
    div V=A+mu,
    10<=A<=51/5, 99/100<=mu<=101/100, 29<=g<=30,
    0<delta<=1, 3delta<p/2.                                  (1)

No stationarity of rho is assumed. Let a=grad rho and ell=X.a/3.
The canonical order-zero velocity has vector Fourier symbol

    m(xi,eta)=(xi eta/(xi^2+eta^2), -xi^2/(xi^2+eta^2)).        (2)

Its arbitrary value at the single frequency zero is immaterial in L2.
Write sigma[h]=psi[h]_xy(0) for RAW strain. The normalized linearization
in this note is

    Lh=V.grad h-h+a.U[h]+ell sigma[h].                       (3)

Thus the scaling functional called c[h] in PROMPT.md is sigma[h]/3.
The source document's symbol c in ell*c must mean raw sigma. We use (3)
throughout to avoid a hidden factor of three.

Initially take h in C_c^infinity with h(0)=grad h(0)=0. This guarantees
absolute convergence of the strain kernel integral below. Conclusions
extend by limits in the explicitly displayed norms, with sigma and U
defined by those limits. No density claim about another IPM domain is made.

Choose smooth cutoffs valued in [0,1], centred at P:

    chi=1 on B_(5delta/4), supp chi inside B_(7delta/4),
    tau=1 on supp chi, supp tau inside B_(9delta/4),
    theta=1 on B_(2delta), supp theta inside B_(3delta),
    zeta=1 on B_(5delta/2), supp zeta inside B_(3delta).        (4)

All displayed inclusions are strict support inclusions, so products extend
smoothly by zero. Put

    w=theta(V-D(X-P)), q=theta(a-aP),
    Aop=D(X-P).grad-1-gM+w.grad+q.U,
    Mhat=xi^2/(xi^2+eta^2).                                 (5)

The theorem below is a local a priori estimate whenever E<kappa, with
kappa=1687/500 and E in (12). Every constant is defined here.


## 5. Velocity commutator, remote kernel, and strain

The vector symbol m=(cos theta sin theta,-cos²theta) has norm<=1 and
angular derivative(cos2theta,sin2theta) of norm1. Thus ||Dm(xi)||<=1/|xi|.
For |eta|>=1, |k|<=|eta|/2, integrate this derivative along the segment:
|m(eta+k)-m(eta)|<=2|k|/|eta|. Also <eta+k><=(3/2)<eta> and
<eta>/|eta|<=sqrt2. The desired estimate follows because
sqrt2(3/2)^s<=3^s and |k|<=<k>^s. In the complement, if |eta|<1 then
<eta+k><=sqrt3<k>; if |eta|>=1 and |k|>|eta|/2 then
<eta+k><=3<k>. Using |m(eta+k)-m(eta)|<=2 proves in all cases

 <eta+k>^s|m(eta+k)-m(eta)|
 <=2*3^s <k>^s <eta>^(s-1).

Young's inequality therefore gives

 ||[U,chi]v||_(H^s)<=C_U W_s(chi)||v||_(H^(s-1)), C_U=2*3^s. (14)

The off-diagonal kernels are Im and Re of(2pi)^(-1)(x+iy)^(-2):
K1=-xy/(pi r4), K2=(x²-y²)/(2pi r4). Every real derivative of total
orderj is a unit-complex multiple of(-1)^j(j+1)!(x+iy)^(-2-j)/(2pi).
Thus |D^gamma K_i|<=(j+1)!/(2pi) r^(-2-j). The local term-rho e2/2
has no effect across separated supports.

Define

 N= integral_(|X-P|>=5delta/2)|h(X)|/|X-P|² dX
   +integral_(R²\B_(3delta)(P)) |h(X)|/|X|³ dX.              (15)

For hfar=(1-zeta)h and X in B_(9delta/4), source distance d=|Y-P|
is at least5delta/2, so |X-Y|>=d/10 and >=delta/4. Therefore

 |D^gamma U_i hfar(X)|<=k_j N,
 k_j=100(j+1)!/(2pi)(4/delta)^j.                            (16)

For f supported in B_(9delta/4) set

 T_m(f)=(9sqrt(pi)delta/4)
  *sqrt(sum_(|gamma|<=m) m!/[(m-|gamma|)!gamma!]
       [sum_(beta<=gamma) choose(gamma,beta)||D^beta f||_infinity
                                  k_(|gamma-beta|)]²).     (17)

Leibniz, (10) and the area of that ball give
||f U_i hfar||_(H^r)<=T_m(f)N for0<=r<=m.

The raw strain kernel away from zero is
Ksigma(X)=y(3x²-y²)/(pi r6)=sin(3theta)/(pi r3), up to the already
fixed convolution sign, which is positive in this displayed expression.
Thus its absolute value is at most1/(pi r3). The local contribution is
-proportional to h_y(0), which vanishes. Near0 the integral is absolutely
convergent because h=O(r²); at infinity h is compactly supported.
Split at B_(3delta)(P), use |X|>=p-3delta there and Cauchy-Schwarz to get

 |sigma[h]|<=C_c H_h+N/pi,
 C_c=3delta/[sqrt(pi)(p-3delta)^3],
 H_h=||h||_(H^t(B_(3delta)(P))).                            (18)

Restriction norms dominate the restricted L2 norm. Similarly, foru=chi h,
|sigma[u]|<=2delta/[sqrt(pi)(p-2delta)^3] ||u||_2, using its smaller support.
These bounds are for RAW sigma; they are three times as generous as needed
for the prompt's scaling functional sigma/3.

