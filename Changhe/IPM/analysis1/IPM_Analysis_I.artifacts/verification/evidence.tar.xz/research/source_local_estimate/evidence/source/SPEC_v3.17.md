# SPEC (ipmA-lead): target theorem, spaces, splitting, bounds and owners

Version 3.17, 2026-10-21T00:06Z (shift 2). Supersedes v3.16 (23:18Z, notes/SPEC_v3.16_backup.md), v3.15 (23:15Z, notes/SPEC_v3.15_backup.md), v3.14 (22:48Z, notes/SPEC_v3.14_backup.md), v3.13 (22:29Z, notes/SPEC_v3.13_backup.md), v3.12 (21:58Z, notes/SPEC_v3.12_backup.md), v3.11 (21:32Z, notes/SPEC_v3.11_backup.md), v3.10 (21:19Z, notes/SPEC_v3.10_backup.md), v3.9 (20:53Z, notes/SPEC_v3.9_backup.md), v3.8 (19:01Z, notes/SPEC_v3.8_backup.md), v3.7 (18:37Z, notes/SPEC_v3.7_backup.md), v3.6 (18:19Z, notes/SPEC_v3.6_backup.md), v3.5 (18:01Z, notes/SPEC_v3.5_backup.md), v3.4 (17:23Z, notes/SPEC_v3.4_backup.md), v3.3 (17:14Z, notes/SPEC_v3.3_backup.md), v3.2 (16:54Z, notes/SPEC_v3.2_backup.md), v3.1 (16:38Z, notes/SPEC_v3.1_backup.md), v3 (15:53Z, notes/SPEC_v3_backup.md), v2.1 (15:24Z,
notes/SPEC_v2.1_backup.md), v2 (14:57Z), v1 (14:15Z). Change log at the end. Status labels: PROVED (place of proof), VERIFIED (independently
reproduced by the verifier), AUDITED (checked by an astra audit only), CONDITIONAL, HEURISTIC, REFUTED.

## 0. Decisions (v3)
- The verdict target for this run is realistic: UNRESOLVED with (a) a certified residual of the explicit trial, (b) the
  verified frozen and local theorems, (c) the conditional two-norm theorem T2N with named constants, (d) a precise
  structural account of WHY the reference route fails, and (e) ranked obstructions. No decisive `P_infty` route (the
  `B_3` exclusion is formal at every achieved radius). A YES would need a global inverse that nobody has; we keep
  the formulation below ready in case one becomes available.
- Structural picture (section 3.7, CONDITIONAL): every realization is fixed by its type at the source P (above or below
  the fast threshold) and at infinity (tails `gamma > k` or `gamma < k`). v3.7: the earlier claim "smooth-at-P classes
  with free tails (R+) are overdetermined by one after normalization (index -1)" is WITHDRAWN: it rested on the scalar
  germ count (kernel `y`, cokernel `f_y(P)`) of pure transport, which does not transfer to the coupled operator
  (astra pcusp1 Q5 counterexample, checked by lead), and at the frozen level smoothness at P costs infinitely many
  conditions (pcusp1 Q2, eq. (15)). The problem's own class `P_2` is of MIXED type
  (below threshold at P, tails up to `gamma < 1`): its linearization has a formal kernel containing the tail traces,
  so a Newton argument in `P_2` must fix a complement. The target formulation is F- (section 4): tail fixed to the
  trial's, remainder decaying relative to `r^k`, exponent `k'` and one tail parameter as scalar unknowns, scale fixed by
  the tail and J normalized afterwards by exact scaling.
- Weight convention (corrected after the verifier, spec_audit final section): "allowed growth gamma" means the norm
  `sup W / [m (1+u)^{gamma-k}]`, `m = u^3 (1+u^2)^{(k-3)/2}`, `u = r/L`. v3.1 correction (ver 16:17Z): the numerics
  code multiplies `W/m` by `(1+u)^{1/2}` (not `(1+u)^{1/2-k}`), i.e. allowed growth `k - 1/2 = -0.3206`; it is a
  valid UPPER bound for every allowed growth `gamma_Y >= -0.3206`, in particular for the F- forcing class
  (`2k - 1 < gamma_Y < k`). Reports must state the exponent actually used.

## 1. Equation and notation (fixed)
- `F(rho) = (c_l X + U[rho]).grad rho - rho`, `U = (-psi_y, psi_x)`, `-Lap psi = d_x rho` (canonical inverse, no
  `lambda x y`), `c[rho] = psi_xy(0)`, `c_l = (1 + c[rho])/3` built in (so `J(F(rho)) = 0` identically; realize1 C3:
  a separate closure equation would be redundant with the J-equation). Parity: rho even in x, odd in y; `rho = x^2 y a`
  near 0; `J(rho) := a(0)`. The y-axis ODE forces `rho(0, y) = 0`.
- `V = c_l X + U[rho]`; `DV(0) = diag(-A, D)`, `A = 2c_l - 1`, `D = 2A + 1`. Axis source `P = (x_*, 0)`,
  `DV(P) = diag(2c_l - mu, mu)`, `mu = 1` at exact solutions with `g := rho_y(P) != 0` (VERIFIED, ver local_geometry,
  scaling_index). `g' := rho_xy(P)`, `d := 1 + g`, `k := 1/c_l`, `b_0 := (A+3)/2`.
- X3 values: `c_l = 5.5753626`, `A = 10.1507252`, `D = 21.3014504`, `x_* = 8.60006`, `g = 29.7495`, `k = 0.17936`,
  `L = 7.6514`. Trial balls (num S1, rigorous): `x_* = 8.600063805157177 +/- 2.9e-13`, `mu~ - 1 in [-2.2529e-8,
  -2.2527e-8]`, `g in [29.749490663330, 29.749490663337]`, `g' in [0.2734114439768, 0.2734114439777]`.
- Linearization `L h = (V.grad - 1) h + B h`, `B h = W[h].grad rho`, `W[h] = Gamma h = U[h] + (c[h]/3) X`.
- Scaling: `rho_a(X) = a rho(X/a)`, `F(rho_a) = (F rho)_a`, `c[rho_a] = c[rho]`, `J(rho_a) = a^{-2} J(rho)`;
  `K = rho - X.grad rho`, `L K = eps - X.grad eps`, `c[K] = 0`, `J(K) = -2 J(rho)` (VERIFIED, ver scaling_index, under
  the stated differentiability / membership hypotheses; bare `P_2` does not put K in the same trace space: ver's
  oscillatory-factor example). A tail `r^k Theta` scales to `a^{1-k} r^k Theta`.

## 2. The trial (decided)
num's explicit modal trial `rho~` (exponential-polynomial splines in `t = log r`, even polynomial core, explicit far
form `x^2 y r^{k-3} (...)`), closed-form Green integrals, `c_l := 1/k`, `c~ = 3/k - 1` by exactified dependent
coefficients (VERIFIED: ver modal_repair, total exactification cost `< 4.080e-10`). Only residual: `eps~ = F(rho~)`.
Its tail is `r^k Theta_0~(theta)` with the trial's own angular profile.

## 3. Analytic facts

### 3.1 Source box, pure transport (VERIFIED, ver source_transport; AUDITED realize1 C1)
`L_A h = A s h_s + y h_y - h`, odd f in `C^{m,alpha}`, m >= 1: solvable in `C^{m,alpha}` iff `f_y(0) = 0`; kernel `y`;
`R f = int_0^inf e^t f(T_t X) dt`; `|D^beta R f| <= |D^beta f|/(A a + b - 1)` for `|beta| = a + b >= 2`. No derivative
gain. Dini modulus necessary.

### 3.2 Frozen coupled operator at P (VERIFIED, ver frozen_conjugation, coupled_thresholds, frozen_cokernel)
`L_P = A s d_s + y d_y - 1 - g M`, `M = xi^2/|zeta|^2`.
- Exact conjugation: with `a = g/(A-1)` (= 3.2511) and `Lambda = (-Lap)^{1/2}`, `Lambda^a L_P Lambda^{-a} = T + a - 1`;
  on `H_a` the inverse norm is exactly `1/|a - b_0|`.
- Sobolev thresholds `s_fast = (g + b_0)/A = 3.57855` (3.5785476; not "3.5786", which lies above it),
  `s_slow = b_0 = 6.5754`. Ordinary `H^s`: bijective for
  `0 <= s < s_fast` (so `3 < s < 3.57855` gives a `C^{2,s-3}` realization dissipative at P); infinite-dimensional
  adjoint kernel for every `s > s_fast`. Energy identity `Re <L_P h, h>_{H_s} = int [s - b_0 + (s(A-1) - g) m] |F|^2`.
- Hoelder (local cusp regularity at P): fast `d/A = 3.0293`, slow 1. Degree-d cusps `sgn y |y|^d F(s/|y|^A)` and the planar
  layer `|n|^{g/A}` (`C^{2.93}`) lie below the fast threshold.
- REFUTED (v2): Weyl sequences in every space below threshold; the rule "both T2N norms above threshold".
- Uniform coupled source inverse through resonance (VERIFIED, ver source_pole, 16:29Z):
  `A x d_x + mu y d_y - 1 - g M` is bijective from its maximal graph domain onto ordinary `H^{31/10}` (also with
  parity), inverse norm `<= 500/1687`, uniformly on `10 <= A <= 51/5`, `99/100 <= mu <= 101/100`, `29 <= g <= 30`
  (contains the trial's coefficients); source derivative bound `(500/1687)[8 pi (s-1)(s-2)]^{-1/2}`. Energy margins:
  `b - s mu >= 1687/500`, `b + g - s A >= 159/40`, `b = 1 + (A + mu)/2`.
- Variable-coefficient obstruction (VERIFIED conditional theorem, ver source_localization): if V is `C^{N+1}` near
  a fixed point (N > s), coupling = finite sum of bounded coefficients (`C^N` near P) times degree-zero multipliers,
  and the frozen model has normalized approximate adjoint kernels in `dot H^{-s}` (true for
  `A x d_x + y d_y - 1 - g M` when `(g + b_0)/A < s < b_0`), then no ordinary `H^s` graph realization plus finite rank
  is Fredholm. So "above threshold at P" is excluded for the variable operator in ordinary Sobolev graph form.
- The frozen homotopy pure transport -> coupled crosses `s_fast(tau) = (tau g + b_0)/A` (0.648 -> 3.579) (AUDITED
  realize1 C1): no fixed `3 < s < 3.579` is Fredholm-stable along it, so indices below threshold cannot be computed
  from pure transport by that homotopy.

### 3.3 Saddle (AUDITED realize1 C2; my derivation agrees)
Linear saddle `T_0 = -A x d_x + D y d_y - 1`. Incoming data G on `|x| = 1`: `h = |x|^{-1/A} G(y |x|^{D/A})`, modes
`|x|^{p_b} y^b`, `p_b = 2b + (b-1)/A`, `p_3 = 6.19703`. Exit data H on `|y| = 1`: `h = sgn y |y|^{1/D} H(x |y|^{A/D})`,
modes `x^{2j} sgn y |y|^{beta_j}`, `beta_j = j - (j-1)/D`: `beta_1 = 1` (the J mode), `beta_2 = 1.95305` (not `C^2`
across the stable segment), `beta_3 = 2.90611`. For smooth traces removing the `j = 2` singular coefficient suffices
for `C^{2,alpha}`, `alpha < 0.90611`; in `H^s` the `j = 3` term is forbidden for `s >= 3.40611`. The obstruction is the
singular coefficient after subtracting the particular solution (raw `H_4` need not vanish: `h = x^4 y`), and it is one
scalar only in a trace space smoother than `C^{2,alpha}` (`|x|^{2+nu}` traces give infinitely many independent
obstructions). Energy at the saddle: `S(0,(0,1)) = sD - (1 + c_l) > 0` for `s > 3`: isotropic `H^s` estimates fail
there in either direction; a separate (conormal / anisotropic) saddle space is required.
v3.2: the proposed saddle/edge spaces are in notes/conormal_framework.md (revision 2, after the astra conormal1
audit; PROPOSED): weighted b-Sobolev inverse of `T_0` with sharp norm `1/|bD - aA - b_0|` on the maximal graph domain
(forward iff `bD - aA < b_0`; AUDITED VALID; VERIFIED ver conormal_saddle (V6) 17:20Z, with the norm made precise:
`1/|delta|` in the base norm, `1 + 1/|delta|` into the sum graph norm); exit-trace regularity `C^{4+nu}`, `nu >= 2 alpha + (1 + alpha)/A`, as a
SUFFICIENT condition for a one-scalar saddle count, which also needs a regular particular solution (`J(L h) = 0`
excludes the resonant `x^2 y` forcing), `H_0 = 0` from global y-axis hypotheses, and a specified trace class;
triangular axis jet system; the ordinary disc at P is a design choice (a point blow-up resolves the coupling symbol).
Revision 1's local inclusion of the b-space in `H^s` was FALSE; the repair `b > s` forces the corner weight
`a - 1/2 > [D(s - 1/2) - 1]/A > 5.148 + 2.099 alpha`; the inequalities are feasible for `alpha < 0.406` (feasibility
only). The fixed-cutoff Taylor modification of the velocity is unbounded on the face weights (astra counterexample);
the x-face velocity remainder with global or frequency-adapted extensions is proved in notes/weighted_velocity.md
(Lemmas W1, W1'; EXACT; AUDITED VALID by astra weightedvel1 for N >= 1; VERIFIED ver edge_velocity (V7) 17:10-17:20Z,
with Arb/iv constants `C_{3,2.6} < 78.7988`, `C' < 82.2601`, `C_{3,3.4} < 151.0602`, `C' < 156.1241`). v3.3: the COUPLING is not bounded
on the pure power weight `L^2(|y|^{-2b})` (constant-norm dilates `R^{b-1} F(X/R)` give edge forcing `~ R^{b-2} c[F]` on a
fixed collar; weighted_velocity 4.2): the edge traces are controlled by W1 only in homogeneous norms, and their low
frequencies must be bounded by the far weight (`gamma' < 2` bounds `c[h]`). v3.5: the near/far splitting on BOUNDED
collars `I x (-d/2, d/2)`, `I` compact in `(0, inf)` avoiding nothing but the corner (`x_1 > 2d`), is in
notes/collar_coupling.md revision 2 (Lemma NF: fixed cutoff, inhomogeneous edge norms `H^{b-j-1/2}`, far part via the
parity-symmetrized kernel, `gamma' < 2` sharp; Lemma E: edge components; Corollary CC: coupling = `chi_0 y q + R_W`
with `R_W in L^2_b`, under finite strain `N_c(h) < inf`; `q_n` gains `b - 3/2`, the edge part `q_e` is order zero in the
edge coefficient). EXACT, AUDITED astra collar1 (single model; CC of revision 1 INVALID as stated, repaired), VERIFIED
ver V10 (18:24:59Z; endpoint `gamma' = 2` and "finite strain from collar norms" REFUTED; constants b = 3.403:
`K_n < 1211.755`, `A_0 < 1759.316`, `K_f < 9.3453e6`; FINAL_REPORT 5(i)). Open: P-disc transition, corner (Mellin), conic large x (cross-annulus summation), y-face (with the local
`-h` term of `U_2`), derivative/Hoelder versions. The edge forcing gains `b - 3/2` (not `b - 1/2`) derivatives.
v3.6 (conditioning, EXACT arithmetic on the VERIFIED V6 norm): in the window, `|delta| < 8.6507 - 21.3015 alpha`, so the
corner model inverse costs at least `0.13` (`alpha = 0.05`) up to `7.7` (`alpha = 0.4`); the old example `alpha = 0.4`,
`b = 3.403`, `a = 6.495` costs `64.6`. Working choice from v3.6: `alpha = 0.05`, `s = 3.06`, `b = 3.07`, `a = 6.45`,
`delta = -6.652` (cost `0.150`); inheritance of the lower bound by the variable operator is HEURISTIC.
v3.7 (source cusps of the FROZEN model; AUDITED astra pcusp1, single model, full argument astra/pcusp1/PROOF.md;
lead checked the conjugation `|zeta|^a L^ |zeta|^{-a} = -D - q` and the counterexample; ver V13 pending). For
`L_P = A s d_s + y d_y - 1 - g M`, `q = A + 2 - a`, `d = 1 + g`:
- (C1) forward inverse `h^(zeta) = -|zeta|^{-a} int_0^1 r^{q-1} |delta_r zeta|^a f^(delta_r zeta) dr`,
  `delta_r(s, y) = (r^A s, r y)`; for smooth compact odd f: `h = h_reg + chi K_f + h_rem`, `K_f = sgn(y)|y|^d F_f(s/|y|^A)`
  (finite-part definition; no logarithms since `d - A i` = 30.75, 20.60, 10.45, 0.297 for i = 0..3),
  `h_rem in H^r_loc` for `r < s_1 = s_fast + 2 - 2/A = 5.3815`.
- (C2) `F_f != 0` for an explicit f; then `h notin H^{s_fast}` at P, `h in C^{3, alpha_*}`, `alpha_* = d/A - 3 = 0.029290`
  (endpoint INCLUDED, sharp), `h notin C^4`; trace `d_y h(s, 0) = P_2(s) + c_f |s|^{g/A} + O(|s|^3)`, `g/A = 2.93077`, and
  `c_f` is one scalar functional (F_f != 0 does not force `c_f != 0`). h is smooth near P iff `F_f = 0`, an infinite-
  codimensional closed condition; the functionals are exactly the adjoint kernel elements for `s_fast < sigma < (A+3)/2`.
- (C3) `L(chi K_f) in H^r_loc`, `r < 5.3815`; frozen graph density: smooth trials have arbitrarily small residual in
  `H^sigma`, `sigma < s_fast`, with errors also small there. Ordinary mollification need NOT have small residual above
  `s_fast` (transport commutator at the cusp scale).
- (C4, CONDITIONAL) variable coefficients: the slow invariant curve `s = c y^2` displaces more than the cusp width
  `|y|^A`; the cusp must be centred in adapted coordinates (`S = s - c y^2`); the original-coordinate homogeneity is
  unjustified. A variable-coefficient theorem needs adapted coordinates, global realization and exclusion of other
  singular terms.
- (C5) REFUTED: "`f_y(P) = 0` is a cokernel condition of the coupled operator". Counterexample: `k = chi_0 (s^2 y - y^3/3)`,
  `u = -Lap k` vanishes near P, `f = L_P u = (T - 1) u + g d_s^2 k = 2 g y` near P. Correct jet identity
  `f_y(0) = (mu - 1) h_y(0) - g (M h)_y(0)` (nonlocal).
Consequences. Frozen level, local regularity at P only (ver V13: this is NOT membership in the global classes `P_m`,
which constrain the centre factorization, the canonical law and the growth; the earlier wording is withdrawn): generic
forcing gives local `C^{3,alpha}` with `alpha <= 0.0293` at P, not `C^4`; whether exact
F- solutions near X3 are cusped at P is CONDITIONAL (C4 plus the nonlinear problem). The F- spaces (`3 < s_H < 3.406` at
P, below `s_fast`) are compatible with a cusp. A numerical residual near P is meaningful in `H^sigma`, `sigma < s_fast`
(`sigma = 3.06` in the working choice), not in `C^4` or `H^4` (a smooth trial cannot be `C^4`-close to a cusped solution).
Floating diagnostics (code/energy_conormal.py): face flows have zeros only at 0 and `x_*`; `mu > 0`, `V_2(0,y) > 0`.
v3.7 (G1 status): y-face collar coupling in notes/yface_collar.md (Lemmas S, NF-Y, E-Y, Corollary CC-Y; EXACT, by swap
reduction to collar_coupling rev 2; revision 2 after astra yface1, single model, NEEDS-FIX with all repairs
incorporated: jets defined by continuous extension, exact localized edge decomposition `h = h_n + H_2 + H_4 + h_f`,
finite-regularity ranges (near `q_2 in H^{min(a-3/2,4)}`, `q_4 in H^{min(a-7/2,2)}`, far `W^{4,inf}`, `W^{2,inf}`), axis
condition `h(0,.) = 0` conditional on listed global hypotheses and kept as a class assumption; ver V12 on rev 2). Key difference from the x-face: the
full velocity jets of y-face edge components are smoothing (order `-1`; the local `-h` of `U_2` cancels the order-zero
part), so the coupling does not change the principal part of the y-face edge system on bounded collars. Corner: astra
corner1 (single model; lead checks in notes/corner_coupling.md): the double remainder `T_x^{N_x} T_y^{N_y} U_i` is
bounded on `L^2_{a,b}` for `N_x - 1/2 < a < N_x + 1/2`, `N_y - 1/2 < b < N_y + 1/2`; rectangular corner subtraction is
REFUTED globally (annular trace spaces needed; resonance at even integer `A = a + b`); with unit-box data the corner
coefficients are bounded iff `A > k + 1`; the coupling decomposes as `y q_1(x) + x^2 q_2(y) + x^4 q_4(y) - J x^2 y - K x^4 y
+ f_rem` with `J = 0` (strain cancellation) and `f_rem` bounded on unit-box data, unbounded on the pure global weight.
v3.8: notes/corner_coupling.md written (lead sympy checks of `J = 0`, `K`, `q_1, q_2, q_4` and the degree-7 obstruction).
Consequence: face traces near the corner need subtraction of ALL parity-allowed corner powers below `A - j - 1` (resp.
`A - l - 1`), i.e. corner coefficients up to degree 7 at `A = 9.52`; `A` must avoid even integers (resonance); the
parity `alpha` even in x and y is automatic in the class; `alpha in C^8` near 0 for the trial is OPEN.

### 3.4 Far field (AUDITED realize1 C3, C6; my derivation agrees)
`(c_l r d_r - 1)(r^sigma H) = (c_l sigma - 1) r^sigma H`; at `sigma = k` every angular trace is free (exterior kernel).
Energy at infinity `S = c_l gamma - 1`: forward (R-) estimates need `gamma < k`. The scalar term
`(c[h]/3) X.grad rho ~ (k c[h]/3) r^k Theta` is outside every `gamma < k` target; it is cancelled exactly by the log
tail: `(c_l r d_r - 1)(r^k log r Theta) = c_l r^k Theta`, with `delta k = -(k^2/3) c[h]`.

### 3.5 Source functional and scaling (VERIFIED, ver scaling_index)
`d_y(L h)(P) = (mu - 1) h_y(P) + g d_y W[h]_2(P) + g' W[h]_1(P)` (h only `C^1`). At an exact solution
`w'(x_*) g' + g mu'(x_*) = 0` and `d_y(L K)(P) = 0`. v3.1 correction: the cost `1/|mu~ - 1|` (`~ 4.4e7`) belongs to
the isolated pure-transport jet equation only; it is NOT a lower bound for the coupled inverse (REFUTED as an
inference by ver source_pole: the frozen coupled operator is uniformly invertible through `mu = 1`, and at `mu = 1`
the nonlocal term solves forcings with `f_y(0) != 0`). `f -> f_y(P)` is not the full cokernel functional of L
(index1: `l = j - j B M^{-1} R Pi`, CONDITIONAL on a global transport inverse). Consequence for F-: no bordering at P
is needed below threshold.

### 3.6 Codimension-one bookkeeping (VERIFIED, ver scaling_index)
If L is Fredholm on a graph domain D and J is continuous and nonzero on D, then `ind(L|ker J) = ind L - 1`. A
norm-continuous Fredholm path on fixed spaces has constant index. Neither the initial index nor Fredholmness along a
path is proved for the IPM operator. J is not continuous in plain `C^{2,alpha}` or `H^s` (realize1:
`h_eps = x^2 y chi(X/eps)`, `J = 1`, norms `O(eps^{1-alpha})`, `O(eps^{4-s})`), so factor control is part of every
realization.

### 3.7 Realization types (CONDITIONAL structural picture; the local pieces are 3.1-3.4)
| type | at P | at infinity | saddle | formal count after normalization |
|---|---|---|---|---|
| R+ | above `d/A` (e.g. `C^{4,alpha}`), values from P | `k < gamma < 1`, tail determined | incoming modes `|x|^{p_b} y^b` | v3.7: NO count. The old "index -1" is withdrawn (pcusp1 C5); frozen level: infinite-codimensional range (C2) |
| R- | below `s_fast` (`H^s`, `3 < s < 3.406`) | `gamma < k`, tail fixed | one singular exit coefficient (`beta_2`) in a smooth-trace space | see F- (section 4) |
| mixed (= the class `P_2`) | below `s_fast` | `k < gamma < 1` | as R- | formal kernel contains the tail traces (infinite-dimensional) |
| opposite mixed | above | `gamma < k` | as R+ | infinite cokernel (frozen whole-plane model: VERIFIED) |
Reasoning (CONDITIONAL): along transport orbits from P to infinity, a solution is fixed by one end. R+ fixes it at P
(finitely many jets, so the tail is determined); R- fixes it at infinity (the tail is data). In the mixed class both
ends are free: the tail traces `r^k H(theta)` are formal kernel directions (each corrected by an R- solve and by the
log mode for its `c[.]`), and the saddle and source conditions are absorbed by tail freedom. (v3.5: revision 3.4 said
"`c_l` moves along the family"; that is NOT established: first-order variation is the undecided functional `ell` of
notes/tail_family.md section 5.) Consequences:
(a) In `P_2`, an exact solution near X3 (if any) is not expected to be isolated: the expected solution set is a family
parametrized by tail data, modulo finitely many conditions. v3.5: this is now a CONDITIONAL theorem, VERIFIED as a
conditional statement (ver V8, 17:44Z) and AUDITED (astra family1): notes/tail_family.md revision 2 (Lemma T tail
uniqueness, unconditional; Theorem FL kernel `~ Tau/span Theta_1` on `X_+`; Theorem FN injective family on an affine
slice, normalized on a codimension-two slice, non-isolation in `G_gamma` under embeddings; `c_l = 1/k'` on members;
`ell` decides only first-order variation). The hypotheses (S1)-(S5) (F- mapping, bounded F- inverse, uniform closure,
continuity, differentiability) are open. Answer to PROMPT 5(ii) in FINAL_REPORT section 10 (realize1 C5: the numerics
alone cannot distinguish). Corroboration only: the first run's numerics found states with
`c_l` in [5.29, 5.60] at equal residual, softest directions in the far field near the y-axis, and `c_l` pinned only
when smoothness at P was enforced (h(P) row, Taylor patch).
(b) v3.7 (replaces "non-generic (index -1)"): in smooth-at-P classes the frozen source already imposes infinitely
many conditions (pcusp1 C2: smoothness iff `F_f = 0`), so such a class is not a Fredholm realization at the frozen
level and no finite index is assigned. Whether an exact solution near X3 is smooth at P is open; at the frozen level
it would require the vanishing of the whole cusp profile. The pure-transport germ count (kernel `y`, cokernel
`f_y(P)`, 3.1) concerns `T - 1` only. A Newton argument cannot close there (3.8); a nonexistence argument would need
the same missing inverse.
(c) `P_infty` constrains only the centre (`a` in `C^infty` near 0: the centre modes `|x|^{p_b} y^b`, b = 3, 5, ...,
must vanish); it does not require smoothness at P (VERIFIED scope, ver scaling_index).

### 3.8 Unnormalized contraction lower bound (VERIFIED as a conditional statement, ver scaling_index)
In unnormalized spaces satisfying all T2N hypotheses with K in the high and low domains:
`K_L C_B K_H eta >= eta ||B(K,K)||_{Y_L}/(||LK||_{Y_H} ||LK||_{Y_L})`, `L K~ = eps~ - X.grad eps~`. No numerical ratio
is claimed until the three norms and eta are validated (num R5).

### 3.9 Global flow and pure transport (VERIFIED as conditional statements, ver topics 52-54; AUDITED flow1, flow2)
notes/global_flow.md rev 3 (FINAL_REPORT 5(l)). Under the flow hypotheses H0-H4 every open-quadrant orbit comes from
P and escapes to infinity; on the maximal L^2(w0) domain `||(V.grad - 1)^{-1}|| <= e^{C_kappa/2}/kappa` with the box cost
`C_kappa <= 2 sum tau_i t_i`; instance (conditional on the box inequalities) `5 exp(1111/5000) < 6.245` at
`kappa = 1/5` and `(50/11) exp(2929/13000) < 5.695` at `kappa = 11/50`; far lower bound `1/kappa_inf`,
`kappa_inf in (0.2807, 0.281)`. Exterior part of H4 certified for the trial (`r >= 3634`, topic 53). OPEN: the bounded-region
inequalities (num N1'), a smooth weight for the coupled estimate, the coupled inverse.

### 3.10 Centre coefficient B_3 and P_infty (lead notes/pinf_B3.md rev 1 from astra pinf1; V16(b) VERIFIED ver topic 59 with a sign fix in A4; ver topic 60: the trial's reconstructed Q has nonzero resonant logarithms, so the polynomial-only B1/B4 premise fails for this trial; no value of a generalized B3 is proved)
`B_3 = -FP int_0^{x_*} H f/w` is a criterion only: smooth `a` (C^{6,alpha}, `alpha > p_3 - 6`) forces `B_3 = 0`; it is
not a `P_2` obstruction; at exact solutions w alone determines B_3. The trial's B_3 estimators are dominated by its
centre defects (x < 0.03; floating code/b3_axis.py), so the trial cannot decide B_3. A scoped P_infty exclusion would
need a centre-regular reference with `w0'(L0) = -w0'(0)`, a validated 1D evaluation and a uniform corner bound; its
meaningfulness as a NO is doubtful (pinf_B3 section 4). Not a current target.

### 3.11 Axis jets and the P-row (J3-J7 of notes/global_flow.md section 12; V16(a) VERIFIED ver topic 58 with scoped refutations (J3 bound needs normalized evaluations; J5 does not control a separate outer branch; J7 needs a Dini condition); prow1 collected; V17(a,d) VERIFIED ver topic 61, V17(c) topic 62, V17(b) topic 63)
x-axis jet `b = h_y(x,0)`: `w b' + (mu - 1) b + U_1[h](x,0) G_1' + d_y U_2[h](x,0) G_1 + (c[h]/3)(x G_1' + G_1) = f_y`,
`T G_1 = 0` at exact solutions. At P the pure jet transport is not onto (`mu_P = 1`).
prow1 (21:00Z, AUDITED, lead checked (1), (45)-(47) arithmetic; V17 requested):
- (1) `(mu_P - 1) h_y(P) + l_P(h) = f_y(P)` is the y-derivative of `L h = f` at P, so the P-row is IMPLIED by the
  equation (no extra condition). J3 is a statement about the split jet operator, not about L.
- Origin matching (7): if the incoming trace `b_1` at `x_1` is prescribed independently, normalization imposes one
  scalar equation; at exact solutions it is consistent with the scaling direction K (LK = 0); at the trial
  `L K~ = (X.grad - 1) F(rho~)`.
- Scale collapse (18): a strip-to-disc transition with `lambda -> 0` adds `(b_x - sigma) w lambda'/lambda` to the
  transverse rate, unboundedly positive if `b_x < sigma`. Characteristic-set form (21).
- Induced jet operators (31)-(33): `B_chi` of order -1, `P_chi = I - S_chi` (smoothing), `c[Eb] = -(P_chi b)(0)`,
  `N_chi b = G_1' B_chi b - G_1 P_chi b - ((x G_1' + G_1)/3)(P_chi b)(0)`; Volterra bound `M/(1 - M n)` (36).
- Closure: Schur complement `S = A - B D^{-1} C`, `sigma_min(S) >= s > 0`, `||L^{-1}|| <= d + (1 + d||C||) s^{-1}(1 + ||B|| d)`
  (41); a homotopy switching the coupling off is NOT justified (needs `t > 0.888` at sigma = 13/4).
- Uniform frozen window over the F1 box: `kappa_y = 6 - (sigma - 1/2) 101/100`, `kappa_x = 99/200 + 30 - (sigma - 1/2) 51/5`,
  `3 < sigma < 2373/680`; `||L_P^{-1}||_{H^{13/4}} <= 200/489` (47).
- Corner constraints (49)-(50): a generic `x^p y^q` remainder term needs `a < p + 1/2`, `b < q + 1/2`; with only the y-jet
  removed, `x^2 y^3` forces `a < 5/2` and then `delta > 0`.
Decision (v3.10): the strip/collar design of v3.9 is SET ASIDE (scale collapse; no x-axis jets are needed once the
P-row is redundant). Replacement: D_b (3.12).

### 3.12 Design D_b / D_b' (PROPOSED; floating diagnostics only; AUDITED by astra dib1 (obstructions O1-O5) and dib2 (D1-D10))
- Vector fields `Z_1 = g_1^{1/2} d_x`, `Z_2 = g_2^{1/2} d_y`, `g_2 = <r>^2 = 1 + (r/L)^2`,
  `g_1 = <r>^2 x^2/(x^2 + lam^2 <r>^2)` (b-type `x d_x/lam` near the y-axis, scaled ordinary elsewhere, ordinary and
  nearly isotropic near P). Weight `omega = |x|^{-2a} (1 + (r/L_w)^2)^{a - gamma'} e^{+phi}`. Correction of v3.10
  (dib1 (20)): the sign is `e^{+phi}`, since the weight contributes `-(1/2) V.grad phi` to the rate. phi is bounded
  with `V.grad phi >= 2 (E + kappa)^+` for a strict margin kappa > 0; this needs a smooth majorant of E with
  derivative bounds.
- Space: direct sum `X = E_2 J_2 (+) E_4 J_4 (+) R`; the weighted integral is infinite on jets, so the jets carry
  their own norms. Locally `R = x^alpha H^s_b(dx dy/x)` with `alpha = a - 1/2`, and `x^m b(y)` lies in R iff
  `m > alpha`. The jet norms at infinity are `int <y>^{4j + 1 - 2 gamma'} |a_{2j}|^2` (dib1 (12)).
  y-axis jets only (`a_0 = 0` is invariant since `rho(0, y) = 0`); no x-axis jets, no y-weight.
- Parameters: `s = 3.06`, `(sD - c_0)/A = 5.77 < a < 6.5`, `gamma' = 1.129 < 1 + 1/c_l`, `lam = 0.5`. By dib1
  (5)-(7) the projected Riesz constant is `C (1 + 1/dist(alpha, Z))`, so `a = 6.45` (`alpha = 5.95`) is a poor
  choice. By that constant `a = 6.0` (`alpha = 5.5`) is best; the corner rate is then `-c_0 - aA + sD = -2.30`
  (see the trade-off after the rate table).
- Identities from dib1, elementary, checked by the lead at 21:28Z (V18 requested):
  (1) `U_2(0, .)^ = k int_0^inf e^{-kz} h~ dz`.
  (8) `u_0 = B`, `u_2 = -a_2 - B''/2`, `u_4 = -a_4 + a_2''/12 + B''''/24`, `u_1 = -B'`, `u_3 = a_2'/3 + B'''/6`,
  `u_5 = -u_4'/5`, `c[h] = B'(0)`.
  (23) `[x^2 y] L h = 0` for every admissible h, so the target must satisfy `[x^2 y] f = 0` (cf. `J_c = 0`, 5(k)).
  (14) An exact profile is not in `L^2(<r>^{-2 gamma})` for `gamma < 1 + 1/c_l`. Proof by flow scaling:
  `rho(Phi_t X) = e^t rho(X)` and `det D Phi_t = e^{2 c_l t}`.
- Obstructions found by dib1 (to be repaired):
  (O1) Far field. For compactly supported h with zero jets and `c[h] != 0`, outside the support
  `L h = U[h].grad rho + (c[h]/3) X.grad rho` (correction 22:07Z after a verifier objection: the nonlocal velocity
  does not vanish outside supp h; dib1 (17) keeps it). For compact h, `U[h] = O(r^{-2})`, so `U[h].grad rho =
  O(r^{k-3})` lies in the far weighted space, while `(c[h]/3) X.grad rho` does not (18). Repair: use the fixed-tail formulation (section 4,
  F-) and add the log-tail direction `chi r^k log r Theta_0` to the domain. Since
  `(V.grad - 1)(r^k log r Theta_0) ~ c_l r^k Theta_0`, it balances `(c[h]/3) k r^k Theta_0`.
  (O2) Scaling. K is not in the far space (30), so scaling contributes no kernel and no `[x^2 y] h = 0`
  normalization is needed; the scale is fixed by the tail amplitude, as in F-.
  (O3) Jets. At `t = s` the jet blocks have positive top-order rates `D (t - 1/2 - p_j)` (29). In the diagonal
  model each jet row has one matching condition `int_0^inf F/(v H_j) = 0` (28), because the homogeneous solution
  `H_j ~ y^{k - 2j}` at infinity is excluded by `gamma' < 1 + k`. In the coupled system these become coupled
  constraints. A tail-profile parameter tau (F-) with a nonzero x^4-jet at the y-axis may balance the a_4 row; the
  a_2 row is consistent with `[x^2 y] f = 0`.
  (O4) Fredholm route. Compactness fails for translation-invariant smoothing in log variables. An index argument
  along `L - tau I` needs Fredholmness on the whole path, and switching off the coupling is unsafe (F1).
  (O5) Orbit cost. Norm comparison loses a factor `e^{W/2}`, which is 77.5 at W = 8.7.
- Floating principal rates (code/energy_b.py; maxima of E over the region):

  | region | a = 6.45, L_w/L = 1 (runs/energy_b_l0.5.json) | a = 6.0, L_w/L = 1 (runs/energy_b_a6_lw1.json) | a = 6.0, L_w/L = 0.5 (runs/energy_b_a6_lw0.5.json) |
  |---|---|---|---|
  | corner `r < 0.1` | -6.86 (limit -6.865) | -2.29 (limit -2.30) | -2.27 |
  | `0.1 <= r < 1` | -6.12 | -1.72 | +0.45 (x-axis, r = 0.98) |
  | incoming x-axis `0.05 < x < 8.5` | <= -0.88 | up to +1.52 (x = 4.0) | up to +11.8 (x = 4.0) |
  | `\|X - P\| < 1` | <= -2.08 | <= -2.23 | <= -2.94 |
  | y-axis | <= -0.58 | <= -0.55 | <= -0.55 |
  | far field | -> -0.281 | -> -0.281 | -> -0.281 |
  | off-axis maximum | 10.3 at r = 10.6 | 10.4 at r = 10.6 | 8.9 at r = 5.1 |

  On the incoming x-axis the y-derivatives see the transverse expansion `s d_y V_2` and the inflow makes the far-weight
  term positive; at a = 6.45 the term `a V_1/x` compensates. These rates cover the remainder only; the jet blocks are
  not covered (O3). Trade-off: a = 6.0 has the better Riesz constant (`1 + 1/dist(alpha, Z) = 3` against 21 at
  a = 6.45) but a smaller corner margin and a positive x-axis segment; a = 6.25 (`alpha = 5.75`, factor 5) is the
  compromise to test. a = 6.25 (runs/energy_b_a6.25_lw*.json, 21:44-21:50Z): corner `r < 0.1` -4.80 / -4.83,
  `0.1 <= r < 1` -1.88 / -4.17, incoming x-axis up to +11.0 / +0.19, `|X - P| < 1` -2.99 / -2.14 (L_w/L = 0.5 / 1);
  backward costs with `kappa = 0.1`: 7.18 (L_w/L = 0.5), 8.94 (L_w/L = 1).
- Orbit costs by backward integration (code/orbit_back.py, runs/orbit_back_*.json; forward shooting under-samples
  the orbits). sweep_b1/b2: `sup W = 8.72` at the base point, range 5.4-12.7, `L_w/L = 0.35-0.5` gives 6.5-6.9.
  sweep_b3 (runs/sweep_b3.log; Rt = 1e4 unless noted): a = 6.0, `L_w/L = 0.5`: `W = 7.18` (`kappa = 0`; 7.179 at
  Rt = 400), 7.33 (`kappa = 0.1`), 7.48 (`kappa = 0.2`); a = 6.45, `L_w/L = 0.5`, `kappa = 0.1`: 7.06; a = 6.0,
  `L_w/L = 1`, `kappa = 0.1`: 9.01. Strict margins up to 0.2 cost about 0.15 per 0.1 (the far rate -0.281 bounds
  kappa).
- astra dib2 (21:36:55Z, collected 21:55Z; astra/dib2/answer.md) on D_b' = D_b local spaces + fixed tail F-
  (log tail q = chi r^k log r Theta_0, tau-tail t = chi r^k Theta_1, e = chi r^k Theta_0). Lead checks (21:58Z):
  items marked [checked] were rederived by hand.
  (D1) Count. Conditional on an index-zero remainder block and admissible couplings, the unnormalized count is
  `0 - 1 + (1 - 1) + 1 = 0` (a_2 row 0, a_4 row -1, (k', far scalar) 0, tau +1). Imposing `a(0) = 1`
  (`[x^2 y] h = 0`) gives -1, so F- must solve the unnormalized fixed-tail problem and normalize afterwards by the
  scaling `rho_lambda = lambda^{-1} rho(lambda X)` (which changes the tail amplitude), as section 4 already states.
  (D2) a_2 row [checked]: `[y] F_2 = [y] f_2` including the nonlocal terms (`r_2 = y + O(y^3)`, `B = c y + O(y^3)`,
  coefficient `-2c + c + c = 0`), so the only local condition is `[x^2 y] f = 0`; the solution from infinity
  `a = -H_1 int_y^inf F/(v H_1)` is unique (H_j not in the far jet space since `gamma' < 1 + k`). Needs `v > 0` on the
  whole y-axis, `s' > 3/2`, a graph domain for `v d_y` and endpoint Hardy estimates. This solves the row only for
  known forcing; B depends on all of h.
  (D3) a_4 row [checked]: the raw matching integral diverges for `F'(0) != 0` (`T_2 y = D(1 - p_2) y`). Regularized
  functional `ell_4^0(F) = int_0^inf (F - T_2 S_F)/(v H_2)`, `S_F = F'(0) y chi_0/(D(1 - p_2))`, independent of
  chi_0 since `T_2 S/(v H_2) = (S/H_2)'`. One condition, for `s' > p_2 + 1/2 = 2.453`. The row contains `a_2'` and
  `B'''`, not `a_2''`, `B''''`.
  (D4) Tail jets [checked]: `r^k Theta = theta_2 x^2 y^{k-2} + (theta_4 + (k-2) theta_2/2) x^4 y^{k-4} + ...`;
  log-tail jets include the extra term `theta_2 y^{k-4}/2` in the x^4 jet. Tail directions are not jet + remainder:
  at the far corner `||y^beta b(x/y)||_R^2 ~ int y^{2 beta + 1 - 2 gamma'} dy int t^{-2a} |b|^2 dt` diverges at
  `beta = k`; they must be carried as full functions. No extra matching at the far corner for the exact far
  transport (gap `kappa_inf = 1 - c_l (gamma' - 1) = 0.2808` [checked], equal to minus the far rate of 3.12); uniformity for the full operator is unproved.
  (D5) Mapping: transport is unbounded on a same-order Sobolev space (`h_n = n^{-s} chi e^{i n xi.X}`), so the
  domain must be a graph domain `{h in X : V.grad h in X}` (jets likewise). Far subtraction (11)-(12):
  `L(h, kappa, tau) = (A h + a kappa + b_tau tau, d(h) + m kappa + n tau)`, `A h = (V.grad - 1) h + U[h].grad rho
  + c[h] w`, `w = (X.grad rho - k e)/3`, `d(h) = k c[h]/3`, `a = L q - m e`, `m = c_l + k c[q]/3`, `b_tau = L t - n e`,
  `n = k c[t]/3` [checked]; columns admissible since `2k - 1 = -0.641 < gamma' - 1` under far symbol hypotheses (13).
  (D6) Velocity: `B^(eta) = |eta| int_0^inf e^{-|eta| x} h^(x, eta) dx` (h vanishing on the axis) [checked against
  dib1 (1)]; remainder supported off the axis has `B != 0`; local smoothing `B_R in H^{s + a - 1/2}_y`
  (flat model, (15)); jets `B ~ 2 |D_y|^{-2} a_2`, `24 |D_y|^{-4} a_4` [checked]; keep the cancellations in `u_2`,
  `u_3`. `c[h] = int_{x>0} 2y(3x^2 - y^2)/(pi r^6) h` [checked] is bounded on R for `2 < a`, `gamma' < 2`. The global estimate
  for the projected product `h -> U[h].grad rho` is unproved; U does not preserve X.
  (D7) Source: with `mu_P = 1` the pure-transport inverse from infinity is not regular at P (smooth `f = y phi(s)
  psi(y)`, phi = 0 near 0, gives `d_y h(s, 0) = -(1/A) int_s^inf phi(z)/z dz` for s > 0, hence a jump
  across s = 0 [checked; VERIFIED ver topic 68, 22:41Z: no C^1 representative, not H^sigma_loc for sigma > 2, not H^1_loc for A >= 3, FR 5(l)]; for phi(0) != 0 a log singularity); the remainder reference block near P must contain the
  nonlocal term (G1), as in 5(a)-(b) of the report.
  (D8) Blocks: no triangular structure (C_2, C_4 of (19) are explicit and nonzero; the extension cutoff contributes
  `(V.grad chi) x^{2j} a_{2j}`). Conditional closure (20)-(24): `mu_J = 1 - C_J eps_JJ`, `mu_R = 1 - C_R eps_RR`,
  `theta = C_J C_R C_JR C_RJ/(mu_J mu_R) < 1`, `C_H` (22), bordered Schur complement `S = D_f - C H^{-1} B` and
  `||L^{-1}|| <= C_H + (1 + C_H ||B||) C_S (1 + ||C|| C_H)`.
  (D9) Transversality: eliminate kappa (`T = A - a d/m`, `b = b_tau - (n/m) a`); with `T^* ell = 0` the condition is
  `ell(b) != 0`, not `ell_4^0` of the raw x^4 jet of `L t`. Counterexample to the angular criterion [checked]:
  `Theta_1 = sin theta cos^2 theta (1 + (3 - k) cos^2 theta/2)` has `cos^4` coefficient `(2 - k)/2 != 0` but zero
  x^4 jet. `Theta_1 proportional to Theta_0` puts the scaling kernel `K - (k - 1) t` in the enlarged domain; num's
  C2 tau-column (`Theta_0 cos 2 theta` in this notation) is not proportional to Theta_0. (Here Theta_1 is the
  tau-profile, not the asymptotic correction `r^{k-1} Theta_1` of the task statement.) Checking `ell(b) != 0` needs an enclosure (30) with
  validated adjoint stability; far truncation error decays only like `R^{-(1 + k - gamma')} = R^{-0.050}` from
  the weighted target norm alone.
  (D10) Size: `e^{W/2}/kappa_inf = 130-276` before projection, localization, coupling and Schur losses; a
  successful bound plausibly `1e3-1e4` (planning estimate, not a bound). Remaining analytic gaps: the global
  projected velocity estimate near the axis and corner, the extension transition, a source estimate retaining the
  nonlocal term, the far-corner uniformity, Fredholmness/surjectivity, and a validated nonzero coupled Schur
  complement.
- Requirements on the trial (lead analysis). Near 0, a non-polynomial homogeneous term `r^m E(theta)` of the
  correction or of the residual is admissible only if `m > a + s - 1` (8.06 at a = 6.0). The present trial has
  `m = 5` (section 4 of the report), and its residual has `H^3 ~ 1` on the P-disc. D_b therefore needs N7
  (`j <= 4`) and a P-disc refit (chainR).

### 3.13 Lower-order route (PROPOSED; floating diagnostics only; AUDITED by astra dib3; lead checks 22:23-22:29Z, code/chk_dib3.py; obstructions B2, B3 (identity), B5-B8, B10 VERIFIED ver topic 70, 23:03Z, FR 5(n); B8 only for the explicit annular norm)
Proposal (lead, 22:07Z). Prove existence through T2N in a D_b'-type realization of local order `2 < sigma_H < 3` (low
order `sigma_L = sigma_H - 1`), where the trial's residual near P is smaller, then upgrade the solution to `C^{2,alpha}`
(`P_2`) by a separate regularity theorem.
- Floating inputs. Residual of the trial near P (num, FFT of `chi eps~`, NUM_REPORT 7.5):

  | patch | sup | H^2 | H^2.25 | H^2.5 | H^2.75 | H^3 | H^3.06 |
  |---|---|---|---|---|---|---|---|
  | 0.5-disc | 1.14e-5 | 7.34e-3 | 2.28e-2 | 7.43e-2 | 0.253 | 0.890 | 1.208 |
  | 1.0-disc | 1.67e-5 | 4.40e-2 | 0.159 | 0.580 | 2.13 | 7.86 | 10.76 |

  A factor 3.2-3.6 per quarter derivative (knot-scale structure). Rates and orbit costs at lower order (sweep_b4,
  WORKLOG 22:18Z): `e^{W/2} = 5.6-20.6` for `s = 2.25-2.75` against 39-91 at `s = 3.06`. Corner limit
  `-c_0 - aA + sD`: -9.40 at (2.25, 5.0), -4.08 at (2.5, 5.0); at (2.75, 5.0) it is +1.25 (inadmissible, a = 6 used).
- Audit dib3. Items marked [checked] were rederived by the lead (V20 requested).
  (B1) [checked; VERIFIED ver topic 68, FR 5(l)] At any exact solution with `rho, V in C^1`, `V(P) = 0`, `grad rho(P) = (0, g_P)`, `g_P != 0`:
  `mu_P = 1` and `A_P = 2c_l - 1`. Proof: `V.grad rho - rho` is differentiable at P with derivative
  `DV(P)^T grad rho(P) - grad rho(P)`; DV(P) is diagonal by parity; the y-component is `g_P (mu_P - 1)`; `div V = 2c_l`.
  (B2) [checked, sympy] Frozen counterexamples to a local bootstrap. For odd n with `p = (g + 1 - n)/A > 1`
  nonintegral, `H_n = sum_{j <= (n-1)/2} b_j |s|^{p+2j} y^{n-2j}`, `b_0 = 1`,
  `b_{j+1} = -[g + 2j(A-1)](n-2j)(n-2j-1) / [2(j+1)(A-1)(p+2j+2)(p+2j+1)] b_j`, satisfies `-Lap L_P H_n = 0` (mu = 1),
  using `-Lap M = -d_s^2` and `-Lap L_P w = (g + 1 - lambda) d_s^2 w + (1 - lambda) d_y^2 w` for `w = |s|^q y^r`,
  `lambda = Aq + r`, `lambda_j = g + 1 + 2j(A-1)`. So `L_P(chi H_n)` is harmonic where `chi = 1`, while
  `chi H_n in H^t_loc` iff `t < p + 1/2`. n = 7: p = 2.33974 (in H^2.5, not in H^3.1); n = 11: p = 1.94568 (not C^2).
  Hence "u in H^{sigma_0}, L u in H^{sigma_1} locally implies u in H^{sigma_1} locally" is FALSE for the frozen
  operator. No conflict with (G1): the global forcing of `chi H_n` is rough on `supp grad chi`. Any upgrade must be
  global, with the same operator, domain and target at both orders.
  (B3) [checked] Uniqueness transfer: if A is injective on `D_0` and maps `D_1 c D_0` onto `Y_1 c Y_0`, then
  `u in D_0`, `A u in Y_1` imply `u in D_1`. For the nonlinear problem the exact identity is `A_h h = -f_0` with
  `A_h u = (V_rho.grad - 1) u + (Gamma u).grad rho~`, `f_0 = F(rho~)`; its transport coefficient `V_rho` is only
  `C^{1,beta}`, `beta < sigma_0 - 2`. Using `DF(rho)` instead is circular (`DF(rho) h = -f_0 + (Gamma h).grad h`).
  Possible repair: a global tame estimate, uniform under a regularization `J_eps`:
  `||J_eps h||_{X_1} <= C (||f_0||_{Y_1} + ||h||_{X_0}) + theta ||J_eps h||_{X_1}`, `theta < 1`. Not proved.
  (B4) [checked] Lipschitz transport alone does not propagate `H^{sigma_1}`: `B(y) d_x u - u = 0`, `u(0, y) = 1`,
  `B = 1 + eps chi(y) |y|^p`, `u = exp(x/B(y))`, `sigma_0 - 1/2 < p < sigma_1 - 1/2`. The active-scalar structure may
  allow tame commutator estimates (Kato-Ponce); not proved for this realization.
  (B5) [checked] Regularity does not give the factorization: `rho = chi(r) x^2 y r^{-eps}` is `C^{2,alpha}`
  (`alpha <= 1 - eps`) and `H^s_loc` for `s < 4 - eps`, but `rho/(x^2 y)` is unbounded. Continuity of the factor must
  come from the realization (jets plus weighted remainder) or from the equation.
  (B6) [checked] c at low order: `|c[h]| <= C_s ||h||_{H^s}` iff `s > 2` (`int^inf r^{3-2s} dr`). For `t = sigma_H - 1 < 2`
  the family `e_eps = eps^{t-1} phi(X/eps)` (phi annular, even in x, odd in y, `c[phi] != 0`) has `||e_eps||_{H^t} ~ 1`
  and `c[e_eps] = eps^{t-2} c[phi] -> infinity`. So C_B fails for the unaugmented `E = H^{sigma_H - 1}`. In D_b' the
  corner weight may control c (`|K_c| <~ r^{-3}`; the near-origin bound is finite for a > 2), with separate jet bounds.
  (B7) [checked] Corner and jet window at lower order: `max{9/2, (sD - c_0)/A} < a < 13/2`,
  `(sD - c_0)/A = 2s - 1/2 + (s - 3/2)/A`; s = 2.5: `a > 4.5985`, a = 5.0 gives -4.0754. The mode `y^{p_2}` stays excluded
  from the a_4 jet space iff `s' > p_2 + 1/2 = 2.4531`, independently of s; keep `s' >= 2.46` (count of 3.12 unchanged).
  If `s' < 2.4531` the domain gains one dimension and tau must be dropped or one scalar condition added (conditional on
  the actual matching map). A `y^{p_2}` jet term with a rectangular cutoff is not `C^2` across `y = 0` at `x != 0`;
  with a conical cutoff (`|x| <~ |y|`) it is.
  (B8) [checked] Centre condition `m > a + s - 1` (radial integral), 6.5 at (2.5, 5.0). Correction of the lead's question:
  the trial's residual is `r^5 E(theta)` at 0 (report section 4: m = 5 in density units; the factor has the
  non-polynomial `r^2 D(theta)`), not "degree five in the factor"; dib3's conclusion that degree 8 passes rests on this
  misstatement. The centre condition fails at both orders; N7 is needed for any D_b' route.
  (B9) [checked] The source estimate still needs the nonlocal term for `2 < s < 3`: `beta_fast = sA - c_0 - g`,
  `beta_slow = s - c_0`, both negative; without gM, `beta_fast = sA - c_0 > 0`. The pure-transport resonance
  `(A s d_s + y d_y - 1)(y log|y|) = y` persists.
  (B10) [checked] Residual norms: `||chi f||_{H^s} <= (eps ||chi||_2)^{1 - s/3} ||chi f||_{H^3}^{s/3}`, constant 1
  (Hoelder on the Fourier side); illustration with eps = 1e-4, radius 0.5, `B_3 = 0.9`: 0.090, 0.193, 0.417 at
  s = 2.25, 2.5, 2.75 (num's direct values are smaller: 2.28e-2, 7.43e-2, 0.253). Fractional norms can also be certified
  directly (Gagliardo double integral, constant `4^theta Gamma(1+theta)/(2 pi |Gamma(-theta)|)`). dib3's warning on
  spline interfaces (a `C^2` cubic spline gives a residual outside `H^{5/2}`) does not apply to X3: its modes are
  degree-7 splines with exact `C^6` joins, so `eps~` is `C^5` across joins and cellwise derivative bounds of order
  `<= 5` are bounds on global weak derivatives.
- Lead assessment. The route is conditional on (L1) low-norm control of c in the realization; (L2) a high-order a
  priori estimate for `A_h` in the same realization at some `sigma_1 in (3, s_fast)`, with lower-order part bounded by
  `||h||_{X_0}` and quasilinear part `<= C ||h||_{X_0} ||u||_{X_1}`, so that `theta = K_1 C ||h||_{X_0} < 1` (only finiteness
  of `f_0` in `Y_1` is needed, not smallness); (L3) a regularization family compatible with the weighted b-structure;
  (L4) preservation of the factorization and the far bound. In addition the low-order closing inequality needs
  `K_L C_B K_H eta_0 < 1` with `eta_0 ~ 7e-2` (H^2.5, 0.5-disc, floating) and `e^{W/2} ~ 11-21` inside K_H, K_L.
  The route stays a proposal and does not change the verdict.

### 3.14 Hoelder scale at the source (AUDITED astra holder1, single model; lead checked (3)-(5), (8)-(11), (19), (20) and the endpoint table against notes/holder_heuristic.md; V21 requested)
Frozen model only: `L_P = A s d_s + y d_y - 1 - g M` (mu = 1), `R = L^2`-selected inverse `-int_0^inf S_t dt`,
`S_t = e^{-t} D_t Q_t`, `D_t f(z) = f(e^{tB} z)`, `B = diag(A, 1)`, `Q^_t = ((xi^2 + eta^2)/(e^{2(A-1)t} xi^2 + eta^2))^{a/2}`,
`a = g/(A - 1) = 3.2511`, `q = (1 + g)/A = 3.0293` (cusp order of G2), `C_*^sigma = B^sigma_{inf,inf}`; forcing
supported in a fixed compact K, constants depend on K; assumes `A > 1`, `1 < a < A + 1`.
- (H1) `||R f||_{C_*^{r(sigma)}} <= C_K ||f||_{C_*^sigma}` for `1 < sigma < a`, `r(sigma) = sigma - (sigma - 1)/A`; the
  exponent cannot be raised, even for smooth forcing supported in an arbitrarily small neighbourhood of P, even in s and
  odd in y. Packets `f_N = N^{-sigma} phi(s) psi(y) sin(N y)`, `N = 2^n`: `||R f_N||_{C_*^sigma(B_r(P))} ~ 2^{n(sigma-1)/(A-1)}`
  for `1 < sigma < q` (mechanism: the transverse frequency is carried for time `log N`, then the slow direction
  amplifies by `e^{(sigma-1)t}` until the s-scale `l N^A` is reached; my heuristic gives the same exponent).
- (H2) Endpoints: `0 < sigma < 1` bounded on `C_*^sigma`; `sigma = 1` loses a logarithm, necessarily
  (`d_y R f_N(0) = -phi(0) psi(0) log N/(A - 1) + O(1)` with `f_N = N^{-1} phi psi sin(N y)`, and a dyadic sum in `C_*^1`);
  `sigma = a` log upper bound, sharpness for odd forcing open; `sigma > a` output `C_*^q` (optimal by G2); at
  `sigma = q` the uniform output order is `r(q) = 2.8294`, not q.
- (H3) In `C^{2,alpha}` language: forcing `C^{2+alpha}` gives at best `C^{2+alpha'}`, `alpha' = ((A-1) alpha - 1)/A`,
  positive iff `alpha > 1/(A-1) = 0.1093`. A correction of order beta needs forcing order
  `tau(beta) = (A beta - 1)/(A - 1)` (2.6639 for beta = 2.5).
- (H4) Weighted and anisotropic Hoelder spaces: power weights do not embed in unweighted `C^sigma`; anisotropic
  orders keep the packet growth `N^{(r-1)/(A-1)}`. A mixed space (Sobolev `3 + alpha < sigma_H < s_fast` near P, Hoelder
  elsewhere) is not ruled out by the frozen obstruction and needs `alpha < 0.5786`; cutoff commutators, nonlocal tails
  and interface compatibility are open.
- (H5) Conditional persistence (Q4): if the transport and coupling coefficients are smooth near P, the global norm
  controls the nonlocal tails and is locally equivalent to `C_*^sigma` on compact corrections, a two-parameter Weyl
  sequence (truncated, mollified frozen packets, then an isotropic dilation `eps^sigma w_j(z/eps)` at P) rules out
  `||h||_{C_*^sigma} <= C (||L h||_{C_*^sigma} + ||h||_lower)`. Not proved for exact `P_2` profiles (whose `grad rho` is
  only `C^{1,alpha}`) or for every Hoelder-type space.
- (H6) Consequences: same-order Hoelder Newton at `C^{2,alpha}` is obstructed in the frozen model; a standard smooth tame
  Nash-Moser theorem does not apply directly (smooth forcing produces the cusp; the loss `(sigma - 1)/A` depends on the
  order). A two-norm scheme with a stronger forcing norm, a restricted range or a cusp-adapted scale is not excluded.
- Lead assessment. This supports local order `3 < sigma_H < s_fast` near P (3.2, G1) over a native Hoelder realization,
  and it explains the role of `s_fast`. It changes no verdict.

### 3.15 Local H^s a priori estimate at the source (AUDITED astra srcloc1, single model; lead checked (3)-(5), (10)-(18), (21), (22), (26), (28)-(34), (45), (48) by hand and with code/chk_srcloc1.py, chk_srcloc1_kernel.py (floating); V23 requested)
Setting. `s = 31/10`, `t = 21/10`; P the trial's source with `V(P) = 0`, `DV(P) = D = diag(A_P, mu_P)`,
`grad rho~(P) = a_P = (0, g)`, `div V = tr D`; `(A_P, mu_P, g)` in the box `10 <= A <= 51/5`, `99/100 <= mu <= 101/100`,
`29 <= g <= 30`; `V in C^4`, `rho~ in C^5` on `B_{3 delta}(P)` with certified derivative bounds, `0 < delta <= 1`,
`3 delta < |P|/2`. Inhomogeneous `H^r` (`J^r = (1 - Lap)^{r/2}`, unitary Fourier transform), restriction norms
`||h||_{H^r(Omega)} = inf ||H||_{H^r}` over extensions. `h in C_c^infty` with `h(0) = 0`, `grad h(0) = 0` (true for
`h = x^2 y b`), and the completion in the graph norms. Cutoffs centred at P: chi (1 on `B_{5 delta/4}`, support in
`B_{7 delta/4}`), tau (1 on supp chi, support in `B_{9 delta/4}`), theta (1 on `B_{2 delta}`, support in `B_{3 delta}`),
zeta (1 on `B_{5 delta/2}`, support in `B_{3 delta}`).
- (S1) Frozen margin [checked]. `Re <L_P u, u>_{H^s} <= -kappa ||u||_{H^s}^2`, `kappa = 1687/500 = 3.374` over the box:
  the inhomogeneous symbol `-(A + mu)/2 - 1 + s (A xi^2 + mu eta^2)/<zeta>^2 - g xi^2/|zeta|^2` is bounded by the
  homogeneous one, which is affine in `xi^^2`; slow direction at `A = 10`, `mu = 101/100` gives 3.374, fast direction
  `35.595 - 10.2 s` (= 3.975 at s = 3.1). The box version reaches only `s < 3.4897`; larger s needs narrower enclosures.
- (S2) Energy estimate [checked]. With `w = theta (V - D z)`, `q = theta (grad rho~ - a_P)` and the whole-plane auxiliary
  operator `A = L_P + w.grad + q.U`:
  `Re <A u, u>_{H^s} <= -(kappa - E) ||u||_{H^s}^2 + R ||u||_{H^{s-1}} ||u||_{H^s}`,
  `E = (1/2) ||div w||_inf + s ||Dw||_{inf,F} + ||q||_inf`, `R = T_s(w) + sum_i P_s(q_i)`.
  The point is the expansion `[J^s, w.grad] = -s sum (d_j w_i) d_ij J^{s-2} + R_w` with
  `||R_w u||_2 <= T_s(w) ||u||_{H^{s-1}}`, `T_s(w) = s(s-1) 2^{s-4} sum_i (W_2(w_i) + beta_{s-1} ||w_i||_{H^s})`: only first
  derivatives of w and values of q enter E. Taylor bounds: `E <= C_V delta`,
  `C_V = [3s + (9/2)(s + 1/2) C_theta] M_V + 3 M_rho`, `M_V = sup ||D^2 V||_F`, `M_rho = sup ||D^2 rho~||_F` on `B_{3 delta}`,
  `C_theta = delta ||grad theta||_inf`; `C_theta = 2` gives `C_V = 41.7 M_V + 3 M_rho`.
- (S3) Explicit constants [checked]. `W_r(f) = (2 pi)^{-1} int <k>^r |f^|`, `alpha_r = 1/(2 sqrt(pi (r-1)))`,
  `beta_r = 1/(2 sqrt(pi (r-1)(r-2)))`; `P_s(f) = s 2^{s-2} (W_1(f) + alpha_{s-1} ||f||_{H^s})` bounds `[J^s, f]` from
  `H^{s-1}` to `L^2`; `B_s(f) = ||f||_inf + P_s(f)` bounds multiplication on `H^s` (given the `H^{s-1}` norm);
  `M_r(f) = 2^{r/2} W_r(f)` on `H^r`. `||[U, chi] v||_{H^s} <= 2 * 3^s W_s(chi) ||v||_{H^{s-1}}` (symbol `|m| <= 1`,
  `|Dm| <= 1/|zeta|`). Kernels `K_1 = -xy/(pi |X|^4)`, `K_2 = (x^2 - y^2)/(2 pi |X|^4)` (imaginary and real parts of
  `(x + iy)^{-2}/(2 pi)`), `|D^gamma K_i| <= (|gamma| + 1)!/(2 pi) |X|^{-2-|gamma|}`. Far part
  `|D^gamma U_i[(1 - zeta) h]| <= k_j N_far(h)` on `B_{9 delta/4}`, `k_j = 100 (j+1)!/(2 pi) (4/delta)^j`,
  `N_far(h) = int_{|X-P| >= 5 delta/2} |h|/|X-P|^2 + int_{R^2 \ B_{3 delta}(P)} |h|/|X|^3`. Strain
  `|c[h]| <= C_c ||h||_{H^t(B_{3 delta})} + N_far(h)/pi`, `C_c = 3 delta/(sqrt(pi) (|P| - 3 delta)^3)` (kernel
  `|d_y K_2| <= 1/(pi |X|^3)`; the vanishing of h and grad h at 0 removes the local terms).
- (S4) Local estimate [checked]. Localization identity
  `A(chi h) = chi L h + (V.grad chi) h + (a_P + q).[U, chi] h - chi ell c[h]`, `ell = X.grad rho~/3`. Result:
  `||chi h||_{H^s} <= K_1 ||tau L h||_{H^s} + K_2 A_h + K_3 H_h + K_4 N_far(h)`, `K_1 = 1/(kappa - E)`,
  `A_h = ||h||_{H^s(B_{2 delta} \ B_delta)}`, `H_h = ||h||_{H^t(B_{3 delta})}`, `K_2, K_3, K_4` explicit (srcloc1 (24), (31),
  (34)). Exactly `K_1 = 1/(kappa - E)` (instead of `B_s(chi)/(kappa - E)`) uses inner/outer partitions with separation
  `delta/8` and the off-diagonal kernel bound `|K_{J^s}(X)| <= D_s |X|^{-2-s}`, `D_s = 2^s Gamma(1 + s/2)/(pi |Gamma(-s/2)|)`
  (1.62874 at s = 3.1; checked by quadrature), giving `J_delta = (4 pi D_s/s)(8/delta)^s`. Inputs: `D^j V`, `j <= 4`,
  `D^j rho~`, `j <= 5`, on `B_{3 delta}`, and cutoff derivatives through order 5. Size: `delta <= kappa/(2 C_V)` gives
  `K_1 <= 1000/1687 = 0.59277`; keeping the knot-scale radius `delta = 0.0165` needs `C_V <= 102.24`. For fixed cutoff
  shapes the conservative constants scale as `K_2 = O(delta^{3-2s})`, `K_3 = O(delta^{3-3s})`, `K_4 = O(delta^{-s-2})`
  (not optimal).
- (S5) Outflow and the outer estimate [checked]. `V.grad chi >= -eps chi` is impossible for a cutoff that orbits leave
  (`chi(Phi_t z) >= e^{-eps t} chi(z)`); on a factor-two annulus `sup |V.grad chi| >= A_P/log 2` in the frozen
  calculation. So the annular term `A_h` is intrinsic. An outer estimate O(h) must give
  `||h||_{H^s(B_{2 delta} \ B_delta)} <= C_A O(h)` in ordinary `H^s` (an `H^{s-eps}` or `C^{2,alpha}` outer estimate does not);
  with `S <= aF + bO + dR_0`, `O <= cF + eps S + eR_0` the two combine iff `b eps < 1` (b contains `K_2 C_A`), giving
  `S <= ((a + bc) F + (d + be) R_0)/(1 - b eps)`. The lower-order quantity `R_0` (here `H_h`, `N_far`) still needs a
  separate bound or a Fredholm argument with the kernel excluded.
- (S6) Auxiliary whole-plane inverse (AUDITED; the lead checked the comparison inequality (45) by ODE integration, not
  the semigroup construction). If `a_s = kappa - E > 0`, then with `a_0 = 1 + tr D/2 - ||div w||_inf/2 - ||q||_inf`
  (`a_0 - a_s = 1 + tr D/2 - kappa + s ||Dw||_{inf,F} > 0`): `||A^{-1}||_{H^s -> H^s} <= (1/a_s)(1 + R/(a_0 - a_s))^s`,
  `A^{-1} = -int_0^inf S_A(t) dt`. Not a Neumann series (w.grad is unbounded on `H^s`). It solves an auxiliary problem
  only: it does not match outer data, and the localized rank-one strain term needs a certified
  `|1 + c[A^{-1} ell_delta]| > 0`.
- (S7) Exact residual identity [checked]. `d_y F(rho~)(P) = (mu_P - 1) g` (parity and `V(P) = 0`); at the trial's floating
  values `-6.70198e-7`. This is the identity behind the trial-centred jet exclusion of FINAL_REPORT section 7 (pending V22).
- Lead assessment. (S1)-(S5) give the local source piece of the linear hypothesis of T2N at order 3.1 with explicit
  constants, conditional on certified coefficient bounds on `B_{3 delta}(P)` (N8) and on an outer estimate in ordinary
  `H^s` with `b eps < 1`. It is not a global inverse, and the residual must still be small in `||tau eps~||_{H^s}` on
  `B_{9 delta/4}(P)` (floating, 0.5-disc: `H^{3.06}` about 1.2). Changes no verdict.

## 4. Target formulation F- (CONDITIONAL; the a posteriori theorem we would prove if the inverse were available)
- Ansatz `rho = rho~_{k', tau} + h`, where `rho~_{k',tau}` replaces the trial's tail `r^k Theta_0~` by
  `r^{k'} (Theta_0~ + tau Theta_1)` outside a fixed radius (smooth cutoff), `Theta_1` a fixed admissible angular
  profile (odd about theta = 0, vanishing at theta = pi/2). Unknowns `(h, k', tau)`.
- Spaces (v3.1: concrete proposal in notes/conormal_framework.md section 2.3): h has allowed growth
  `gamma_E < k - margin` at infinity; near P `H^{s_H}`, `3 < s_H < 3.406` (high) and
  `H^{s_H - 1}` (low); along the stable segment a conormal space carrying `x^{2j} |y|^{beta_j}`, j >= 3, with the
  `beta_2` coefficient absent; near 0 a factor norm with positive-power remainder (index1: continuous-factor centre
  norms admit infinite cokernels from log forcings); high regularity in the exit region near the y-axis (so exit traces
  are smooth enough for the one-scalar saddle count). Forcing: `Y_- (+) R`, the scalar being the coefficient of the
  `r^{k'} Theta` term (it equals `(c_l[rho] k' - 1)` times the tail amplitude).
- No J constraint (the tail amplitude fixes the scale); after solving, rescale by `a = J^{1/2}` to normalize.
- Formal count: R- transport injective; source 0 (frozen bijective below `s_fast`); saddle -1; `(k', far scalar)` 0;
  `tau` +1. Index 0 if the saddle functional is nonzero on the `tau`-direction. Unproved: the global Fredholm estimate
  (source localization, saddle transmission, nonlocal tails, compactness at infinity; realize1 C6) and K_H, K_L.
- T2N then applies on this complement (the inverse is unique on the chosen complement, so the identity
  `R_h - R_h' = -R_h (A_h - A_h') R_h'` used in T2N holds).
- Alternative R+ (+) span(eta) (one singular source mode): index 0 iff `l(L eta) != 0` (index1), but the nonlinear term
  `(Gamma eta).grad eta` is not in a high forcing space and moving layers are not differentiable in fixed
  `C^{2,alpha}`; not pursued. v3.7: at the frozen level one singular mode does not suffice (the cusp profile `F_f` is
  a function, pcusp1 C2), so this alternative is also unsupported as an index-0 realization.

## 5. T2N (VERIFIED as a conditional theorem, ver two_norm_scheme)
`A_h u = L u + (Gamma h).grad u`, `B(e, u) = (Gamma e).grad u`. Hypotheses: `||R_h f||_X <= K_H ||f||_{Y_H}`;
`||u||_E <= K_L ||A_h u||_{Y_L}`; `||B(e,u)||_{Y_L} <= C_B ||e||_E ||u||_X`; `||Gamma h||_V <= C_V ||h||_X`; ball closed in
E. Closing: `K_H eta <= r`, `K_L C_B K_H eta < 1`, `C_V r <= r_V`. Conclusion: unique h in the ball, `||h||_X <= K_H eta`,
`F(rho~ + h) = 0`. In F- the scalar unknowns `(k', tau)` are adjoined to X and E and the far scalar to Y.

## 6. Owners and tasks

### 6.1 num (priority order)
N1' (v3.9, priority below chains 4/5) certified bounded-region flow inequalities of 3.9 (src/cert_flow.py, chainN1):
    `T_0 <= -0.22` off the box, box inequalities, root of w with `w' > 0`; also `sup |rho~(0,y)|/y` (floating).
N7  centre-regular variant of the trial (floating first; v3.10: remove r^{2j} cos(2 m theta), m > j, j <= 4, needed by
    D_b, 3.12); if it exists, centre Taylor data of w up to x^9. Cost estimate first. P-disc refit (chainR) for H^{3.06}.
R0  Rigorous weighted residual by region (num middle rerun queued in chain5; the verifier's independent full middle
    pass is complete with one method, VERIFIED inner/exterior; whole-plane `N_0 < 1.904e-3`, FINAL_REPORT 6). Report `sup W/m`, the shell values, and
    `sup W/[m (1+u)^{gamma_Y - k}]` for `gamma_Y = 0` and `gamma_Y = k - 1/2` (the current multiplier `(1+u)^{1/2}`).
R1  `r^j grad^j eps~`, j = 1, 2 globally; R3 Taylor bounds of eps~ to order 4 on the disc `|X - P| < x_*/4`.
R5  `||eps~ - X.grad eps~||` and `||K~||` in the R0/R1 norms (for 3.8).
N8  (v3.17) certified (Arb) sup bounds on `B_{3 delta}(P)` of `||D^j V||_F`, `j <= 4`, and `||D^j rho~||_F`, `j <= 5`, for
    `delta in {0.0165, 0.05, 0.1, 0.2}` (floating first); report `M_V`, `M_rho` and `C_V = 41.7 M_V + 3 M_rho`
    against `kappa/(2 delta)` (3.15 S2, S4); also the floating `||tau eps~||_{H^{3.1}}` with tau = 1 on `B_{7 delta/4}`,
    support in `B_{9 delta/4}`, for the same delta.
RES Three resolutions (variants v3, v4, v5) through the same pipeline (section 6 of the report needs >= 3).
C2  (floating point, after R0) unchanged from v2: finite sections of L, two smallest singular values; add the F-
    columns (k', tau) if feasible.

### 6.2 ver
V1  Independent reproduction of S1 and R0 (ongoing).
V3' Audit of 3.7 (the realization table and the mixed-class formal kernel claim) and of the F- count in section 4;
    counterexamples welcome. (index1 and realize1 were single-model audits: Opus unavailable for both.)
V6  Audit of notes/conormal_framework.md (revision 2) sections 1.2, 1.3, 1.4, 2.1, 2.4 (exact local lemmas) and, with
    interval arithmetic where cheap, the axis facts of 4.1 (D1): `mu > 0` on the x-axis, `V_2(0,y) > 0`, a single zero
    of `w` on `(0, inf)`. Your axis-velocity machinery covers points; a full-axis statement needs a covering argument
    and the far-field expansion.
V7  Audit of notes/weighted_velocity.md revision 2 (Lemmas W1, W1': Taylor-modified velocity bounded on `L^2(|y|^{-2b})`,
    `N - 1/2 < b < N + 1/2`, explicit constants; edge coefficients in `dot H^{b-j-1/2}`). Elementary (partial Fourier,
    dilation, Hilbert-Schmidt/Schur); a rigorous evaluation of the constants `C_{3,b}`, `C'_{3,b}` is cheap.
V12 (v3.8: REVISION 2 of notes/yface_collar.md, 18:56Z) Audit: Lemma S (swap), the reduction of NF-Y to collar_coupling
    rev 2, the full-jet multiplier bounds of E-Y (E2-Y), the localized decomposition (1.2), the exact remainder (5.2) and
    the ranges (5.4). Do not use code/check_yface.py (2) as an accuracy check (its smoothing-jet quadrature is wrong by
    three orders, see rev 2 section 7).
V13 (v3.7) Independent check of the frozen cusp theorem of astra pcusp1 (3.3 C1-C3, C5): the conjugation, the
    exponents `s_fast, s_1, alpha_*, g/A`, the explicit `F_f != 0` example, the counterexample to the `f_y(P)` cokernel.
V14 (v3.8: notes/corner_coupling.md now exists, 18:59Z) Check of Lemma D (double remainder window, section 2), the
    trace criterion (T1) with its table and (T3) resonance, (K3), and section 5 (`J_c = 0`, `K_c`, `q_1, q_2, q_4`, the
    unit-box bound of `f_rem`, the degree-7 obstruction); code/corner/check_corner1.py, check_corner_q.py.
V16 (v3.9) J3-J7 of notes/global_flow.md section 12 and notes/pinf_B3.md sections 1-2 (A1, A3, A5, B1, B2, B4, B5),
    sanity check of C1. Topics 50-57 done (V14 = topics 51, 55-57; V15 = topics 52-54); middle second method running.
V17 (v3.10) astra prow1: (45)-(47) incl. the existence argument of (47); (1) with its regularity hypotheses;
    (31)-(33); (18), (21) (lowest).
V18 (v3.11) astra dib1 (astra/dib1/answer.md): (14)-(18) far exclusion and the c[h] obstruction; (23) `[x^2 y] L h = 0`;
    the identities (1), (8); (28)-(30) jet matching, jet rates, K not in the far space. Priority below V16(b), V17.
V19 (v3.12, low priority) elementary items of astra dib2 (SPEC 3.12 D1-D10; list in NOTES_FOR_TEAM 22:03Z).
V20 (v3.13, low priority) elementary items of astra dib3 (3.13 B1-B10): the H_n recurrence and `-Lap L_P H_n = 0`,
    the c[e_eps] scaling, `mu_P = 1` from C^1, the factorization example, the interpolation constant 1.
V21 (v3.16) astra holder1 (3.14 H1-H6): the dyadic upper bound, packet sharpness, the two order-1 logarithms.
V22 (v3.17) frrev1 corrections now in FINAL_REPORT: (a) the trial-centred jet exclusion of section 7 (identity S7, the
    bound `|d_y F(rho~ + h)(P) - (mu~ - 1) g| <= 30.0229 delta + 2 delta^2` in the four jet quantities and the radius about
    2.2e-8); (b) the normalized face-coupling coefficient `(2/3) c (2 G_1 - x G_1')` of 5(f); (c) the Dini non-necessity
    example; (d) `s_fast = 3.57855` wherever a threshold is stated.
V23 (v3.17) astra srcloc1 (3.15): S1 margin, S2 expansion and remainder constant T_s, the `E <= C_V delta` Taylor bounds,
    `C_U = 2 * 3^s`, the kernel and far bounds (17), (18), the strain bound (21), identity (26), the K_1 bookkeeping
    (28)-(34) incl. `D_s`; low priority: (45)-(46).
V5  Audit of the energy-symbol diagnostic (lead code/energy_symbol.py, runs/energy_s3.25_N*.json): formula and the
    reported values; floating point only.

### 6.3 lead
L2 Explicit C_B, C_V for the F- spaces at the frozen-source level (Sobolev products and the Riesz bound for U).
L3 Strongest linear statement: the verified frozen and local theorems plus the realization analysis (3.7).
L4 FINAL_REPORT.md.
L5 Edge/corner framework (notes/conormal_framework.md rev. 2): G1 x-face velocity remainder done (W1, W1'; VERIFIED
   V7); bounded-collar near/far splitting and coupling done (collar_coupling rev 2; AUDITED collar1; VERIFIED V10);
   y-face collar done (notes/yface_collar.md rev 2, AUDITED yface1 with repairs; V12); corner splitting from astra
   corner1 (notes/corner_coupling.md, V14: corner coefficients and double remainder VERIFIED, T2 traces open);
   global flow (3.9, VERIFIED conditional); P-row redundant (3.11, prow1, V17); design D_b (3.12, dib1 obstructions O1-O5, repair through F-); next the P-disc transition, the conic large-r collars, derivative versions, the
   edge problems G3; G5 conditional index reduction (notes/index_deformation.md, unaudited).

## Change log
- v1 2026-10-20T14:15Z: initial.
- v2 2026-10-20T14:57Z: same-order spaces; common power far weight; W[h] includes `(c[h]/3) X`; T2N adopted;
  thresholds from packets1; centre exponent corrected; source functional with `g' W_1`; index obstruction added.
- v2.1 2026-10-20T15:24Z: 3.2 corrected after the verifier's refutation; rule "both norms above threshold" withdrawn;
  realizations R+, R- added.
- v3 2026-10-20T15:53Z: realization table with the mixed class `P_2` (formal tail kernel) and the soft-`c_l`
  interpretation; F- target formulation (tail fixed, no J constraint, `(k', tau)` unknowns); saddle and far-field facts
  from realize1; J discontinuity in plain norms; frozen conjugation and homotopy-crossing facts; weight convention
  corrected; tasks V3', V5, RES added.
- v3.1 2026-10-20T16:38Z: weight exponent of the numerics multiplier corrected (`k - 1/2`); 3.5 corrected (the
  `1/|mu - 1|` cost is not a coupled-inverse bound; ver source_pole); 3.2 gains the uniform frozen inverse through
  `mu = 1` and the variable-coefficient Sobolev obstruction above threshold; 3.3 and 4 point to the edge/corner
  framework; tasks V6, L5.
- v3.2 2026-10-20T16:54Z: 3.3 rewritten after the astra conormal1 audit (framework revision 2: sufficient, not iff;
  false Sobolev inclusion replaced by `b > s` and the stronger corner weight; P disc a design choice; fixed-cutoff
  velocity splitting unbounded, frequency-adapted splitting proved in notes/weighted_velocity.md); task V7.
- v3.3 2026-10-20T17:14Z: astra weightedvel1 incorporated (notes/weighted_velocity.md revision 2): W1, W1' valid (constant `2^{|b|}`
  for `N = 0`, `b < 0`; W1' bounded for `-1/2 < b < N + 1/2`); homogeneous-trace qualification; the bounded-coupling
  claim of revision 1 section 4 withdrawn (counterexample); the global Hardy-type expectation false as worded; edge
  forcing gains `b - 3/2`. V7 now refers to revision 2.
- v3.4 2026-10-20T17:23Z: V6 and V7 CONFIRMED by ver (saddle model inverse, exit-trace sufficient condition, feasibility point;
  face splitting with constants; dilation obstruction). Ver V6 caveat recorded: for `a = 9/2 + nu`, `b = 5/2 + alpha` the
  arithmetic `delta < 0` coincides with the trace condition, but the generic `C^{4,nu}` remainder `|x|^{4+nu}` sits at the
  critical x-weight (log divergence), so a positive x-margin or a separate trace component is needed.
- v3.5 2026-10-20T18:01Z: tail family theory (notes/tail_family.md rev 2) VERIFIED as conditional statements by ver V8
  and AUDITED by astra family1; 3.7 no longer asserts that `c_l` moves along the family. Bounded-collar near/far
  splitting (notes/collar_coupling.md rev 2) after astra collar1 (CC repaired: finite strain hypothesis, Sobolev edge
  data, finite-regularity profile; (E3) restricted to `j < 3`; `x_1 > 2d`); ver V10 pending. Ver V9 CONFIRMED the
  isotropic saddle energy symbol with the scope correction that indefiniteness rules out coercivity in that pairing
  only. Ver topic39: complete coarse exterior residual majorant (`W/m < 5740483`).
- v3.6 2026-10-20T18:19Z: saddle conditioning bound `|delta| < 8.6507 - 21.3015 alpha` and the working parameters
  `alpha = 0.05`, `s = 3.06`, `b = 3.07`, `a = 6.45` (3.3); source cusp heuristic (3.3, astra pcusp1 pending); astra corner1
  (corner double Taylor splitting) pending; num asked for H^3/H^4 residual norms on the P-disc (R3 preview: high
  derivatives of eps~ near P are large).
- v3.7 2026-10-20T18:37Z: astra pcusp1 incorporated (3.3 C1-C5, AUDITED single model): frozen source cusp theorem
  (`C^{3,0.0293}` endpoint included, not `C^4`, smooth iff the cusp profile vanishes, infinitely many conditions);
  the coupled `f_y(P)` cokernel REFUTED; adapted coordinates needed for variable coefficients. Section 0, the R+ row of
  3.7, 3.7(b) and the R+ alternative of section 4: the "index -1" count is WITHDRAWN. G1 status: y-face collar note,
  astra corner1 (rectangular corner subtraction refuted globally; `J = 0`). Tasks V12-V14. Ver V10 CONFIRMED (collar
  lemma, FINAL_REPORT 5(i)); ver topic43 complete exterior certificate (`W/m < 9.4957e-5` on `r >= R_e`, FINAL_REPORT 6).
- v3.8 2026-10-20T19:01Z: pcusp wording restricted to local regularity at P (ver V13 refuted the inference to `P_2`/`P_3`
  membership); y-face note revision 2 after astra yface1 (NEEDS-FIX, repaired); notes/corner_coupling.md written with lead
  checks; V12 and V14 updated. Ver topic45: complete inner certificate (`W/m < 9.3285e-6` on `r <= e^{t_a}`, FINAL_REPORT 6).
- v3.9 2026-10-20T20:53Z: 3.9 global flow and pure transport (ver topics 52-54, constants corrected: 6.2 withdrawn);
  3.10 B_3 is a criterion only (pinf1); 3.11 axis jets J3-J7 and the P-row design decision (no jet splitting on the
  P-disc); V14 closed by topics 51 and 55 (double remainder constant < 4.725e17); verifier's full middle pass
  (one method) and whole-plane zeroth-order `N_0 < 1.904e-3`; tasks N1', N7, V16.
- v3.10 2026-10-20T21:19Z: 3.11 rewritten after astra prow1 (P-row implied by L h = f; scale-collapse obstruction of the
  strip/collar design, which is set aside; jet operators; Schur closure; uniform frozen window, 200/489 at 13/4;
  corner constraints); new 3.12 design D_b (y-axis jets only, |x|^{-2a}, flow weight) with floating rates and
  backward orbit costs, and its requirements on the trial (m > a + s - 1 at 0; P-disc refit); N7 extended; V17.
- v3.11 2026-10-20T21:32Z: 3.12 revised after astra dib1: weight sign e^{+phi} with a strict margin; direct-sum
  space; a = 6.0 (alpha away from the integers); identities (1), (8), (23) and the far exclusion (14) checked by the
  lead; obstructions O1-O5; repair route through the fixed-tail formulation F- (log-tail and tail-profile
  parameters); V18.
- v3.12 2026-10-20T21:58Z (O1 wording corrected 22:08Z): 3.12 extended with astra dib2 (D1-D10: unnormalized count 0 conditional; regularized a_4
  matching; tail jets; graph domain; far subtraction (11)-(12); source needs the nonlocal term; block closure;
  transversality ell(b) != 0 with a counterexample to the angular criterion; size estimate) and the a = 6.0 / 6.25
  rate tables; V18 extended.
- v3.13 2026-10-20T22:29Z: new 3.13 lower-order route (astra dib3 B1-B10, lead checks; the local bootstrap is false
  for the frozen operator; c unbounded on the unaugmented low space; centre condition fails at both orders for the
  present trial (m = 5); conditions L1-L4); lower-order residual norms and orbit costs; V19, V20.
- v3.14 2026-10-20T22:48Z: 3.12 D7 and 3.13 B1 VERIFIED (ver topic 68) and in FR 5(l). Band-restriction reading of the
  P-disc refits (NOTES 22:45Z; heuristic): band-supported corrections cannot cancel a transport residual, so the refits
  do not test convergence of X3 on its knots; FR section 10 item 4 reworded.
- v3.15 2026-10-20T23:15Z: 3.13 obstructions VERIFIED (ver topic 70) and in FR 5(n) and section 4; exact strain norm
  `1/(8 sqrt(pi(sigma-1)(sigma-2)))` on H^sigma (c = psi_xy(0)); weight window `s < (14A+3)/(4A+2)`. Hoelder question at P
  sent (astra holder1, notes/holder_heuristic.md).
- v3.16 2026-10-20T23:18Z: 3.10 and 3.11 status labels brought up to date (V16, V17 complete in ver topics 58-63).
  New 3.14 Hoelder scale at the source (astra holder1, AUDITED, lead checked): sharp loss `(sigma - 1)/A` in
  `C_*^sigma`, `1 < sigma < a`; endpoints; mixed Sobolev-near-P space not excluded; V21 requested.
- v3.17 2026-10-21T00:06Z: `s_fast = 3.57855` (3.2; "3.5786" is above it). New 3.15 local `H^{3.1}` a priori estimate at the
  source (astra srcloc1, AUDITED, lead checked): `K_1 = 1/(kappa - E)`, `E <= C_V delta`, outflow term intrinsic, outer
  estimate condition `b eps < 1`, auxiliary whole-plane inverse; tasks V21, V22 (frrev1 corrections), V23, N8.
