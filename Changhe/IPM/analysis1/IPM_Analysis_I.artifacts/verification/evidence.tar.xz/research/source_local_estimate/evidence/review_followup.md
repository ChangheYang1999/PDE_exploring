# Follow-up on the scaling and kernel review

This supplies the exact definitions omitted from the localization excerpt. The claimed correction to Q in the previous review appears false: 2-s=-1.1<0, so a positive constant IS O(delta^(2-s)) for 0<delta<=1. More importantly B_s is the improved multiplier in section3, not M_s=2^(s/2) W_s. For amplitude delta^a and uniform rescaled profiles, P_s is O(delta^(a-1)+delta^(a+1-s))=O(delta^(a+1-s)) since s>2. Thus B_s(q)=O(delta^(2-s)), and B_s(T)=O(delta^(1-s)); these recover the original K3. Please explicitly reconsider and either retract or give a valid counterexample with these actual definitions.

Additional kernel details: Delta psi=partial_x h, U=(partial_y psi,-partial_x psi). With G=(2pi)^(-1)log r, partial_xx G=delta_0/2+PV[(y^2-x^2)/(2pi r4)]; hence U2=-h/2+PV[(x^2-y^2)/(2pi r4)]*h. The original sign in K2 is correct. Raw sigma=(partial_xxy G*h)(0)=h_y(0)/2+PV(Ksigma*h)(0), where Ksigma=y(3x^2-y^2)/(pi r6). Its convolution value at0 evaluates Ksigma(-Y), but all estimates use the absolute value. The typo local term-rho will be corrected to-h. The phrase -proportional is not a claimed sign; replace it by the explicit +h_y(0)/2. No bound changes.

Closure scope will be tightened: only the graph completion of the displayed estimate for smooth admissible h is claimed, including N on differences, the local Ht norm, annular Hs norm, and ||tau Lh||Hs. This suffices to pass to the estimate. The two tail moments alone do not guarantee sigma continuity at0 on arbitrary Ht functions; the estimate18 does control it for this completion. No claim of density in an external domain is made.

Bibliographic mention at the end is unused and unverified; no external theorem is imported. Semigroup generation remains OPEN. The resulting local estimate is conditional on the box and E<kappa, not a full IPM inverse.

## 3. Explicit multiplication and transport commutators

For a compact coefficient f define

 W_r(f)=(2pi)^(-1) integral <k>^r |fhat(k)|dk,
 alpha_r=1/[2 sqrt(pi(r-1))], r>1,
 beta_r=1/[2 sqrt(pi(r-1)(r-2))], r>2,
 P_s(f)=s 2^(s-2)[W_1(f)+alpha_(s-1)||f||_(H^s)],
 B_s(f)=||f||_infinity+P_s(f), M_r(f)=2^(r/2)W_r(f).          (7)

Polar integration proves integral(1+|xi|^2)^(-r)d xi=pi/(r-1)
and integral|xi|^2(1+|xi|^2)^(-r)d xi=pi/[(r-1)(r-2)]. Cauchy-Schwarz
therefore gives (2pi)^(-1)||vhat||_1<=alpha_r||v||_(H^r),
and (2pi)^(-1)|| |xi|vhat||_1<=beta_r||v||_(H^r).

For s=3.1, the mean value theorem and the convex inequality
(a+b)^(s-1)<=2^(s-2)(a^(s-1)+b^(s-1)) give

 |<eta+k>^s-<eta>^s|
 <=s 2^(s-2)(|k|<eta>^(s-1)+|k|^s).

Apply the L1*L2 and L2*L1 forms of Young's inequality to the two terms,
including the (2pi)^(-1) convolution factor. This proves

 ||[J^s,f]v||_2<=P_s(f)||v||_(H^(s-1)),
 ||fv||_(H^s)<=||f||_infinity||v||_(H^s)
                      +P_s(f)||v||_(H^(s-1)),
 ||fv||_(H^r)<=M_r(f)||v||_(H^r), r>=0.                     (8)

The last bound uses <eta+k><=sqrt(2)<eta><k>. In particular B_s(f)
is a valid full H^s multiplier bound, because H^s controls H^(s-1).

To isolate the leading transport derivative, Taylor expand j_s=<eta>^s.
Its Hessian is s<eta>^(s-2)I+s(s-2)<eta>^(s-4) eta eta^T, with operator
norm at most s(s-1)<eta>^(s-2). Integral Taylor remainder and
<eta+vk><=<eta>+v|k| yield

 |j_s(eta+k)-j_s(eta)-Dj_s(eta).k|
 <=s(s-1)2^(s-4)|k|^2[<eta>^(s-2)+|k|^(s-2)].

Here integral_0^1(1-v)dv=1/2 and v^(s-2)<=1 explain the coefficient.
Multiplying by |eta_i| and using the two Young inequalities proves

 [J^s,w.grad]u=-s sum_(i,j)(partial_j w_i)partial_ij J^(s-2)u+Rw u,
 ||Rw u||_2<=T_s(w)||u||_(H^(s-1)),
 T_s(w)=s(s-1)2^(s-4) sum_i[W_2(w_i)+beta_(s-1)||w_i||_(H^s)]. (9)

The sign follows independently by the Fourier factor
(ik_j)(-eta_i eta_j) times -s. Moreover
sum_ij||partial_ij J^(s-2)u||_2^2<=||u||_(H^s)^2, so pointwise
Cauchy-Schwarz controls the leading term by s||Dw||_(infinity,F)||u||_(H^s).

All constants use finite derivatives. Indeed

 W_r(f)<=alpha_(n-r)||f||_(H^n), n-r>1,
 ||f||_(H^n)^2=sum_(|gamma|<=n) n!/[(n-|gamma|)!gamma!] ||D^gamma f||_2^2, (10)

by Cauchy-Schwarz and the multinomial expansion of(1+|xi|^2)^n.
Use support area and derivative suprema for the latter terms. Also
||f||_(H^s)<=||f||_(H^3)^(4-s)||f||_(H^4)^(s-3), with constant1 by Holder
in Fourier space. Coefficients w,q in compact C^4 have the required norms;
W2(w) uses H4, W1(q) uses H3, and Hs uses H4. The given rho C5 suffices.

## 4. Perturbed energy and its small coefficient

The transport part w.grad contributes -div w/2 after integrating the
principal term, and the commutator (9) contributes the remaining terms.
The vector U symbol has norm at most1. Apply (8) to each q_i U_i u, using
pointwise |q.U J^s u|<=|q| |U J^s u| for its leading term. Thus

 Re <Aop u,u>_(H^s)
 <=-(kappa-E)||u||_(H^s)^2+R||u||_(H^(s-1))||u||_(H^s),     (11)
 E=||div w||_infinity/2+s||Dw||_(infinity,F)+||q||_infinity,
 R=T_s(w)+sum_i P_s(q_i).                                   (12)

Write M_V=sup_B ||D²V||_F, M_rho=sup_B ||D²rho||_F,
C_theta=delta||grad theta||_infinity. Taylor's integral formula gives
|V-Dz|<=M_V|z|²/2 and ||DV-D||_F<=M_V|z|. Since div(V-Dz)=0,

 ||Dw||_(infinity,F)<=[3+(9/2)C_theta]M_V delta,
 ||div w||_infinity<=(9/2)C_theta M_V delta,
 ||q||_infinity<=3M_rho delta.

Consequently

 E<=C_V delta,
 C_V=[3s+(9/2)(s+1/2)C_theta]M_V+3M_rho.                   (13)

For C_theta=2 this is41.7 M_V+3M_rho. If delta<=kappa/(2C_V), then
(kappa-E)^(-1)<=1000/1687. At delta33/2000 the sufficient exact
threshold is C_V<=3374/33, approximately102.2424. Any actual use requires
certified coefficient bounds on that containing disc; none are supplied here.

## 8. Shrinking-cutoff scaling and the necessary outflow term

For fixed shapes, f_delta(X)=delta^p fshape((X-P)/delta), change Fourier
variables to obtain W_r(f_delta)<=delta^(p-r)W_r(fshape) and
||f_delta||Hr<=delta^(p+1-r)||fshape||Hr, fordelta<=1,r>=0.
The same conclusions hold for uniformly bounded shape families.
Taylor vanishing gives amplitudesw=O(delta²),q=O(delta),V=O(delta),ell=O(delta)
in local rescaled coordinates. T=V.grad chi has amplitudeO(1), whilea has
amplitudeO(1). The exact formulas above yield

 P_s(chi)=O(delta^(1-s)), R=O(delta^(2-s)), Q=O(delta^(2-s)),
 Z,C_chi=O(delta^(1-s)), W_s(chi)=O(delta^(-s)),
 d_A=O(delta^(1-s)), e_A=O(delta^(2-s)),
 d_H=O(delta^(3-3s)), e_H=O(delta^(2-2s)), f_H=O(delta^(1-s)),
 d_N,e_N=O(delta^(-3)), f_N=O(delta), J_delta=O(delta^(-s)).

Here boundedp>0 keeps C_c=O(delta); the ell terms are of lower size.
When E<=kappa/2 the denominators stay bounded. For s=3.1 the largest
allowed powers in(26) are therefore

 K2=O(delta^(3-2s)), K3=O(delta^(3-3s)), K4=O(delta^(-s-2)). (27)

Uniform shape hypotheses include the needed derivatives; one cannot deduce
(27) for arbitrary delta-dependent coefficients from pointwise amplitudes.

If a trajectory leaves a compact cutoff's support in finite forward time,
V.grad chi>=-epsilon chi is impossible at every point of that trajectory
starting wherechi>0. The scalar differential inequality implies
chi(Phi_t X)>=exp(-epsilon t)chi(X)>0 up to exit, a contradiction.
For a frozen fast-axis orbit crossing a factor-two annulus, elapsed time is
log2/A, so integration of its drop from1 to0 gives
sup|V.grad chi|>=A/log2. This last numerical constant is for the frozen
orbit; no perturbed-orbit comparison is certified here.

