# Global characteristic flow of the trial velocity, transport inverses and orbit weights (target T3 of the framework)

Lead note, revision 1, 2026-10-20T19:40Z. Status labels: [P] proof given here (lead), not yet independently checked;
[F] floating-point diagnostic (certifies nothing); [C] conditional on hypotheses that still need certification.
Nothing here is used in a conclusion of FINAL_REPORT.md until the verifier and an astra audit have checked it.

## 0. Summary
- (Lemma NT) [P] Assume the parity, C^1 regularity and linear growth of `V = c_l X + U[rho]`, and the four certifiable facts
  H1-H4 below: only two equilibria in the closed quadrant, sign conditions on the axes, the saddle and source
  linearizations, and outward radial drift beyond `R_0`. Then every orbit of the open quadrant `Q` comes from `P` and goes
  to infinity: `alpha(X) = {P}` and `|phi_t X| -> inf`.
- (Lemma U, flow box) [P] Each orbit of `Q` crosses a small circle `Sigma` around `P` exactly once, which gives
  `Q = Sigma x R` as a C^1 flow box. The time an orbit spends outside fixed neighbourhoods of `0`, `P` and infinity is
  bounded uniformly over `Q`, including orbits that hug the separatrices.
- (Lemma T) [P] `R_- f = -int_0^inf e^{-t} f o phi_t dt` inverts `V.grad - 1`. If a weight `m` satisfies `V.grad log m <= beta < 1`,
  then `||R_-||_{sup/m} <= 1/(1 - beta)`. In `L^2(w dX)`, using `div V = 2 c_l`, `||R_-|| <= 1/(1 + c_l - beta/2)` whenever
  `w(phi_{-t} Y) <= e^{beta t} w(Y)`. Uniqueness holds in both classes.
- (Lemma W, orbit weights) [P] For a reference weight `w_0` with margin `T_0 = -(1 + c_l) - (1/2) V.grad log w_0`, put
  `C_kappa = sup` over orbit segments of `int 2 (T_0 + kappa) dt`. If `C_kappa < inf`, then the weight `w_0 e^psi` with
  `0 <= psi <= C_kappa` has margin `<= -kappa`, and `||R_-||_{L^2_{w_0}} <= e^{C_kappa/2}/kappa`. By Lemma U, `C_kappa` is finite
  whenever `T_0 + kappa <= 0` near `0`, near `P` and near infinity.
- (Necessary margins) [P] The pointwise margins at the three ends are explicit. Corner: `-(1 + c_l) - aA + bD`. Source:
  `-(1 + c_l) + b mu`. Infinity: `-(1 + c_l) + gamma' c_l`. At the V11 point these are -6.652, -3.505 and -0.281
  (the last uses `c_l = 1/k`).
- [F] Conic weight `w_0 = |cos theta|^{-2a} |sin theta|^{-2b} M(r)`, where `-(1/2) r M'/M = mu(r)` interpolates from `A` to
  `gamma'` near `r = 6`. At the V11 parameters, `sup T_0 = 1.23` and `sup (T_0 + b+) = 1.80`. The maximal orbit-segment costs at
  `kappa = 1/4` are 0.155 (transport) and 0.292 (transport plus the zeroth-order coupling symbol). Hence, in floating point,
  `||R_-||_{L^2_{w_0}} <~ 4.3`, a bound set by the far-field margin. The naive composite weight
  `|x|^{-2a}|y|^{-2b}(1 + r^2/R_w^2)^{A - gamma'}` has `sup T_0` between 20 and 54 for every tested `R_w`, and orbit costs of
  about 12 (`R_w = 20`).
- (Coupling) [C] The zeroth-order coupling `U[h].grad rho` has principal symbol `(rho_x xi eta - rho_y xi^2)/|zeta|^2`, with
  maximum `b+ = (|grad rho| - rho_y)/2` over directions. A weight with `T + b+ <= -kappa` gives only a Garding-type
  estimate modulo a compact-type term. It does not give an explicit inverse. Section 6 lists the gaps.

## 1. Setting and hypotheses
`V = c_l X + U[rho]` on `R^2`, with `rho` the trial (or any background) even in x and odd in y. Then `V_1` is odd in x and
even in y, and `V_2` is even in x and odd in y. Hence `V_1(0, y) = 0` and `V_2(x, 0) = 0`: both axes are invariant, the four
open quadrants are invariant, and the reflections `(x, y) -> (-x, y)`, `(x, -y)` conjugate the flow. Also `div V = 2 c_l`
(`div U = 0`). Let `Q = {x > 0, y > 0}`, `P = (x_*, 0)` and `q(X) = |X - P|^2`. Standing assumptions:
- (H0) `V` is C^1 on `R^2` and `|V(X)| <= C_V (1 + |X|)`. Then the flow `phi_t` is global and C^1. Since `V_1/x` and `V_2/y`
  are continuous on `R^2` by parity and C^1, `DV` is diagonal on the axes.
- (H1) In the closed quadrant `Q-bar`, `V` vanishes only at `0` and `P`.
- (H2) `V_2(0, y) > 0` for `y > 0`. `V_1(x, 0) < 0` for `0 < x < x_*` and `V_1(x, 0) > 0` for `x > x_*`.
- (H3) `DV(0) = diag(-A, D)` with `A, D > 0`. `DV(P) = diag(A_P, mu_P)` with `A_P, mu_P > 0`. (At exact solutions
  `A_P = 2 c_l - mu_P` and `mu_P = 1`; for the trial, `mu~ - 1 = -2.25e-8`, SPEC 1.)
- (H4) `X.V(X) >= kappa_0 |X|^2` for `|X| >= R_0`, with some `kappa_0 > 0`.
For the trial, (H0) holds: `rho` is C^{4,1}, so `U` is C^{4,nu} locally, and `U = O(r^k)` at infinity. (H1)-(H4) are
floating-point facts at present (section 7). Their certification is request N1 to the numerics lane.

## 2. Lemma NT (non-trapping) [P]
Under (H0)-(H4), for every `X in Q`: `phi_t X in Q` for all `t`, `phi_t X -> P` as `t -> -inf`, and `|phi_t X| -> inf` as
`t -> +inf`.

Proof.
(a) Basic sets.
- `Q` is invariant because the axes are unions of orbits.
- On `|X| >= R_0`, `d/dt |X|^2 = 2 X.V >= 2 kappa_0 |X|^2`. So `N_inf := {|X| > R_0}` is forward invariant,
  `|phi_t X| >= e^{kappa_0 t} |X|` there for `t >= 0`, and `B-bar_{R_0}` is backward invariant. A backward orbit starting at
  `|X| > R_0` enters `B-bar_{R_0}` within time `log(|X|/R_0)/kappa_0`.
- By (H3), `V(Y) = DV(P)(Y - P) + o(|Y - P|)`, so `V.grad q = 2 (A_P (x - x_*)^2 + mu_P y^2) + o(q) >= m_P q` on
  `{0 < q <= delta}` for some `delta > 0`, where `m_P = min(A_P, mu_P)`.
- Consequently, for `0 < d <= delta`, no orbit enters `{q < d}` in forward time from `{q >= d}`. At a first entry time one
  would have `d/dt q <= 0` at `q = d`, contradicting `V.grad q > 0`. Also, a backward orbit in `{q <= delta}` satisfies
  `q(phi_{-s} Y) <= e^{-m_P s} q(Y)`.

(b) Stable and unstable sets of 0.
- By the stable manifold theorem for the hyperbolic saddle 0, there is a neighbourhood `N` of 0 in which
  `{Y in N : phi_t Y in N for all t >= 0}` is a C^1 graph `y = w_s(x)` over `|x| < eps`.
- The points `(x, 0)`, `|x| < eps`, have forward orbits in `N` that converge to 0. This uses (H2), the oddness of `V_1` in
  x, and invariance of the axis. So they lie in that set, and by the graph property `w_s = 0`.
- Hence any orbit with `phi_t Y -> 0` lies in the x-axis. Symmetrically, using (H2) for `V_2` and backward time, any orbit
  with `phi_{-t} Y -> 0` lies in the y-axis.
- So there is no orbit in `Q` converging to 0 in either time direction, and no homoclinic orbit at 0: the two axes meet
  only at 0.

(c) No periodic orbit in `Q-bar`.
- A periodic orbit meeting an axis would lie in that axis, where the flow is one-dimensional and has no periodic orbits.
- A periodic orbit in `Q` bounds a Jordan domain contained in the convex set `Q`, and that domain contains an equilibrium,
  contradicting (H1).

(d) Forward limit.
- Suppose the forward orbit of `X in Q` never meets `N_inf`. Then it stays in the compact set `K = Q-bar cap B-bar_{R_0}`, and
  `omega(X)` is nonempty, compact, connected, invariant and contained in `K`. It contains at most the two equilibria 0 and P.
- By the Poincare-Bendixson theorem, `omega(X)` is an equilibrium, a periodic orbit, or a union of equilibria and orbits
  whose alpha- and omega-limits are equilibria in `omega(X)`.
- `P` is not in `omega(X)`, since by (a) the forward orbit avoids `{q < min(q(X), delta)}`. So `omega(X) = {0}` or
  `omega(X)` contains a homoclinic orbit at 0, both excluded by (b). Periodic orbits are excluded by (c).
- Hence the orbit meets `N_inf` and `|phi_t X| -> inf`.

(e) Backward limit.
- By (a) we may assume the backward orbit lies in `K`, so `alpha(X)` is nonempty, compact, connected, invariant and in `K`.
- If `P in alpha(X)`, the backward orbit enters `{q < delta}` at some time and then `q -> 0` by (a), so `alpha(X) = {P}`.
- Otherwise the Poincare-Bendixson alternatives for `-V` reduce, as in (d), to `alpha(X) = {0}` or a homoclinic orbit at 0.
  Both are excluded by (b), and periodic orbits by (c). QED.

## 3. Lemma U (flow box and uniform transit) [P]
Fix `0 < eps_P <= sqrt(delta)` with `eps_P < x_*/2`, and let `Sigma = {q = eps_P^2} cap Q`, parametrized by
`sigma(t) = P + eps_P (cos t, sin t)`, `0 < t < pi`. Fix `eps_0 > 0` such that the box `B_0 = [0, eps_0]^2` is disjoint from
`{q <= eps_P^2}`, with `V_1/x <= -A/2` and `V_2/y >= D/2` on `B_0` (continuity at 0). Fix `R_1 >= R_0`. Put
`N_0 = [0, eps_0)^2`, `N_P = {q < eps_P^2}`, `N_inf = {|X| > R_1}` and `K' = Q-bar \ (N_0 cup N_P cup N_inf)`.

(i) Flow box.
- Every orbit of `Q` meets `Sigma` exactly once, transversally. It enters `N_P` in backward time by Lemma NT and leaves it
  in forward time. A second crossing would be a forward entry into `N_P`, excluded by 2(a).
- So `Phi : Sigma x R -> Q`, `Phi(sigma, t) = phi_t sigma`, is a bijective local C^1 diffeomorphism (transversality),
  hence a C^1 diffeomorphism, and the crossing time is C^1 on `Q`.

(ii) Uniform transit. `tau_* := sup over X in Q of |{t in R : phi_t X in K'}|` is finite.
Proof.
- For the orbit through `sigma(t)`, the time before the crossing is spent in `N_P`. Let `H(t)` be the time at which the orbit
  reaches the sphere `|X| = R_1`. The crossing is transversal (`X.V > 0`) and `N_inf` is forward invariant, so the time in
  `K'` is at most `H(t)`.
- `H` is finite (Lemma NT) and continuous on `(0, pi)` by continuous dependence and the implicit function theorem. So the
  transit time is bounded on compact subsets of `(0, pi)`.
- At `t = 0`: `sigma(0) = (x_* + eps_P, 0)` lies on the x-axis. By (H2) and (H4) its axis orbit reaches `|X| = R_1` at a
  finite time `H_0`, transversally, so `H` extends continuously to `t = 0` and is bounded near 0.
- At `t = pi`, entry: `sigma(pi) = (x_* - eps_P, 0)` flows along the x-axis and crosses the line `{x = eps_0}`
  transversally (`V_1 < 0`) at a finite time `t_1`. By continuous dependence, for `t` near `pi` the orbit of `sigma(t)` crosses
  `{x = eps_0}` at a time `<= t_1 + 1`, at a point `(eps_0, y_in)` with `0 < y_in -> 0` as `t -> pi`.
- Box passage: inside `B_0`, `x` decreases and `y` increases. So the orbit stays in `N_0` until it leaves through the top
  face, at a point `(x_out, eps_0)`, after a time `t_box >= log(eps_0/y_in)/sup_{B_0}(V_2/y)`. Since
  `x_out <= eps_0 e^{-A t_box/2}`, we get `x_out -> 0`.
- Exit: the y-axis orbit of `(0, eps_0)` reaches `|X| = R_1` at a finite time `H_1` by (H2) and (H4). By continuous
  dependence, the orbit of `(x_out, eps_0)` reaches it by time `H_1 + 1` once `x_out` is small.
- So the time in `K'` is at most `t_1 + H_1 + 2` for `t` near `pi`. Compactness of `[0, pi]` gives `tau_* < inf`. QED.

## 4. Transport inverse (Lemma T) [P]
Let `R_- f(X) = -int_0^inf e^{-t} f(phi_t X) dt`. Along orbits, `d/ds (R_- f)(phi_s X) = (R_- f)(phi_s X) + f(phi_s X)`, so
`(V.grad - 1) R_- f = f` in the sense of derivatives along the flow, and distributionally when the integral converges in
`L^1_loc`. `R_-` commutes with both reflections, so it preserves the parity class.
- (T-sup) If `m > 0` is C^1 with `V.grad log m <= beta < 1`, then `m(phi_t X) <= e^{beta t} m(X)`, so
  `|R_- f| <= ||f/m||_inf m/(1 - beta)`. If `(V.grad - 1) u = 0` with `u/m` bounded, then `u(phi_t X) = e^t u(X)` and
  `|u(X)| <= C e^{(beta - 1) t} m(X) -> 0`. So the inverse is unique in this class.
- (T-L2) All `L^2` statements are on the open quadrant `Q`. The axes are null sets and the parity class is determined by the
  restriction to `Q`. The weights of interest (e.g. `|x|^{-2a}` with `a >= 1/2`) are not locally integrable across the
  axes, but they are locally bounded above and below on `Q`, so `L^2_w(Q)` is contained in `L^2_loc(Q)` and distributions are
  taken on `Q`. Let `||f||_w^2 = int_Q |f|^2 w dX` and suppose `w(phi_{-t} Y) <= e^{beta t} w(Y)` for all `t >= 0` and a.e. `Y`. For
  C^1 `w` this is implied by `-V.grad log w <= beta`. The flow has Jacobian `det D phi_{-t} = e^{-2 c_l t}`, since
  `div V = 2 c_l`. So `||f o phi_t||_w^2 = int |f(Y)|^2 w(phi_{-t} Y) e^{-2 c_l t} dY <= e^{(beta - 2 c_l) t} ||f||_w^2`. Minkowski's
  inequality gives `||R_- f||_w <= ||f||_w/(1 + c_l - beta/2)` when `1 + c_l - beta/2 > 0`.
- Uniqueness in `L^2_w`: in the flow-box coordinates of Lemma U (and the axes, a null set), distributional solutions of
  `(V.grad - 1) u = 0` are `e^t g(sigma)`. So `u = e^{-t} u o phi_t`, and `||u||_w <= e^{-(1 + c_l - beta/2) t} ||u||_w -> 0`.
- Hence `V.grad - 1` is a bijection from its maximal domain in `L^2_w` onto `L^2_w`, with inverse `R_-`.
- Unweighted, `beta = 0` and the bound is `1/(1 + c_l) = 0.1521`. In terms of the pointwise margin
  `T_w := -(1 + c_l) - (1/2) V.grad log w`, the condition `T_w <= -kappa` gives `||R_-||_{L^2_w} <= 1/kappa`.
- On an L^2 weight the energy identity is the same statement: for `h in C_c^inf(Q)`,
  `Re <(V.grad - 1) h, h>_w = int T_w |h|^2 w dX`, from `int (V.grad h) h w = -(1/2) int |h|^2 (2 c_l + V.grad log w) w`.

## 5. Orbit weights (Lemma W) [P]
Let `w_0 > 0` be C^1 on `Q`, `T_0 = -(1 + c_l) - (1/2) V.grad log w_0`, `kappa > 0`, and
`C_kappa = sup over X in Q, t_1 <= t_2 of int_{t_1}^{t_2} 2 (T_0 + kappa)(phi_s X) ds`, the maximal orbit-segment cost.
If `C_kappa < inf`, put `psi(X) = sup_{s >= 0} int_{-s}^0 2 (T_0 + kappa)(phi_tau X) dtau`. Then:
- `psi` is lower semicontinuous and `0 <= psi <= C_kappa`.
- `psi(phi_t X) >= psi(X) + int_0^t 2 (T_0 + kappa)(phi_tau X) dtau` for `t >= 0`. Write the defining supremum for
  `phi_t X` with `s = s' + t` and take the supremum over `s'`.
- `w = w_0 e^psi` satisfies `log w(phi_{-t} Y) - log w(Y) <= 2 (1 + c_l - kappa) t`. The `w_0` part contributes
  `int_0^t 2 (T_0 + 1 + c_l)(phi_{-s} Y) ds`, and the `psi` part at most `-int_0^t 2 (T_0 + kappa)(phi_{-s} Y) ds`.
- Hence `||R_-||_{L^2_w} <= 1/kappa` by (T-L2) with `beta = 2 (1 + c_l - kappa)`. Since `w_0 <= w <= e^{C_kappa} w_0`,
  `||R_- f||_{w_0} <= e^{C_kappa/2} ||f||_{w_0}/kappa`.
The sup-norm analogue is the same with `V.grad log m - 1` in place of `2 T_0` and `m e^{-psi}` in place of `w_0 e^psi`.

Finiteness. If `sup_Q T_0 < inf` and `T_0 + kappa <= 0` on `(N_0 cup N_P cup N_inf) cap Q` for some admissible choice of
`eps_0`, `eps_P` and `R_1` in Lemma U, then `C_kappa <= 2 tau_* sup_Q (T_0 + kappa)^+`. The integrand is nonpositive outside
`K'`, and the time in `K'` is at most `tau_*`. Strict margins at the three ends therefore suffice, provided `T_0` extends
continuously to the axes near 0 and P. The two-sided limits at the corner exist for the weights below.

Necessary values at the ends [P], for the conic weight of section 7. The product weight `|x|^{-2a}|y|^{-2b}` has the same
values at the corner and at P, and the composite weight has the same values at all three ends:
- at the corner (`V_1/x -> -A`, `V_2/y -> D`, `mu = A`): `T_0(0) = -(1 + c_l) - a A + b D`. This is `delta` of V11:
  -6.652 at (6.45, 3.07).
- at P (`V = 0`, `V_1/x = 0`, `V_2/y = mu_P`): `T_0(P) = -(1 + c_l) + b mu_P`, which is -3.505 at `b = 3.07`, `mu_P = 1`.
- at infinity (`V = c_l X + O(r^k)`, `c_l = 1/k`, angular terms `O(r^{k-1})`): `T_0 -> -(1 + c_l) + gamma' c_l =
  -(1 + k - gamma')/k`, which is -0.2808 at `gamma' = 1129/1000`. This requires `gamma' < 1 + k` (T4) and caps
  `kappa < 0.2808`. Heuristic (not proved here): in the dilation model `c_l r d_r - 1` on `L^2(r^{1 - 2 gamma'} dr)` the
  spectrum lies on the line `Re = c_l (gamma' - 1) - 1 = -0.2808`. Approximate eigenfunctions supported far out then suggest
  `||R_-||_{L^2_{w_0}} >= 1/0.2808 = 3.56` for every weight with this tail.

## 6. Coupling at zeroth order [C]
`L h = (V.grad - 1) h + U[h].grad rho + (c[h]/3) X.grad rho`. The multipliers of `U_1, U_2` are `xi eta/|zeta|^2`,
`-xi^2/|zeta|^2`, so `U[h].grad rho` has principal symbol `b(X, zeta) = (rho_x xi eta - rho_y xi^2)/|zeta|^2`. With
`zeta = (cos phi, sin phi)`, `b = (rho_x/2) sin 2 phi - (rho_y/2)(1 + cos 2 phi)`, so `max_phi b = b+ := (|grad rho| - rho_y)/2`
(exact). Frozen at P, `b` is `-g` times the symbol of `M`, which is `<= 0`. The zeroth-order energy symbol with weight `w` is
`E_w = T_w + b+`. A weight with `E_w <= -kappa` (Lemma W applied to `E_0 = T_0 + b+`) would give, by a sharp Garding inequality,
`Re <L h, h>_w <= -(kappa - eps) ||h||_w^2 + (compact-type term)`. This is NOT an inverse estimate. The gaps are:
- (i) In the corner the coupling must be applied to the double Taylor remainder (Lemma D, notes/corner_coupling.md),
  because `|x|^{-2a}|y|^{-2b}` with `a = 6.45` is not an `A_2` weight and the Riesz transforms are unbounded on it. The Taylor
  projections do not commute with `V.grad` beyond the linear part, so the margin of the remainder system is not `T_w`
  alone.
- (ii) Garding remainders are compact only locally. The explicit low-frequency and far-field control needs a separate
  argument.
- (iii) The strain functional `c[h]` is bounded on the composite weight (corner_coupling K4: `A > 2`, `gamma' < 2`), but
  `X.grad rho ~ x^2 y` is not in `L^2_{a,b}` near 0 for `a > 5/2`. The strain term lives in the jet part of the split space.
- (iv) The trial's residual is not in the corner product-weight `L^2` for `A >= 6` (verified centre obstruction, topic 50 of
  the verification record). The forcing space or the trial's centre representation must change before any of this applies
  to the actual residual.
So the zeroth-order computation shows only that no principal-symbol obstruction exists at the `L^2` level for these weights.
It does not give a closing estimate.

## 7. Floating diagnostics [F] (grids 1500 x 128; key numbers repeated on 3000 x 256)
| check | script / output | result |
|---|---|---|
| zeros of `V` in `Q` | code/vzeros.py, runs/vzeros_N1500.json | no interior local minimum of `|V|/r` on `r in [1e-3, 1e5]`, `|X - P| > 0.5`; global min `0.079` at `(8.57, 0.061)` (next to P) |
| (H4) | same | `min X.V/r^2` by band: `[20,100]` 3.53, `[100,1e3]` 5.18, `[1e3,1e5]` 5.52 (negative below 20) |
| `b+` | code/energy_s0.py, runs/energy_s0_N1500.json | `max b+ = 10.14` at `(r, theta) = (12.59, 1.240)`; `{b+ > 1 + c_l}` within `r in [5.5, 51.7]`, `theta in [0.785, 1.485]`; `b+ = 0` on the axes |
| unweighted energy costs | energy_s0 (forward), energy_s0_back (backward) | `max int 2 (b+ - 1 - c_l + kappa)^+ = 1.06, 1.32, 1.61, 2.27` for `kappa = 0, 0.5, 1, 2` |
| naive composite weight | code/transport_margin.py, code/orbit_costs.py | `sup T_0 = 53.8, 20.2, 46.5, 53.3` for `R_w = 1, 20, 60, 200`; costs about 12 at `R_w = 20` |
| conic weight, `R_m = 6`, `p = 4` | code/conic_weight.py, runs/conic_Rm6_p4.json | `sup T_0 = 1.225` (1.226 at 3000 x 256), `sup E_0 = 1.798` (same); maximal segment costs (`kappa = 0, 0.1, 0.2, 0.25`): `T_0`: 0.116, 0.131, 0.147, 0.155; `E_0`: 0.235, 0.257, 0.280, 0.292; all 60 backward orbits from `r = 1e5` reach P |
The conic weight is `w_0 = |cos theta|^{-2a} |sin theta|^{-2b} M(r)`, where `-(1/2) r M'/M = mu(r) = gamma' + (A - gamma')/(1 + (r/R_m)^p)`. It
equals `|x|^{-2a}|y|^{-2b}` times a factor tending to 1 as `r -> 0`, and is asymptotic to the composite weight at infinity.
Margin formula, with `s = X.V/r^2`: `T_0 = -(1 + c_l) + a (V_1/x - s) + b (V_2/y - s) + mu(r) s`.
The positive parts of `T_0` sit near the x-axis segment `x in [4.9, 6]` (`T_0 <= 1.23`). The positive parts of `E_0` sit near
`(6.1, 0.39 rad)`. Both are crossed in bounded time.
Reading: with `kappa = 1/4`, `||R_-||_{L^2_{w_0}} <= e^{0.078} * 4 = 4.3` (floating), dominated by the far margin 0.281. The
radial transition of `mu` must sit at `r ~ 6`. A transition near `r ~ 3` is required along the y-axis and one near `r ~ 14`
along the outgoing x-axis. The orbit correction `psi` reconciles the two at small cost.

## 8. What certification needs (requests)
- N1 (numerics lane): certified versions of (H1)-(H4) for the trial velocity. These are: zero exclusion in
  `Q-bar cap B-bar_{R_0}` outside small disks at 0 and P, with Krawczyk or linearization inside the disks; the axis signs
  (H2); `X.V >= kappa_0 |X|^2` for `|X| >= R_0` with explicit `R_0` (about 20); and enclosures of `DV(0)` and `DV(P)`. The far
  field (H4) beyond the computed region follows from the certified tail bounds for `U`.
- N1b: certified `sup T_0` and `sup E_0` for the conic weight on `Q`, and a certified upper bound for `tau_*` (Lemma U) or,
  better, for the segment costs `C_kappa`. A crude version suffices: certified sup bounds on cells plus certified exit times
  through cell faces.
- Verifier: reproduce N1, audit Lemmas NT, U, T and W.

## 9. Lead checks
- The margin values at the three ends were checked against code/conic_weight.py on two grids: corner -6.652, far field
  -0.281 (from below).
- The value at P was checked by hand: `-(1 + c_l) + b = -3.505`.
- The formula for `b+` was checked by hand.
- The energy identity in section 4 was checked by direct integration by parts.
- Not checked: the Poincare-Bendixson case analysis by an independent reader; the continuity of `H` at the endpoint in
  Lemma U (relies on continuous dependence up to the axis, which holds since the axis points are regular points of `V`).
