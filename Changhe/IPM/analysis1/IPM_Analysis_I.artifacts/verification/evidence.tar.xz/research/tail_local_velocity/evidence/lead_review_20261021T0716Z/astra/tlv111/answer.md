**Claims 1–4 are VALID. Claims 5–6 are VALID WITH REPAIR.** I found one false supporting assertion: the base density is not \(C^6\) at the origin. Its explicit construction gives \(C^4\), which suffices for the claimed residual convergence. The numerical conclusions survive unchanged.

I read all requested files, including topic 76 and its addendum. Fresh arithmetic checks passed, as did all 186 distinct dependency hashes. The previously certified angular norm and canonical source integration remain dependencies; I did not repeat those full computations.

**1. Fourier coefficient, canonical Green formula and integration by parts: VALID.**

Using
\[
\partial_x=\cos\theta\,\partial_r-\frac{\sin\theta}{r}\partial_\theta
\]
on \(D_j(r)\sin((2j+1)\theta)\) gives precisely
\[
f_n=\frac{D'_{n-1}+D'_n}{2}
-\frac{(2n-1)D_{n-1}-(2n+1)D_n}{2r}.
\]

For \(-\Delta\psi=\partial_xq\), the canonical radial formula is
\[
\psi_n(r)=\frac1{4n}\left[
r^{-2n}\int_0^r s^{2n+1}f_n(s)\,ds+
r^{2n}\int_r^\infty s^{1-2n}f_n(s)\,ds
\right].
\]
It has the correct sign for \(-\Delta\). Regularity at zero and the canonical condition at infinity fix the homogeneous terms. Parity excludes a zero angular mode.

On \(r<1\), the first integral vanishes. For the actual cutoff tails,
\[
D_j(1)=0,\qquad
s^{1-2n}D_j(s)=O(s^{a+1-2n})\longrightarrow0
\]
because \(a<1\) and \(n\ge1\). Their differentiated tails also give absolute convergence. The joins introduce no boundary contributions.

Consequently,
\[
\int_1^\infty s^{1-2n}D'_j(s)\,ds
=(2n-1)\int_1^\infty s^{-2n}D_j(s)\,ds.
\]
The coefficients after substitution are exactly
\[
\frac{2n-1}{2}-\frac{2n-1}{2}=0
\quad\text{for }D_{n-1},
\]
and
\[
\frac{2n-1}{2}+\frac{2n+1}{2}=2n
\quad\text{for }D_n.
\]
Thus
\[
\boxed{\psi_n(r)=\frac{r^{2n}}2
\int_1^\infty s^{-2n}D_n(s)\,ds.}
\]
There is no missing endpoint term or factor.

**2. Compensator and cubic interior velocity: VALID.**

The qualification **interior** matters. Differentiating the compensator can produce a \(\sin4\theta\) forcing, but its contribution to the corresponding interior stream coefficient cancels by the identity above.

Indeed,
\[
\cos^2\theta\sin\theta=\frac{\sin\theta+\sin3\theta}{4},
\]
so the compensator has only \(D_0,D_1\). Formula (6) therefore lets it change only the \(n=1\) interior coefficient.

Writing
\[
A=\int_T^\infty s^{-2}D_1(s)\,ds,
\]
that stream term is
\[
\frac A2\operatorname{Im}(x+iy)^2=Axy.
\]
Its strain is exactly \(A\). All higher interior harmonics have zero strain at zero. Hence exact strain compensation removes the entire quadratic stream term.

The remaining velocity terms have the stated signs:
\[
n h_nJ_{a,n}T^{a-2n+1}
\left(-\operatorname{Re}(x+iy)^{2n-1},
       \operatorname{Im}(x+iy)^{2n-1}\right),\qquad n\ge2.
\]
Cubic is the **first possible** order; a nonzero cubic coefficient is not established or needed.

**3. Scaling, derivative estimates and constants: VALID.**

The substitution \(s=Tt\) gives
\[
\int_T^\infty s^{-2n}\chi(s/T)s^a\,ds
=T^{a-2n+1}J_{a,n}.
\]
The compensator has the same density scaling \(T^a\).

For \(|\alpha|=j\le3\),
\[
\partial^\alpha z^{2n-1}
=i^{\alpha_y}(2n-1)_jz^{2n-1-j}.
\]
Factoring \(R^{3-j}T^{a-3}\) leaves
\[
(R/T)^{2n-4}\le4^{2-n},
\]
which proves (10).

Both further inequalities are correct:
\[
\frac{n}{2n-\beta-1}\le\frac2{3-\beta}
\iff(\beta+1)(n-2)\ge0,
\]
and
\[
|h_n|
=\left|\frac1\pi\int_0^{2\pi}H(\theta)\sin((2n+1)\theta)\,d\theta\right|
\le2\|H\|_\infty<2N.
\]

The exact sums and recomputed constants are:

| \(j\) | \(S_j\) | \(C_j\), approximately |
|---|---:|---:|
| 0 | \(4/3\) | \(56.21412400010233277\) |
| 1 | \(44/9\) | \(206.11845466704188683\) |
| 2 | \(416/27\) | \(649.58543289007140093\) |
| 3 | \(1312/27\) | \(2048.69251911484057216\) |

All four proposed strict ceilings hold by exact rational comparison. These are individual component and derivative bounds; no vector or tensor norm factor is silently included.

**4. Numerical specialization and source consequence: VALID.**

Fresh Arb384 and mpmath.iv100 calculations independently verified
\[
9^3C_0\,3000^{\beta-3}
=8.941380733654130419\ldots\times10^{-9},
\]
\[
9^2C_1\,3000^{\beta-3}
=3.642784743340571652\ldots\times10^{-9}.
\]
Therefore both claimed strict upper bounds hold. These numbers are **majorants**, not computed values of the actual jets.

I also checked
\[
3412.96685816156<R_b<3412.96685816157,
\qquad p\approx8.6000638051571783<9.
\]
Since \(\beta-3<0\), the majorants decrease with \(T\).

The topic-76 identity is applied correctly. Exact compensation gives \(\sigma[h_T]=0\), so its normalized increment
\[
W[h_T]=U[h_T]+\frac{\sigma[h_T]}3X
\]
equals \(U[h_T]\), and the normalized scalar remains \(c_0\).

Separately, \(p<T\) and \(h_T\equiv0\) near \(P\) give
\[
z=h_y(P)=0,\qquad v=h_{xy}(P)=0.
\]
These local vanishings do **not** imply zero strain; the exact moment compensation supplies that fact.

Direct differentiation at the original source yields
\[
\partial_yF(\rho_T,c_0)(P)
=(\mu-1)g+g\,w+g'u.
\]
The perturbed velocity need not have a source at \(P\).

The original source endpoints verify \(D>6.70197\times10^{-7}\) and \(C<30.0230\). The displayed conservative subtraction is exactly
\[
6.70197\times10^{-7}
-30.0230\times10^{-8}-2\times10^{-16}
=\boxed{3.699669998\times10^{-7}}
>3.69\times10^{-7}.
\]
The quadratic allowance is unnecessary but harmless. Using the separate jet bounds and individual certified source coefficients even gives
\[
|\partial_yF(\rho_T,c_0)(P)|>5.59382\times10^{-7}.
\]

**5. Higher-tail convergence: VALID WITH REPAIR.**

The velocity argument is valid unchanged. The three exponents are
\[
\beta,\quad 3k-2,\quad k-2,
\]
all below \(1\), with \(\beta\) largest. The summed compensator decomposes exactly into the three individual compensators. Adding their finite estimates gives
\[
U[h_T]=O(T^{\beta-3})=O(T^{2k-4})
\quad\text{in }C^3(K)
\]
for every fixed compact \(K\).

The flaw is the [assertion that the base density is locally \(C^6\)](verification/research/tail_local_velocity/PROOF.md:135). This is false at the origin for the actual input.

The inner formula has the form
\[
\rho_0=x^2y+\sum_{j=1}^7r^{2j+3}A_j(\theta)
+r^{b_i+3}\sum_{\ell=0}^6(\log(r/R_-))^\ell B_\ell(\theta),
\qquad b_i>4,
\]
with smooth finite angular functions.

There is a concrete obstruction to \(C^5\): both the exact JSON and original NPZ give
\[
D_{259,1}=\frac{6648046164061931}{2^{113}}\ne0.
\]
The degree-five term consequently contains
\[
\frac{D_{259,1}}{8R_-^2}\,r^5\sin(521\theta).
\]
No lower input angular mode can cancel that frequency. A degree-five Cartesian polynomial has no angular frequency above five. If \(\rho_0\) were \(C^5\), its fifth-order Taylor term would have to equal this leading homogeneous correction, which is impossible.

The repair is straightforward: the same inner formula proves
\[
\rho_0\in C^4_{\mathrm{loc}}.
\]
Through derivative order four, the nonpolynomial degree-five terms are \(O(r^{5-j})\), with continuous extensions at zero; the other terms decay faster. Away from zero, the existing joins are \(C^6\).

On \(K\), for sufficiently large \(T\),
\[
F(\rho_T,c_0)-F(\rho_0,c_0)=U[h_T]\cdot\nabla\rho_0.
\]
The product rule only needs \(\rho_0\in C^3(K)\) to bound this difference in \(C^2(K)\). The repaired regularity supplies that, and canonical local velocity regularity ensures the residuals themselves are \(C^2\). Thus the claimed convergence holds, also at rate \(O(T^{2k-4})\).

**6. Overstatement and scope: VALID WITH REPAIR.**

Replace the false \(C^6_{\mathrm{loc}}\) sentence with the explicit \(C^4_{\mathrm{loc}}\) argument above. I found no further overstatement in the requested local-control conclusions. The restrictions to individual derivatives, the specified single-tail family, and unevaluated higher-tail constants are appropriate. No neighborhood exclusion, small global residual, inverse estimate, or stationary existence conclusion follows.

The standalone argument and verification evidence are saved in [the referee report](analysis/astra/tlv111/local_velocity_referee/PROOF.md) and [completed audit](analysis/astra/tlv111/local_velocity_referee/ADDENDUM.md).

A fresh request specifically selected Claude Opus 5.5, but the configured Bedrock credentials could not be retrieved before invocation. No model response or collaborative acceptance was obtained; no substitute was used.