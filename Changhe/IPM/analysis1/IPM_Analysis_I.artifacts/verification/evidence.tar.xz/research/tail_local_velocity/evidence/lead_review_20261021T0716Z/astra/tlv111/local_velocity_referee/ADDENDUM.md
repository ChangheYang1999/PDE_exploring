# Completed independent referee audit

Read with the proof-first PROOF.md. The pending scalar checks there have
now passed. The result is an informal mathematical verification with the
explicit upstream certificate dependencies, not a formally verified proof.

| Requested claim | Verdict |
|---|---|
| 1. Fourier coefficient, Green formula, integration by parts | VALID |
| 2. Interior harmonic compensation and cubic velocity order | VALID |
| 3. Scaling, derivative estimate, sums and constant ceilings | VALID |
| 4. Finite-radius jets and source-residual consequence | VALID |
| 5. Higher-tail local velocity and residual convergence | VALID WITH REPAIR |
| 6. Scope and overstatement audit | VALID WITH REPAIR |

The specific repair is to PROOF.md line 135 of the reviewed topic:
“The base density is C6 locally” is false at zero. The modal joins away
from zero are C6, but the actual degree-five angular term has nonzero
frequency 521. Its coefficient is D_(259,1)/(8 R_-^2), with the nonzero
exact input D_(259,1)=0x1.79e5cde0f2eebp-61. This was checked in both
the exact JSON and the original NPZ archive. The density is not C5 at
zero. PROOF.md here supplies a standalone proof of C4 regularity, which
is sufficient for the C2 residual convergence by the product rule.
No quantitative theorem or claimed decay rate needs to change.

The fresh exact sums are

    S=(4/3,44/9,416/27,1312/27).

The exact rational C_j have approximate values

    C0 = 56.2141240001023327727914218005575...
    C1 = 206.118454667041886833568546602044...
    C2 = 649.585432890071400930034207473109...
    C3 = 2048.69251911484057216395403895365...

All four requested strict ceilings hold by rational comparison.
Arb384 and mpmath.iv100 separately give strict enclosures

    8.94138073365e-9
      < 9^3 C0 3000^(beta-3) < 8.94138073366e-9,
    3.64278474334e-9
      < 9^2 C1 3000^(beta-3) < 3.64278474335e-9,
    3412.96685816156 < R_b < 3412.96685816157.

These intervals enclose the majorants; they are not lower bounds on
the actual velocity jets. The exact source satisfies
p approximately 8.6000638051571783 and p<9. Direct rational arithmetic on the
original source output gives D>6.70197e-7 and C<30.0230.
The published conservative subtraction is exactly

    6.70197e-7 -30.0230e-8 -2e-16 =3.699669998e-7.

Because the density perturbation jets vanish exactly, one may omit
the final subtraction of 2e-16. Using the separate velocity bounds
and the individual original source jets gives the stronger rigorous
lower bound >5.59382e-7, although the requested >3.69e-7 already follows
from the conservative calculation.

The audit checked 42, 98 and 146 file pins in the three dependency
verdicts, amounting to 186 distinct pins including the verdict files.
All matched. It checked the exact original k, tplus and the regularity
witness against the NPZ archive, the original root certificate's
endpoint signs and derivative sign, and the source endpoint arithmetic.
Exact mixed-derivative polynomial checks complement the general
analytic proof. No original full canonical integration or angular-norm
calculation was rerun; those remain the stated previously verified
dependencies. Complete new numerical evidence is in evidence/checks.json.

A fresh collaboration request specifically selected
us.anthropic.claude-opus-5-5 through the existing Bedrock configuration.
Credential retrieval failed for the configured cline-profile before
model invocation. No actual model response was obtained and no
substitute was used. The request and availability metadata are saved in
evidence/opus_request.txt and evidence/opus_metadata.json. This independent
referee verdict does not claim collaborative acceptance.

All writes and computations for this review stayed in the referee's own
folder. Computations were single threaded with a 1.5 GiB address-space
limit. No JavaScript/TypeScript, servers, GPU, or RLScience cluster were used.
