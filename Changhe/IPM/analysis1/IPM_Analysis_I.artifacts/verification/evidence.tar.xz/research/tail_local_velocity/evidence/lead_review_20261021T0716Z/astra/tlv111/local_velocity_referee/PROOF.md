# Referee argument for the local velocity estimate

This is an independent informal derivation, written before this referee's
scalar recomputation. The supplied source-jet and angular-norm certificates
are dependencies; the full original canonical numerical integration is not
repeated here. Numerical comparisons remain pending until check.py passes.

## Exact statement and hypotheses

Let U[q]=(-psi_y,psi_x), where -Delta psi=q_x is the canonical whole-plane
inverse with no added harmonic polynomial. Assume q is even in x, odd in y.
Use the finite angular functions, compact bump b and transition chi of
topics 105 and 106, including their addenda. In particular 0<=chi<=1,
chi=0 on [0,1], chi=1 on [2,infinity), and
b(s)=(s-1)^8(2-s)^8 on (1,2), zero otherwise. Put
J_b=integral_1^2 s b(s) ds>0.

For a<1 and a finite odd-sine polynomial
H(theta)=sum_{j>=0} h_j sin((2j+1)theta), define

    J_(a,n)=integral_1^infinity chi(s)s^(a-2n) ds, n>=1,
    h_T=chi(r/T)r^a H(theta)
        -[4 h_1 J_(a,1) T^(a-3)/J_b] x^2 y b(r/T).

Then h_T vanishes on r<=T and has exactly zero canonical strain.
For R>0, 2R<=T, 0<=j<=3, every Cartesian multiindex alpha of order j
and every velocity component i satisfy

    sup_(|X|<=R) |partial^alpha U[h_T]_i(X)|
      <= K_j(a,H) R^(3-j) T^(a-3),
    K_j(a,H)
      =sum_(n>=2) n |h_n| (2n-1)_j 4^(2-n)/(2n-a-1).

All sums involving the actual angular coefficients are finite.
For the single tail, k=1615536043799051/2^53, beta=2k-1,
H=cos^2(theta)sin(theta)Q(cos(2theta)), and
||Q||_infinity<N=38.37961982. The preceding constants are bounded by

    C_j=4 N S_j/(3-beta),
    (S_0,S_1,S_2,S_3)=(4/3,44/9,416/27,1312/27).

The local velocity and source-residual assertions follow below. The
higher-tail residual convergence needs a repair to the stated regularity
justification, but not to the conclusion.

## 1. Canonical Green identity and endpoint terms

Write q=sum D_j(r) sin((2j+1)theta). Since
partial_x=cos(theta)partial_r-sin(theta)partial_theta/r,
product-to-sum gives, for n>=1,

    f_n=(D'_(n-1)+D'_n)/2
        -(2n-1)D_(n-1)/(2r)+(2n+1)D_n/(2r).

There is no zero angular stream mode: q_x is odd in both coordinates.
For m=2n, the inverse of the radial operator
-(partial_rr+r^-1 partial_r-m^2 r^-2) is

    psi_n(r)=(1/(4n))[
      r^(-2n) integral_0^r s^(2n+1) f_n(s) ds
      +r^(2n) integral_r^infinity s^(1-2n) f_n(s) ds].

This follows by differentiating the two integrals; the derivative jump
has the sign appropriate to -Delta. The chosen limits enforce regularity
at zero and the canonical condition at infinity. An additional r^(2n)
term would have at least linear velocity at infinity; an additional
r^(-2n) term would be singular at zero.

For q vanishing on r<=1, the first integral vanishes for r<1.
If D_j=O(s^a), D'_j=O(s^(a-1)) at infinity, with a<1, then
all integrals below converge absolutely. The endpoint at 1 vanishes,
and s^(1-2n)D_j(s)=O(s^(a+1-2n)) tends to zero at infinity.
Integration by parts therefore gives

    integral_1^infinity s^(1-2n)D'_j(s) ds
       =(2n-1) integral_1^infinity s^(-2n)D_j(s) ds.

The coefficient of the D_(n-1) integral is
(2n-1)/2-(2n-1)/2=0. The coefficient of the D_n integral is
(2n-1)/2+(2n+1)/2=2n. Consequently

    psi_n(r)=(r^(2n)/2) integral_1^infinity s^(-2n)D_n(s) ds.

The actual b and chi have more than sufficient differentiability at both
joins; no internal boundary contribution occurs.

## 2. Compensation and scaling

The angular identity
cos^2(theta)sin(theta)=(sin(theta)+sin(3theta))/4 means the compact
compensator has D_0,D_1 only. Its differentiated forcing can contain
sin(4theta), but the D_1 contribution to the n=2 *interior* stream
coefficient is precisely the canceled D_(n-1) contribution above.
It can therefore alter only the n=1 interior coefficient.

Let A=integral_T^infinity s^-2 D_1(s) ds for a correction at scale T.
The n=1 stream term is (A/2)Im(x+iy)^2=Axy, whose strain psi_xy(0)
is exactly A. Higher harmonic terms contribute zero strain at zero.
The tail strain is h_1 J_(a,1)T^(a-1), and the strain of
x^2 y b(r/T) is T^2 J_b/4. The displayed compensation therefore kills
the entire n=1 interior term, including its sign and factor.

For n>=2, substitution s=Tt in the density moment gives

    integral_T^infinity s^-2n chi(s/T)s^a h_n ds
      =h_n J_(a,n)T^(a-2n+1).

Thus the interior velocity, with z=x+iy, is the finite sum

    U[h_T]=sum_(n>=2) n h_n J_(a,n) T^(a-2n+1)
                   (-Re z^(2n-1), Im z^(2n-1)).

The first possible order is cubic; it need not be a nonzero cubic.
Equivalently h_T(X)=T^a h_1(X/T) and U[h_T](X)=T^a U[h_1](X/T),
where h_1 in this last sentence denotes the scale-one correction rather
than a Fourier coefficient.

## 3. Derivative constants

For |alpha|=j<=3 and m=2n-1>=3,
partial^alpha z^m=i^(alpha_y)(m)_j z^(m-j). Also

    0<J_(a,n)<=integral_1^infinity s^(a-2n) ds
                 =1/(2n-a-1).

Factoring R^(3-j)T^(a-3) from the resulting derivative bound leaves
(R/T)^(2n-4), bounded by 4^(2-n). This proves K_j.
For -1<beta<1 and n>=2, clearing positive denominators shows

    n/(2n-beta-1)<=2/(3-beta)
       iff (beta+1)(n-2)>=0.

The sine coefficient formula gives
|h_n|<=2||H||_infinity<2N. The elementary estimate
|cos^2(theta)sin(theta)|<=1 used here is conservative and valid.
Extending the positive finite sum to infinity proves the C_j bounds.

For t=1/4, the four moments of m^l t^m, l=0,1,2,3, are

    4/3, 4/9, 20/27, 44/27.

The falling-factorial polynomials (2m+3)_j are respectively
1; 2m+3; 4m^2+10m+6; 8m^3+24m^2+22m+6.
Their moment sums give the displayed S_j exactly.
These are individual component and derivative estimates, not tensor norms.

## 4. Source-jet identity

The exact base normalization gives c0=(1+sigma[rho0])/3.
For this family sigma[h_T]=0, so the normalized scalar after correction
is still c0=1/k and the topic-76 velocity increment W[h_T] is U[h_T].
Let V0=c0 X+U[rho0] and let P=(p,0) be its exact source. Put

    mu=partial_y V0_2(P), g=rho0_y(P), gp=rho0_xy(P).

At P, oddness in y gives rho_x=0 and V_2=0. Differentiating the
residual yields V_1 rho_xy+(partial_y V_2-1)rho_y.
Because V0(P)=0 and h_T is identically zero on a neighborhood of P,

    partial_y F(rho_T,c0)(P)
       =(mu-1)g+gp U[h_T]_1(P)+g partial_y U[h_T]_2(P).

Thus the two density perturbation jets z=h_y(P), v=h_xy(P) are exactly
zero. Zero density jets do not themselves imply zero strain; the latter
was proved separately by the exact canonical moment compensation.
The perturbed velocity is not required to have its source at P.

The dependent certificate gives p<9, T>=R_b>3000,
D=|(mu-1)g|>6.70197e-7, and |mu-1|+|g|+|gp|<30.0230.
If the two velocity jets are below 1e-8, the residual derivative is
strictly greater than

    6.70197e-7 -30.0230e-8 =3.69967e-7.

Keeping the unnecessary nonnegative allowance 2e-16 from the general
four-jet estimate gives 3.699669998e-7, still strictly above 3.69e-7.
The source conclusion depends on the existing source certificate and
the angular norm certificate, not on a new full-field integration.

## 5. Higher tails and the regularity repair

Topic 106 is the sum of three corrections of the above type, with
exponents beta=2k-1, 3k-2, k-2. Its summed compensator is exactly the
sum of the three individual compensators. All exponents are less than
1 and beta is the largest. Adding the three finite K_j estimates gives
U[h_T]=O(T^(beta-3)) in C^3 on each fixed compact set.

For T larger than the compact set's radius, the density increment and
all its derivatives vanish there. Hence exactly

    F(rho_T,c0)-F(rho0,c0)=U[h_T] dot grad rho0.

The proof's assertion that rho0 is C6 locally is false at the origin
for the actual finite modal data. Only the radial joins are C6.
The inner formula in modal_repair/PROOF.md is

    rho0=x^2 y + sum_(j=1)^7 r^(2j+3) A_j(theta)
                +r^(bi+3) sum_(l=0)^6 (log(r/R_-))^l B_l(theta),

where A_j,B_l are smooth finite angular functions, R_-=exp(tminus)
is fixed, and bi>4. Differentiating a homogeneous angular function
r^d A(theta) to order l gives O(r^(d-l)). For l<=4 each nonpolynomial
term and its derivative tend to zero at the origin; the logarithmic
terms have degree bi+3>7. Induction using the difference quotient
extends these derivatives continuously. Thus rho0 is C4 locally.

This repair suffices: the C2 norm of U[h_T] dot grad rho0 on a compact
set is bounded by a fixed constant times the C2 norm of U[h_T] and
the C3 norm of rho0. The base velocity is locally C2 by its canonical
regularity, so both residuals themselves are C2. The residual convergence
in C2 follows, at the same O(T^(beta-3)) rate on each fixed compact set.

An exact data witness makes the C6 overstatement concrete:
D_(259,1)=0x1.79e5cde0f2eebp-61 is nonzero in modal_v2.json.
It contributes a nonzero sin(521 theta) term to the degree-five
homogeneous part of rho0-x^2 y; the coefficient is
D_(259,1)/(8R_-^2). No smaller mode supplies that frequency.
A homogeneous polynomial of degree five restricted to the circle has
no frequency above five. If rho0 were C5, its degree-five Taylor
polynomial would equal that leading homogeneous term by taking
rho0(r omega)-x^2 y, dividing by r^5 and letting r tend to zero.
The sin(521 theta) term contradicts this. Thus the actual density is
not C5 at zero, and in particular is not C6 there.

## Verdict and scope

Claims 1–4 are analytically valid, subject to the explicit numerical
certificate dependencies and the fresh scalar comparisons.
Claim 5 is valid with the regularity repair just proved.
Claim 6 is valid with repair: delete the C6 assertion at the origin.
The quantitative statement excludes stationarity for each specified
single-tail trial. It does not exclude a neighborhood, bound a global
residual norm, supply a linear inverse, or prove nonexistence near the
trial. No finite-T numerical source bound is given for the higher-tail
family. Opus collaboration availability will be recorded separately.
