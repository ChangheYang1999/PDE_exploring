# Lead mathematical review of ver topic 111 (tail_local_velocity)

Reviewed files: PROOF.md SHA 5c68e6baee735728c3afc146d47f940e9809b8f55b8c177a731e6622b13a5411, ADDENDUM.md and
PUBLICATION.md as present at 2026-10-21T06:53Z; topic 76 PROOF.md (source_jet_corrections) for identity (1).

Reviewers:
1. The lead lane itself, model Claude Opus 5.5 (us.anthropic.claude-opus-5-5), 2026-10-21T06:53Z to 07:03Z.
2. Astra (GPT-6 astra through Codex, high reasoning effort), tag tlv111, question notes/q_tlv111/question.md, answer
   astra/tlv111/answer.md (received by 07:02Z) with its folder local_velocity_referee/. Its attempt to consult Opus
   failed before any model ran; not part of the review.

Lead checks by hand:
- (5): d_x = cos d_r - (sin/r) d_theta on D_j sin((2j+1) theta); the sin(2n theta) coefficient is
  (D'_{n-1} + D'_n)/2 - ((2n-1) D_{n-1} - (2n+1) D_n)/(2r). Correct.
- Canonical mode formula on r < 1 (first Green integral vanishes); integration by parts
  int s^{1-2n} D' = (2n-1) int s^{-2n} D (boundary terms vanish: D(1) = 0, a < 1); D_{n-1} coefficients
  (2n-1)/2 - (2n-1)/2 = 0, D_n coefficients (2n-1)/2 + (2n+1)/2 = 2n; so psi_n = (r^{2n}/2) int s^{-2n} D_n. Correct.
- Velocity of (h_n J/2) Im z^{2n} with U = (-psi_y, psi_x): (-n h_n J Re z^{2n-1}, n h_n J Im z^{2n-1}). Correct.
- Compensator x^2 y b = r^3 cos^2 sin b has only D_0, D_1, so it changes only n = 1; zero raw strain is zero n = 1
  coefficient. Interior velocity starts at cubic order. Correct.
- Scaling U[T^a q(./T)](X) = T^a U[q](X/T); factor T^{a-2n+1} on psi_n; (R/T)^{2n-4} <= 4^{2-n} for 2R <= T;
  n/(2n-beta-1) <= 2/(3-beta) iff (n-2)(1+beta) >= 0; |h_n| <= 2 ||H||_inf. Correct.
- Source consequence: topic 76 identity with W[h_T] = U[h_T] (sigma[h_T] = 0), z = v = 0 (h_T = 0 near P since
  p < 9 < T), |u|, |w| < 1e-8: |d_y F(rho_T)(P)| >= 6.70197e-7 - 30.0230e-8 - 2e-16 > 3.69e-7. Correct.
- Higher-tail family: each exponent below 1; for a < -1 the factor n/(2n-a-1) < 1/2, so each K_j is finite;
  rate T^{beta-3} = T^{2k-4}. Correct.

Lead numerics (notes/fr111/check_constants.py, independent code): S_0 = 4/3, S_1 = 44/9 exactly; C_0 = 56.2141240001,
C_1 = 206.118454667, C_2 = 649.585432890, C_3 = 2048.69251911 (below ver's ceilings); at R = 9, T = 3000 the majorants
are 8.94138073365e-9 and 3.64278474334e-9 (mpmath iv, 40 digits; below ver's printed bounds); margin 3.69967e-7.

Repair (found by astra, checked by the lead): PROOF section 3 says the base density is C^6 locally. At the origin the
trial is only C^4 (indeed C^{4,1}, not C^5: its degree-5 term carries angular frequency 521, coefficient
D_{259,1} = 6648046164061931/2^113 != 0). The final report already records "C^{4,1} but not C^5" for the trial's
density at 0. C^3 suffices for the C^2 residual convergence, so the conclusion stands.

Verdict: claims 1 to 4 VALID; claim 5 VALID with the C^6 -> C^4 repair; no other overstatement. Scope: the source
defect statement is about the explicit family rho_T at the trial's source P; no neighbourhood exclusion follows.
