# A whole-plane auxiliary inverse at the hyperbolic source

Status at proof writing: complete proposed proof, pending independent review
and arithmetic checks. This constructs only the auxiliary cut-off-coefficient
operator from topic77. It does not assemble the full IPM inverse.

## Statement and dependencies

Use the unitary Fourier transform and H^r norms defined by J^r=(1-Delta)^(r/2)
on R^2. Set s=31/10, t=s-1. Let D=diag(A,mu), P in R^2, and assume

 10<=A<=51/5, 99/100<=mu<=101/100, 29<=g<=30.

Let w and q be real vector fields in C_c^4(R^2). Write b=D(X-P)+w and

 Aop u=b.grad u-u-gM u+q.Uu,
 Mhat=xi^2/(xi^2+eta^2),
 Uhat=(xi eta,-xi^2)/(xi^2+eta^2).

The value of these bounded multipliers at frequency0 is immaterial.
Vector and derivative tensor norms are Euclidean and Frobenius norms.
Define

 kappa=1687/500,
 E=||div w||infinity/2+s||Dw||infinity,F+||q||infinity,
 R=T_s(w)+sum_i P_s(q_i),
 a_s=kappa-E,
 a0=1+(A+mu)/2-||div w||infinity/2-||q||infinity,
 d=a0-a_s=1+(A+mu)/2-kappa+s||Dw||infinity,F.              (1)

Here, for compact coefficients,

 W_r(f)=(2pi)^(-1) integral <xi>^r |fhat|,
 alpha_r=[2sqrt(pi(r-1))]^(-1),
 beta_r=[2sqrt(pi(r-1)(r-2))]^(-1),
 P_s(f)=s2^(s-2)[W1(f)+alpha_(s-1)||f||Hs],
 T_s(w)=s(s-1)2^(s-4)sum_i[W2(w_i)+beta_(s-1)||w_i||Hs].

All are finite for C_c^4 coefficients. Suppose E<kappa. Then the maximal
realization

 D(Aop)={u in Hs: b.grad u belongs to Hs as a distribution} (2)

is densely defined and generates a strongly continuous semigroup S_A(t).
It has the bound

 ||S_A(t)||_(Hs->Hs)<=C exp(-a_s t),
 C=(1+R/d)^s,
 d>=3121/1000>0.                                         (3)

It is invertible onto Hs, and

 Aop^(-1)f=-integral_0^infinity S_A(t)f dt,
 ||Aop^(-1)||_(Hs->Hs)<=C/a_s.                            (4)

This includes existence, uniqueness and an explicit domain, unlike an a
priori inequality alone. No prescribed outer data is included.

The analytic dependency is topic77, sections2-4, which proves on Schwartz u

 Re<Aop u,u>Hs<=-a_s||u||Hs^2+R||u||Ht||u||Hs,             (5)
 [J^s,w.grad]u=-s sum_(i,j)w_(i,j)partial_ij J^(s-2)u+R_wu,
 ||R_wu||2<=T_s(w)||u||Ht.                                (6)

For clarity, the passage from (6) to a bounded conjugation, the generator,
its maximal domain, its core, and the extension of (5) are proved below.
No external semigroup theorem or unspecified core assertion is needed.

## 4. Energy on the full domain and exponential decay

Graph convergence from that core passes every term of (5) to the limit:
Aop u and u converge in Hs, and Hs convergence implies Ht convergence.
Therefore (5) holds for every u in D(Aop).
Also u in D(Aop) implies u is in D0 as an L2 function, since
b.grad u=Aop u-Bu belongs to Hs, hence to L2. By (10), positivity of M,
and the vector symbol bound ||Uu||_(L2 vector)<=||u||2,

 Re<Aop u,u>2<=-a0||u||2^2.                              (15)

For initial u in the generator domain, the semigroup preserves that domain
and its trajectory is differentiable there in Hs. This follows directly
from the difference quotient: Aop S_A(t)u=S_A(t)Aop u.
Hence y(t)=||S_A(t)u||2<=exp(-a0 t)y0. Fourier Holder interpolation gives

 ||v||Ht<=||v||Hs^(1-1/s)||v||2^(1/s).

For x(t)=||S_A(t)u||Hs while x(t)>0, (5) yields

 x'<=-a_s x+R x^(1-1/s)y^(1/s).

If x first reaches0, the trajectory is identically0 afterwards by the
semigroup property; thus integrating only up to that time suffices.
For z=x^(1/s), multiplication by exp(a_s t/s) and integration give

 x(t)^(1/s)<=exp(-a_s t/s)
 [x0^(1/s)+(R/d)y0^(1/s)(1-exp(-dt/s))].                  (16)

The box implies

d=1+(A+mu)/2-kappa+s||Dw||infinity,F
 >=1+(10+99/100)/2-1687/500=3121/1000.

Since y0<=x0, (16) proves (3) on domain initial data. Density and strong
continuity extend it to every initial u in Hs. No low-frequency compactness,
Fredholm argument or smallness of the unbounded transport perturbation was
assumed in this construction.

## 5. Inversion and the remaining rank-one condition

The integral in (4) converges in Hs by (3). For every f, a finite semigroup
integral is in the generator domain and

 Aop integral_0^T S_A(t)f dt=S_A(T)f-f.

Take the graph limit as T tends to infinity. The negative integral is in
the domain and is a right inverse. If Aop u=0, then S_A(t)u=u for all t;
(3) forces u=0. This proves both-sided inversion and its stated norm.

For any ell_delta in Hs, let sigma[u]=psi[u]_xy(0) be the raw canonical
strain, Delta psi=partial_x u. Its Fourier symbol at the evaluation point
has magnitude |eta xi^2/(xi^2+eta^2)|<=|(xi,eta)|. Thus Cauchy-Schwarz gives

 |sigma[u]|<=beta_s||u||Hs,
 beta_s=[2sqrt(pi(s-1)(s-2))]^(-1).                       (17)

This defines a continuous functional without invoking a pointwise singular
integral or origin vanishing. The bounded rank-one perturbation
Aop+ell_delta sigma has the same domain and is invertible if and only if

 Delta_sigma=1+sigma[Aop^(-1)ell_delta] !=0.               (18)

If (18) holds, its inverse is

 Aop^(-1)f - Aop^(-1)ell_delta
                 sigma[Aop^(-1)f]/Delta_sigma.

If the scalar vanishes, v=Aop^(-1)ell_delta satisfies sigma[v]=-1,
so v!=0 and is a null vector of the perturbed operator. With
K_A=C/a_s, the inverse norm when (18) holds is at most

 K_A+K_A^2 ||ell_delta||Hs beta_s/|Delta_sigma|.           (19)

No nonzero enclosure of Delta_sigma for the actual trial is supplied.

## Scope and remaining tasks

This theorem closes the generator/domain gap left explicitly open in
topic77, for the auxiliary global C4 cut-off coefficients satisfying E<kappa.
It is consistent with the local estimate there. It proves neither a
solution with arbitrary outer data nor invertibility for the full IPM
linearization. The actual derivative bounds that ensure E<kappa, a useful
numerical value of the auxiliary inverse constant, the rank-one denominator,
outer matching, centre and far-field spaces, high-norm residual control,
and a nonlinear contraction are still required. No decisive endpoint follows.
