## Axis equations and their hypotheses

Suppose a sufficiently differentiable reflection-equivariant field has expansions near the x-axis V_1=w(x)+O(y^2), V_2=mu(x)y+O(y^3). Then

(V dot grad-1)(y c(x))=y[w c'+(mu-1)c]+O(y^3).

Near the y-axis write V_1=x lambda(y)+x^3 lambda_3(y)+O(x^5), V_2=v(y)+x^2 v_2(y)+O(x^4), and h=x^2 e_2(y)+x^4 e_4(y)+O(x^6). Multiplication gives the two coefficients

x^2: v e_2'+(2lambda-1)e_2,
x^4: v e_4'+(4lambda-1)e_4+v_2 e_2'+2lambda_3 e_2.

Thus the jet system is triangular, not diagonal. If rho=x^2 y a with sufficient derivatives and W is a velocity with the same parity, direct product differentiation gives

partial_y(W dot grad rho)(x,0)=W_1(x,0)rho_xy(x,0)+partial_y W_2(x,0)rho_y(x,0),
(1/2)partial_x^2(W dot grad rho)(0,y)=2partial_x W_1(0,y)y a(0,y)+W_2(0,y)(y a)_y(0,y).

These are exact identities when the traces exist, not estimates that they are bounded in a proposed space.

For the exactly linear frozen center retain D=2A+1 and beta_2=(4A+1)/D. Here w=-Ax, mu=D, v=Dy, lambda=-A and v_2=lambda_3=0, so the homogeneous transport solutions are c(x)=x^2, e_2(y)=y and e_4(y)=y^(beta_2). At a source with w(P)=0,w'(P)!=0, the pure-transport exponent is (1-mu(P))/w'(P), equal to0 only when mu(P)=1. For an exact stationary background V dot grad rho=rho, differentiation at y=0 gives w g'+(mu-1)g=0 with g=rho_y(x,0). At w(P)=0 and g(P)!=0 this proves mu(P)=1. The normalized numerical trial instead has a small nonzero mu(P)-1, so its transport exponent is not exactly0. The coupled source problem does not inherit a resonance pole from this scalar equation, as proved separately in ../source_pole/PROOF.md.

If at infinity w(x)/x and mu(x) tend to c_l=1/k, the leading transport exponent for c is k-1; if v(y)/y and lambda(y) tend to c_l, that for e_2 is k-2. Limits alone give logarithmic asymptotic growth x^(k-1+o(1)) or y^(k-2+o(1)), not a nonzero asymptotic coefficient without a rate of convergence. These statements are about the uncoupled scalar transport parts.

Finally, if on the whole positive y-axis the coupling vanishes, the forcing vanishes, v(y)>0, and v(y)/y tends to c_l>0, a nonzero homogeneous axis solution obeys h'=h/v. Integration gives h(y)=y^(k+o(1)) times a nonzero constant in logarithmic asymptotics. A bound |h(y)|<=C y^gamma with gamma<k therefore forces it to be zero. The positivity and limit hypotheses for the actual profile must still be proved, and are not supplied by sampled axis diagnostics.

## Resolved symbol observation and limits

On the x-face, an ordinary tangential covector xi dx and normal b covector sigma dy/y give the multiplier

m=y^2 xi^2/(y^2 xi^2+sigma^2).

At y=0,sigma=0,xi!=0, limits with different sigma/y disagree, so this face symbol has no continuous extension there. This does not exclude every resolved formulation. Blowing up a source point via x-x_*=r cos(theta),y=r sin(theta), a covector tau dr/r+omega dtheta has ordinary components r^(-1)(tau cos(theta)-omega sin(theta),tau sin(theta)+omega cos(theta)). Hence

m=(tau cos(theta)-omega sin(theta))^2/(tau^2+omega^2),

smooth down to r=0 away from the zero covector. Likewise

A(x-x_*)partial_x+y partial_y
 =(A cos^2(theta)+sin^2(theta))r partial_r+(1-A)sin(theta)cos(theta)partial_theta,
r^2 Delta=(r partial_r)^2+partial_theta^2.

These direct identities describe resolved symbols only. They prove no boundedness of the nonlocal operator on a weighted blow-up space, no normal-family inverse, and no matching with the proposed source disc.

