## Exit trace and regularity at a finite saddle box

Retain A>0, D=2A+1, T=-Ax partial_x+Dy partial_y-1, and weighted measure x^(-2a)y^(-2b)dxdy from above. Let 0<nu<=1, 0<alpha<1, and H be even and C^(4,nu) on a neighborhood of[-1,1]. On0<y<=1, the homogeneous solution determined by H on y=1 is

h_hom(x,y)=y^(1/D) H(x y^(A/D)).

Differentiating this expression proves T h_hom=0; its value at y=1 is H(x). Extend evenly in x and oddly in y. Write

H(z)=H_0+H_2 z^2+H_4 z^4+R_H(z),
H_2=H''(0)/2, H_4=H''''(0)/24.

Taylor's theorem with a Holder fourth derivative gives

|R_H^(j)(z)|<=C|z|^(4+nu-j), j=0,...,4.

Therefore

h_hom=H_0 sgn(y)|y|^(1/D)+H_2 x^2 y
 +H_4 x^4 sgn(y)|y|^(beta_2)+R(x,y),
beta_2=(4A+1)/D=2-1/D,
q_nu=(1+(4+nu)A)/D.

On each quadrant, chain-rule differentiation gives for i+j<=3

|partial_x^i partial_y^j R(x,y)|<=C|x|^(4+nu-i)|y|^(q_nu-j).

For y!=0, the C^4 regularity of R_H already gives C^3 regularity across x=0; the displayed vanishing powers agree with those derivatives there. If q_nu>=2+alpha, derivatives through order2 extend across y=0 and are Holder with exponent alpha. Here are the details for the last assertion. Every second derivative is bounded by C|y|^alpha, and its first derivatives off y=0 are bounded by C|y|^(alpha-1) on a bounded box. Given two points at distance d, if either point has |y|<=2d then both have |y|<=3d and the second-derivative difference is bounded by Cd^alpha. Otherwise the segment between them stays at distance at least d from y=0, and the third-derivative estimate bounds the difference by Cd times d^(alpha-1). The same argument handles opposite sides of the axis. The lower derivatives extend by their vanishing bounds. Hence R is C^(2,alpha), including at equality q_nu=2+alpha.

The sufficient condition is exactly

nu>=2alpha+(1+alpha)/A.

It is not a necessary condition on an individual H, which may have a smoother or zero remainder. If a particular inhomogeneous solution is already C^(2,alpha), H_0=0, and the preceding trace hypotheses hold, then H_4 is the sole remaining obstruction among these displayed homogeneous terms: beta_2 lies strictly between1 and2, so x^4 sgn(y)|y|^(beta_2) is not C^2 at y=0 for any fixed x!=0 unless its coefficient vanishes. H_2 x^2 y is smooth. This conclusion is conditional on the regularity of the particular solution and the trace; it is not a Fredholm index calculation.

The need to control the particular solution is real. Direct differentiation gives

T(x^2 y log|y|)=D x^2 y.

Thus vanishing of a forcing on the y-axis alone does not ensure a C^2 particular solution. A separate exact resonance cancellation and a solved inhomogeneous problem are needed.

## The weight/trace arithmetic correspondence

With b=5/2+alpha and a=9/2+nu, direct substitution gives

delta=A(2alpha-nu)+1+alpha.

Hence delta<0 is equivalent to the strict inequality nu>2alpha+(1+alpha)/A. This numerical correspondence does not identify the two spaces: a monomial x^p y^q belongs locally to the weighted L^2 space near both faces exactly when p>a-1/2 and q>b-1/2. The equalities give logarithmic divergence. This can fail for every nu in the preceding correspondence, not just on delta=0. For example H(z)=|z|^(4+nu), with a harmless cutoff equal to1 near0, is even and C^(4,nu). Its homogeneous remainder is |x|^(4+nu)sgn(y)|y|^(q_nu). For a=9/2+nu the x exponent is exactly a-1/2; integrating its weighted square in x diverges logarithmically on every fixed interval0<y_1<y<y_2. Thus even delta<0 and the sufficient C^(2,alpha) trace condition do not embed the generic C^(4,nu) trace remainder into this weighted space. A positive x margin, extra vanishing, or a separate trace component is required.

The lead's example alpha=2/5, s=1701/500, b=3403/1000, a=1299/200 is only an algebraic feasibility point. Its inequalities and delta are checked separately against the exact normalized modal k, with A=2/k-1. No embedding theorem or global operator estimate follows from passing these rational inequalities. This is a separate general-weight point, not an example of a=9/2+nu,b=5/2+alpha from the preceding C^(4,nu) trace comparison: here a-9/2=399/200>1 and b!=5/2+alpha. The C^(4,nu) argument above is therefore not applied to this point. The exact audit gives delta=-6254978666120071/403884010949762750, between -0.015487067 and -0.015487066; all six displayed feasibility margins are strictly positive.

