## Weighted maximal-domain inverse

Fix A>0, D=2A+1, b_0=(A+3)/2, real a,b, and a nonnegative integer m. On Q={(x,y):x>0,y>0}, define H_b^m(a,b) as the completion of C_c^infinity(Q) under

||h||^2=sum_(i+j<=m) integral_Q x^(-2a)y^(-2b)|(x partial_x)^i(y partial_y)^j h|^2 dx dy.

Put T=-Ax partial_x+Dy partial_y-1 and delta=bD-aA-b_0. Its maximal distributional domain is D(T)={h in H_b^m(a,b):Th in H_b^m(a,b)}. If delta!=0, T is bijective from D(T) to H_b^m(a,b), and

sup_(f!=0) ||T^(-1)f||_(H_b^m)/||f||_(H_b^m)=1/|delta|.

This is the inverse norm measured in the base space. With the sum graph norm ||h||_D=||h||+||Th||, the inverse norm into D(T) is exactly1+1/|delta|. With the Hilbert graph norm it is sqrt(1+|delta|^(-2)). Thus a bare assertion of the sharp inverse norm must specify the output norm.

For delta<0 the inverse is

T^(-1)f(X)=-integral_0^infinity exp(-t) f(exp(-At)x,exp(Dt)y)dt.

For delta>0 it is

T^(-1)f(X)=integral_(-infinity)^0 exp(-t) f(exp(-At)x,exp(Dt)y)dt.

Both integrals converge in the base Hilbert space. If delta=0, T is injective with dense nonclosed range and has no bounded inverse.

To prove these statements put u=log x,v=log y and

F(u,v)=exp((1/2-a)u+(1/2-b)v)h(exp u,exp v).

This is a unitary map for the weighted L^2 term. The two b derivatives become partial_u+a-1/2 and partial_v+b-1/2. Consequently, with unitary Fourier transform in (u,v), the full norm becomes

integral_R2 P_m(xi,eta)|F_hat(xi,eta)|^2 dxi deta,
P_m=sum_(i+j<=m)(xi^2+(a-1/2)^2)^i(eta^2+(b-1/2)^2)^j.

P_m is positive, bounded below by1, and comparable to(1+xi^2+eta^2)^m. The conjugated T is -A partial_u+D partial_v+delta, with symbol delta+i(D eta-A xi). Distributional differentiation identifies its maximal domain with the functions for which this symbol times F_hat belongs to L^2(P_m dxi deta). When delta!=0, division by the symbol defines an everywhere bounded inverse into the base space and lies in the maximal domain. Its exact norm is the essential supremum of the reciprocal modulus, namely1/|delta|. Fourier functions supported in increasingly narrow strips about D eta=A xi give sharpness. The graph-norm constants follow by adding ||T T^(-1)f||=||f||, or adding its square.

When delta=0, the zero set of the symbol is a line of measure zero, so the kernel is zero. The range is dense: truncate the Fourier transform of any target to the sets |D eta-A xi|>=epsilon, then divide by the symbol; these targets converge in the base norm. Its range is not closed because unit vectors supported in shrinking strips have ||Th|| tending to0. A closed range for an injective closed operator would give a bounded inverse onto its range with the graph norm by the closed graph theorem, contradicting these vectors. Equivalently one may choose a target whose square-integrable Fourier transform does not remain square-integrable after division near the line.

The semigroup S(t)h=exp(-t)h(exp(-At)x,exp(Dt)y) has norm exp(delta t), either by change of variables or its Fourier multiplier. Its generator is T, and it is strongly continuous. The two integrals have the asserted norms and solve T R f=f by integration of partial_t S(t)f, first for smooth compact Fourier data and then by closure. They agree with the unique Fourier inverse. A graph core can be obtained by truncation and smoothing in log coordinates: T has constant coefficients, smoothing commutes with it, and derivatives of expanding cutoffs tend to zero in the commutator. This also verifies the distributional realization independently of the integral formula.

This inverse gives no full additional b derivative. Indeed high-frequency packets can remain near D eta=A xi while their transverse frequency tends to infinity. Their inverse multiplier stays of size1/|delta|, with no transverse decay.

