# Review of research/normalized_tail_repair (proof, addendum, publication, code, evidence)

**Verdict: ACCEPT**

The acceptance is scoped to an explicit trial construction. It is not a stationary profile, not a closing estimate and not a decisive endpoint.

## Reconstructed and confirmed

**1. Tail repair and cancellation.**
- (c0E−1)(r^β H) equals exactly (β/k−1) r^β H.
- By (1), this is −r^β Epsilon.
- For r ≥ 2T there is no remainder from this term, because the term is exactly homogeneous.
- The cross terms have exponents k+β−1 = β2 (both) and 2β−1 = 4k−3 < β2.
- Homogeneous products are at most k−4.
- The finite logarithmic degree is collected into one q.
- So F = O(r^β2 log^q r) at infinity. Since k < 1/3, β2 < −1, which gives unweighted L² there.
- The audit checks k < 1/3 by exact rational comparison of the NPZ dyadic.
- Local L² follows from continuity, using C^{2,α}_loc for ρ0 and C⁷ for the correction.

**2. Positive canonical strain.**
- K_s = sin3θ/(πr³), and the angular factor is 1/4. The audit checks this with an exact rational moment: 3·ang(2,1) − ang(1,2) = 1/4.
- σ[g_T] = T² J_b/4.
- σ[h_tail] = I_H J_χ T^(β−1).
- These give λ_T = 4 I_H J_χ T^(β−3)/J_b, so the strain is exactly zero.
- J_χ is an exact convergent integral and is never approximated. Only its upper bound 1/(1−β) enters C.

**3. Angular quotient.**
- The sin-projection recurrence (11) and the collected forms with c_d = (−1)^d(⌊d/2⌋+1) are correct.
- The audit symbolically rebuilt all 271962 = 521·522 entries.
- The Laurent route is also correct: (w−1)(w+1)²/4, degree 2M+3 → 2M.
- Both routes are triangular. Each therefore encloses the unique exact quotient whatever the remainders show; divisibility comes from (9).
- In the Laurent engine, the top-down q_0 can depend on h_0 through poly[M+1], unlike the recurrence. This is harmless:
  - the two are algebraically equal by (9);
  - the exact audit applies the recurrence map to each engine's own input box and confirms containment in that engine's boxes, for all 521 coefficients.

**4. Interval arithmetic.**
- I retract my earlier claim: unit-modulus characteristic roots do not imply polynomial growth of naive interval radii. Uncorrelated radius propagation is what blows up, as the archived width of about 2.9e5 shows.
- Collecting exact integer forms first fixes this.
- The reported widths are consistent: raw_N < 2.4e−64 (Arb) and < 2.1e−63 (iv).
- No monotonic residual growth is claimed, and the earlier "grows with T" request is correctly declined.

**5. Exponents and weighted cost.**
- r^(β−3)/W = L^(k−3) r^(k−1) (1+L²/r²)^α, with α = (3−k)/2.
- Compensator term: T^(β−3)·(5T²/L²)^α gives T^(k−1).
- Formula (6) is matched exactly in both engines:
  - b_max = 2^−16, written as (1/4)^8 in the iv engine;
  - J_b = 3B/2, with B computed by factorials in one engine and a Beta product in the other;
  - physical factor (k/(1−k))·R_b^(−β), written as exp(−βt) in Arb and exp(t)^β in iv.
- Public numbers are consistent across both engines and the audit:
  - N < 38.37961982 and |I_H| < 0.0389378614;
  - C_public ≈ 0.3346159388 < 0.334616, with sharp C in the stated window;
  - all six T-rows equal 0.334616·T^(k−1), upper-bounded in Arb768 and iv200, with T > exp(tplus) ≈ 3.4e3 checked.

**6. P2 scope (A5).**
- The kinematic requirements now match PROMPT: C^{2,α} density, a continuous factor with a(0)=1, the parities, canonical sublinear velocity, and growth.
- Stationarity is correctly marked unproved, and P_∞ is not claimed.

## Residual qualifications (not grounds for rejection)

- **(a) Superseded wording.** PROOF (a) ("global regularity at least P2", "C7 globally") is superseded by A5: the global regularity is C⁶ at the old joins. The verdict scope should cite PROOF+ADDENDUM jointly, which finalize_verdict does.
- **(b) Transcendental scalars not rationally audited.** The physical factor, L^(k−3), 2^α and 5^α rest on Arb/mpmath outward rounding. These are trusted dependencies.
- **(c) Inputs are pinned, not rerun.** The 522-coefficient inputs are the pinned topic-42 enclosures, read by two engines. No convolution was rerun, so soundness inherits that certificate.
- **(d) Hard-coded count.** The 4045 exponent-check count is hard-coded, not tallied. The underlying assertions do run.
- **(e) Wording mismatch in a dependency.** far_residual_obstruction still says the "trial density is C2" near zero. This is harmless but inconsistent with A5's continuous-factor wording.

## Acceptance scope

For every T ≥ max(R_b, L, 1), there is an explicit ρ_T with the following properties:
- it is exactly strain-normalized, with c0 = 1/k;
- its density equals ρ0 on r ≤ T, though its velocity changes there;
- it meets the P2 kinematic requirements only;
- its residual is in unweighted L², with no norm bound;
- its correction is not in L²;
- its weighted factor sup is below 0.334616·T^(k−1).

The leading r^k tail is unchanged. The construction gives no stationarity, no X3 class, no source control or inverse, and no endpoint.
