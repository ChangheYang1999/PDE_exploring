# Edge and corner split realization for the forward (F-) problem: exact local facts, proposed spaces, gaps

Lead note, started 2026-10-20T16:27Z; revision 2 at 2026-10-20T16:53Z after the single-model astra audit of
revision 1 (section 6; revision 1 kept in notes/conormal_framework_v1_backup.md). Status labels as in SPEC.md
(EXACT = proved here, short proof given; PROPOSED = a definition or a design choice; CONDITIONAL; HEURISTIC).
Section 1.2 is AUDITED (astra, single model); nothing here is verified by the verifier yet.

Notation as in SPEC v3: `A = 2c_l - 1`, `D = 2A + 1`, `b_0 = (A+3)/2 = 1 + c_l`, `V = c_l X + U[rho]`,
`L h = (V.grad - 1) h + W[h].grad rho`. On the x-axis `w(x) = V_1(x,0)`, `mu(x) = d_y V_2(x,0)`; on the y-axis
`v(y) = V_2(0,y)`, `lambda(y) = d_x V_1(0,y)`. X3 values: `A = 10.1507252`, `D = 21.3014504`, `b_0 = 6.5753626`,
`g = 29.7494907`, `a_P := g/(A-1) = 3.2510528`, `s_fast = (g + b_0)/A = 3.5785476`, `b_0/D = 0.3086815`.

## 0. Summary
The isotropic Sobolev failure at the saddle (`sD - b_0 > 0` for `s > 0.309`) is removed by measuring regularity with
b-vector fields (`x d_x`, `y d_y`) near the axes and the corner, with power weights at the faces. In such spaces:
(i) the linear saddle is invertible with an explicit sharp inverse norm on both sides of one exact weight line (1.2,
audited VALID); (ii) the class `P_2` (`C^{2,alpha}`) is approached by splitting finitely many edge terms along the axes,
the J mode and the `beta_2` mode at the corner; (iii) at the source P we keep an ordinary `H^s` disc, where the
verified frozen theorem applies. (iii) is a design choice: the face b-calculus cannot use the coupling at P, but a
point blow-up at P resolves the coupling symbol smoothly (2.4), so b-type analysis at P is not excluded.
The parameter inequalities of section 3 are algebraically feasible at X3 (with the corrected embedding condition
`b > s`, section 2.3) for `0 < alpha < 0.406`; this is a feasibility window only, not an admissible window for L.
Missing: the global estimate with the nonlocal coupling on weighted edge spaces, edge compatibility, normal-operator
and adjoint estimates, compactness and the index (section 5).

## 1. Exact facts at the linear saddle

### 1.1 Indicial line (EXACT)
`T_0 = -A x d_x + D y d_y - 1`. For `h = |x|^p sgn(y) |y|^q`: `T_0 h = (Dq - Ap - 1) h`. Kernel modes lie on the line
`Dq - Ap = 1`: the J mode `(2,1)` (`D - 2A = 1`), the exit modes `(2j, beta_j)`, `beta_j = (2jA + 1)/D`
(`beta_2 = 1.9530548`, `beta_3 = 2.9061097`, `beta_4 = 3.8591645`), and the incoming modes `(p_b, b)`,
`p_b = (bD - 1)/A = 2b + (b-1)/A` (`p_3 = 6.1970303`, `p_5 = 10.3940605`).

### 1.2 Weighted b-Sobolev inverse at the saddle (EXACT, with proof; AUDITED VALID)
Let `Q = {x > 0, y > 0}` (parity reduces the plane to Q), `u = log x`, `v = log y`, and
`||f||_{m,a,b}^2 = sum_{i+j<=m} || x^{-a} y^{-b} (x d_x)^i (y d_y)^j f ||_{L^2(Q, dx dy)}^2`, `H^m_b(a,b)` the
completion of `C_c^infty(Q)`. Put `delta := bD - aA - b_0`. Realize `T_0` as the closed operator with maximal graph
domain `D_m = {h in H^m_b(a,b) : T_0 h in H^m_b(a,b)}` (it is not bounded on `H^m_b(a,b)` and its inverse does not gain
a b-derivative in every direction). Then:
(a) If `delta < 0`, `T_0: D_m -> H^m_b(a,b)` is bijective for every m with `||T_0^{-1}|| = 1/|delta|` exactly; the
inverse is the forward solution `R_- f(X) = -int_0^inf e^{-t} f(e^{-At} x, e^{Dt} y) dt`.
(b) If `delta > 0`, the same with norm `1/delta` and the backward solution
`R_+ f(X) = int_{-inf}^0 e^{-t} f(e^{-At} x, e^{Dt} y) dt`.
(c) If `delta = 0`, `T_0` is not invertible (approximate kernel).
Proof. With `F(u,v) = e^{(1/2 - a)u + (1/2 - b)v} f(e^u, e^v)` the weighted `L^2` norm becomes `||F||_{L^2(R^2)}`;
`x d_x`, `y d_y` become `d_u + a - 1/2`, `d_v + b - 1/2`, so `||f||_{m,a,b}^2 = int P_m |F^|^2` with
`P_m(xi, eta) = sum_{i+j<=m} (xi^2 + (a-1/2)^2)^i (eta^2 + (b-1/2)^2)^j`, and `T_0` becomes `-A d_u + D d_v + delta`,
symbol `delta + i(D eta - A xi)`. The same positive factor `P_m` appears on both sides, so the inverse has norm
`sup 1/|delta + i(D eta - A xi)| = 1/|delta|`; Fourier packets concentrated near `D eta = A xi` give sharpness and, at
`delta = 0`, the approximate kernel. The semigroup `S(t) f = e^{-t} f(e^{-At}x, e^{Dt}y)` has `||S(t)|| = e^{delta t}`
by change of variables, which identifies the inverse with `R_-` (`delta < 0`) or `R_+` (`delta > 0`).
`delta = kappa - 1` with `kappa = bD - aA - (D - A)/2`, since `(D - A)/2 + 1 = (A + 3)/2`. QED.
Remarks. (1) Ordinary derivatives behave differently: `d_x T_0 = (T_0 - A) d_x` helps, `d_y T_0 = (T_0 + D) d_y` hurts;
this is the isotropic `0.309` failure (`a = b = 0`, one `d_y`: `D - b_0 > 0`). (2) The weight, not the regularity,
selects forward versus backward solvability at the saddle. Forward (`R_-`) is the choice compatible with F- (tail
fixed, data from the future). (3) The local integrability thresholds of the weighted space are `p > a - 1/2`,
`q > b - 1/2` (strict: `x^{a-1/2}` itself is not in the space); the dividing line `delta = 0` is the indicial line
shifted by `(1/2, 1/2)`. (4) These are whole-quadrant statements; a bounded saddle box needs an exit-trace or boundary
prescription in addition.

### 1.3 Exit-trace regularity for a one-scalar saddle condition (EXACT as a sufficient condition)
In the saddle box the forward solution equals a particular solution plus `sgn(y)|y|^{1/D} H(x|y|^{A/D})`, H the trace
on `|y| = 1`. If `H` is even and `C^{4+nu}` at 0, `H = H_0 + H_2 z^2 + H_4 z^4 + O(|z|^{4+nu})` (with the derivative
estimates of a genuine `C^{4,nu}` Taylor remainder), then
`h_hom = H_0 sgn(y)|y|^{1/D} + H_2 x^2 y + H_4 x^4 sgn(y)|y|^{beta_2} + R`, `|R| <= C |x|^{4+nu} |y|^{q_nu}`,
`q_nu = (1 + (4+nu)A)/D`, with the same homogeneity for derivatives. R is `C^{2,alpha}` across `y = 0` if
`q_nu >= 2 + alpha`, i.e. `nu >= 2 alpha + (1 + alpha)/A = 0.0985 + 2.0985 alpha`. This is sufficient, not necessary
(the equality case `|x|^{4+nu} sgn y |y|^{2+alpha}` is `C^{2,alpha}`; a given H may have a smoother remainder).
Three hypotheses are needed before `H_4` is the only obstruction:
- the particular solution must itself be `C^{2,alpha}`; vanishing of the forcing on the y-axis does not ensure this
  (`T_0(x^2 y log|y|) = D x^2 y`); the resonant `x^2 y` forcing is excluded for forcings in the range of the
  linearization by `J(F(rho)) = 0` (SPEC 1, so `J(L h) = 0`), and the regularity of the particular solution must
  still be proved in the chosen forcing space;
- `H_0 = 0`: the coupling vanishes on the y-axis (`rho(0,y) = 0`, rho even in x, so `grad rho = 0` there); if
  `f(0,y) = 0` for `y > 0`, `v(y) > 0` for `y > 0` and `v(y)/y -> c_l`, every nonzero axis solution is
  `C exp(int dy/v) = y^{k + o(1)}`, excluded by the growth restriction `gamma < k`. This uses the whole axis and its
  connection to infinity; at X3 these hypotheses hold in floating point only (4.1, D1);
- the trace class must be specified (section 2.3).

### 1.4 The same number from the corner weight (EXACT arithmetic; an algebraic correspondence only)
With `b = 5/2 + alpha`, `a = 9/2 + nu`: `delta = bD - aA - b_0 = A[2 alpha + (1 + alpha)/A - nu]`, so the forward
condition `delta < 0` is `nu > 2 alpha + (1 + alpha)/A`, the number of 1.3. This is an algebraic correspondence, not an
equivalence of spaces: a remainder behaving exactly like `x^{a - 1/2}` (or `y^{b-1/2}`) is not in the weighted space
(logarithmic divergence), so strict margins and a bounded trace and extension theorem are needed. Section 2.3 shows
that the ordinary Sobolev embedding forces a much stronger corner weight.

## 2. Edge structure along the invariant axes

### 2.1 Axis components (EXACT computations)
Odd-in-y, even-in-x functions satisfy, near the x-axis, `(V.grad - 1)(y c(x)) = y [w c' + (mu - 1) c] + O(y^3)`.
Near the y-axis write `V_1 = x lambda(y) + x^3 lambda_3(y) + O(x^5)`, `V_2 = v(y) + x^2 v_2(y) + O(x^4)`,
`h = x^2 e_2(y) + x^4 e_4(y) + O(x^6)`; then
`(V.grad - 1) h = x^2 [v e_2' + (2 lambda - 1) e_2] + x^4 [v e_4' + (4 lambda - 1) e_4 + v_2 e_2' + 2 lambda_3 e_2] + O(x^6)`.
The jet system is triangular, not diagonal; the `x^4` equation also receives the `x^4` coefficient of the coupling.
The full x-axis edge equation is
`w c_1' + (mu - 1) c_1 + W_1[h](x,0) rho_xy(x,0) + d_y W_2[h](x,0) rho_y(x,0) = f_y(x,0)`.
Local exponents of the homogeneous transport parts (not automatically indicial exponents of the coupled edge
problems): `c_1 ~ x^2` at 0 (J mode), exponent 0 at P (the pure-transport resonance of SPEC 3.5, which the coupled
frozen problem does not inherit), `x^{k-1}` at infinity (tail mode `r^k Theta` near `theta = 0`); `e_2 ~ y` at 0,
`y^{k-2}` at infinity; `e_4 ~ y^{beta_2}` at 0. So the corner modes that must be split are the near-corner limits of
the axis components, and the tail traces are their far limits.

### 2.2 Coupling contributions (EXACT, assuming the derivatives exist)
`d_y (W[h].grad rho)(x,0) = W_1[h](x,0) rho_xy(x,0) + d_y W_2[h](x,0) rho_y(x,0)`;
`(1/2) d_x^2 (W[h].grad rho)(0,y) = 2 d_x W_1[h](0,y) y a(0,y) + W_2[h](0,y) (y a)_y(0,y)` (`rho = x^2 y a`).
Both are nonlocal functionals of h; the axis problems are 1D transport equations with nonlocal forcing.

### 2.3 Proposed split space (PROPOSED; incomplete)
`h = E_1 c_1 + E_2 e_2 + E_4 e_4 - (corner overlap) + h_rem`, with extension maps `E_j` and:
- `c_1` on `[0, inf)`, `e_2`, `e_4` on `[0, inf)`, in weighted 1D spaces (factors `x^{k-1}`, `y^{k-2}` at infinity
  allowed only through the fixed tail of F-, otherwise decay `gamma < k`);
- extensions: NOT a fixed cutoff `chi(y) y c_1(x)` (fails, section 5 G1, and requires `c_1 in H^s` to lie in `H^s`
  while an `H^s` function has normal-derivative trace only in `H^{s - 3/2}`). Candidates: the frequency-adapted
  extension `E_1 c = y chi(y |D_x|) c` (dilation invariant; the construction of notes/weighted_velocity.md Lemma W1',
  which proves the velocity splitting; its mapping properties for the solution components are not proved), or the
  conic extension `y chi(y/<x>) c(x)` at large scales;
- the overlap: if it is `J x^2 y + K x^4 y`, the components must satisfy compatible jets `c_1 = J x^2 + K x^4 + ...`,
  `e_2 = J y + ...`, `e_4 = K y + (singular/regular remainder)`; existence and continuity of the subtracted `e_4` limit
  must be proved;
- `h_rem` in the composite weighted space with weight `|x|^{-2a}|y|^{-2b} <r/L>^{2(a + b - gamma')}` near the axes,
  b-regularity of order m near the faces, ordinary regularity elsewhere, and ordinary `H^s` on a disc around P.
  At infinity the weight is `r^{-2 gamma'}` with `dx dy`; `r^q` is radially square integrable iff `q < gamma' - 1`, so
  the growth threshold is `gamma = gamma' - 1` and `gamma' c_l - b_0 = gamma c_l - 1`;
- embedding (corrected): b-regularity with weight `|y|^{-2b}` gives `d_y^j h_rem in |y|^{b-j} L^2` only
  (`d_y^j = y^{-j} prod_{l<j}(y d_y - l)`), which does not remove the weight. Revision 1 claimed a local inclusion in
  `H^s`; it is FALSE (`h = phi(x) chi(y) sgn(y)|y|^{2.4}`, `b = 2.8`, `a = 5.4`, `s = 3.25`: in the remainder space,
  not `H^3`). Repair: `b > s` with enough b-derivatives and a proved embedding. Then forward dissipativity at the
  corner requires `p := a - 1/2 > [D(s - 1/2) - 1]/A > 5.14777 + 2.09852 alpha` (using `s > 3 + alpha`);
- parameter window for `P_2` with `C^{2,alpha}`: `3 + alpha < s < b < beta_3 + 1/2 = 3.406`,
  `(bD - b_0)/A < a < 6.5` (`a - 1/2 < 6` keeps `x^6 |y|^{beta_3}` and `|x|^{p_3} y^3` in the remainder), `gamma < k`.
  Feasible for `alpha < 0.4061097` (`3 + alpha < beta_3 + 1/2`); example `alpha = 0.4`, `s = 3.402`, `b = 3.403`,
  `a = 6.495`, `delta = -0.0155`. The margins are thin: at `alpha = 0.4` both `b < 3.406` and `a < 6.5` are nearly
  active;
- the `beta_2` coefficient `c_2 := lim e_4(y)/y^{beta_2}` (after the particular part) is the saddle functional; `P_2`
  requires `c_2 = 0`. In F- it is balanced by `tau` (SPEC section 4).
Still missing for a definition: component norms, bounded extraction maps, the operator domain and the forcing space,
and the transition rules near P and at infinity.

### 2.4 The coupling at P and the face b-calculus (EXACT observation; the conclusion is a design choice)
At the x-face the b-covector `(xi, sigma)` (`sigma` dual to `y d_y`) gives `m = xi^2/|zeta|^2 = y^2 xi^2/(y^2 xi^2 + sigma^2)`,
which does not extend smoothly to `y = 0` in this chart. At P the b-characteristic direction is `sigma = 0`, and the
radial threshold there needs the coupling (`sA - b_0 - g < 0`); without it the x-order would be limited to
`s < (b_0 - b)/A < 0.65`. So the face b-calculus alone cannot use the coupling at P. Revision 1 concluded that no
b-calculus can; that is wrong. A point blow-up at P, `x - x_* = r cos theta`, `y = r sin theta`, covector
`tau dr/r + omega dtheta`, gives `m = (tau cos theta - omega sin theta)^2/(tau^2 + omega^2)`, smooth down to `r = 0`;
`A s d_s + y d_y = (A cos^2 theta + sin^2 theta) r d_r + (1 - A) sin theta cos theta d_theta` lifts smoothly and
`r^2 Lap = (r d_r)^2 + d_theta^2`. These give smooth resolved symbols, not operator bounds or normal-family
invertibility. Keeping an ordinary `H^s` disc around P (where the verified frozen theorem applies) is our design
choice. Along the forward flow (P to the corner) R_- reads forcing from the future, so the regularity demanded later
along the flow must be at least that demanded earlier; for a microlocal estimate this must be formulated on the
lifted characteristic flow (with covectors), not by comparing scalar orders of different spaces.

## 3. Parameter inequalities (EXACT at the model level; not a sufficient criterion)
(T1) Source P, ordinary `H^s`: `s < s_fast = 3.5785` (frozen theorem, VERIFIED) and `s < b_0` in the slow direction.
(T2) Corner: `bD - aA < b_0` (1.2).
(T3) Faces away from P and 0: the flow restricted to the x-face is `x' = w(x)`, to the y-face `y' = v(y)`; if `w`
vanishes on `[0, inf)` only at 0 and `x_*`, and `v(y) > 0` for `y > 0` (floating point at X3, 4.1), the face flows
have no other zeros. The normal components (`mu(x)`, `lambda(y)`) enter through the weight terms.
(T4) Infinity: `gamma c_l - 1 < 0`, i.e. `gamma < k` (`gamma = gamma' - 1`), in scaled derivatives.
(T5) Variable orders non-decreasing along the forward flow, formulated on the lifted characteristic flow.
(T6) Embedding: `3 + alpha < s` at P; `b > s` near the x-face (2.3); `a - 1/2 > [D(s - 1/2) - 1]/A` at the corner.
Feasibility: `alpha < 0.4061` (2.3). These inequalities are necessary-type model conditions; they are not a complete
estimate criterion. Missing: global characteristic geometry beyond axis zero counts; uniform control of trajectories
approaching the separatrices (D3 shows the ordinary cost diverging for orbits hugging the incoming axis); nonlocal
mapping and transition estimates; edge compatibility, bounded scalar functionals and tail-scalar cancellation;
normal-operator and adjoint estimates; compact error control and elimination of the remaining kernel.

## 4. Floating diagnostics (code/energy_conormal.py)
(D1) Axis functions of X3: `w, w', mu` on the x-axis, `lambda, v/y` on the y-axis; signs of `mu`, `v`, zeros of `w`,
`lambda`, and the coupling coefficients `rho_y(x,0)`, `rho_xy(x,0)`.
(D2) Energy rates on the characteristic set only (`zeta` normal to V), compared with the old all-directions maximum
(code/energy_symbol.py).
(D3) Orbit costs `int (rate)^+ dt` along orbits from P, as a function of the departure angle.

### 4.1 Results (FLOATING POINT, s = 3.25, grids 1500 x 128 and 3000 x 256 agree to 4 digits; they certify nothing)
- (D1) On `(0, inf)` the x-axis drift `w` has the single zero `x_* = 8.60006`; `mu(x)` lies in `[0.9885, 21.3015]`
  (minimum at `x = 8.88`, just beyond P; `mu -> c_l` at infinity); `v(y)/y` lies in `[5.5756, 21.3015]`;
  `lambda(y)` changes sign once, at `y = 9.147` (from `-A` to `+c_l`); `rho_xy(x,0)` changes sign once, at `x = 9.115`.
- (D1b) Face weight rates with the composite weight (`gamma' = 1 + k - 0.05`): on the y-face `R_y < 0` everywhere
  (max `-0.28`, at infinity) for every tested `(alpha, a, b)` (these tests used revision 1's window, `b` from
  `2.55 + alpha`); on the x-face `R_x` is positive on bounded stretches (e.g. `x in (1.16, 5.06)` and `(11.2, 87.5)` for
  `alpha = 0.05`, `b = 2.6`, `a = 4.86`) and negative near 0, near P and at infinity. Positive stretches crossed in
  finite flow time can be absorbed by a bounded factor `e^{phi(x)}`.
- (D2) On the characteristic set the ordinary rate `E_Sigma` is much smaller than the all-directions maximum in the
  interior and the y-collar (y-collar, `0.1 <= r < 20`: max 5.0 against 62.6; positive on 8% of points against 100%),
  but equals `sD - b_0 = 62.65` on the incoming x-axis near 0 (the saddle failure) and `s c_l - b_0 = 11.5` in the far
  field (unscaled derivatives). Near P (`|X - P| < 1`) `E_Sigma <= -1.87 < 0`.
- (D3) Orbit costs on Sigma from a circle around P: about 1.61 for every orbit leaving towards infinity; for orbits
  leaving towards the corner the cost grows as the departure angle tends to `pi` (4.4 at 2.09, 12.4 at 3.04, 28.3 at
  `pi - 1e-3`), i.e. for orbits hugging the incoming x-axis and passing the saddle: the separatrix nonuniformity that
  the corner weights of 1.2 must replace by the negative corner rate `delta`.

## 5. What a theorem needs (the precise remaining obstruction)
G1 Weighted nonlocal coupling. The natural fixed-cutoff formulation FAILS: for `T_chi h = M h - chi(y) y d_y(Mh)(x,0)`
   and `h_R = R^{b-1} F(X/R)` (F smooth, compactly supported away from the axes, `d_y(MF)(.,0) != 0`),
   `||h_R||` is constant and `||T_chi h_R||_{L^2(|y|^{-2b})} >= c R^{b - 3/2}`; the same happens for the composite
   weight in a far angular collar (astra conormal1, Q6). The x-face part with dilation-invariant Taylor subtraction is
   now proved (notes/weighted_velocity.md: Lemma W1, global subtraction; Lemma W1', frequency-adapted extension).
   Open: the corner (product weights), the y-face, the conic extension at large scales and its comparison with W1'.
G2 Energy sign of the coupling near P and in the transition collar between the ordinary disc and the x-face.
G3 Edge problems: the triangular 1D nonlocal transport system (`c_1`; `e_2`, `e_4`) with its coupling functionals,
   compatible corner jets and the saddle functional. No bordering at P is justified (the coupled frozen problem is
   bijective below threshold, SPEC 3.2).
G4 Compactness: weights improving under the error terms at the faces and at infinity AND a gain in regularity
   (multiplication by a compactly supported smooth function is not compact on `H^s`).
G5 Index: the homotopy from pure transport crosses `s_fast(tau)` (SPEC 3.2); the index must be computed directly in
   F- (formal value 0) or by a homotopy that keeps the inequalities of section 3 and the missing items listed there.
G6 Nonlinear constants `C_B`, `C_V` in these spaces and the residual `eta` in the forcing norm (`h_rem` part plus
   the edge parts).

## 6. Audit record
astra conormal1 (2026-10-20, single model) on revision 1: 1.2 VALID (domain clarification and sharpness argument
added); 1.3, 1.4 NEEDS-FIX ("iff" replaced by a sufficient condition; particular solution, `H_0` and trace hypotheses
added; algebraic correspondence only); 2.1-2.2 NEEDS-FIX (triangular system); 2.4 INVALID as a categorical claim
(rewritten as a design choice); 2.3 and section 3 NEEDS-FIX (false Sobolev inclusion replaced by `b > s`; the
inequalities are a feasibility window, list of missing ingredients added); G1 INVALID for the fixed cutoff
(counterexample recorded); revision 1's section 6 remark that modal Wiener norms cannot carry a transport inverse is
WITHDRAWN (counterexample: `(1 + eps cos x) d_x - 1` is invertible on the Wiener algebra `A(T)` for `|eps| < 1` by a
Neumann series, although its flow is non-affine).
