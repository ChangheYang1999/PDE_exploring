# Taylor-modified velocity operators on power weights at the x-face (gap G1, face part)

Lead note, 2026-10-20T16:44Z; Lemma W1' and the extension discussion added 2026-10-20T16:53Z. Status: EXACT (proofs
below), not yet verified. Notation of notes/conormal_framework.md. Floating sanity check: code/check_W1.py (section 6).
Purpose: gap G1 asks whether the nonlocal coupling `W[h].grad rho` is bounded on the weighted edge spaces, whose
power weights `|y|^{-2b}`, `b in (2.5, 3.406)`, lie far outside the Muckenhoupt range `|2b| < 1` where Riesz
transforms are bounded. This note proves the x-face part: after splitting the first N Taylor coefficients at `y = 0`
(the edge terms), the velocity is bounded on `L^2(|y|^{-2b})` exactly in the window `N - 1/2 < b < N + 1/2`, with
explicit constants and all b-derivatives. The corner (product weights) is not covered (section 5).

## 1. Setting
`L^2_b := L^2(R^2, |y|^{-2b} dx dy)`, `D_0 := C_c^infty(R^2 \ {y = 0})` (dense in `L^2_b` for every real b).
Canonical velocity `U[h] = (-psi_y, psi_x)`, `-Lap psi = d_x h`; Fourier multipliers `U_1: xi eta/|zeta|^2`,
`U_2: -xi^2/|zeta|^2`. Partial Fourier transform in x: `h^(xi, y)`. For `xi != 0` and `h in D_0`
(the decaying solution of `(xi^2 - d_y^2) psi^ = i xi h^` is the canonical one, since the y-Fourier transform of
`e^{-|xi||t|}/(2|xi|)` is `1/(xi^2 + eta^2)`):
  `U_2^(xi, y) = -(|xi|/2) int e^{-|xi||y - y'|} h^(xi, y') dy'`,
  `U_1^(xi, y) = (i xi/2) int sgn(y - y') e^{-|xi||y - y'|} h^(xi, y') dy'`.
Check: for `h^ = e^{i eta y}` the first gives `-xi^2/(xi^2 + eta^2)`, the frozen multiplier `-m` (sign as in the
verified frozen theory).

Edge (Taylor) coefficients. For `h in D_0`, `U_i[h](x, .)` is smooth near `y = 0` and `u_{i,j}(x) := d_y^j U_i(x, 0)/j!`
is given by
  `u_{2,j}^(xi) = -(|xi|^{j+1}/(2 j!)) int (sgn y')^j e^{-|xi||y'|} h^(xi, y') dy'`,
  `u_{1,j}^(xi) = -(i xi |xi|^j/(2 j!)) int (sgn y')^{j+1} e^{-|xi||y'|} h^(xi, y') dy'`.
(For `y' > 0`, `y < y'`: `e^{-|xi||y - y'|} = e^{-|xi| y'} e^{|xi| y}`; for `y' < 0`, `y > y'`: `e^{-|xi||y'|} e^{-|xi| y}`.)
Taylor remainder: `T_N U_i := U_i - sum_{j<N} y^j u_{i,j}(x)`.

## 2. Statement
Lemma W1. Let `N >= 0` be an integer and `N - 1/2 < b < N + 1/2`. For `h in D_0`, `i = 1, 2`:
(a) `||T_N U_i[h]||_{L^2_b} <= C_{N,b} ||h||_{L^2_b}` with
  `C_{N,b} = 2^b + S_A^{1/2} + S_K^{1/2} + sum_{j<N} (S_{B,j}^{1/2} + S_{C,j}^{1/2})`,
  `S_A = 2^{2b-2N} Gamma(2N+2)/(2 (2N+1-2b) N!^2)`, `S_K = 2^{-2b-1}/(2b+1)`,
  `S_{B,j} = 2^{-2b-1} Gamma(2j+2)/((2b-2j-1) j!^2)`, `S_{C,j} = 3 * 2^{2b-1} Gamma(2j+2)/j!^2`.
(b) For `j < N`: `|u_{i,j}^(xi)| <= c_{j,b} |xi|^{j + 1/2 - b} ||h^(xi, .)||_{L^2(|y|^{-2b} dy)}`,
  `c_{j,b} = Gamma(2b+1)^{1/2} 2^{-b-1}/j!`; hence `u_{i,j}` lies in the homogeneous space `dot H^{b - j - 1/2}(R)`
  (positive order, since `j <= N - 1 < b - 1/2`) with norm `<= c_{j,b} ||h||_{L^2_b}`.
(c) The same bounds hold with `d_x^n` applied to both sides, and, with constants `C_{N,b,m}`, with
  `||(y d_y)^m T_N U_i h||_{L^2_b} <= C_{N,b,m} sum_{l <= m} ||(y d_y)^l h||_{L^2_b}`.
Consequently `T_N U_i` and `u_{i,j}` extend continuously to `L^2_b` and to the b-Sobolev spaces `H^{m,n}_b`
(m b-derivatives in y, n ordinary x-derivatives, weight `|y|^{-2b}`), and on these spaces
`U_i[h] = sum_{j<N} y^j u_{i,j} + T_N U_i[h]` is the edge splitting of the velocity.
At the end points `b = N +/- 1/2` the bound (a) fails (logarithmic divergence of `S_A`, resp. `S_{B,N-1}`).

## 3. Proof
Reduction to one dimension. The weight depends only on y, so by Plancherel in x it suffices to bound, uniformly in
`xi != 0`, the operator `f -> T_N (K_xi * f)` on `L^2(R, |y|^{-2b} dy)`, where `K_xi(t) = (|xi|/2) e^{-|xi||t|}` or
`(|xi|/2) sgn(t) e^{-|xi||t|}` (the factors `-1`, `i sgn xi` are unimodular). With `(delta_l f)(y) = f(l y)`:
`K_xi * f = delta_{|xi|}(K_1 * delta_{1/|xi|} f)`, Taylor subtraction at 0 commutes with dilations, and
`||delta_l f||_{L^2_b} = l^{b - 1/2} ||f||_{L^2_b}`. Hence the operator norm does not depend on `xi`; take `|xi| = 1`,
`K(t) = e^{-|t|}/2` or `sgn(t) e^{-|t|}/2`. The operator has kernel
`k_N(y, y') = K(y - y') - sum_{j<N} (y^j/j!) K_j(y')`, `K_j(y') = (sgn y')^j e^{-|y'|}/2`, resp. `-(sgn y')^{j+1} e^{-|y'|}/2`.
Conjugating by the weight, it suffices to bound the kernel `k~(y, y') = |y|^{-b} k_N(y, y') |y'|^b` on `L^2(R)`.
Split `R^2` into A `{|y| <= |y'|/2}`, B `{|y| >= 2|y'|}`, C (the rest, `|y'|/2 < |y| < 2|y'|`).

(A) For `|y| < |y'|` the function `y -> K(y - y')` equals `+/- (1/2) e^{-|y'|} e^{+/- y}`, so Taylor's theorem gives
`|k_N| <= (1/2) e^{-|y'|} |y|^N e^{|y|}/N! <= |y|^N e^{-|y'|/2}/(2 N!)` on A. Hilbert-Schmidt norm squared:
`int dy' |y'|^{2b} e^{-|y'|}/(4 N!^2) int_{|y| <= |y'|/2} |y|^{2N-2b} dy`; the inner integral is finite iff
`b < N + 1/2` and equals `2 (|y'|/2)^{2N+1-2b}/(2N+1-2b)`; the outer then gives `S_A`.

(B) Here `|y - y'| >= |y|/2`, so `|K(y - y')| <= e^{-|y|/2}/2`, and `|K_j(y')| <= e^{-|y'|}/2`. The first part has
Hilbert-Schmidt norm squared `int dy |y|^{-2b} e^{-|y|}/4 int_{|y'| <= |y|/2} |y'|^{2b} dy' = S_K` (needs `b > -1/2`).
The j-th polynomial part: `int dy' |y'|^{2b} e^{-2|y'|}/(4 j!^2) int_{|y| >= 2|y'|} |y|^{2j-2b} dy`; the inner integral is
finite iff `b > j + 1/2` (true for all `j <= N - 1` because `b > N - 1/2`) and equals
`2 (2|y'|)^{2j+1-2b}/(2b-2j-1)`; the outer gives `S_{B,j}`.

(C) Here `|y|^{-b}|y'|^b <= 2^{|b|}`. The convolution part is bounded by `2^b |K(y - y')|`; by the Schur test with
constant test functions its norm is at most `2^b ||K||_{L^1} = 2^b`. The polynomial parts are bounded by
`2^b |y|^j e^{-|y|/2}/(2 j!)` (since `|y'| > |y|/2`); the y'-section of C has measure `3|y|`, so the Hilbert-Schmidt
norm squared is at most `3 * 2^{2b} int |y|^{2j+1} e^{-|y|} dy/(4 j!^2) = S_{C,j}`.

Summing the three regions gives (a). For (b), Cauchy-Schwarz in `y'` with
`int e^{-2|xi||y'|} |y'|^{2b} dy' = 2 Gamma(2b+1) (2|xi|)^{-2b-1}` gives the stated bound.
For (c): `d_x` is the multiplier `i xi` and commutes with everything. For `y d_y`, with distributional derivatives
(the sgn kernel has a unit jump at 0, and `t delta(t) = 0`):
`y d_y (K * f) = (t K') * f + K * ((1 + y d_y) f)`, where `t K'(t) = -(|t|/2) e^{-|t|}`, resp. `-(t/2) e^{-|t|}`, is
again an exponentially decaying kernel that is smooth on each side of 0; Taylor subtraction commutes with `y d_y`
(`(y d_y G)_j = j G_j`). The proof of (a) applies verbatim to `t K'` (with `|t K'(t)| <= e^{-|t|/2}` and one-sided
analyticity), and induction on m gives (c). The dilation reduction is compatible with `y d_y` (dilation invariant).
End points: at `b = N + 1/2` the inner integral in (A) diverges logarithmically for every `y'`, and a test function
concentrated at scale `|y'| ~ 1` with `|y|` ranging over `(e^{-R}, 1)` shows the norm is at least of order
`sqrt(R)`; at `b = N - 1/2` the same happens in (B) for `j = N - 1` at large `|y|`. QED.

## 3a. Frequency-adapted extension of the edge terms (Lemma W1')
The global terms `y^j u_{i,j}(x)` are not localized near the axis. A fixed cutoff `chi(y) y^j u_{i,j}(x)` does NOT give
a bounded splitting: astra conormal1 (Q6) shows `||M h_R - chi(y) y d_y(M h_R)(x,0)||_{L^2_b} >= c R^{b-3/2}` for
`h_R = R^{b-1} F(X/R)` with `||h_R||_{L^2_b}` constant. The mechanism: by (b), `|u^_{i,j}(xi)|` may grow like
`|xi|^{j+1/2-b}` at low frequency, and a fixed cutoff then leaves `y^j u_{i,j}` on `2 < |y| < 1/|xi|` in the remainder.
The extension must be scale adapted.

Lemma W1'. Let `chi` be smooth, even, `0 <= chi <= 1`, `chi = 1` on `[-1, 1]`, `supp chi in [-2, 2]`, and define the
frequency-adapted extension `(E_j u)^(xi, y) := y^j chi(y |xi|) u^(xi)` (i.e. `E_j u = y^j chi(y |D_x|) u`). For
`N - 1/2 < b < N + 1/2` and `h in D_0`:
  `U_i[h] = sum_{j<N} E_j u_{i,j} + T^chi_N U_i[h]`,
  `||T^chi_N U_i[h]||_{L^2_b} <= C'_{N,b} ||h||_{L^2_b}`, `C'_{N,b} = C_{N,b} + sum_{j<N} c_{j,b} (2/(2b - 2j - 1))^{1/2}`,
with `u_{i,j}` bounded into `dot H^{b-j-1/2}(R)` by (b). All three maps commute with the joint dilation
`h -> h(X/R)` up to the factors of the norms, so the counterexample above does not apply. With `C_{N,b,m}` replaced by
analogous constants, the same holds for `(y d_y)^m` and `d_x^n` (since `y d_y [chi(y|xi|) y^j] = [j chi + (t chi')(y|xi|)] y^j`
and `t chi'(t)` is supported in `1 <= |t| <= 2`).
Proof. `T^chi_N U_i h = T_N U_i h + sum_{j<N} (1 - chi(y|D_x|)) y^j u_{i,j}`. The first term is bounded by (a). For the
others, by Plancherel in x and `1 - chi(y|xi|) = 0` for `|y||xi| <= 1`, `0 <= 1 - chi <= 1`:
`||(1 - chi(y|D_x|)) y^j u||_{L^2_b}^2 <= (2 pi)^{-1} int |u^(xi)|^2 int_{|y| > 1/|xi|} |y|^{2j-2b} dy dxi
 = (2/(2b - 2j - 1)) (2 pi)^{-1} int |xi|^{2b-2j-1} |u^(xi)|^2 dxi`, finite since `2j - 2b < -1` for `j <= N - 1`;
by (b) this is `<= (2/(2b-2j-1)) c_{j,b}^2 ||h||_{L^2_b}^2`. QED.
Remarks. (1) `E_j u` is not in `L^2_b` (`|y|^{2j-2b}` is not integrable at 0 for `j < b - 1/2`): it is the edge part,
measured by `||u||_{dot H^{b-j-1/2}}`. (2) On a fixed bounded x-range the difference between `E_j` and the
fixed-cutoff extension is a high/low frequency issue only; on the global face the edge spaces are homogeneous, and the
low frequencies must be matched to the conic structure at infinity (the conic extension `y^j chi(y/<x>) u(x)`), which is
NOT proved here. (3) For the extension of the solution's own edge components (`h = E_1 c_1 + ...`, conormal note 2.3) the
same construction removes the trace-loss problem of the fixed extension (an `H^s` function has `d_y h(.,0)` only in
`H^{s-3/2}`, while `chi(y) y c(x)` in `H^s` needs `c in H^s`) is the natural candidate: the expected statement
(an `H^s` function minus its frequency-adapted y-jets of order `< s - 1/2` lies in the weighted remainder space with
`b < s`) is of Hardy type but is NOT proved here.

## 4. Consequences for the coupling near the x-axis (EXACT bookkeeping)
For odd-in-y h in the face space (`b in (2.5, 3.5)`, `N = 3`): parity gives `u_{2,0} = u_{2,2} = 0`, `u_{1,1} = 0`, so
`U_1 = u_{1,0}(x) + y^2 u_{1,2}(x) + T_3 U_1`, `U_2 = y u_{2,1}(x) + T_3 U_2`. With `rho_x = y rho_xy(x,0) + O(y^3)`,
`rho_y = rho_y(x,0) + O(y^2)`:
`U[h].grad rho = y [u_{1,0} rho_xy(x,0) + u_{2,1} rho_y(x,0)] + y^3 (...) + (T_3 U).grad rho`.
The y-coefficient is the edge forcing of the `c_1` equation (conormal note 2.2, audited there as correct when the
derivatives exist). With the extensions of Lemma W1' in place of the global terms, the edge forcing is carried by
`E_0, E_1` and the remainder by `T^chi_3 U`. The `y^3` terms are cutoff-times-`y^3` functions, which belong to `L^2_b`
near the axis iff `b < 3.5`; the remainder term is in `L^2_b` by Lemma W1' since `grad rho` is bounded near the axis. So on the x-face collar the coupling maps the remainder space
to (edge forcing) + (remainder forcing) boundedly; its edge part is the nonlocal functional
`h -> u_{1,0} rho_xy(.,0) + u_{2,1} rho_y(., 0)`, which by (b) gains `b - 1/2 > 2` derivatives in x relative to h at
high x-frequency (`dot H^{b-1/2}`, `dot H^{b-3/2}`). This gain is what makes the edge equation for `c_1` a transport
ODE with a smoothing nonlocal forcing.
Low x-frequencies are not controlled by (b) (homogeneous norms); in the global space they are controlled by the decay
of h at infinity, which is the far-field part of the problem.

## 5. What is not covered
- Corner: product weights `|x|^{-2a}|y|^{-2b}` with Taylor subtraction in both variables (`a in (4.6, 6.5)`). The
  partial-Fourier reduction does not apply. Proposed route: Mellin transform in `r` (the velocity is homogeneous of
  degree 0, the product weight homogeneous of degree `-2(a+b)`), reducing to an angular operator family on `(0, pi/2)`
  whose behaviour at the two end points is the one-dimensional Taylor-modified problem of section 3 in each variable;
  the corner Taylor monomials `x^i y^j` are the Mellin poles.
- y-face: the same lemma with x and y exchanged (partial Fourier in y, weight `|x|^{-2a}`); `U_2` then has the local
  part `-h` (the kernel of `d_x^2 (xi^2 - d_x^2)^{-1}` contains `-delta`), whose Taylor coefficients vanish on `D_0`.
  This is routine but not written out.
- The Hoelder version (needed if the low T2N norm is Hoelder) is not addressed.
- The conic extension at large scales (Remark (2) of 3a) and the transition to the far-field weight.

## 6. Floating sanity check (code/check_W1.py; NOT rigorous)
Nystrom discretization of `f -> T_3(K * f)` at `|xi| = 1` on `L^2(|y|^{-2b})`, log-spaced nodes on
`e^{-14} <= |y| <= 80` (2800 nodes), operator 2-norm:
| b | 2.51 | 2.55 | 2.70 | 3.00 | 3.30 | 3.45 | 3.49 |
|---|---|---|---|---|---|---|---|
| even kernel | 1.476 | 1.414 | 1.250 | 1.110 | 1.404 | 2.207 | 2.795 |
| sgn kernel | 1.274 | 1.195 | 0.975 | 0.773 | 1.165 | 2.065 | 2.683 |
Bounded in the window, increasing towards the end points (the logarithmic divergence is slow and truncated by the
finite node range, in particular at `b -> 2.5`, whose divergence sits at large `|y|`). The analytic constants
(`C_{3,2.6} ~ 79`, `C_{3,3.4} ~ 151`) are crude upper bounds, consistent with these values.
